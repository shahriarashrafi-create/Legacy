package com.shahriar.growth

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.shahriar.growth.data.*
import kotlinx.coroutines.launch

fun roleLabel(role:String)=if(role=="leader")"راهبر" else "عضو"
@Composable fun NetworkScreen(modifier:Modifier,db:AppDatabase,selfName:String,tasks:List<Task>,today:Long,onOpenTask:(String)->Unit) {
    val people by db.networkDao().observe().collectAsState(initial=emptyList())
    val owners by db.networkDao().owners().collectAsState(initial=emptyList())
    val engine=remember(db){NetworkEngine(db)};val scope=rememberCoroutineScope()
    var selected by rememberSaveable{mutableStateOf<String?>(null)}
    var editing by rememberSaveable{mutableStateOf<String?>(null)}
    var tree by rememberSaveable{mutableStateOf(false)}
    var treeRoot by rememberSaveable{mutableStateOf<String?>(null)}
    var search by rememberSaveable{mutableStateOf("")}
    var role by rememberSaveable{mutableStateOf("all")}
    var status by rememberSaveable{mutableStateOf("all")}
    var branch by rememberSaveable{mutableStateOf("")}
    var archive by rememberSaveable{mutableStateOf(false)}
    var busy by remember{mutableStateOf(false)};var error by remember{mutableStateOf("")}
    var confirmArchive by remember{mutableStateOf<Person?>(null)}
    fun change(action:suspend()->Unit) {if(busy)return;busy=true;error="";scope.launch{try{action()}catch(e:Exception){if(e is kotlinx.coroutines.CancellationException)throw e;error=if(e is IllegalArgumentException)e.message?:"تغییر انجام نشد" else "ذخیره انجام نشد؛ دوباره تلاش کن."}finally{busy=false}}}
    BackHandler(enabled=editing==null && (selected!=null || tree)){if(selected!=null)selected=null else tree=false}
    val person=people.firstOrNull{it.id==selected}
    Column(modifier.fillMaxSize()) {
        if(error.isNotEmpty()) Text(error,Modifier.padding(16.dp),color=MaterialTheme.colorScheme.error)
        if(person!=null) {
            val history by remember(person.id){db.networkDao().history(person.id)}.collectAsState(initial=emptyList())
            PersonProfile(person,people,tasks.filter{t->owners.any{it.taskId==t.id && it.personId==person.id}},history,today,busy,
                onBack={selected=null},onEdit={editing=person.id;error=""},onArchive={confirmArchive=person},
                onTree={treeRoot=person.id;tree=true;selected=null},onOpenPerson={selected=it},onOpenTask=onOpenTask)
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal=16.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                Text("شبکه من",style=MaterialTheme.typography.headlineSmall)
                Button(onClick={editing="new";error=""},enabled=!busy){Icon(Icons.Outlined.Add,null);Text("فرد جدید")}
            }
            Row(Modifier.padding(horizontal=16.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                FilterChip(!tree,{tree=false},label={Text("فهرست افراد")},leadingIcon={Icon(Icons.Outlined.People,null)})
                FilterChip(tree,{tree=true},label={Text("درختواره")},leadingIcon={Icon(Icons.Outlined.AccountTree,null)})
            }
            if(tree) NetworkTree(people,selfName,treeRoot,onRoot={treeRoot=it},onOpen={selected=it})
            else {
                val filtered=people.filter{it.archived==archive && (role=="all" || it.role==role) && (status=="all" || it.status==status) && (branch.isBlank() || normalizeText(it.branch).contains(normalizeText(branch.trim()))) && matchesPerson(it,search)}
                LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
                    item{OutlinedTextField(search,{search=it},label={Text("نام، تلفن، شهر یا شاخه")},singleLine=true,modifier=Modifier.fillMaxWidth())}
                    item{Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                        listOf("all" to "همه نقش‌ها","member" to "عضو","leader" to "راهبر").forEach{(v,l)->FilterChip(role==v,{role=v},label={Text(l)})}
                        FilterChip(archive,{archive=!archive},label={Text("بایگانی")})
                    }}
                    item{Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
                        listOf("all" to "همه وضعیت‌ها","active" to "فعال","inactive" to "غیرفعال").forEach{(v,l)->FilterChip(status==v,{status=v},label={Text(l)})}
                    }}
                    item{OutlinedTextField(branch,{branch=it},label={Text("فیلتر شاخه (اختیاری)")},singleLine=true,modifier=Modifier.fillMaxWidth())}
                    item{Text("${faNumber(filtered.size)} فرد · ${faNumber(people.count{!it.archived})} عضو در شبکه",style=MaterialTheme.typography.bodySmall)}
                    if(filtered.isEmpty())item{Text(if(people.isEmpty())"اولین فرد شبکه‌ات را اضافه کن؛ بالاسری او می‌تواند خودت باشی." else "فردی با این فیلترها پیدا نشد."); if(people.isNotEmpty())TextButton(onClick={search="";role="all";status="all";branch="";archive=false}){Text("پاک‌کردن فیلترها")}}
                    items(filtered,key={it.id}){p->PersonRow(p,people,onClick={selected=p.id})}
                }
            }
        }
    }
    if(editing!=null)key(editing){PersonEditor(people.firstOrNull{it.id==editing},people,selfName,busy,error,onDismiss={if(!busy){editing=null;error=""}},onSave={p->change{engine.save(p);editing=null;selected=p.id}})}
    confirmArchive?.let{p->AlertDialog(onDismissRequest={if(!busy)confirmArchive=null},title={Text(if(p.archived)"بازگردانی فرد" else "بایگانی فرد")},text={Text(if(p.archived)"این فرد به شبکه برگردد؟ بالاسری باید در شبکه باشد." else "سوابق و کارها حفظ می‌شوند. اگر فرد مستقیم دارد، ابتدا آن‌ها را منتقل یا بایگانی کن.")},confirmButton={TextButton(enabled=!busy,onClick={confirmArchive=null;change{engine.archive(p.id,!p.archived)}}){Text("تأیید")}},dismissButton={TextButton(onClick={confirmArchive=null},enabled=!busy){Text("انصراف")}})}
}
@Composable private fun PersonRow(p:Person,people:List<Person>,onClick:()->Unit) {
    Card(onClick=onClick,modifier=Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){
        Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){
            Icon(if(p.role=="leader")Icons.Outlined.StarOutline else Icons.Outlined.Person,null,tint=MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){
                Text(p.name,style=MaterialTheme.typography.titleMedium)
                Text(roleLabel(p.role)+" · "+if(p.status=="active")"فعال" else "غیرفعال",style=MaterialTheme.typography.bodySmall)
                Text("بالاسری: "+(people.firstOrNull{it.id==p.parentId}?.name?:"خودم")+(if(p.branch.isBlank())"" else " · ${p.branch}"),style=MaterialTheme.typography.bodySmall)
            };Icon(Icons.Outlined.ChevronLeft,null)
        }
    }
}
@Composable private fun PersonProfile(p:Person,people:List<Person>,tasks:List<Task>,events:List<PersonEvent>,today:Long,busy:Boolean,onBack:()->Unit,onEdit:()->Unit,onArchive:()->Unit,onTree:()->Unit,onOpenPerson:(String)->Unit,onOpenTask:(String)->Unit) {
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{TextButton(onClick=onBack){Text("بازگشت به شبکه")}}
        item{Text(p.name,style=MaterialTheme.typography.headlineSmall);Text(roleLabel(p.role)+" · "+(if(p.status=="active")"فعال" else "غیرفعال")+(if(p.archived)" · بایگانی" else ""))}
        item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            Button(onClick=onEdit,enabled=!busy && !p.archived){Text("ویرایش")}
            OutlinedButton(onClick=onArchive,enabled=!busy){Text(if(p.archived)"بازگردانی" else "بایگانی")}
        }}
        item{Text("تلفن: ${p.phone.ifBlank{"ثبت نشده"}}\nشهر: ${p.city.ifBlank{"ثبت نشده"}}\nشاخه: ${p.branch.ifBlank{"بدون برچسب"}}")}
        item{val parent=people.firstOrNull{it.id==p.parentId};TextButton(onClick={parent?.let{onOpenPerson(it.id)}},enabled=parent!=null){Text("بالاسری: ${parent?.name?:"خودم"}")}}
        item{val direct=people.count{it.parentId==p.id && !it.archived};val total=descendants(p.id,people).count{id->people.any{it.id==id && !it.archived}};Text("${faNumber(direct)} فرد مستقیم · ${faNumber(total)} نفر در زیرمجموعه")}
        item{OutlinedButton(onClick=onTree,enabled=!p.archived){Icon(Icons.Outlined.AccountTree,null);Text("مشاهده شاخه در درختواره")}}
        if(p.note.isNotBlank())item{Card(Modifier.fillMaxWidth()){Text(p.note,Modifier.padding(16.dp))}}
        item{Text("افراد مستقیم",style=MaterialTheme.typography.titleMedium)}
        items(people.filter{it.parentId==p.id && !it.archived},key={"child"+it.id}){child->PersonRow(child,people){onOpenPerson(child.id)}}
        item{Text("کارهای مرتبط · ${faNumber(tasks.count{!it.done && !it.archived})} باز",style=MaterialTheme.typography.titleMedium);Text("برای اتصال کار، آن را باز کن و در بخش فرد مرتبط انتخابش کن.",style=MaterialTheme.typography.bodySmall)}
        items(tasks.sortedBy{it.done},key={"task"+it.id}){t->Card(onClick={onOpenTask(t.id)},modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text(t.title);Text(if(t.archived)"بایگانی" else if(t.done)"انجام‌شده" else dueLabel(t,today),style=MaterialTheme.typography.bodySmall)}}}
        item{Text("تاریخچه تغییرات",style=MaterialTheme.typography.titleMedium)}
        items(events,key={"event"+it.id}){e->Text(e.text+" · "+persianDay(java.time.Instant.ofEpochMilli(e.at).atZone(java.time.ZoneId.systemDefault()).toLocalDate().toEpochDay()),style=MaterialTheme.typography.bodySmall)}
    }
}
@Composable private fun PersonEditor(old:Person?,people:List<Person>,selfName:String,busy:Boolean,error:String,onDismiss:()->Unit,onSave:(Person)->Unit) {
    val id=rememberSaveable{old?.id?:java.util.UUID.randomUUID().toString()}
    var name by rememberSaveable{mutableStateOf(old?.name?:"")};var phone by rememberSaveable{mutableStateOf(old?.phone?:"")}
    var city by rememberSaveable{mutableStateOf(old?.city?:"")};var branch by rememberSaveable{mutableStateOf(old?.branch?:"")}
    var note by rememberSaveable{mutableStateOf(old?.note?:"")};var role by rememberSaveable{mutableStateOf(old?.role?:"member")}
    var status by rememberSaveable{mutableStateOf(old?.status?:"active")};var parent by rememberSaveable{mutableStateOf(old?.parentId)}
    var picking by rememberSaveable{mutableStateOf(false)}
    Dialog(onDismissRequest=onDismiss,properties=DialogProperties(usePlatformDefaultWidth=false,dismissOnBackPress=!busy,dismissOnClickOutside=!busy)){
        Surface(Modifier.fillMaxSize().imePadding(),color=MaterialTheme.colorScheme.background){Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
            Text(if(old==null)"فرد جدید" else "ویرایش فرد",style=MaterialTheme.typography.headlineSmall)
            if(error.isNotEmpty())Text(error,color=MaterialTheme.colorScheme.error)
            OutlinedTextField(name,{if(it.length<=80)name=it},label={Text("نام *")},singleLine=true,modifier=Modifier.fillMaxWidth(),enabled=!busy)
            OutlinedTextField(phone,{if(it.length<=30)phone=it},label={Text("تلفن (اختیاری)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Phone),singleLine=true,modifier=Modifier.fillMaxWidth(),enabled=!busy)
            OutlinedTextField(city,{if(it.length<=80)city=it},label={Text("شهر")},singleLine=true,modifier=Modifier.fillMaxWidth(),enabled=!busy)
            OutlinedTextField(branch,{if(it.length<=80)branch=it},label={Text("برچسب شاخه")},singleLine=true,modifier=Modifier.fillMaxWidth(),enabled=!busy)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("member","leader").forEach{v->FilterChip(role==v,{role=v},enabled=!busy,label={Text(roleLabel(v))})}}
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("active" to "فعال","inactive" to "غیرفعال").forEach{(v,l)->FilterChip(status==v,{status=v},enabled=!busy,label={Text(l)})}}
            OutlinedButton(onClick={picking=true},enabled=!busy){Text("بالاسری: "+(people.firstOrNull{it.id==parent}?.name?:"خودم · $selfName"))}
            Text("تغییر بالاسری، کل شاخه زیر این فرد را همراه او جابه‌جا می‌کند.",style=MaterialTheme.typography.bodySmall)
            OutlinedTextField(note,{if(it.length<=4000)note=it},label={Text("یادداشت معرفی")},modifier=Modifier.fillMaxWidth(),enabled=!busy,minLines=3)
            if(phone.isNotBlank() && people.any{it.id!=id && normalizeText(it.phone).trim()==normalizeText(phone).trim()})Text("این تلفن برای فرد دیگری هم ثبت شده است؛ قبل از ذخیره بررسی کن.",color=MaterialTheme.colorScheme.error)
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){
                Button(enabled=!busy && name.isNotBlank(),onClick={onSave(Person(id=id,name=name,phone=phone,city=city,branch=branch,note=note,role=role,status=status,parentId=parent))}){Text(if(busy)"در حال ذخیره…" else "ذخیره")}
                TextButton(onClick=onDismiss,enabled=!busy){Text("انصراف")}
            }
        }}
    }
    if(picking) PersonPicker("انتخاب بالاسری",people.filter{validParent(id,it.id,people)},parent,"خودم · $selfName",onDismiss={picking=false},onPick={parent=it;picking=false})
}
@Composable fun PersonPicker(title:String,people:List<Person>,selected:String?,noneLabel:String,onDismiss:()->Unit,onPick:(String?)->Unit) {
    var query by rememberSaveable{mutableStateOf("")}
    Dialog(onDismissRequest=onDismiss){Surface(shape=RoundedCornerShape(20.dp)){
        Column(Modifier.fillMaxWidth().heightIn(max=520.dp).padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            Text(title,style=MaterialTheme.typography.titleMedium)
            OutlinedTextField(query,{query=it},label={Text("جست‌وجو")},singleLine=true,modifier=Modifier.fillMaxWidth())
            LazyColumn(Modifier.weight(1f,false)){
                item{TextButton(onClick={onPick(null)}){Text((if(selected==null)"✓ " else "")+noneLabel)}}
                items(people.filter{matchesPerson(it,query)},key={it.id}){p->TextButton(onClick={onPick(p.id)},modifier=Modifier.fillMaxWidth()){Text((if(selected==p.id)"✓ " else "")+p.name)}}
            }
            TextButton(onClick=onDismiss){Text("بستن")}
        }
    }}
}
@Composable fun TaskPersonPanel(task:Task,people:List<Person>,owners:List<TaskOwner>,busy:Boolean,onAssign:(String?)->Unit) {
    var picking by remember{mutableStateOf(false)}
    val person=people.firstOrNull{p->owners.any{it.taskId==task.id && it.personId==p.id}}
    OutlinedButton(onClick={picking=true},enabled=!busy,modifier=Modifier.fillMaxWidth()){Text("فرد مرتبط: "+(person?.let{it.name+if(it.archived)" (بایگانی)" else ""}?:"کار شخصی من"))}
    if(picking)PersonPicker("ارتباط این کار با فرد",people.filter{!it.archived},person?.id,"کار شخصی من",onDismiss={picking=false},onPick={onAssign(it);picking=false})
}
