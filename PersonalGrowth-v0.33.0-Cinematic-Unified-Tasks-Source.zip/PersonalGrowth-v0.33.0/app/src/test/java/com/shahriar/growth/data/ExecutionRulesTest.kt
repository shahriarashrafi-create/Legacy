package com.shahriar.growth.data
import org.junit.Assert.*
import org.junit.Test
class ExecutionRulesTest {
    private fun session(state:String="running")=FocusSession(taskId="a",durationMs=60000,accruedMs=10000,anchorWall=100000,anchorElapsed=50000,boot=3,state=state)
    @Test fun monotonicTimeSurvivesWallClockChange(){assertEquals(20000,focusSpent(session(),ClockReading(1,60000,3)))}
    @Test fun pauseDoesNotAccumulate(){assertEquals(10000,focusSpent(session("paused"),ClockReading(900000,900000,3)))}
    @Test fun recoveryAfterRebootUsesWallClock(){assertEquals(25000,focusSpent(session(),ClockReading(115000,2000,4)))}
    @Test fun waitingDoesNotAccumulate(){assertEquals(10000,focusSpent(session("waiting"),ClockReading(900000,900000,3)))}
    @Test fun timerNeverExceedsDuration(){assertEquals(60000,focusSpent(session(),ClockReading(900000,900000,3)))}
    @Test fun clockGoingBackDoesNotProduceNegative(){assertEquals(10000,focusSpent(session(),ClockReading(90000,2000,4)))}
    @Test fun prerequisitesNeverBlockUnifiedJourney() {
        val step=Task(id="a",title="step",dueDay=100,stepNumber=1)
        val legacyEdges=listOf(Prerequisite("a","missing"))
        assertEquals(step,nextAction(listOf(step),null,100,legacyEdges))
    }
    @Test fun focusAndDailyProposalHaveNoStageGate() {
        val step=Task(id="a",title="step",stepNumber=1)
        assertEquals(step,nextAction(listOf(step),null,100,listOf(Prerequisite("a","b"))))
    }
    @Test fun resetKeepsPreviousFocusSeparateFromTimer(){val s=session().copy(previousMs=45000);assertEquals(20000,focusSpent(s,ClockReading(110000,60000,3)));assertEquals(65000,s.previousMs+focusSpent(s,ClockReading(110000,60000,3)))}
}
