package com.shahriar.growth.data

import org.junit.Assert.*
import org.junit.Test

/** One continuous task journey, without old groups or prerequisite stage gates. */
class TaskRulesTest {
    private val today = 20000L
    @Test fun everyOpenTaskIsEligibleRegardlessOfDueDate() {
        val future = Task(title="future",dueDay=today+30,stepNumber=3)
        val undated = Task(title="undated",stepNumber=1)
        val archived = Task(title="archive",archived=true,stepNumber=0)
        assertEquals(undated,nextAction(listOf(future,undated,archived),null,today))
    }
    @Test fun lowestUnresolvedStepIsHighlightedRegardlessOfInputOrder() {
        val third = Task(title="third",stepNumber=3)
        val first = Task(title="first",stepNumber=1)
        val second = Task(title="second",stepNumber=2)
        assertEquals(first,nextAction(listOf(third,second,first),null,today))
    }
    @Test fun successFailureAndArchivesAreNotProposedAgain() {
        val finished=Task(title="done",done=true,stepNumber=1)
        val failed=Task(title="failed",failed=true,stepNumber=2)
        val archive=Task(title="archive",archived=true,stepNumber=3)
        assertNull(nextAction(listOf(finished,failed,archive),null,today))
    }
    @Test fun statusesSortBelowOpenTasksKeepingOriginalStepNumbers() {
        val tasks=listOf(Task(title="open3",stepNumber=3),Task(title="fail2",failed=true,stepNumber=2),
            Task(title="done1",done=true,stepNumber=1),Task(title="open4",stepNumber=4))
        assertEquals(listOf(1L,2L,3L,4L),taskJourneyOrder(tasks).map { it.stepNumber })
        assertTrue(taskJourneyOrder(tasks).take(2).all { it.done || it.failed })
    }
    @Test fun completedOutOfOrderNeverRenumbersSteps() {
        val third=Task(title="third",stepNumber=3)
        val second=Task(title="second",stepNumber=2)
        val first=Task(title="first",stepNumber=1)
        val changed=third.copy(done=true)
        assertEquals(listOf(3L,1L,2L),taskJourneyOrder(listOf(first,changed,second)).map { it.stepNumber })
        assertEquals(first,nextAction(listOf(first,changed,second),null,today))
    }
    @Test fun openFiltersExcludeFailedTasks() {
        val failed=Task(title="fail",failed=true,dueDay=today)
        assertFalse(taskMatches(failed,0,today))
        assertFalse(taskMatches(failed,6,today))
    }
    @Test fun archivedFilterIsSeparate() {
        val t=Task(title="archive",dueDay=today,done=true,archived=true)
        assertFalse(taskMatches(t,4,today));assertTrue(taskMatches(t,5,today))
    }
    @Test fun arabicAndPersianSearchMatch() {
        assertEquals(normalizeText("علي ١٢"),normalizeText("علی ۱۲"))
    }
}
