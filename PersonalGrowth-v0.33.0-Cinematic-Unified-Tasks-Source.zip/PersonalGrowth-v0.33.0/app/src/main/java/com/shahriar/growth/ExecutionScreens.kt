package com.shahriar.growth

import androidx.compose.foundation.Canvas
import androidx.activity.compose.BackHandler
import kotlinx.coroutines.delay
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.shahriar.growth.data.*

@Composable fun SubtaskPanel(subtasks:List<Subtask>,frozen:Boolean,onCheck:(Subtask,Boolean)->Unit,onAdd:(String,Boolean,()->Unit)->Unit,onRemove:(Subtask)->Unit){
    var title by rememberSaveable{mutableStateOf("")};var required by rememberSaveable{mutableStateOf(true)}
    Text("زیرکارها",style=MaterialTheme.typography.titleMedium)
    subtasks.forEach { sub->Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Checkbox(sub.checked,{onCheck(sub,it)});Column(Modifier.weight(1f)){Text(sub.title);Text(if(sub.required)"اجباری" else "اختیاری",style=MaterialTheme.typography.bodySmall)};if(!frozen)IconButton(onClick={onRemove(sub)}){Icon(Icons.Outlined.Close,"حذف زیرکار")}} }
    if(frozen)Text("تا پایان جلسه، ساختار زیرکارها ثابت است؛ تیک‌ها قابل تغییرند.",style=MaterialTheme.typography.bodySmall)
    else {
        OutlinedTextField(title,{title=it},label={Text("زیرکار جدید")},modifier=Modifier.fillMaxWidth())
        Row(verticalAlignment=Alignment.CenterVertically){Checkbox(required,{required=it});Text("اجباری");Spacer(Modifier.weight(1f));TextButton(enabled=title.isNotBlank(),onClick={onAdd(title,required){title=""}}){Text("افزودن")}}
    }
}
@Composable fun FocusScreen(modifier:Modifier,task:Task?,session:FocusSession?,subtasks:List<Subtask>,clock:ClockReading,busy:Boolean,error:String,onBack:(String)->Unit,onToggle:()->Unit,onReset:(String)->Unit,onClose:(String)->Unit,onFinish:(Boolean,String)->Unit,onNote:(String)->Unit,onCheck:(Subtask,Boolean)->Unit,musicEnabled:Boolean,onMusic:(Boolean)->Unit,endSound:Boolean,onEndSound:(Boolean)->Unit){
    var confirm by remember{mutableStateOf("")};var note by rememberSaveable(session?.id){mutableStateOf(session?.note?:"")}
    BackHandler(enabled=!busy){onBack(note)}
    LaunchedEffect(note){delay(500);if(session!=null && note!=session.note)onNote(note)}
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp),horizontalAlignment=Alignment.CenterHorizontally){
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){TextButton(onClick={onBack(note)}){Text("بازگشت")};Text("تمرکز",style=MaterialTheme.typography.titleLarge)}
        if(session==null){Text("جلسه باز ندارید.");return@Column}
        Text(task?.title?:"کار",style=MaterialTheme.typography.headlineSmall)
        Text(when(session.state){"paused"->"مکث‌شده";"waiting"->"زمان تمام شد؛ نتیجه را ثبت کن";else->"در حال اجرا"},color=MaterialTheme.colorScheme.primary)
        val spent=focusSpent(session,clock);val remaining=((session.durationMs-spent+999)/1000).coerceAtLeast(0)
        Box(Modifier.size(210.dp),contentAlignment=Alignment.Center){CircularProgressIndicator(progress={spent.toFloat()/session.durationMs},modifier=Modifier.fillMaxSize(),strokeWidth=7.dp);Column(horizontalAlignment=Alignment.CenterHorizontally){Text(faNumber("%02d:%02d".format(java.util.Locale.ROOT,remaining/60,remaining%60)),fontSize=38.sp,fontWeight=FontWeight.Medium);Text("تمرکز این تلاش ${faNumber((session.previousMs+spent)/60000)} دقیقه",style=MaterialTheme.typography.bodySmall)}}
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){if(session.state!="waiting")Button(enabled=!busy,onClick=onToggle){Text(if(session.state=="paused")"ادامه" else "مکث")};OutlinedButton(enabled=!busy,onClick={confirm="reset"}){Text("شروع دوباره ساعت")}}
        Row(verticalAlignment=Alignment.CenterVertically){Switch(musicEnabled,{onMusic(it)});Text("صدای محیط ملایم")}
        Row(verticalAlignment=Alignment.CenterVertically){Switch(endSound,onEndSound);Text("صدای پایان تایمر")}
        Text("نوار، زمان را نشان می‌دهد؛ موفقیت با ثبت نتیجه مشخص می‌شود.",style=MaterialTheme.typography.bodySmall)
        Column(Modifier.fillMaxWidth()){SubtaskPanel(subtasks,true,onCheck,{_,_,_->},{})}
        OutlinedTextField(note,{note=it},label={Text("یادداشت این جلسه")},modifier=Modifier.fillMaxWidth(),minLines=2)
        TextButton(enabled=!busy,onClick={onNote(note)}){Text("ذخیره یادداشت")}
        if(error.isNotEmpty())Text(error,color=MaterialTheme.colorScheme.error)
        Button(enabled=!busy && subtasks.none{it.required && !it.checked},onClick={onFinish(true,note)},modifier=Modifier.fillMaxWidth()){Text("انجام شد")}
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){OutlinedButton(enabled=!busy,onClick={confirm="fail"}){Text("ناموفق")};TextButton(enabled=!busy,onClick={confirm="close"}){Text("بازگشت به آماده")}}
    }
    if(confirm.isNotEmpty())AlertDialog(onDismissRequest={confirm=""},title={Text("تأیید")},text={Text(when(confirm){"reset"->"فقط ساعت از ابتدا و در حالت مکث شروع شود؟ یادداشت و تیک‌ها حفظ می‌شوند.";"fail"->"این تلاش ناموفق ثبت شود؟";else->"جلسه بدون نتیجه بسته شود؟ یادداشت، زمان این تلاش و تیک‌ها حفظ می‌شوند."})},confirmButton={TextButton(onClick={when(confirm){"reset"->onReset(note);"fail"->onFinish(false,note);else->onClose(note)};confirm=""}){Text("تأیید")}},dismissButton={TextButton(onClick={confirm=""}){Text("انصراف")}})
}
