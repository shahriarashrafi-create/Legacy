package com.shahriar.growth

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Route
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.shahriar.growth.data.Task
import com.shahriar.growth.data.journeyItemOnLeft
import com.shahriar.growth.data.taskJourneyOrder

private val TaskBlue = Color(0xFF355CDE)
private val TaskInk = Color(0xFF17223B)
private val TaskOpen = Color.White
private val TaskSuggested = Color(0xFFDCE8FF)
private val TaskSuccess = Color(0xFFE4F5E9)
private val TaskFailure = Color(0xFFFCE8E8)
private val StrokeUpcoming = Color(0xFFA7BFEF)
private val StrokeSuccess = Color(0xFF78BD97)
private val StrokeFailure = Color(0xFFDD929D)

/**
 * One unified task journey, not a roadmap above a second list.
 *
 * The ascending screen order is: resolved tasks in permanent step-number order,
 * followed by unresolved tasks in permanent step-number order. With reverseLayout,
 * resolved history is physically BELOW the blue suggested step and is available
 * by scrolling down. The physical side of a card depends on this DISPLAY index,
 * rather than the immutable step number, so an early completion cannot break zigzag.
 */
@Composable
fun TaskJourneyScreen(
    modifier: Modifier,
    tasks: List<Task>,
    listState: LazyListState,
    onNew: () -> Unit,
    onOpen: (String) -> Unit
) {
    val reduceMotion = rememberReducedMotion()
    val dark = MaterialTheme.colorScheme.background.luminance() < .45f
    val ordered = remember(tasks) { taskJourneyOrder(tasks) }
    val firstOpen = ordered.indexOfFirst { !it.done && !it.failed }
    val recommendedId = ordered.getOrNull(firstOpen)?.id
    val orderIds = ordered.map { it.id }

    // The bottom row is a glimpse of recent resolved history (when it exists),
    // with the recommended blue step immediately above and plainly visible.
    // This deliberately avoids scrollToItem(firstOpen) which hid all resolved
    // history below the viewport and made completed cards seem deleted.
    LaunchedEffect(orderIds, recommendedId) {
        if (ordered.isNotEmpty()) {
            val target = if (firstOpen >= 0) (firstOpen - 1).coerceAtLeast(0)
                else (ordered.lastIndex - 1).coerceAtLeast(0)
            if (reduceMotion) listState.scrollToItem(target)
            else listState.animateScrollToItem(target)
        }
    }

    Box(modifier.fillMaxSize()) {
        if (ordered.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(horizontal = 24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Outlined.Route, contentDescription = null,
                    tint = TaskBlue, modifier = Modifier.size(56.dp))
                Spacer(Modifier.height(14.dp))
                Text("اولین قدم مسیرت را بساز",
                    color = MaterialTheme.colorScheme.onBackground,
                    style = MaterialTheme.typography.titleMedium)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(), state = listState, reverseLayout = true,
                contentPadding = PaddingValues(start = 14.dp, end = 14.dp,
                    bottom = 38.dp, top = 74.dp)
            ) {
                itemsIndexed(ordered, key = { _, task -> task.id }) { index, task ->
                    val placement = if (reduceMotion) Modifier else Modifier.animateItem()
                    JourneyCard(
                        modifier = placement,
                        task = task,
                        displayIndex = index,
                        selected = task.id == recommendedId,
                        below = ordered.getOrNull(index - 1),
                        above = ordered.getOrNull(index + 1),
                        dark = dark,
                        reduceMotion = reduceMotion,
                        onClick = { onOpen(task.id) }
                    )
                }
            }
        }
        // Physical top-left in RTL is Alignment.TopEnd. No middle toolbar,
        // percentage, filter or duplicate list; only the small fixed add button.
        Surface(
            onClick = onNew,
            modifier = Modifier.align(Alignment.TopEnd)
                .padding(end = 16.dp, top = 10.dp).size(40.dp),
            shape = CircleShape,
            color = if (dark) Color(0xFF263E69) else Color(0xFFE9F0FE),
            shadowElevation = 3.dp,
            border = BorderStroke(1.dp,
                if (dark) Color(0xFF52709D) else Color(0xFFC9D9FA))
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Add, contentDescription = "افزودن کار جدید",
                    tint = if (dark) Color(0xFFD6E4FF) else TaskBlue,
                    modifier = Modifier.size(22.dp))
            }
        }
    }
}

private fun journeyStrokeColor(task: Task): Color = when {
    task.done -> StrokeSuccess
    task.failed -> StrokeFailure
    else -> StrokeUpcoming
}

/** Draw one softly glowing gradient stroke; half-segments meet at the same
 * interpolated color and at a vertical tangent on their shared row boundary.
 * This avoids kinks at either end even as visual order changes.
 */
private fun DrawScope.drawJourneyStroke(path: Path, from: Color, to: Color,
                                       startY: Float, endY: Float) {
    val ink = Brush.verticalGradient(listOf(from, to), startY = startY, endY = endY)
    drawPath(path, brush = ink, alpha = 0.14f,
        style = Stroke(width = 11.dp.toPx(), cap = StrokeCap.Round))
    drawPath(path, brush = ink,
        style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round))
}

@Composable
private fun JourneyCard(
    modifier: Modifier,
    task: Task,
    displayIndex: Int,
    selected: Boolean,
    below: Task?,
    above: Task?,
    dark: Boolean,
    reduceMotion: Boolean,
    onClick: () -> Unit
) {
    // A separate physical side calculation is intentional: task.stepNumber is
    // immutable and may have gaps after nonsequential completion or archiving.
    val left = journeyItemOnLeft(displayIndex)
    val face by animateColorAsState(
        targetValue = when {
            task.done -> if (dark) Color(0xFF254736) else TaskSuccess
            task.failed -> if (dark) Color(0xFF542C37) else TaskFailure
            selected -> if (dark) Color(0xFF294879) else TaskSuggested
            dark -> Color(0xFF202F45)
            else -> TaskOpen
        },
        animationSpec = if (reduceMotion) snap() else tween(330),
        label = "journey card color"
    )
    val border = when {
        task.done -> if (dark) Color(0xFF59886D) else Color(0xFFBDE1C9)
        task.failed -> if (dark) Color(0xFF995D65) else Color(0xFFF2CCCC)
        selected -> Color(0xFF86A8F2)
        dark -> Color(0xFF3C5068)
        else -> Color(0xFFE1E7F0)
    }
    val caption = when {
        task.done -> if (dark) Color(0xFFB3EDC7) else Color(0xFF286A49)
        task.failed -> if (dark) Color(0xFFFFCCD1) else Color(0xFF93424B)
        selected -> if (dark) Color(0xFFD5E4FF) else TaskBlue
        dark -> Color(0xFFD0DCEB)
        else -> Color(0xFF6A7E9D)
    }
    val ink = if (dark) Color(0xFFEEF4FC) else TaskInk

    Box(modifier.fillMaxWidth().height(210.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.matchParentSize()) {
            val cardCenterX = size.width * if (left) .275f else .725f
            val sharedX = size.width * .5f
            val cardHalf = 49.dp.toPx()
            val upperY = size.height * .5f - cardHalf
            val lowerY = size.height * .5f + cardHalf
            val self = journeyStrokeColor(task)

            if (above != null) {
                val join = lerp(self, journeyStrokeColor(above), .5f)
                val p = Path().apply {
                    moveTo(cardCenterX, upperY)
                    cubicTo(cardCenterX, upperY * .43f,
                        sharedX, upperY * .56f, sharedX, 0f)
                }
                drawJourneyStroke(p, join, self, 0f, upperY)
            }
            if (below != null) {
                val join = lerp(self, journeyStrokeColor(below), .5f)
                val h = size.height
                val gap = h - lowerY
                val p = Path().apply {
                    moveTo(sharedX, h)
                    cubicTo(sharedX, h - gap * .56f,
                        cardCenterX, lowerY + gap * .43f, cardCenterX, lowerY)
                }
                drawJourneyStroke(p, self, join, lowerY, h)
            }
        }
        Surface(
            onClick = onClick,
            modifier = Modifier.fillMaxWidth(.55f).height(98.dp)
                .align(if (left) Alignment.CenterEnd else Alignment.CenterStart),
            shape = RoundedCornerShape(22.dp), color = face,
            border = BorderStroke(if (selected) 1.6.dp else 1.dp, border),
            shadowElevation = if (selected) 5.dp else 1.5.dp
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("قدم ${faNumber(task.stepNumber)}",
                    fontWeight = FontWeight.SemiBold, color = caption,
                    style = MaterialTheme.typography.labelMedium,
                    maxLines = 1)
                Spacer(Modifier.height(5.dp))
                Text(task.title, color = ink, textAlign = TextAlign.Center,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
