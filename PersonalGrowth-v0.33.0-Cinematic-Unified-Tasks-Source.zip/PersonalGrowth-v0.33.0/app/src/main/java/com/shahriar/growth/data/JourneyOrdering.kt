package com.shahriar.growth.data

/** Presentation order runs from the bottom of the reversed list to its top.
 * Stable step numbers identify tasks; alternating sides are based on DISPLAY POSITION,
 * not step number, because completed tasks are reordered below unresolved ones.
 */
data class JourneyOrderItem(
    val id: String,
    val stepNumber: Long,
    val createdAt: Long,
    val resolved: Boolean,
    val archived: Boolean
)

fun orderJourneyItems(items: List<JourneyOrderItem>): List<JourneyOrderItem> =
    items.asSequence().filterNot { it.archived }.sortedWith(
        compareBy<JourneyOrderItem> { if (it.resolved) 0 else 1 }
            .thenBy { if (it.stepNumber > 0L) it.stepNumber else Long.MAX_VALUE }
            .thenBy { it.createdAt }
            .thenBy { it.id }
    ).toList()

/** First OPEN task after resolved history: recommended, never compulsory. */
fun recommendedJourneyId(items: List<JourneyOrderItem>): String? =
    orderJourneyItems(items).firstOrNull { !it.resolved }?.id

/** Bottommost item is left, the next is right, regardless of immutable step number. */
fun journeyItemOnLeft(displayIndex: Int): Boolean = displayIndex % 2 == 0
