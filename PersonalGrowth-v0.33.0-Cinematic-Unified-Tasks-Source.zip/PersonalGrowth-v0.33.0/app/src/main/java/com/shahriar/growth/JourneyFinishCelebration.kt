package com.shahriar.growth

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog

/** One-time journey milestone, NOT an XP/coin reward and never a second payout. */
@Composable
fun JourneyFinishCelebration(successes: Int, failures: Int, onDismiss: () -> Unit) {
    val reducedMotion = rememberReducedMotion()
    var entered by remember(successes, failures) { mutableStateOf(false) }
    LaunchedEffect(successes, failures) { entered = true }
    val scale by animateFloatAsState(if (entered) 1f else .9f,
        animationSpec = if (reducedMotion) snap() else tween(400), label = "journey milestone")
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth().graphicsLayer(scaleX = scale, scaleY = scale),
            shape = RoundedCornerShape(26.dp), color = Color(0xFFF9FBFF),
            border = BorderStroke(1.dp, Color(0xFFDCE6F7)), shadowElevation = 8.dp
        ) {
            Column(Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(if (failures == 0) Icons.Outlined.AutoAwesome else Icons.Outlined.CheckCircle,
                    contentDescription = null, tint = Color(0xFF355CDE),
                    modifier = Modifier.size(48.dp))
                Text(if (failures == 0) "آفرین! همه قدم‌ها رو انجام دادی"
                    else "تمام قدم‌های فعلی تعیین‌تکلیف شدند",
                    style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center, color = Color(0xFF17223B))
                Text("${faNumber(successes)} موفق · ${faNumber(failures)} ناموفق",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF64748B), textAlign = TextAlign.Center)
                Text("مسیر و سابقه قدم‌ها باقی می‌مونه؛ هر زمان خواستی قدم جدید بساز.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF64748B), textAlign = TextAlign.Center)
                Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                    Text("ادامه مسیر")
                }
            }
        }
    }
}
