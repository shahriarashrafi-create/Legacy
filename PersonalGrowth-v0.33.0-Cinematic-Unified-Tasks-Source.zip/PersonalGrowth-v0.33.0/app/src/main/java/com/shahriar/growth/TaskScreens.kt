package com.shahriar.growth

import android.icu.text.SimpleDateFormat
import android.icu.util.Calendar
import android.icu.util.ULocale
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.shahriar.growth.data.*
import java.time.LocalDate
import java.time.ZoneId
import java.util.Date

fun faNumber(value: Any): String = value.toString().map { if(it in '0'..'9') ('۰'.code + it.code - '0'.code).toChar() else it }.joinToString("")
fun persianDay(day: Long, numeric: Boolean = false): String {
    val formatter = SimpleDateFormat(if(numeric) "yyyy/MM/dd" else "d MMMM yyyy", ULocale("fa_IR@calendar=persian"))
    return formatter.format(Date.from(LocalDate.ofEpochDay(day).atStartOfDay(ZoneId.systemDefault()).toInstant()))
}
fun parsePersianDay(raw: String): Long? = try {
    val parts = normalizeText(raw).trim().split('/').map { it.toInt() }
    require(parts.size == 3 && parts[0] in 1300..1600)
    val calendar = Calendar.getInstance(ULocale("fa_IR@calendar=persian"))
    calendar.isLenient = false; calendar.clear(); calendar.set(parts[0], parts[1]-1, parts[2], 12, 0, 0)
    java.time.Instant.ofEpochMilli(calendar.timeInMillis).atZone(ZoneId.systemDefault()).toLocalDate().toEpochDay()
} catch (_: Exception) { null }
fun dueLabel(t: Task, today: Long): String {
    val day = t.dueDay ?: return "بدون موعد"
    val date = when { day == today -> "امروز"; day == today + 1 -> "فردا"; else -> persianDay(day) }
    val time = t.dueMinute?.let { " · " + faNumber("%02d:%02d".format(java.util.Locale.ROOT, it/60,it%60)) } ?: ""
    return date + time + if (day < today && !t.done) " · عقب‌افتاده" else ""
}
/** Full-screen task detail or compact quick-create sheet. Existing CRM, goals, recurrence,
 * subtasks and history are supplied by [extra] on the detail screen.
 */
@Composable fun TaskEditor(
    modifier: Modifier, task: Task?, events: List<TaskEvent>, today: Long, busy: Boolean,
    externalError: String, onDismiss: () -> Unit, onSave: (Task) -> Unit,
    onDone: (Boolean) -> Unit, onFail: () -> Unit, onArchive: (Boolean) -> Unit,
    onFocus: () -> Unit, quick: Boolean = false, extra: @Composable () -> Unit
) {
    val draftId = rememberSaveable { task?.id ?: java.util.UUID.randomUUID().toString() }
    var title by rememberSaveable { mutableStateOf(task?.title ?: "") }
    var note by rememberSaveable { mutableStateOf(task?.note ?: "") }
    var dateText by rememberSaveable { mutableStateOf(task?.dueDay?.let { persianDay(it, true) } ?: "") }
    var time by rememberSaveable { mutableStateOf(task?.dueMinute?.let { "%02d:%02d".format(java.util.Locale.ROOT,it/60,it%60) } ?: "") }
    var priority by rememberSaveable { mutableIntStateOf(task?.priority ?: 1) }
    var duration by rememberSaveable { mutableStateOf(task?.duration?.toString() ?: "") }
    var expanded by rememberSaveable { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    val dirty = task != null && (title != task.title || note != task.note || dateText != (task.dueDay?.let { persianDay(it,true) } ?: "") ||
        time != (task.dueMinute?.let { "%02d:%02d".format(java.util.Locale.ROOT,it/60,it%60) } ?: "") || priority != task.priority || duration != (task.duration?.toString() ?: ""))
    Column(modifier.then(if(quick) Modifier.fillMaxWidth().heightIn(max = 700.dp) else Modifier.fillMaxSize())
        .imePadding().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(if (quick) "کار جدید" else "جزئیات کار · قدم ${faNumber(task?.stepNumber ?: 0)}",
                modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
            IconButton(onClick = onDismiss) { Icon(Icons.Outlined.Close, "بستن") }
        }
        if(task!=null) {
            Text(if(task.done) "انجام‌شده" else if(task.failed) "ناموفق · قابل تلاش دوباره" else "شروع‌نشده",
                style = MaterialTheme.typography.labelLarge, color = when { task.done -> androidx.compose.ui.graphics.Color(0xFF278159)
                    task.failed -> androidx.compose.ui.graphics.Color(0xFFA94450); else -> MaterialTheme.colorScheme.primary })
        }
        OutlinedTextField(title, { title = it }, label = { Text("عنوان کار") },
            modifier = Modifier.fillMaxWidth(), enabled = !busy, maxLines = 3)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = { dateText = persianDay(today,true) }) { Text("امروز") }
            TextButton(onClick = { dateText = persianDay(today+1,true) }) { Text("فردا") }
            TextButton(onClick = { dateText = ""; time = "" }) { Text("بدون موعد") }
        }
        if (quick) TextButton(onClick = { expanded = !expanded }) {
            Icon(if(expanded) Icons.Outlined.ExpandLess else Icons.Outlined.Tune, null)
            Text(if(expanded) "بستن تنظیمات پیشرفته" else "تنظیمات پیشرفته · اختیاری")
        }
        if(!quick || expanded) {
            OutlinedTextField(note, { note = it }, label = { Text("توضیحات · اختیاری") },
                modifier = Modifier.fillMaxWidth(), enabled = !busy, minLines = 2)
            OutlinedTextField(dateText, { dateText = it }, label = { Text("تاریخ شمسی · سال/ماه/روز") },
                modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !busy)
            OutlinedTextField(time, { time = it }, label = { Text("ساعت · ۱۸:۳۰ · اختیاری") },
                modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !busy)
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("کم", "متوسط", "زیاد").forEachIndexed { i, label ->
                    FilterChip(selected = priority == i, onClick = { priority = i }, label = { Text(label) })
                }
            }
            OutlinedTextField(duration, { duration = it }, label = { Text("مدت تخمینی به دقیقه · اختیاری") },
                modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !busy)
        } else if(dateText.isNotBlank()) Text("موعد: $dateText", style = MaterialTheme.typography.bodySmall)
        if(error.isNotBlank() || externalError.isNotBlank()) Text(error.ifBlank { externalError },color = MaterialTheme.colorScheme.error)
        Button(enabled = !busy, onClick = {
            error = ""
            val parsedDay = if(dateText.isBlank()) null else parsePersianDay(dateText)
            val normalizedTime = normalizeText(time).trim()
            val minute = if(normalizedTime.isBlank()) null else if(Regex("\\d{1,2}:\\d{2}").matches(normalizedTime))
                normalizedTime.split(':').map{it.toInt()}.let{if(it[0] in 0..23 && it[1] in 0..59)it[0]*60+it[1] else -1} else -1
            val durationValue = if(duration.isBlank())null else normalizeText(duration).toIntOrNull()
            when {
                title.isBlank() -> error="عنوان را وارد کن."
                title.length>300 -> error="عنوان حداکثر ۳۰۰ نویسه باشد."
                dateText.isNotBlank() && parsedDay==null -> error="تاریخ شمسی معتبر وارد کن."
                minute==-1 || (minute!=null && parsedDay==null) -> error="ساعت معتبر و تاریخ مربوط را وارد کن."
                duration.isNotBlank() && (durationValue==null || durationValue !in 1..240) -> error="مدت بین ۱ تا ۲۴۰ دقیقه باشد."
                else -> onSave((task ?: Task(id=draftId,title=title.trim())).copy(
                    title=title.trim(), note=note.trim(), dueDay=parsedDay,
                    dueMinute=minute, priority=priority, duration=durationValue))
            }
        },modifier = Modifier.fillMaxWidth()) { Text(if(busy) "در حال ثبت…" else "ذخیره کار") }
        if(task!=null) {
            if(dirty) Text("ابتدا تغییرات را ذخیره کن، سپس وضعیت را تغییر بده.",style=MaterialTheme.typography.bodySmall)
            if(!task.archived) {
                if(!task.done && !task.failed) {
                    Button(enabled=!busy && !dirty,onClick=onFocus,modifier=Modifier.fillMaxWidth()) { Text("شروع یا ادامه تمرکز") }
                    OutlinedButton(enabled=!busy && !dirty,onClick={confirm="done"},modifier=Modifier.fillMaxWidth()) { Text("ثبت موفقیت · انجام شد") }
                    OutlinedButton(enabled=!busy && !dirty,onClick={confirm="failed"},modifier=Modifier.fillMaxWidth()) { Text("ثبت نتیجه ناموفق") }
                } else {
                    OutlinedButton(enabled=!busy && !dirty,onClick={confirm="reopen"},modifier=Modifier.fillMaxWidth()) {
                        Text("بازگرداندن به شروع‌نشده")
                    }
                }
            }
            // Editing a task never hides any of its existing non-journey functionality.
            extra()
            TextButton(enabled=!busy && !dirty,onClick={confirm="archive"}) { Text(if(task.archived) "بازگردانی از بایگانی" else "بایگانی کار") }
            if(events.isNotEmpty()) {
                Text("تاریخچه",style=MaterialTheme.typography.titleMedium)
                events.take(25).forEach { e -> Text(e.description + " · " + persianDay(java.time.Instant.ofEpochMilli(e.at)
                    .atZone(ZoneId.systemDefault()).toLocalDate().toEpochDay()),style=MaterialTheme.typography.bodySmall) }
            }
        }
    }
    if(confirm.isNotEmpty()) AlertDialog(onDismissRequest={confirm=""},title={Text("تأیید تغییر")},
        text={Text(when(confirm) { "done" -> "این کار با نتیجه موفق ثبت شود؟"
            "failed" -> "این تلاش ناموفق ثبت شود؟"
            "reopen" -> "این قدم دوباره در کارهای باز قرار بگیرد؟"
            else -> if(task?.archived==true) "کار از بایگانی بازگردد؟" else "کار با حفظ سابقه بایگانی شود؟" })},
        confirmButton={TextButton(onClick={
            when(confirm) {"done"->onDone(true); "failed"->onFail(); "reopen"->onDone(false)
                else->onArchive(task?.archived!=true)}; confirm=""
        }) { Text("تأیید") }},dismissButton={TextButton(onClick={confirm=""}) { Text("انصراف") }})
}
