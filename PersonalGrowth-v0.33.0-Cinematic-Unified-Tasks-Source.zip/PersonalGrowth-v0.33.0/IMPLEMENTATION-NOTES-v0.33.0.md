# PersonalGrowth 0.33.0 — Cinematic Unified Task Journey

## Base and compatibility
- Derived from the user-provided `PersonalGrowth v0.32.0` source. The `RedesignedHome.kt` home design is byte-for-byte unchanged.
- App version `0.33.0`, `versionCode 35`. The Room database remains **schema version 8**, so no new migration is needed from v0.32.0. Existing 7->8 migration for v0.31.0 remains registered. No user database or task data is intentionally deleted.
- App's original shared Home header, bottom navigation, quick-create, full-page editor, focus session, rewards, archived tasks, goals, clients, network, meetings and repeat integration are retained.

## Main visible changes
- Removed the *entire* internal Task header/tool strip: no inner title, percentage, search field, filters or filter button on the Task journey. Home's main header and floating bottom navigation still render globally.
- One and only one 40dp circular `+` under the global header, positioned on the **physical left** under RTL, overlaid and accessible during scrolling. It opens the existing quick-create bottom sheet.
- Tasks shown in a single scrollable, reverse-layout `LazyColumn`; no separate list and map. The displayed list is the journey itself. First visual step begins at the physical lower-left; cards alternate left and right by **display index**, independent of permanent step number.
- Card: 98dp high, rounded corners, large 210dp row rhythm; permanent Persian step number and title only. Titles at most **two lines**, ellipsized beyond that. Open white, recommended blue, success mint green, failure soft red, with dark-surface adaptations.
- All resolved tasks (successful OR failed) stay in the same journey, in permanent numerical order, physically **below** all unresolved tasks. The first unresolved task is highlighted blue, but no other tasks are locked.
- Corrected the perceived disappearance of completed cards: auto-scroll now leaves one resolved row below the first open row whenever possible, allowing the user to discover completed history by scrolling down. The scroll still smoothly focuses the first blue card. Archiving is the only ordinary way for a task to leave the active journey.
- Connected Bézier path half-segments from the *top center of the lower card* to the *bottom center of the upper card*, meeting at the row boundary with a vertical tangent. Color is interpolated through the boundary using equal mix of adjacent task states. A ~3.5dp stroke plus subtle 11dp translucent halo is static, without continuous motion or distracting particle effects.
- Existing `animateItem()` handles smooth placement and `animateColorAsState` handles status transitions. If Android animation duration scale is zero, placement animation and animated scrolling are disabled, and color/reward/finish transitions snap.
- Added brief **one-time** milestone dialog when the final unresolved task is **successfully/unsuccessfully resolved** (not merely archived); the ongoing journey remains visible, and a user can create more steps. The milestone does not issue additional XP/coins. Existing per-task reward popup retains its behavior; the milestone waits for it to close.

## Deterministic ordering algorithm
`data/JourneyOrdering.kt` is a platform-independent sorting helper, used directly by `taskJourneyOrder` and exercised by the included Kotlin scenario test. Bottom-to-top order is:
1. Resolved (done or failed) tasks by permanent step number.
2. Unresolved tasks by permanent step number.
3. Ties (only for legacy invalid numbers): creation timestamp, then ID.
Archived steps are excluded from the visible journey, but remain stored and keep their assigned number.

**Fixed scenario:** Done: steps 1 and 4; open: steps 2, 3, 5, 6. Bottom-to-top display: `1 green (left) → 4 green (right) → 2 blue (left) → 3 white (right) → 5 white (left) → 6 white (right)`. Failed tasks use the same resolved ordering but are red. Step identifiers themselves do not change.

## Implementation locations
- `app/src/main/java/com/shahriar/growth/TaskJourneyScreen.kt` — screen, geometry, colors, overlaid plus, scroll anchor, animation.
- `.../data/JourneyOrdering.kt` — canonical ordering and alternating side semantics.
- `.../data/Tasks.kt` — routes the existing journey ordering through the tested helper; DB, schema, reward functions otherwise unchanged.
- `.../MainActivity.kt` — updated screen parameters, dropped now-unused Task filter controls, milestone trigger.
- `.../JourneyFinishCelebration.kt` — outcome-specific one-shot completion dialog with no reward action.
- `.../MotionPreference.kt` — Android reduced-motion preference.
- `.../TaskRewardCelebration.kt` — respects reduced-motion preference.
- `tools/JourneyOrderingChecks.kt` and `tools/verify_v033.py` — reproducible source-level QA checks.

## Reproducible validation
Run `python tools/verify_v033.py`. To execute the 13 Kotlin assertions on a machine with `kotlinc` and Java:

```bash
kotlinc app/src/main/java/com/shahriar/growth/data/JourneyOrdering.kt tools/JourneyOrderingChecks.kt -include-runtime -d /tmp/journey-ordering-checks.jar
java -jar /tmp/journey-ordering-checks.jar
```

All 39 static source invariants and the Room 7->8 SQL backfill simulation passed in the supplied environment. All 13 Kotlin assertion scenarios passed. A Kotlin syntax-only diagnostic was run and had no reported parsing errors; full type resolution cannot happen without Compose/Android dependencies. `./gradlew :app:assembleDebug --offline` was blocked **before compilation** because the Gradle 8.7 distribution was not installed and services.gradle.org could not be reached. No APK was built or device tested here.

## REQUIRED before shipping to users
1. Build debug and release variants on a machine with Android SDK 35, JDK 17, Gradle 8.7 and project dependencies.
2. Test layout direction on an actual RTL phone and screen sizes: plus physically at top-left, no content hidden under global Home header / bottom bar.
3. Test 1 and 4 success, 2 proposed, alternating sides, same-path connections; repeat with 4 failure and reopening.
4. Test 100–250+ tasks for jank, long scroll, stable keys and placement animations.
5. Test focus-based success, quick detail success, failure, subtask rules, reward idempotency, no duplicate completion modal, empty and all-resolved state.
6. Test migration from v0.31.0 (schema 7) as well as upgrade from v0.32.0 (schema 8), backup/restore, and dark mode.

This is an **updated source ZIP awaiting Android compilation and on-device visual acceptance**, not a verified APK.
