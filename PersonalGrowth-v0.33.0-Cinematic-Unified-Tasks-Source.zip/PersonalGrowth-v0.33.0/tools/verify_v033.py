"""Static source verification + deterministic Room migration simulation.
This does NOT stand in for Android Gradle compilation or device/UI tests.
"""
from pathlib import Path
import json, sqlite3
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/shahriar/growth'
ui=(src/'TaskJourneyScreen.kt').read_text()
app=(src/'MainActivity.kt').read_text()
db=(src/'data/AppData.kt').read_text()
logic=(src/'data/Tasks.kt').read_text()
order=(src/'data/JourneyOrdering.kt').read_text()
editor=(src/'TaskScreens.kt').read_text()
rewards=(src/'TaskRewardCelebration.kt').read_text()
finish=(src/'JourneyFinishCelebration.kt').read_text()
build=(root/'app/build.gradle.kts').read_text()

# Schema 7 -> 8 simulation, including identical timestamps, uniqueness and archive.
schema=json.loads((root/'app/schemas/com.shahriar.growth.data.AppDatabase/7.json').read_text())['database']
create=next(e['createSql'] for e in schema['entities'] if e['tableName']=='tasks').replace('${TABLE_NAME}','tasks')
con=sqlite3.connect(':memory:')
con.execute(create)
for id, created in [('q',900),('b',100),('a',100),('c',101)]:
    con.execute('INSERT INTO tasks(id,title,note,priority,failed,done,archived,createdAt,updatedAt) VALUES(?,?,?,?,?,?,?,?,?)',
        (id,id,'',1,0,0,0,created,created))
con.execute('ALTER TABLE tasks ADD COLUMN stepNumber INTEGER NOT NULL DEFAULT 0')
for i, (task_id,) in enumerate(con.execute('SELECT id FROM tasks ORDER BY createdAt ASC,id ASC').fetchall(),1):
    con.execute('UPDATE tasks SET stepNumber=? WHERE id=?',(i,task_id))
con.execute('CREATE UNIQUE INDEX IF NOT EXISTS index_tasks_stepNumber ON tasks(stepNumber)')
seq=con.execute('SELECT id,stepNumber FROM tasks ORDER BY stepNumber').fetchall()
assert seq==[('a',1),('b',2),('c',3),('q',4)],seq
try:
    con.execute('UPDATE tasks SET stepNumber=2 WHERE id="q"')
    raise AssertionError('unique index accepts duplicate')
except sqlite3.IntegrityError: pass

checks = {
    'v0.33.0 version and code': 'versionName = "0.33.0"' in build and 'versionCode = 35' in build,
    'single Home header in shared Scaffold': app.count('topBar = { HomePremiumLevelCard(')==1,
    'shared bottom bar remains': 'bottomBar = {' in app,
    'journey in main navigation': 'TaskJourneyScreen(Modifier.padding(padding), tasks, listState' in app,
    'old journey alias': '12 -> selected=3' in app,
    'no separate legacy path screen': 'fun PathScreen(' not in (src/'ExecutionScreens.kt').read_text(),
    'home unchanged from reference': (src/'RedesignedHome.kt').read_bytes() == (root.parent/'PersonalGrowth-v0.32.0/app/src/main/java/com/shahriar/growth/RedesignedHome.kt').read_bytes(),
    'task list is ONLY one reverse lazy journey': 'LazyColumn(' in ui and 'reverseLayout = true' in ui and 'taskJourneyOrder(tasks)' in ui,
    'legacy task filtering UI removed': all(x not in ui for x in ['ModalBottomSheet','FilterChip(', 'filtersOpen', 'progressPercent','Text("کارهای من"']),
    'filter bypassed from Home onList': 'onList={selected=3}' in app,
    'fixed small plus only': 'size(40.dp)' in ui and 'Icons.Outlined.Add' in ui,
    'physical top-left RTL': 'Alignment.TopEnd' in ui,
    'all statuses stay in journey': 'orderJourneyItems(tasks.map' in logic and 'task.done || task.failed' in logic and 'filterNot { it.archived }' in order,
    'finished history stays below open tasks': 'if (it.resolved) 0 else 1' in order,
    'stable IDs and numbers': 'stepNumber = old?.stepNumber' in logic and 'itemsIndexed(ordered, key = { _, task -> task.id })' in ui,
    'side based on display position': 'journeyItemOnLeft(displayIndex)' in ui and 'displayIndex % 2 == 0' in order,
    'physical left first in RTL': 'if (left) Alignment.CenterEnd else Alignment.CenterStart' in ui,
    'first unresolved recommended': 'val recommendedId = ordered.getOrNull(firstOpen)?.id' in ui,
    'no hidden history by autofocus': '(firstOpen - 1).coerceAtLeast(0)' in ui,
    'upper/lower curved path segments': 'if (above != null)' in ui and 'if (below != null)' in ui and 'cubicTo(' in ui,
    'smooth path gradients': 'Brush.verticalGradient' in ui and 'lerp(self, journeyStrokeColor(above), .5f)' in ui,
    'subtle glow': 'alpha = 0.14f' in ui and '11.dp.toPx()' in ui and '3.5.dp.toPx()' in ui,
    'completed green and failed red': 'TaskSuccess' in ui and 'TaskFailure' in ui,
    'upcoming white and highlighted blue': 'TaskOpen' in ui and 'TaskSuggested' in ui,
    'two line card title': 'maxLines = 2, overflow = TextOverflow.Ellipsis' in ui,
    'large gaps between cards': '.height(210.dp)' in ui and '.height(98.dp)' in ui,
    'fixed add button atop scroll': 'Modifier.align(Alignment.TopEnd)' in ui,
    'post-commit reward dialog': 'engine.complete(task.id, value)' in app and 'rewardNotice = task.title to rewardFor(task.priority)' in app,
    'wallet idempotency': 'val id="task:${task.id}"' in (src/'data/FinalFeatures.kt').read_text(),
    'success and failure state in detail': all(s in editor for s in ['"done"','"failed"','"reopen"']),
    'details full-page and quick create sheet': 'editorPanel(Modifier.padding(padding), false)' in app and 'if(editorId == "new") ModalBottomSheet' in app,
    'saved archive + legacy tables retained': all(s in db for s in ['Mission::class','PathGroup::class','Prerequisite::class','MIGRATION_7_8']),
    'reduced animation support in list': 'if (reduceMotion) listState.scrollToItem(target)' in ui and 'if (reduceMotion) Modifier else Modifier.animateItem()' in ui,
    'reduced animation support in rewards': 'rememberReducedMotion()' in rewards and 'snap()' in rewards,
    'once-per-last-resolved completion dialog': 'newlyResolved' in app and 'journeyFinished' in app and 'JourneyFinishCelebration(' in app,
    'completion not triggered by just archiving': 'it.id == previousId && (it.done || it.failed)' in app,
    'no extra milestone payouts': 'FinalEngine' not in finish and 'reward(' not in finish,
    'full legacy links retained': 'TaskContactPanel(' in app and 'SubtaskPanel(' in app and 'TaskGoalsPanel(' in app,
    'versions upgraded no new schema': '@Database(' in db and 'version = 8' in db,
}
failed=[name for name,passed in checks.items() if not passed]
report=['PersonalGrowth 0.33.0 verification','SQLite 7->8 migration simulation: PASS',
        f'Static source invariants: {len(checks)-len(failed)}/{len(checks)} pass',
        'Kotlin test for journey ordering: see tools/JourneyOrderingChecks.kt',
        'Android APK Gradle build: BLOCKED (Gradle 8.7 distribution not cached; network inaccessible)',
        'Android device, instrumentation, UI render: NOT RUN',
        'No APK included. Source is NOT device-verified.','']
report += [f'{"PASS" if v else "FAIL"} {k}' for k,v in checks.items()]
(root/'QA-REPORT-v0.33.0.txt').write_text('\n'.join(report)+'\n')
for line in report:print(line)
if failed:raise SystemExit('Failed checks: '+', '.join(failed))
