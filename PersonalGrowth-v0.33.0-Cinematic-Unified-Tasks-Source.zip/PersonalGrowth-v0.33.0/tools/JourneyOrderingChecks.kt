import com.shahriar.growth.data.*

fun main() {
    fun step(n: Long, done: Boolean = false, failed: Boolean = false, archived: Boolean = false) =
        JourneyOrderItem("task$n", n, n * 100, done || failed, archived)

    val initial = (1L..6L).map { step(it) }
    check(orderJourneyItems(initial).map { it.stepNumber } == listOf(1L, 2L, 3L, 4L, 5L, 6L))
    check(recommendedJourneyId(initial) == "task1")
    val mixed = listOf(step(1, done = true), step(2), step(3), step(4, done = true), step(5), step(6))
    check(orderJourneyItems(mixed).map { it.stepNumber } == listOf(1L, 4L, 2L, 3L, 5L, 6L))
    check(recommendedJourneyId(mixed) == "task2")
    check((0..5).map { journeyItemOnLeft(it) } == listOf(true, false, true, false, true, false))
    // Reopening step 4 must restore the original sequence, without renumbering.
    val reopened = mixed.map { if (it.stepNumber == 4L) it.copy(resolved = false) else it }
    check(orderJourneyItems(reopened).map { it.stepNumber } == listOf(1L, 2L, 3L, 4L, 5L, 6L))
    val fail = listOf(step(1, failed = true), step(2, done = true), step(3, failed = true))
    check(recommendedJourneyId(fail) == null)
    check(orderJourneyItems(fail).size == 3)
    // Archived tasks keep their permanent IDs but leave the active display.
    check(orderJourneyItems(initial + step(7, archived = true)).size == 6)
    // Deterministic ties: creation timestamp and ID break ties for imported data.
    val ties = listOf(JourneyOrderItem("z", 0L, 1L, false, false),
        JourneyOrderItem("a", 0L, 1L, false, false))
    check(orderJourneyItems(ties).map { it.id } == listOf("a", "z"))
    // 200+ steps can be sorted, preserving priority of resolved history.
    val long = (1L..250L).map { step(it, done = it % 5 == 0L) }
    val ordered = orderJourneyItems(long)
    check(ordered.size == 250 && ordered.take(50).all { it.resolved })
    check(ordered.drop(50).none { it.resolved })
    check(recommendedJourneyId(long) == "task1")
    println("PASS: 13 Kotlin scenario assertions: status reorder, immutable steps, zigzag, archives, empty open, long journey")
}
