import json, sqlite3, pathlib, re, hashlib
root=pathlib.Path(__file__).resolve().parents[1]
source=root/'app/src/main/java/com/shahriar/growth'
old=json.loads((root/'app/schemas/com.shahriar.growth.data.AppDatabase/7.json').read_text())['database']
create=next(x['createSql'] for x in old['entities'] if x['tableName']=='tasks').replace('${TABLE_NAME}','tasks')
con=sqlite3.connect(':memory:')
con.execute(create)
entries=[('c',100),('b',101),('a',100),('d',103)]
for i,t in entries:
    con.execute('INSERT INTO tasks(id,title,note,priority,failed,done,archived,createdAt,updatedAt) VALUES(?,?,?,?,?,?,?,?,?)',(i,'Task '+i,'',1,0,0,0,t,t))
con.execute('ALTER TABLE tasks ADD COLUMN stepNumber INTEGER NOT NULL DEFAULT 0')
ids=[x[0] for x in con.execute('SELECT id FROM tasks ORDER BY createdAt ASC,id ASC')]
for step,id in enumerate(ids,1):con.execute('UPDATE tasks SET stepNumber=? WHERE id=?',(step,id))
con.execute('CREATE UNIQUE INDEX IF NOT EXISTS index_tasks_stepNumber ON tasks(stepNumber)')
seq=con.execute('SELECT id,stepNumber FROM tasks ORDER BY stepNumber').fetchall()
assert seq==[('a',1),('c',2),('b',3),('d',4)],seq
assert len(set(x[1] for x in seq))==4
try:con.execute('UPDATE tasks SET stepNumber=1 WHERE id="d"'); raise AssertionError('unique index broken')
except sqlite3.IntegrityError:pass
checks={
 'same header everywhere':(source/'MainActivity.kt').read_text().count('topBar = { HomePremiumLevelCard(')==1,
 'bottom bar unconditional': 'bottomBar = {' in (source/'MainActivity.kt').read_text() and 'bottomBar = { if ' not in (source/'MainActivity.kt').read_text(),
 'one journey without independent path page':'fun PathScreen(' not in (source/'ExecutionScreens.kt').read_text(),
 'no old prerequisites in task detail':'RelationsPanel(' not in (source/'MainActivity.kt').read_text(),
 'no prerequisite enforcement':'requireReady(' not in (source/'data/Execution.kt').read_text(),
 'migration v7 to v8':'MIGRATION_7_8' in (source/'data/AppData.kt').read_text(),
 'stable number backed by DB':'stepNumber = old?.stepNumber' in (source/'data/Tasks.kt').read_text(),
 'zigzag single list':'reverseLayout = true' in (source/'TaskJourneyScreen.kt').read_text(),
 'smooth animated scroll':'animateScrollToItem' in (source/'TaskJourneyScreen.kt').read_text(),
 'success/failure/reopen in detail':all(t in (source/'TaskScreens.kt').read_text() for t in ['"done"','"failed"','"reopen"']),
 'light green/light red/blue/white cards': all(t in (source/'TaskJourneyScreen.kt').read_text() for t in ['JourneyWhite','JourneyCurrent','JourneyDone','JourneyFailed']),
 'quick create plus optional advanced':all(t in (source/'TaskScreens.kt').read_text() for t in ['quick: Boolean = false','"تنظیمات پیشرفته']),
 'navigation legacy alias':'12 -> selected=3' in (source/'MainActivity.kt').read_text(),
 'preserve legacy data schemas':all(t in (source/'data/AppData.kt').read_text() for t in ['Mission::class','PathGroup::class','Prerequisite::class']),
 'new version': 'versionName = "0.32.0"' in (root/'app/build.gradle.kts').read_text(),
}
assert all(checks.values()),{k:v for k,v in checks.items() if not v}
print('Migration test PASS: ',seq)
print('Static checks PASS: ',len(checks))
for k,v in checks.items():print(('PASS' if v else 'FAIL'),k)
(root/'QA-REPORT-v0.32.0.txt').write_text('PersonalGrowth v0.32.0 QA\nMigration SQL simulated against previous 7.json tasks definition: PASS\nStatic source invariants: '+str(len(checks))+' PASS\nAndroid Gradle build: NOT RUN (no Android SDK or predownloaded Gradle; network blocked)\nApp instrumentation/UI device tests: NOT RUN\nNo APK produced.\n\n'+'\n'.join(f'{"PASS" if v else "FAIL"}: {k}' for k,v in checks.items())+'\n',encoding='utf-8')
