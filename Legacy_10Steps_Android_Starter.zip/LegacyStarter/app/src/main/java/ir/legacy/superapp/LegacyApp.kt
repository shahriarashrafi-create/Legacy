package ir.legacy.superapp

import android.os.SystemClock
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.legacy.core.ActivityKind
import ir.legacy.core.RepeatRule
import ir.legacy.core.TaskKind
import ir.legacy.core.TaskPriority
import ir.legacy.core.TaskStatus
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val padding = 16.dp
private fun labelTime(time: Long): String = SimpleDateFormat("yyyy/MM/dd", Locale("fa", "IR")).format(Date(time))

@Composable
fun LegacyApp(vm: LegacyViewModel) {
    val signedIn by vm.signedIn.collectAsState()
    val onboardingDone by vm.onboardingDone.collectAsState()
    val name by vm.displayName.collectAsState()
    val tasks by vm.tasks.collectAsState()
    val steps by vm.steps.collectAsState()
    val activities by vm.activities.collectAsState()
    val focusRecords by vm.focusSessions.collectAsState()
    var tab by rememberSaveable { mutableStateOf(0) }

    when {
        !signedIn -> DemoEntry(onEnter = vm::signInDemo)
        !onboardingDone -> Onboarding(name, onDone = vm::finishOnboarding)
        else -> Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 3.dp) {
                    val tabs = listOf("خانه", "اقدامات", "تمرکز", "گزارش", "پروفایل")
                    val icons = listOf(Icons.Default.Home, Icons.Default.Checklist, Icons.Default.Timer, Icons.Default.Assessment, Icons.Default.Person)
                    tabs.forEachIndexed { index, title ->
                        NavigationBarItem(
                            selected = tab == index,
                            onClick = { tab = index },
                            icon = { Icon(icons[index], contentDescription = null) },
                            label = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        )
                    }
                }
            }
        ) { insets ->
            Column(
                modifier = Modifier.fillMaxSize().padding(insets).verticalScroll(rememberScrollState()).padding(horizontal = padding),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Spacer(Modifier.height(4.dp))
                when (tab) {
                    0 -> HomeScreen(name, tasks, activities, onGoTasks = { tab = 1 }, onGoFocus = { tab = 2 }, onGoReport = { tab = 3 })
                    1 -> TasksScreen(tasks, steps, vm)
                    2 -> FocusScreen(tasks, focusRecords, vm)
                    3 -> ActivitiesScreen(activities, vm)
                    else -> ProfileScreen(name, tasks, activities, focusRecords, onSignOut = { vm.signOut(); tab = 0 })
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun ScreenHeading(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun InfoCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .62f))) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
    }
}

@Composable
private fun StatsTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun DemoEntry(onEnter: (String) -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(Modifier.height(70.dp))
        Icon(Icons.Default.Hub, contentDescription = null, modifier = Modifier.size(64.dp), tint = LegacyTeal)
        Spacer(Modifier.height(20.dp))
        Text("لگاسی", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
        Text("یک قدم واقعی، هر روز", style = MaterialTheme.typography.titleMedium, color = LegacyTeal)
        Spacer(Modifier.height(32.dp))
        InfoCard {
            Text("ورود به نسخه اولیه", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text("نام نمایشی") }, placeholder = { Text("مثلاً شهریار") })
            Button(onClick = { onEnter(name) }, modifier = Modifier.fillMaxWidth()) { Text("ورود آزمایشی") }
            Text("این نسخه فقط برای آزمایش ۱۰ قدم اول است. ورود با رمز، تأیید شماره موبایل و حساب واقعی پس از راه‌اندازی سرور فعال می‌شوند.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun Onboarding(name: String, onDone: () -> Unit) {
    var step by rememberSaveable { mutableIntStateOf(0) }
    val headings = listOf("سازمان و حامی", "اطلاعات اولیه", "آشنایی با برنامه", "هدف روز اول", "اولین مأموریت", "راه ارتباط با حامی")
    val descriptions = listOf(
        "سازمان نمونه و حامی نمونه برای نمایش مسیر عضویت در نظر گرفته شده‌اند. اتصال واقعی پس از راه‌اندازی سرور انجام می‌شود.",
        "نام نمایشی شما ثبت شده است. اطلاعات تکمیلی در نسخه متصل به حساب کاربری مدیریت می‌شوند.",
        "خانه مهم‌ترین اقدام بعدی را نشان می‌دهد؛ مرکز اقدامات فهرست کارها و گزارش روزانه نتایج را نگه می‌دارد.",
        "اولین هدف پیشنهادی: یک ارتباط واقعی برقرار کن و نتیجه‌اش را ثبت کن.",
        "در مرکز اقدامات، مأموریت آغازین آماده است. بعد از راه‌اندازی می‌توانی آن را انجام دهی.",
        "در نسخه آزمایشی ارتباط واقعی با حامی فعال نیست و فقط ساختار آن نمایش داده می‌شود."
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.Center) {
        ScreenHeading("خوش آمدی، $name", "ورود و راه‌اندازی عضو جدید")
        Spacer(Modifier.height(22.dp))
        LinearProgressIndicator(progress = { (step + 1) / 6f }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(22.dp))
        InfoCard {
            Text("مرحله ${step + 1} از ۶", color = LegacyTeal, style = MaterialTheme.typography.labelLarge)
            Text(headings[step], style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(descriptions[step], style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(12.dp))
            Button(onClick = { if (step == 5) onDone() else step++ }, modifier = Modifier.fillMaxWidth()) {
                Text(if (step == 5) "ورود به صفحه اصلی" else "مرحله بعد")
            }
            if (step > 0) TextButton(onClick = { step-- }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("مرحله قبل") }
        }
        Spacer(Modifier.height(18.dp))
        Text("قدم بعدی همیشه مشخص است.", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun HomeScreen(name: String, tasks: List<TaskRecord>, activities: List<ActivityRecord>, onGoTasks: () -> Unit, onGoFocus: () -> Unit, onGoReport: () -> Unit) {
    val pending = tasks.filter { it.status != TaskStatus.COMPLETED.name && it.status != TaskStatus.CANCELLED.name }
    val today = System.currentTimeMillis()
    val todayActivity = activities.count { it.createdAt / 86_400_000L == today / 86_400_000L }
    val completeCount = tasks.size - pending.size
    ScreenHeading("سلام، $name!", "امروز هم یک قدم جلوتر برو")
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, LegacyTeal.copy(alpha = .25f))) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.TrackChanges, contentDescription = null, tint = LegacyTeal)
                Text("اقدام بعدی من", fontWeight = FontWeight.Bold)
            }
            if (pending.isNotEmpty()) {
                Text(pending.first().title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("مهم‌ترین کار فعلی بر اساس اولویت و مهلت", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(onClick = onGoFocus, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("شروع تمرکز")
                }
            } else {
                Text("همه کارها انجام شده‌اند!", fontWeight = FontWeight.Medium)
                Button(onClick = onGoTasks, modifier = Modifier.fillMaxWidth()) { Text("برنامه‌ریزی اقدام تازه") }
            }
        }
    }
    InfoCard {
        Text("خلاصه امروز", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatsTile("اقدام باقی‌مانده", pending.size.toString(), Modifier.weight(1f))
            StatsTile("فعالیت امروز", todayActivity.toString(), Modifier.weight(1f))
        }
        LinearProgressIndicator(progress = { if (tasks.isEmpty()) 0f else completeCount.toFloat() / tasks.size }, modifier = Modifier.fillMaxWidth())
        Text("${completeCount.coerceAtLeast(0)} کار از ${tasks.size} کار تکمیل شده", style = MaterialTheme.typography.bodySmall)
    }
    InfoCard {
        Text("برنامه نزدیک", fontWeight = FontWeight.Bold)
        pending.take(3).forEach { task ->
            HorizontalDivider()
            Text("• ${task.title}", style = MaterialTheme.typography.bodyMedium)
        }
        OutlinedButton(onClick = onGoTasks, modifier = Modifier.fillMaxWidth()) { Text("مشاهده مرکز اقدامات") }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedButton(onClick = onGoReport, modifier = Modifier.weight(1f)) { Text("گزارش روزانه") }
        OutlinedButton(onClick = onGoTasks, modifier = Modifier.weight(1f)) { Text("اقدام جدید") }
    }
    Text("پاداش و امتیاز فقط بعد از اعتبارسنجی واقعی در سرور فعال خواهند شد.", color = MaterialTheme.colorScheme.onSurfaceVariant,
        style = MaterialTheme.typography.bodySmall)
}

@Composable
private fun TasksScreen(tasks: List<TaskRecord>, steps: List<TaskStepRecord>, vm: LegacyViewModel) {
    var showNew by rememberSaveable { mutableStateOf(false) }
    var filter by rememberSaveable { mutableStateOf("همه") }
    var expandedTask by rememberSaveable { mutableLongStateOf(-1L) }
    ScreenHeading("مرکز اقدامات", "کارهای شخصی، سازمانی و حمایتی")
    Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Default.Add, contentDescription = null)
        Text("اقدام جدید")
    }
    val filters = listOf("همه", "آماده", "انجام‌شده")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        filters.forEach { item ->
            FilterChip(selected = filter == item, onClick = { filter = item }, label = { Text(item) })
        }
    }
    val filtered = tasks.filter {
        when (filter) {
            "آماده" -> it.status != TaskStatus.COMPLETED.name
            "انجام‌شده" -> it.status == TaskStatus.COMPLETED.name
            else -> true
        }
    }
    if (filtered.isEmpty()) InfoCard { Text("هنوز اقدامی در این بخش وجود ندارد.") }
    filtered.forEach { task ->
        val taskSteps = steps.filter { it.taskId == task.id }
        val finished = task.status == TaskStatus.COMPLETED.name
        InfoCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (finished) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                    contentDescription = null, tint = if (finished) LegacyTeal else MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(task.title, fontWeight = FontWeight.Bold)
                    Text("${TaskKind.valueOf(task.kind).label} • ${TaskPriority.valueOf(task.priority).label} • ${labelTime(task.dueAt)}",
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { expandedTask = if (expandedTask == task.id) -1L else task.id }) {
                    Icon(Icons.Default.ExpandMore, contentDescription = "جزئیات")
                }
            }
            if (expandedTask == task.id) {
                if (taskSteps.isNotEmpty()) {
                    Text("مراحل انجام", fontWeight = FontWeight.Medium)
                    taskSteps.forEach { step ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            Checkbox(checked = step.done, enabled = !finished, onCheckedChange = { vm.markStep(step.id, it) })
                            Text(step.title)
                        }
                    }
                }
                Text("تکرار: ${RepeatRule.valueOf(task.repeatRule).label}", style = MaterialTheme.typography.bodySmall)
                if (!finished) {
                    val canComplete = taskSteps.all { it.done }
                    Button(onClick = { vm.setTaskStatus(task, TaskStatus.COMPLETED) }, enabled = canComplete, modifier = Modifier.fillMaxWidth()) {
                        Text("ثبت تکمیل اقدام")
                    }
                    if (!canComplete) Text("برای تکمیل، ابتدا مراحل را علامت بزن.", style = MaterialTheme.typography.bodySmall)
                } else Text("این اقدام تکمیل شده است.", color = LegacyTeal)
            }
        }
    }
    if (showNew) AddTaskDialog(onDismiss = { showNew = false }, onCreate = { title, priority, kind, rule, offset, stepsText ->
        vm.addTask(title, priority, kind, rule, System.currentTimeMillis() + offset * 86_400_000L, stepsText)
        showNew = false
    })
}

@Composable
private fun AddTaskDialog(
    onDismiss: () -> Unit,
    onCreate: (String, TaskPriority, TaskKind, RepeatRule, Long, String) -> Unit
) {
    var title by rememberSaveable { mutableStateOf("") }
    var steps by rememberSaveable { mutableStateOf("") }
    var priority by remember { mutableStateOf(TaskPriority.NORMAL) }
    var kind by remember { mutableStateOf(TaskKind.PERSONAL) }
    var repeat by remember { mutableStateOf(RepeatRule.NONE) }
    var dayOffset by remember { mutableLongStateOf(0L) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("اقدام جدید") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("عنوان اقدام") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = steps, onValueChange = { steps = it }, label = { Text("مراحل (هر خط یک مرحله)") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                Text("اولویت", fontWeight = FontWeight.Medium)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TaskPriority.entries.forEach { option ->
                        FilterChip(selected = priority == option, onClick = { priority = option }, label = { Text(option.label) })
                    }
                }
                Text("نوع اقدام", fontWeight = FontWeight.Medium)
                DropdownChoice(kind.label, TaskKind.entries.map { it.label }, onSelect = { kind = TaskKind.entries[it] })
                Text("تکرار", fontWeight = FontWeight.Medium)
                DropdownChoice(repeat.label, RepeatRule.entries.map { it.label }, onSelect = { repeat = RepeatRule.entries[it] })
                Text("مهلت", fontWeight = FontWeight.Medium)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf(0L to "امروز", 1L to "فردا", 7L to "هفته بعد").forEach { (num, name) ->
                        FilterChip(selected = dayOffset == num, onClick = { dayOffset = num }, label = { Text(name) })
                    }
                }
            }
        },
        confirmButton = { TextButton(enabled = title.isNotBlank(), onClick = { onCreate(title, priority, kind, repeat, dayOffset, steps) }) { Text("ذخیره") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
private fun DropdownChoice(current: String, options: List<String>, onSelect: (Int) -> Unit) {
    var opened by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { opened = true }) { Text(current); Icon(Icons.Default.ArrowDropDown, contentDescription = null) }
        DropdownMenu(expanded = opened, onDismissRequest = { opened = false }) {
            options.forEachIndexed { index, label ->
                DropdownMenuItem(text = { Text(label) }, onClick = { onSelect(index); opened = false })
            }
        }
    }
}

@Composable
private fun FocusScreen(tasks: List<TaskRecord>, focusRecords: List<FocusRecord>, vm: LegacyViewModel) {
    val available = tasks.filter { it.status != TaskStatus.COMPLETED.name && it.status != TaskStatus.CANCELLED.name }
    var selectedId by rememberSaveable { mutableLongStateOf(-1L) }
    var minutes by rememberSaveable { mutableIntStateOf(25) }
    var elapsed by rememberSaveable { mutableIntStateOf(0) }
    var isRunning by rememberSaveable { mutableStateOf(false) }
    var showingResult by rememberSaveable { mutableStateOf(false) }
    var outcome by rememberSaveable { mutableStateOf("ادامه دارد") }
    var note by rememberSaveable { mutableStateOf("") }
    var startTime by remember { mutableLongStateOf(0L) }
    var accumulated by remember { mutableIntStateOf(0) }
    val chosen = available.find { it.id == selectedId }
    val remaining = (minutes * 60 - elapsed).coerceAtLeast(0)

    LaunchedEffect(isRunning) {
        if (isRunning) {
            startTime = SystemClock.elapsedRealtime()
            while (true) {
                elapsed = (accumulated + ((SystemClock.elapsedRealtime() - startTime) / 1000L).toInt()).coerceAtMost(minutes * 60)
                if (elapsed >= minutes * 60) {
                    isRunning = false
                    accumulated = elapsed
                    break
                }
                delay(250)
            }
        }
    }

    ScreenHeading("حالت تمرکز", "یک مأموریت، یک زمان مشخص، یک نتیجه واقعی")
    InfoCard {
        Text("مأموریت فعلی", fontWeight = FontWeight.Bold)
        if (available.isEmpty()) Text("برای شروع، ابتدا یک اقدام در مرکز اقدامات ایجاد کن.")
        else DropdownChoice(chosen?.title ?: "انتخاب مأموریت", available.map { it.title }, onSelect = {
            selectedId = available[it].id; elapsed = 0; accumulated = 0; isRunning = false
        })
        Text("مدت تمرکز", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(15,25,45).forEach { duration ->
                FilterChip(selected = minutes == duration, enabled = !isRunning && elapsed == 0,
                    onClick = { minutes = duration }, label = { Text("$duration دقیقه") })
            }
        }
    }
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(24.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(if (isRunning) "در حال تمرکز" else if (elapsed > 0) "جلسه متوقف شده" else "آماده شروع",
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            CircularProgressIndicator(progress = { if (minutes == 0) 0f else elapsed.toFloat() / (minutes * 60f) },
                modifier = Modifier.size(120.dp), strokeWidth = 8.dp)
            Text("%02d:%02d".format(remaining / 60, remaining % 60), style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold)
            Text(chosen?.title ?: "یک مأموریت انتخاب کن", textAlign = TextAlign.Center)
            if (!isRunning) {
                Button(onClick = { isRunning = true }, enabled = chosen != null && remaining > 0,
                    modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Text(if (elapsed == 0) "شروع تمرکز" else "ادامه تمرکز")
                }
            } else {
                OutlinedButton(onClick = { accumulated = elapsed; isRunning = false }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Pause, contentDescription = null)
                    Text("توقف موقت")
                }
            }
            OutlinedButton(onClick = {
                if (isRunning) { accumulated = elapsed; isRunning = false }
                showingResult = true
            }, enabled = chosen != null && elapsed > 0, modifier = Modifier.fillMaxWidth()) { Text("پایان و ثبت نتیجه") }
        }
    }
    InfoCard {
        Text("جلسه‌های قبلی", fontWeight = FontWeight.Bold)
        if (focusRecords.isEmpty()) Text("هنوز جلسه‌ای ثبت نشده است.")
        focusRecords.take(3).forEach { record ->
            Text("• ${record.secondsSpent / 60} دقیقه و ${record.secondsSpent % 60} ثانیه • ${record.result}")
        }
        Text("برای موسیقی تمرکز در نسخه بعدی، صدای دارای مجوز اضافه خواهد شد. زمان‌سنج این نسخه واقعی است، ولی بازیابی جلسه پس از بسته‌شدن کامل برنامه هنوز پیاده نشده است.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    if (showingResult) AlertDialog(onDismissRequest = { showingResult = false },
        title = { Text("ثبت نتیجه جلسه") }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("زمان واقعی: ${elapsed / 60} دقیقه و ${elapsed % 60} ثانیه")
                DropdownChoice(outcome, listOf("تکمیل شد", "ادامه دارد", "بدون نتیجه"), onSelect = {
                    outcome = listOf("تکمیل شد", "ادامه دارد", "بدون نتیجه")[it]
                })
                OutlinedTextField(value = note, onValueChange = { note = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("توضیح نتیجه (اختیاری)") })
                Text("ثبت تمرکز به‌تنهایی امتیاز ایجاد نمی‌کند.", style = MaterialTheme.typography.bodySmall)
            }
        }, confirmButton = {
            TextButton(onClick = {
                vm.saveFocus(selectedId.takeIf { it > 0 }, elapsed, outcome, note, outcome == "تکمیل شد")
                elapsed = 0; accumulated = 0; note = ""; isRunning = false; showingResult = false; selectedId = -1L
            }) { Text("ثبت نتیجه") }
        }, dismissButton = { TextButton(onClick = { showingResult = false }) { Text("بازگشت") } })
}

@Composable
private fun ActivitiesScreen(activities: List<ActivityRecord>, vm: LegacyViewModel) {
    var showNew by rememberSaveable { mutableStateOf(false) }
    var filter by rememberSaveable { mutableStateOf("همه") }
    val all = activities.filter { filter == "همه" || ActivityKind.valueOf(it.kind).label == filter }
    val today = System.currentTimeMillis()
    val todayCount = activities.count { it.createdAt / 86_400_000L == today / 86_400_000L }
    val verifiedCount = activities.count { it.validation == "VERIFIED" }
    ScreenHeading("گزارش فعالیت‌های روزانه", "اقدام‌های واقعی و نتیجه هر فعالیت")
    InfoCard {
        Text("وضعیت ثبت فعالیت‌ها", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatsTile("ثبت امروز", todayCount.toString(), Modifier.weight(1f))
            StatsTile("تأییدشده", verifiedCount.toString(), Modifier.weight(1f))
        }
        Text("فعالیت‌های این نسخه خوداظهاری هستند و هنوز اعتبارسنجی سروری ندارند.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Default.Add, contentDescription = null)
        Text("ثبت فعالیت")
    }
    Text("دسته‌های فعالیت", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    ActivityKind.entries.chunked(4).forEach { row ->
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            row.forEach { kind ->
                Card(modifier = Modifier.weight(1f).clickable { filter = if (filter == kind.label) "همه" else kind.label },
                    shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(
                        containerColor = if (filter == kind.label) MaterialTheme.colorScheme.primaryContainer else Color.White)) {
                    Column(Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(kind.label, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                        Text(activities.count { it.kind == kind.name }.toString(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("تاریخچه فعالیت‌ها", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (filter != "همه") TextButton(onClick = { filter = "همه" }) { Text("نمایش همه") }
    }
    if (all.isEmpty()) InfoCard { Text("برای این دسته، فعالیتی ثبت نشده است.") }
    all.forEach { a ->
        InfoCard {
            Text(a.title, fontWeight = FontWeight.Medium)
            Text("${ActivityKind.valueOf(a.kind).label} • ${a.outcome}", style = MaterialTheme.typography.bodySmall)
            Text("${labelTime(a.createdAt)} • ${if (a.validation == "VERIFIED") "تأییدشده" else "ثبت اولیه (تأییدنشده)"}",
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    if (showNew) AddActivityDialog(onDismiss = { showNew = false }, onCreate = { kind, title, outcome ->
        vm.addActivity(kind, title, outcome); showNew = false
    })
}

@Composable
private fun AddActivityDialog(onDismiss: () -> Unit, onCreate: (ActivityKind, String, String) -> Unit) {
    var kind by remember { mutableStateOf(ActivityKind.CONNECTION) }
    var title by rememberSaveable { mutableStateOf("") }
    var outcome by rememberSaveable { mutableStateOf("انجام شد") }
    val restricted = kind == ActivityKind.SALE || kind == ActivityKind.JOIN
    AlertDialog(onDismissRequest = onDismiss, title = { Text("ثبت سریع فعالیت") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("نوع فعالیت", fontWeight = FontWeight.Medium)
                DropdownChoice(kind.label, ActivityKind.entries.map { it.label }, onSelect = { kind = ActivityKind.entries[it] })
                if (restricted) {
                    Text("فروش و عضویت قطعی فقط از طریق سفارش یا ثبت‌نام تأییدشده سرور وارد گزارش می‌شوند. این قسمت هنوز به سرور متصل نیست.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                } else {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("شرح کوتاه اقدام") }, modifier = Modifier.fillMaxWidth())
                    DropdownChoice(outcome, listOf("انجام شد", "نیاز به پیگیری", "بدون نتیجه"), onSelect = {
                        outcome = listOf("انجام شد", "نیاز به پیگیری", "بدون نتیجه")[it]
                    })
                }
            }
        }, confirmButton = {
            TextButton(enabled = !restricted && title.isNotBlank(), onClick = { onCreate(kind, title, outcome) }) { Text("ثبت اولیه") }
        }, dismissButton = { TextButton(onClick = onDismiss) { Text("بستن") } })
}

@Composable
private fun ProfileScreen(name: String, tasks: List<TaskRecord>, activities: List<ActivityRecord>, focusRecords: List<FocusRecord>, onSignOut: () -> Unit) {
    val completed = tasks.count { it.status == TaskStatus.COMPLETED.name }
    ScreenHeading("پروفایل ۳۶۰ درجه", "تصویر یکپارچه مسیر رشد عضو")
    InfoCard {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(60.dp), tint = LegacyTeal)
            Column {
                Text(name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("سازمان نمونه • عضو • حامی نمونه", style = MaterialTheme.typography.bodySmall)
                Text("رتبه و امتیاز رسمی: پس از اتصال سرور", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        HorizontalDivider()
        Text("اقدام بعدی", style = MaterialTheme.typography.labelLarge, color = LegacyTeal)
        Text(tasks.firstOrNull { it.status != TaskStatus.COMPLETED.name }?.title ?: "برنامه‌ریزی یک اقدام جدید", fontWeight = FontWeight.Medium)
    }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatsTile("کار تکمیل‌شده", completed.toString(), Modifier.weight(1f))
        StatsTile("فعالیت ثبت‌شده", activities.size.toString(), Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatsTile("جلسه تمرکز", focusRecords.size.toString(), Modifier.weight(1f))
        StatsTile("روزهای استمرار", "—", Modifier.weight(1f))
    }
    InfoCard {
        Text("شبکه و سطح دسترسی", fontWeight = FontWeight.Bold)
        Text("عضویت نمونه: یک سازمان و یک حامی. ساختار بالاسری، زیرمجموعه و دسترسی‌ها در مدل مرکزی تعریف شده‌اند؛ اتصال به داده واقعی سازمان در مرحله سرور انجام می‌شود.")
    }
    InfoCard {
        Text("آموزش، اهداف و دستاوردها", fontWeight = FontWeight.Bold)
        Text("جایگاه این بخش‌ها در پروفایل مشخص است. امکانات کاملشان در قدم‌های بعدی ساخته می‌شود.")
    }
    OutlinedButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Default.Logout, contentDescription = null)
        Spacer(Modifier.width(6.dp))
        Text("خروج از نسخه آزمایشی")
    }
    Text("نسخه آزمایشی آفلاین؛ بدون حساب واقعی، سرور، پیام‌رسان و فروشگاه.",
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}
