package ir.legacy.superapp

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

@Entity(tableName = "tasks")
data class TaskRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val kind: String = "PERSONAL",
    val priority: String = "NORMAL",
    val status: String = "READY",
    val repeatRule: String = "NONE",
    val dueAt: Long = System.currentTimeMillis(),
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "task_steps")
data class TaskStepRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskId: Long,
    val title: String,
    val done: Boolean = false
)

@Entity(tableName = "activities")
data class ActivityRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String,
    val title: String,
    val outcome: String,
    val validation: String = "SELF_REPORTED",
    val taskId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "focus_sessions")
data class FocusRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskId: Long?,
    val secondsSpent: Int,
    val result: String,
    val note: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface LocalDao {
    @Query("SELECT * FROM tasks ORDER BY CASE priority WHEN 'URGENT' THEN 0 WHEN 'IMPORTANT' THEN 1 ELSE 2 END, dueAt ASC, createdAt DESC")
    fun observeTasks(): Flow<List<TaskRecord>>

    @Query("SELECT * FROM task_steps ORDER BY id ASC")
    fun observeSteps(): Flow<List<TaskStepRecord>>

    @Query("SELECT * FROM activities ORDER BY createdAt DESC, id DESC")
    fun observeActivities(): Flow<List<ActivityRecord>>

    @Query("SELECT * FROM focus_sessions ORDER BY createdAt DESC")
    fun observeFocusSessions(): Flow<List<FocusRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskRecord): Long

    @Insert
    suspend fun insertStep(step: TaskStepRecord)

    @Insert
    suspend fun insertActivity(activity: ActivityRecord)

    @Insert
    suspend fun insertFocus(focus: FocusRecord)

    @Query("UPDATE task_steps SET done = :done WHERE id = :id")
    suspend fun markStep(id: Long, done: Boolean)

    @Query("UPDATE tasks SET status = :status WHERE id = :id")
    suspend fun changeTaskStatus(id: Long, status: String)

    @Query("SELECT COUNT(*) FROM tasks")
    suspend fun taskCount(): Int

    @Query("SELECT * FROM tasks WHERE id = :id LIMIT 1")
    suspend fun findTask(id: Long): TaskRecord?

    @Query("SELECT * FROM task_steps WHERE taskId = :taskId")
    suspend fun findTaskSteps(taskId: Long): List<TaskStepRecord>

    @Transaction
    suspend fun createWithSteps(task: TaskRecord, steps: List<String>) {
        val id = insertTask(task)
        steps.filter { it.isNotBlank() }.forEach { insertStep(TaskStepRecord(taskId = id, title = it.trim())) }
    }
}

@Database(entities = [TaskRecord::class, TaskStepRecord::class, ActivityRecord::class, FocusRecord::class], version = 1, exportSchema = false)
abstract class LegacyDatabase : RoomDatabase() {
    abstract fun dao(): LocalDao

    companion object {
        @Volatile private var instance: LegacyDatabase? = null
        fun get(context: Context): LegacyDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, LegacyDatabase::class.java, "legacy_local.db")
                .build().also { instance = it }
        }
    }
}

private val Context.sessionPreferences by preferencesDataStore("legacy_session")

class SessionStore(private val context: Context) {
    private val signedInKey = booleanPreferencesKey("demo_signed_in")
    private val onboardingKey = booleanPreferencesKey("onboarding_done")
    private val nameKey = stringPreferencesKey("demo_name")

    val signedIn: Flow<Boolean> = context.sessionPreferences.data.map { it[signedInKey] ?: false }
    val onboardingDone: Flow<Boolean> = context.sessionPreferences.data.map { it[onboardingKey] ?: false }
    val displayName: Flow<String> = context.sessionPreferences.data.map { it[nameKey] ?: "عضو جدید" }

    suspend fun enterDemo(name: String) = context.sessionPreferences.edit {
        it[signedInKey] = true
        it[nameKey] = name.ifBlank { "عضو جدید" }
    }

    suspend fun completeOnboarding() = context.sessionPreferences.edit { it[onboardingKey] = true }
    suspend fun signOut() = context.sessionPreferences.edit { it[signedInKey] = false }
}
