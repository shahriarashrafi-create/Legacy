package ir.legacy.superapp

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ir.legacy.core.ActivityKind
import ir.legacy.core.RepeatRule
import ir.legacy.core.TaskKind
import ir.legacy.core.TaskPriority
import ir.legacy.core.TaskStatus
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

class LegacyViewModel(application: Application) : AndroidViewModel(application) {
    private val store = SessionStore(application)
    private val dao = LegacyDatabase.get(application).dao()
    private val sharing = SharingStarted.WhileSubscribed(5_000)

    val signedIn = store.signedIn.stateIn(viewModelScope, sharing, false)
    val onboardingDone = store.onboardingDone.stateIn(viewModelScope, sharing, false)
    val displayName = store.displayName.stateIn(viewModelScope, sharing, "عضو جدید")
    val tasks = dao.observeTasks().stateIn(viewModelScope, sharing, emptyList())
    val steps = dao.observeSteps().stateIn(viewModelScope, sharing, emptyList())
    val activities = dao.observeActivities().stateIn(viewModelScope, sharing, emptyList())
    val focusSessions = dao.observeFocusSessions().stateIn(viewModelScope, sharing, emptyList())

    fun signInDemo(name: String) = viewModelScope.launch {
        store.enterDemo(name.trim())
        if (dao.taskCount() == 0) {
            dao.createWithSteps(
                TaskRecord(title = "برنامه‌ریزی فعالیت امروز", priority = TaskPriority.IMPORTANT.name),
                listOf("انتخاب مهم‌ترین اقدام", "تعیین زمان انجام")
            )
            dao.createWithSteps(
                TaskRecord(title = "ثبت اولین ارتباط واقعی", kind = TaskKind.PERSONAL.name),
                listOf("برقراری ارتباط", "ثبت نتیجه")
            )
            dao.createWithSteps(TaskRecord(title = "مرور آموزش آغازین", kind = TaskKind.ORGANIZATION.name), emptyList())
        }
    }

    fun finishOnboarding() = viewModelScope.launch { store.completeOnboarding() }
    fun signOut() = viewModelScope.launch { store.signOut() }

    fun addTask(title: String, priority: TaskPriority, kind: TaskKind, repeat: RepeatRule, dueAt: Long, checklist: String) =
        viewModelScope.launch {
            if (title.isNotBlank()) dao.createWithSteps(
                TaskRecord(title = title.trim(), priority = priority.name, kind = kind.name, repeatRule = repeat.name, dueAt = dueAt),
                checklist.lines().map { it.trim() }.filter { it.isNotBlank() }
            )
        }

    fun markStep(id: Long, checked: Boolean) = viewModelScope.launch { dao.markStep(id, checked) }

    fun setTaskStatus(task: TaskRecord, status: TaskStatus) = viewModelScope.launch {
        dao.changeTaskStatus(task.id, status.name)
        if (status == TaskStatus.COMPLETED) {
            val nextDate = Calendar.getInstance().apply {
                timeInMillis = task.dueAt
                when (RepeatRule.valueOf(task.repeatRule)) {
                    RepeatRule.DAILY -> add(Calendar.DAY_OF_YEAR, 1)
                    RepeatRule.WEEKLY -> add(Calendar.DAY_OF_YEAR, 7)
                    RepeatRule.MONTHLY -> add(Calendar.MONTH, 1)
                    RepeatRule.NONE -> return@apply
                }
            }.timeInMillis
            if (task.repeatRule != RepeatRule.NONE.name) {
                val stepTitles = dao.findTaskSteps(task.id).map { it.title }
                dao.createWithSteps(task.copy(id = 0, status = TaskStatus.READY.name, dueAt = nextDate, createdAt = System.currentTimeMillis()), stepTitles)
            }
        }
    }

    fun addActivity(kind: ActivityKind, title: String, outcome: String) = viewModelScope.launch {
        if (title.isNotBlank() && kind != ActivityKind.SALE && kind != ActivityKind.JOIN) {
            dao.insertActivity(ActivityRecord(kind = kind.name, title = title.trim(), outcome = outcome))
        }
    }

    fun saveFocus(taskId: Long?, seconds: Int, result: String, note: String, finishTask: Boolean) = viewModelScope.launch {
        dao.insertFocus(FocusRecord(taskId = taskId, secondsSpent = seconds, result = result, note = note.trim()))
        if (finishTask && taskId != null) {
            val linkedTask = dao.findTask(taskId)
            if (linkedTask != null && linkedTask.status != TaskStatus.COMPLETED.name) {
                setTaskStatus(linkedTask, TaskStatus.COMPLETED)
            }
        }
    }
}
