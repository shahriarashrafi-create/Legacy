package ir.legacy.core

/** The first ten milestones' shared domain vocabulary. */
enum class MemberRole(val label: String) {
    MEMBER("عضو"), LEADER("رهبر"), ADMIN("مدیر"), HEAD("مدیر ارشد سازمان"), PLATFORM_ADMIN("مدیر سامانه")
}

enum class TaskKind(val label: String) {
    PERSONAL("شخصی"), ORGANIZATION("سازمانی"), SUPPORT("حمایتی"), AUTOMATIC("خودکار")
}

enum class TaskPriority(val label: String) {
    NORMAL("عادی"), IMPORTANT("مهم"), URGENT("فوری")
}

enum class TaskStatus(val label: String) {
    READY("آماده"), ACTIVE("در حال انجام"), REVIEW("در انتظار بررسی"), COMPLETED("تکمیل‌شده"), CANCELLED("لغوشده")
}

enum class RepeatRule(val label: String) {
    NONE("بدون تکرار"), DAILY("روزانه"), WEEKLY("هفتگی"), MONTHLY("ماهانه")
}

enum class ActivityKind(val label: String) {
    CONNECTION("ارتباط‌سازی"), INVITATION("دعوت"), PRESENTATION("معرفی"), FOLLOWUP("پیگیری"),
    SALE("فروش"), CUSTOMER("مشتری"), JOIN("ثبت‌نام"), SUPPORT("حمایت")
}

data class Membership(
    val accountId: String,
    val organizationId: String,
    val organizationName: String,
    val sponsorId: String?,
    val sponsorName: String?,
    val role: MemberRole
)

/** The server must enforce these rules when the backend is implemented. */
object AccessRules {
    fun canAssignSupportTask(actor: Membership, target: Membership, isInOwnBranch: Boolean): Boolean =
        actor.organizationId == target.organizationId && (
            actor.role in setOf(MemberRole.ADMIN, MemberRole.HEAD, MemberRole.PLATFORM_ADMIN) ||
                (actor.role == MemberRole.LEADER && isInOwnBranch) ||
                target.sponsorId == actor.accountId
            )

    fun canViewPrivateCustomerData(actor: Membership, owner: Membership): Boolean =
        actor.accountId == owner.accountId || actor.role == MemberRole.PLATFORM_ADMIN
}
