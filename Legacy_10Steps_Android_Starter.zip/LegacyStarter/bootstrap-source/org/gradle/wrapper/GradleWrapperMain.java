package org.gradle.wrapper;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Simple, auditable bootstrap for the pinned official Gradle distribution.
 * This is NOT the official Gradle Wrapper JAR. The official wrapper can replace it later.
 * Included so the GitHub workflow can run without preinstalled Gradle.
 */
public final class GradleWrapperMain {
    public static void main(String[] args) throws Exception {
        Path root = Path.of(System.getProperty("legacy.wrapper.root", ".")).toAbsolutePath().normalize();
        Properties properties = new Properties();
        try (InputStream in = Files.newInputStream(root.resolve("gradle/wrapper/gradle-wrapper.properties"))) {
            properties.load(in);
        }
        String url = properties.getProperty("distributionUrl");
        if (!"https://services.gradle.org/distributions/gradle-8.9-bin.zip".equals(url)) {
            throw new IllegalArgumentException("Unexpected Gradle distribution URL: " + url);
        }
        Path cache = Path.of(System.getProperty("user.home"), ".gradle", "legacy-bootstrap", "gradle-8.9");
        Path executable = cache.resolve("bin/gradle");
        if (!Files.isRegularFile(executable)) {
            Path workspace = Files.createTempDirectory("legacy-gradle-");
            try {
                Path zip = workspace.resolve("gradle-8.9-bin.zip");
                System.out.println("Downloading Gradle 8.9 from the official distribution site...");
                HttpClient client = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.ALWAYS).build();
                HttpRequest request = HttpRequest.newBuilder(URI.create(url)).GET().build();
                HttpResponse<Path> response = client.send(request, HttpResponse.BodyHandlers.ofFile(zip));
                if (response.statusCode() != 200) {
                    throw new IOException("Gradle download failed with HTTP " + response.statusCode());
                }
                try (ZipInputStream zin = new ZipInputStream(Files.newInputStream(zip))) {
                    ZipEntry entry;
                    while ((entry = zin.getNextEntry()) != null) {
                        Path destination = workspace.resolve(entry.getName()).normalize();
                        if (!destination.startsWith(workspace)) throw new IOException("Unsafe ZIP entry");
                        if (entry.isDirectory()) {
                            Files.createDirectories(destination);
                        } else {
                            Files.createDirectories(destination.getParent());
                            Files.copy(zin, destination, StandardCopyOption.REPLACE_EXISTING);
                        }
                        zin.closeEntry();
                    }
                }
                Path unpacked = workspace.resolve("gradle-8.9");
                if (!Files.isRegularFile(unpacked.resolve("bin/gradle"))) {
                    throw new IOException("Gradle executable missing from official distribution");
                }
                Files.createDirectories(cache.getParent());
                if (!Files.exists(cache)) {
                    try {
                        Files.move(unpacked, cache);
                    } catch (IOException moveError) {
                        // A concurrent process may have installed it while we unpacked.
                        if (!Files.exists(cache.resolve("bin/gradle"))) throw moveError;
                    }
                }
            } finally {
                deleteRecursively(workspace);
            }
        }
        executable.toFile().setExecutable(true);
        List<String> command = new ArrayList<>();
        command.add(executable.toString());
        for (String arg : args) command.add(arg);
        Process process = new ProcessBuilder(command).inheritIO().start();
        System.exit(process.waitFor());
    }

    private static void deleteRecursively(Path directory) throws IOException {
        if (!Files.exists(directory)) return;
        try (var paths = Files.walk(directory)) {
            for (Path path : paths.sorted(java.util.Comparator.reverseOrder()).toList()) Files.deleteIfExists(path);
        }
    }
}
