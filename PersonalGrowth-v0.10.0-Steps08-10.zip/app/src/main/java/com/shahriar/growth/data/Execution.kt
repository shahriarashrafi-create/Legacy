package com.shahriar.growth.data

import android.content.Context
import android.os.SystemClock
import android.provider.Settings
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName="focus_sessions", indices=[Index(value=["openSlot"],unique=true)])
data class FocusSession(@PrimaryKey val id:String=java.util.UUID.randomUUID().toString(), val taskId:String,
    val durationMs:Long, val accruedMs:Long=0, val anchorWall:Long=0, val anchorElapsed:Long=0,
    val boot:Int=0, val state:String="running", val createdAt:Long=System.currentTimeMillis(),
    val closedAt:Long?=null, val result:String?=null, val note:String="", val priority:Int=1, @ColumnInfo(defaultValue="0") val previousMs:Long=0, @ColumnInfo(defaultValue="0") val endAnnounced:Boolean=false, val openSlot:Int?=1)
@Entity(tableName="subtasks")
data class Subtask(@PrimaryKey val id:String=java.util.UUID.randomUUID().toString(),val taskId:String,val title:String,val required:Boolean=true,val checked:Boolean=false,val position:Long=System.currentTimeMillis())
@Entity(tableName="path_groups")
data class PathGroup(@PrimaryKey val id:String=java.util.UUID.randomUUID().toString(),val title:String,val position:Long=System.currentTimeMillis())
@Entity(tableName="missions")
data class Mission(@PrimaryKey val taskId:String,val groupId:String,val position:Long=System.currentTimeMillis())
@Entity(tableName="prerequisites",primaryKeys=["taskId","dependsOnId"])
data class Prerequisite(val taskId:String,val dependsOnId:String)
@Dao interface ExecutionDao {
    @Query("SELECT * FROM focus_sessions WHERE closedAt IS NULL LIMIT 1") fun observeActive():Flow<FocusSession?>
    @Query("SELECT * FROM focus_sessions WHERE closedAt IS NULL LIMIT 1") suspend fun active():FocusSession?
    @Query("SELECT * FROM focus_sessions WHERE taskId=:id ORDER BY createdAt DESC") fun sessions(id:String):Flow<List<FocusSession>>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(session:FocusSession)
    @Query("SELECT * FROM subtasks ORDER BY position,id") fun subtasks():Flow<List<Subtask>>
    @Query("SELECT * FROM subtasks WHERE taskId=:id ORDER BY position,id") suspend fun subtasksFor(id:String):List<Subtask>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun putSubtask(subtask:Subtask)
    @Query("DELETE FROM subtasks WHERE id=:id") suspend fun deleteSubtask(id:String)
    @Query("SELECT * FROM path_groups ORDER BY position,id") fun groups():Flow<List<PathGroup>>
    @Query("SELECT * FROM path_groups WHERE id=:id") suspend fun group(id:String):PathGroup?
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun putGroup(group:PathGroup)
    @Query("SELECT * FROM missions ORDER BY position,taskId") fun missions():Flow<List<Mission>>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun putMission(mission:Mission)
    @Query("DELETE FROM missions WHERE taskId=:id") suspend fun detach(id:String)
    @Query("SELECT * FROM prerequisites") fun prerequisites():Flow<List<Prerequisite>>
    @Query("SELECT * FROM prerequisites") suspend fun edges():List<Prerequisite>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun putEdge(edge:Prerequisite)
    @Query("DELETE FROM prerequisites WHERE taskId=:task AND dependsOnId=:dependency") suspend fun deleteEdge(task:String,dependency:String)
}
data class ClockReading(val wall:Long,val elapsed:Long,val boot:Int)
fun readClock(context:Context)=ClockReading(System.currentTimeMillis(),SystemClock.elapsedRealtime(),runCatching { Settings.Global.getInt(context.contentResolver,Settings.Global.BOOT_COUNT) }.getOrDefault(-1))
fun focusSpent(s:FocusSession,now:ClockReading):Long {
    val delta=if(s.state!="running")0L else if(s.boot>=0 && now.boot==s.boot && now.elapsed>=s.anchorElapsed)now.elapsed-s.anchorElapsed else (now.wall-s.anchorWall).coerceAtLeast(0)
    return (s.accruedMs+delta).coerceIn(0,s.durationMs)
}
fun wouldCycle(task:String,dependency:String,edges:List<Prerequisite>):Boolean {
    val seen=mutableSetOf<String>()
    fun visits(id:String):Boolean { if(id==task)return true;if(!seen.add(id))return false;return edges.filter{it.taskId==id}.any{visits(it.dependsOnId)} }
    return visits(dependency)
}
fun blocked(task:String,tasks:List<Task>,edges:List<Prerequisite>)=edges.filter{it.taskId==task}.any{edge->tasks.none{it.id==edge.dependsOnId && it.done}}
class ExecutionEngine(private val db:AppDatabase,private val context:Context) {
    private val dao get()=db.executionDao()
    private suspend fun requireReady(id:String) { dao.edges().filter{it.taskId==id}.forEach { require(db.taskDao().get(it.dependsOnId)?.done==true){"ابتدا پیش‌نیاز را انجام بده."} } }
    private suspend fun requireEditable(id:String) { require(dao.active()?.taskId!=id){"ساختار این کار تا بسته‌شدن جلسه تمرکز ثابت است."} }
    suspend fun start(id:String) = db.withTransaction {
        val active=dao.active();require(active==null || active.taskId==id){"ابتدا جلسه تمرکز باز را ادامه بده یا ببند."}
        if(active!=null)return@withTransaction
        val task=requireNotNull(db.taskDao().get(id));require(!task.done && !task.archived){"این کار برای تمرکز باز نیست."};requireReady(id)
        val now=readClock(context)
        if(task.failed)db.taskDao().put(task.copy(failed=false))
        dao.put(FocusSession(taskId=id,durationMs=(task.duration?:10)*60000L,anchorWall=now.wall,anchorElapsed=now.elapsed,boot=now.boot,priority=task.priority))
        db.taskDao().event(TaskEvent(taskId=id,description="شروع تمرکز"))
    }
    suspend fun tick()=db.withTransaction { val s=dao.active()?:return@withTransaction;val n=readClock(context);if(s.state=="running" && focusSpent(s,n)>=s.durationMs)dao.put(s.copy(accruedMs=s.durationMs,state="waiting")) }
    suspend fun claimEndSignal():Boolean = db.withTransaction { val s=dao.active()?:return@withTransaction false;if(s.state!="waiting" || s.endAnnounced)return@withTransaction false;dao.put(s.copy(endAnnounced=true));true }
    suspend fun toggle()=db.withTransaction {
        val s=dao.active()?:return@withTransaction;val now=readClock(context);val spent=focusSpent(s,now)
        if(spent>=s.durationMs){dao.put(s.copy(accruedMs=s.durationMs,state="waiting"));return@withTransaction}
        dao.put(s.copy(accruedMs=spent,state=if(s.state=="running")"paused" else "running",anchorWall=now.wall,anchorElapsed=now.elapsed,boot=now.boot))
    }
    suspend fun reset()=db.withTransaction {val s=dao.active()?:return@withTransaction;val n=readClock(context);dao.put(s.copy(previousMs=s.previousMs+focusSpent(s,n),endAnnounced=false,accruedMs=0,state="paused",anchorWall=n.wall,anchorElapsed=n.elapsed,boot=n.boot));db.taskDao().event(TaskEvent(taskId=s.taskId,description="شروع دوباره ساعت تمرکز پس از ${focusSpent(s,readClock(context))/1000} ثانیه؛ چک‌لیست حفظ شد"))}
    suspend fun closeReady()=db.withTransaction {val s=dao.active()?:return@withTransaction;dao.put(s.copy(accruedMs=focusSpent(s,readClock(context)),state="closed",openSlot=null,closedAt=System.currentTimeMillis(),result="ready"));db.taskDao().event(TaskEvent(taskId=s.taskId,description="بستن تلاش و بازگشت به آماده"))}
    suspend fun complete(id:String,value:Boolean) {if(value)finish(id,true) else db.withTransaction {val t=db.taskDao().get(id)?:return@withTransaction;requireEditable(id);if(!t.done && !t.failed)return@withTransaction;db.taskDao().put(t.copy(done=false,failed=false,completedAt=null,updatedAt=System.currentTimeMillis()));db.taskDao().event(TaskEvent(taskId=id,description="بازگشایی کار"))} }
    suspend fun finish(id:String,success:Boolean)=db.withTransaction {
        val t=db.taskDao().get(id)?:return@withTransaction
        require(!t.archived){"کار بایگانی شده است."}
        if(t.done && success)return@withTransaction
        if(success){requireReady(id);require(dao.subtasksFor(id).none{it.required && !it.checked}){"زیرکارهای اجباری را کامل کن."}}
        val s=dao.active()?.takeIf{it.taskId==id}
        if(s!=null)dao.put(s.copy(accruedMs=focusSpent(s,readClock(context)),state="closed",openSlot=null,closedAt=System.currentTimeMillis(),result=if(success)"success" else "failed"))
        db.taskDao().put(t.copy(done=success,failed=!success,completedAt=if(success)System.currentTimeMillis() else null,updatedAt=System.currentTimeMillis()))
        db.taskDao().event(TaskEvent(taskId=id,description=if(success)"انجام شد" else "ثبت نتیجه ناموفق"))
    }
    suspend fun note(text:String)=db.withTransaction{val s=dao.active()?:return@withTransaction;dao.put(s.copy(note=text))}
    suspend fun addSubtask(id:String,title:String,required:Boolean)=db.withTransaction{requireEditable(id);require(title.isNotBlank());dao.putSubtask(Subtask(taskId=id,title=title.trim(),required=required))}
    suspend fun checkSubtask(sub:Subtask,checked:Boolean)=db.withTransaction{val current=dao.subtasksFor(sub.taskId).firstOrNull{it.id==sub.id}?:return@withTransaction;dao.putSubtask(current.copy(checked=checked))}
    suspend fun removeSubtask(sub:Subtask)=db.withTransaction{requireEditable(sub.taskId);dao.deleteSubtask(sub.id)}
    suspend fun attach(taskId:String,groupId:String)=db.withTransaction {requireEditable(taskId);requireNotNull(dao.group(groupId));requireNotNull(db.taskDao().get(taskId));dao.putMission(Mission(taskId,groupId));db.taskDao().event(TaskEvent(taskId=taskId,description="اتصال به مسیر پیشرفت"))}
    suspend fun addMission(title:String,minutes:Int,priority:Int,groupId:String)=db.withTransaction {require(title.isNotBlank() && minutes in 1..240);requireNotNull(dao.group(groupId));val t=Task(title=title.trim(),duration=minutes,priority=priority,dueDay=java.time.LocalDate.now().toEpochDay());db.taskDao().save(t);dao.putMission(Mission(t.id,groupId))}
    suspend fun edge(task:String,dependency:String)=db.withTransaction{requireEditable(task);requireNotNull(db.taskDao().get(task));val d=requireNotNull(db.taskDao().get(dependency));require(!d.archived){"پیش‌نیاز بایگانی‌شده قابل انتخاب نیست."};require(!wouldCycle(task,dependency,dao.edges())){"این پیش‌نیاز چرخه ایجاد می‌کند."};dao.putEdge(Prerequisite(task,dependency))}
    suspend fun removeEdge(edge:Prerequisite)=db.withTransaction{requireEditable(edge.taskId);dao.deleteEdge(edge.taskId,edge.dependsOnId)}
    suspend fun detach(id:String)=db.withTransaction{requireEditable(id);dao.detach(id)}
}
val MIGRATION_2_3=object:Migration(2,3){override fun migrate(db:SupportSQLiteDatabase){
    db.execSQL("ALTER TABLE tasks ADD COLUMN failed INTEGER NOT NULL DEFAULT 0")
    db.execSQL("CREATE TABLE IF NOT EXISTS focus_sessions (id TEXT NOT NULL, taskId TEXT NOT NULL, durationMs INTEGER NOT NULL, accruedMs INTEGER NOT NULL, anchorWall INTEGER NOT NULL, anchorElapsed INTEGER NOT NULL, boot INTEGER NOT NULL, state TEXT NOT NULL, createdAt INTEGER NOT NULL, closedAt INTEGER, result TEXT, note TEXT NOT NULL, priority INTEGER NOT NULL, previousMs INTEGER NOT NULL DEFAULT 0, endAnnounced INTEGER NOT NULL DEFAULT 0, openSlot INTEGER, PRIMARY KEY(id))")
    db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_focus_sessions_openSlot ON focus_sessions (openSlot)")
    db.execSQL("CREATE TABLE IF NOT EXISTS subtasks (id TEXT NOT NULL, taskId TEXT NOT NULL, title TEXT NOT NULL, required INTEGER NOT NULL, checked INTEGER NOT NULL, position INTEGER NOT NULL, PRIMARY KEY(id))")
    db.execSQL("CREATE TABLE IF NOT EXISTS path_groups (id TEXT NOT NULL, title TEXT NOT NULL, position INTEGER NOT NULL, PRIMARY KEY(id))")
    db.execSQL("CREATE TABLE IF NOT EXISTS missions (taskId TEXT NOT NULL, groupId TEXT NOT NULL, position INTEGER NOT NULL, PRIMARY KEY(taskId))")
    db.execSQL("CREATE TABLE IF NOT EXISTS prerequisites (taskId TEXT NOT NULL, dependsOnId TEXT NOT NULL, PRIMARY KEY(taskId,dependsOnId))")
}}
