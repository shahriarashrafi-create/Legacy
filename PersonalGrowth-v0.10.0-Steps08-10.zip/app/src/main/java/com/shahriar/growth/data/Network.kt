package com.shahriar.growth.data

import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName="people", indices=[Index("parentId")])
data class Person(
    @PrimaryKey val id:String=java.util.UUID.randomUUID().toString(),
    val name:String, val phone:String="", val role:String="member", val status:String="active",
    val parentId:String?=null, val branch:String="", val city:String="", val note:String="",
    val archived:Boolean=false, val createdAt:Long=System.currentTimeMillis(), val updatedAt:Long=createdAt
)
@Entity(tableName="person_events", indices=[Index("personId")])
data class PersonEvent(@PrimaryKey val id:String=java.util.UUID.randomUUID().toString(),val personId:String,val text:String,val at:Long=System.currentTimeMillis())
@Entity(tableName="task_owners", indices=[Index("personId")])
data class TaskOwner(@PrimaryKey val taskId:String,val personId:String)
@Dao interface NetworkDao {
    @Query("SELECT * FROM people ORDER BY createdAt,id") fun observe():Flow<List<Person>>
    @Query("SELECT * FROM people") suspend fun all():List<Person>
    @Query("SELECT * FROM people WHERE id=:id") suspend fun get(id:String):Person?
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(person:Person)
    @Insert suspend fun event(event:PersonEvent)
    @Query("SELECT * FROM person_events WHERE personId=:id ORDER BY at DESC,id") fun history(id:String):Flow<List<PersonEvent>>
    @Query("SELECT * FROM task_owners") fun owners():Flow<List<TaskOwner>>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun putOwner(owner:TaskOwner)
    @Query("DELETE FROM task_owners WHERE taskId=:id") suspend fun removeOwner(id:String)
}

/** A visited set also makes imported malformed data safe to inspect. */
fun descendants(id:String,people:List<Person>):Set<String> {
    val children=people.groupBy{it.parentId};val found=mutableSetOf<String>();val pending=java.util.ArrayDeque<String>()
    pending.add(id)
    while(pending.isNotEmpty()) children[pending.removeFirst()].orEmpty().forEach{if(it.id!=id && found.add(it.id))pending.add(it.id)}
    return found
}
fun validParent(id:String,parent:String?,people:List<Person>):Boolean = parent==null || (parent!=id && people.any{it.id==parent && !it.archived} && parent !in descendants(id,people))
fun matchesPerson(p:Person,search:String):Boolean = normalizeText(listOf(p.name,p.phone,p.city,p.branch).joinToString(" ")).contains(normalizeText(search.trim()))
fun validatePerson(p:Person,people:List<Person>) {
    require(p.name.trim().length in 1..80){"نام باید بین ۱ تا ۸۰ حرف باشد."}
    require(p.phone.length<=30 && p.city.length<=80 && p.branch.length<=80 && p.note.length<=4000){"یکی از ورودی‌ها طولانی‌تر از حد مجاز است."}
    require(p.role in listOf("member","leader")) {"نقش معتبر نیست."}
    require(p.status in listOf("active","inactive")) {"وضعیت معتبر نیست."}
    require(validParent(p.id,p.parentId,people)){"بالاسری باید از افراد غیربایگانی باشد و حلقه ایجاد نکند."}
}
class NetworkEngine(private val db:AppDatabase) {
    private val dao get()=db.networkDao()
    suspend fun save(draft:Person)=db.withTransaction {
        val old=dao.get(draft.id)
        require(old?.archived!=true){"برای ویرایش، ابتدا فرد را از بایگانی برگردان."}
        val person=draft.copy(name=draft.name.trim(),phone=normalizeText(draft.phone).trim(),city=draft.city.trim(),branch=draft.branch.trim(),note=draft.note.trim(),archived=old?.archived?:false,createdAt=old?.createdAt?:draft.createdAt,updatedAt=System.currentTimeMillis())
        validatePerson(person,dao.all())
        dao.put(person)
        dao.event(PersonEvent(personId=person.id,text=if(old==null)"افزودن فرد به شبکه" else if(old.parentId!=person.parentId)"ویرایش فرد و تغییر بالاسری" else "ویرایش مشخصات فرد"))
    }
    suspend fun archive(id:String,value:Boolean)=db.withTransaction {
        val person=dao.get(id)?:return@withTransaction
        if(person.archived==value)return@withTransaction
        validateArchive(person,value,dao.all())
        dao.put(person.copy(archived=value,updatedAt=System.currentTimeMillis()))
        dao.event(PersonEvent(personId=id,text=if(value)"بایگانی فرد؛ سوابق و کارها حفظ شدند" else "بازگردانی فرد از بایگانی"))
    }
    suspend fun assign(taskId:String,personId:String?)=db.withTransaction {
        require(db.taskDao().get(taskId)!=null){"کار پیدا نشد."}
        clearContactLink(db,taskId)
        if(personId==null)dao.removeOwner(taskId) else {
            require(dao.get(personId)?.archived==false){"فرد انتخاب‌شده بایگانی شده یا پیدا نشد."}
            dao.putOwner(TaskOwner(taskId,personId))
        }
        db.taskDao().event(TaskEvent(taskId=taskId,description=if(personId==null)"حذف ارتباط کار با فرد" else "ارتباط کار با ${dao.get(personId)?.name}"))
    }
}
val MIGRATION_3_4=object:Migration(3,4) {
    override fun migrate(db:SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS people (id TEXT NOT NULL, name TEXT NOT NULL, phone TEXT NOT NULL, role TEXT NOT NULL, status TEXT NOT NULL, parentId TEXT, branch TEXT NOT NULL, city TEXT NOT NULL, note TEXT NOT NULL, archived INTEGER NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL, PRIMARY KEY(id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_people_parentId ON people(parentId)")
        db.execSQL("CREATE TABLE IF NOT EXISTS person_events (id TEXT NOT NULL, personId TEXT NOT NULL, text TEXT NOT NULL, at INTEGER NOT NULL, PRIMARY KEY(id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_person_events_personId ON person_events(personId)")
        db.execSQL("CREATE TABLE IF NOT EXISTS task_owners (taskId TEXT NOT NULL, personId TEXT NOT NULL, PRIMARY KEY(taskId))")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_task_owners_personId ON task_owners(personId)")
    }
}

data class TreeNode(val id:String,val parent:String?,val depth:Int)
/** Iterative preorder: bounded viewport, no recursive stack growth, stable sibling order. */
fun treeNodes(people:List<Person>,rootId:String?,collapsed:Set<String> = emptySet()):List<TreeNode> {
    val active=people.filter{!it.archived};val children=active.groupBy{it.parentId}
    val root=rootId?.takeIf{id->active.any{it.id==id}}?:""
    val result=mutableListOf<TreeNode>();val seen=mutableSetOf<String>();val stack=java.util.ArrayDeque<TreeNode>()
    stack.push(TreeNode(root,null,0))
    while(stack.isNotEmpty() && result.size<201){
        val n=stack.pop();if(!seen.add(n.id))continue;result.add(n)
        if(n.id !in collapsed && n.depth<50){
            val next=if(n.id=="")active.filter{it.parentId==null || active.none{p->p.id==it.parentId}} else children[n.id].orEmpty()
            next.asReversed().forEach{stack.push(TreeNode(it.id,n.id,n.depth+1))}
        }
    }
    return result
}

fun validateArchive(person:Person,value:Boolean,people:List<Person>) {
    if(value) require(people.none{it.parentId==person.id && !it.archived}){"ابتدا افراد مستقیم را به بالاسری دیگری منتقل یا بایگانی کن."}
    else require(person.parentId==null || people.any{it.id==person.parentId && !it.archived}){"ابتدا بالاسری این فرد را از بایگانی برگردان."}
}
