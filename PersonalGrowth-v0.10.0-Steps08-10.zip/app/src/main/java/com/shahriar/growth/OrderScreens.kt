package com.shahriar.growth

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.shahriar.growth.data.*

@Composable fun OrdersPanel(contact:ContactRecord,orders:List<CustomerOrder>,enabled:Boolean,onEdit:(String?)->Unit,onArchive:(CustomerOrder,Boolean)->Unit){
    var archived by rememberSaveable(contact.id){mutableStateOf(false)};var confirm by remember{mutableStateOf<CustomerOrder?>(null)}
    Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        Text("خریدهای مشتری",style=MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={onEdit(null)},enabled=enabled){Text("+ خرید")};FilterChip(archived,{archived=!archived},label={Text("بایگانی خریدها")})}
        val shown=orders.filter{it.archived==archived}
        if(shown.isEmpty())Text("خریدی در این فهرست نیست.",style=MaterialTheme.typography.bodySmall)
        shown.forEach{o->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){
            Text(o.item,style=MaterialTheme.typography.titleMedium);Text("${faNumber(o.quantity)} عدد · ${persianDay(o.day)}")
            Text("مبلغ کل: ${faNumber(o.totalToman)} تومان · PV: ${faNumber(o.pv)}",style=MaterialTheme.typography.bodySmall)
            if(o.note.isNotBlank())Text(o.note)
            Row{if(!o.archived)TextButton(onClick={onEdit(o.id)},enabled=enabled){Text("ویرایش")};TextButton(onClick={confirm=o},enabled=enabled){Text(if(o.archived)"بازگردانی" else "بایگانی")}}
        }}}
        Text("مبلغ، کل همین خرید به تومان است. PV این مرحله سابقه خرید است و در هدف‌ها خودکار محاسبه نمی‌شود.",style=MaterialTheme.typography.bodySmall)
    }
    confirm?.let{o->AlertDialog(onDismissRequest={confirm=null},title={Text(if(o.archived)"بازگردانی خرید" else "بایگانی خرید")},text={Text("خرید حذف نمی‌شود و تغییر در تاریخچه ثبت خواهد شد.")},confirmButton={TextButton(onClick={confirm=null;onArchive(o,!o.archived)},enabled=enabled){Text("تأیید")}},dismissButton={TextButton(onClick={confirm=null}){Text("انصراف")}})}
}
@Composable fun OrderEditor(contactId:String,old:CustomerOrder?,today:Long,busy:Boolean,error:String,onDismiss:()->Unit,onSave:(CustomerOrder)->Unit){
    val id=rememberSaveable{old?.id?:java.util.UUID.randomUUID().toString()}
    var item by rememberSaveable{mutableStateOf(old?.item?:"")};var quantity by rememberSaveable{mutableStateOf(old?.quantity?.toString()?:"1")}
    var amount by rememberSaveable{mutableStateOf(old?.totalToman?.toString()?:"0")};var pv by rememberSaveable{mutableStateOf(old?.pv?.toString()?:"0")}
    var date by rememberSaveable{mutableStateOf(persianDay(old?.day?:today,true))};var note by rememberSaveable{mutableStateOf(old?.note?:"")}
    val q=normalizeText(quantity).trim().toIntOrNull();val a=normalizeText(amount).trim().toLongOrNull();val p=normalizeText(pv).trim().replace('٫','.').toDoubleOrNull();val day=parsePersianDay(date)
    val valid=item.isNotBlank() && q!=null && q in 1..1000000 && a!=null && a in 0..1000000000000L && p!=null && p.isFinite() && p in 0.0..1000000000.0 && day!=null
    Dialog(onDismissRequest=onDismiss,properties=DialogProperties(usePlatformDefaultWidth=false,dismissOnBackPress=!busy,dismissOnClickOutside=!busy)){Surface(Modifier.fillMaxSize().imePadding(),color=MaterialTheme.colorScheme.background){Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text(if(old==null)"ثبت خرید" else "ویرایش خرید",style=MaterialTheme.typography.headlineSmall)
        if(error.isNotEmpty())Text(error,color=MaterialTheme.colorScheme.error)
        OutlinedTextField(item,{if(it.length<=120)item=it},label={Text("محصول / عنوان خرید *")},singleLine=true,enabled=!busy,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(quantity,{if(it.length<=8)quantity=it},label={Text("تعداد")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),isError=q==null || q !in 1..1000000,enabled=!busy,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(amount,{if(it.length<=14)amount=it},label={Text("مبلغ کل به تومان")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),isError=a==null || a !in 0..1000000000000L,enabled=!busy,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(pv,{if(it.length<=16)pv=it},label={Text("PV همین خرید")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),isError=p==null || !p.isFinite() || p !in 0.0..1000000000.0,enabled=!busy,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(date,{date=it},label={Text("تاریخ شمسی: سال/ماه/روز")},isError=day==null,enabled=!busy,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(note,{if(it.length<=2000)note=it},label={Text("یادداشت خرید")},minLines=3,enabled=!busy,modifier=Modifier.fillMaxWidth())
        Row{Button(onClick={onSave(CustomerOrder(id=id,contactId=contactId,item=item,quantity=q!!,totalToman=a!!,pv=p!!,day=day!!,note=note))},enabled=!busy && valid){Text("ذخیره")};TextButton(onClick=onDismiss,enabled=!busy){Text("انصراف")}}
    }}}
}
