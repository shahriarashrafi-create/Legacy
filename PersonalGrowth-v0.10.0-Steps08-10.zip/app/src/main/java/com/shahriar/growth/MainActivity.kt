package com.shahriar.growth

import android.os.Bundle
import android.content.Intent
import android.os.Build
import android.Manifest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.ui.platform.LocalContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shahriar.growth.data.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.time.LocalDate

class MainActivity : ComponentActivity() {
    private val focusRequest = mutableStateOf(false)
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); if(intent.getBooleanExtra("focus",false))focusRequest.value=true }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        focusRequest.value = intent.getBooleanExtra("focus",false)
        val database = AppDatabase.get(this)
        val settings = Settings(applicationContext)
        setContent { GrowthApp(database, settings, focusRequest.value) { focusRequest.value=false } }
    }
}
private val Navy = Color(0xFF193553)
private val Blue = Color(0xFF285BCD)
private val Cyan = Color(0xFF247D86)
private val Gold = Color(0xFF9A6B0C)
private data class Destination(val label: String, val icon: ImageVector)
private val destinations = listOf(
    Destination("خانه", Icons.Outlined.Home), Destination("شبکه", Icons.Outlined.AccountTree),
    Destination("هدف‌ها", Icons.Outlined.Flag), Destination("کارها", Icons.Outlined.CheckCircle),
    Destination("بخش‌ها", Icons.Outlined.GridView)
)
@Composable private fun GrowthApp(db: AppDatabase, settings: Settings, requestFocus:Boolean, onFocusHandled:()->Unit) {
    val profile by db.profileDao().observe().collectAsState(initial = null)
    val endSound by settings.endSound.collectAsState(initial=true)
    val theme by settings.theme.collectAsState(initial = "system")
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val people by db.networkDao().observe().collectAsState(initial=emptyList())
    val owners by db.networkDao().owners().collectAsState(initial=emptyList())
    val networkEngine=remember(db){NetworkEngine(db)}
    val crmEngine=remember(db){CrmEngine(db)}
    val crmContacts by db.crmDao().contacts().collectAsState(initial=emptyList())
    val crmLinks by db.crmDao().links().collectAsState(initial=emptyList())
    val engine = remember(db) { ExecutionEngine(db,context.applicationContext) }
    val musicEnabled by FocusService.musicEnabled.collectAsState()
    val active by db.executionDao().observeActive().collectAsState(initial=null)
    val subtasks by db.executionDao().subtasks().collectAsState(initial=emptyList())
    val groups by db.executionDao().groups().collectAsState(initial=emptyList())
    val missions by db.executionDao().missions().collectAsState(initial=emptyList())
    val edges by db.executionDao().prerequisites().collectAsState(initial=emptyList())
    var focusOpen by rememberSaveable { mutableStateOf(false) }
    var pathOpen by rememberSaveable { mutableStateOf(false) }
    var clock by remember { mutableStateOf(readClock(context)) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(requestFocus) { if(requestFocus){focusOpen=true;onFocusHandled()} }
    LaunchedEffect(active?.id) { if(active!=null)runCatching{FocusService.ensure(context)} }
    LaunchedEffect(Unit) { while(true){clock=readClock(context);engine.tick();delay(1000)} }

    val tasks by db.taskDao().observe().collectAsState(initial = emptyList())
    val choice by db.taskDao().choice().collectAsState(initial = null)
    var today by remember { mutableLongStateOf(LocalDate.now().toEpochDay()) }
    LaunchedEffect(Unit) { while (true) { today = LocalDate.now().toEpochDay(); delay(1000) } }
    val listState = rememberLazyListState()
    val pageState = rememberSaveableStateHolder()
    var taskFilter by rememberSaveable { mutableIntStateOf(0) }
    var editorId by rememberSaveable { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var operationError by remember { mutableStateOf("") }
    var bringToToday by remember { mutableStateOf<String?>(null) }
    val editingTask = tasks.firstOrNull { it.id == editorId }
    val historyFlow = remember(editorId) { db.taskDao().history(editorId ?: "") }
    val events by historyFlow.collectAsState(initial = emptyList())
    val snackbar = remember { SnackbarHostState() }
    fun mutate(close: Boolean = false, action: suspend () -> Unit) {
        if (busy) return
        busy = true; operationError = ""
        scope.launch {
            try { action(); if(close) editorId = null }
            catch (error: Exception) { if(error is kotlinx.coroutines.CancellationException)throw error; operationError = if(error is IllegalArgumentException)error.message ?: "عملیات انجام نشد" else "ثبت تغییر انجام نشد؛ دوباره تلاش کن."; snackbar.showSnackbar(operationError) }
            finally { busy = false }
        }
    }
    fun openTask(id: String) { operationError = ""; editorId = id }
    fun finishTask(id: String, value: Boolean) { mutate { engine.complete(id,value) } }
    fun startFocus(id:String) { mutate(true) {
        engine.start(id)
        if(Build.VERSION.SDK_INT>=33)permission.launch(Manifest.permission.POST_NOTIFICATIONS)
        FocusService.ensure(context);focusOpen=true
    } }

    var selected by rememberSaveable { mutableIntStateOf(0) }
    var settingsOpen by rememberSaveable { mutableStateOf(false) }
    var info by rememberSaveable { mutableStateOf("") }
    val dark = theme == "dark" || (theme == "system" && isSystemInDarkTheme())
    val colors = if (dark) darkColorScheme(primary = Color(0xFFA8C7FF), secondary = Color(0xFF77D9D2), background = Color(0xFF101B2B), surface = Color(0xFF1B2C42), surfaceVariant = Color(0xFF273C56), primaryContainer = Color(0xFF25466E), onPrimaryContainer = Color(0xFFEAF2FF), secondaryContainer = Color(0xFF25466E), onSecondaryContainer = Color(0xFFEAF2FF), onSurface = Color(0xFFEAF2FF))
    else lightColorScheme(primary = Blue, secondary = Cyan, background = Color(0xFFF0F5FC), surface = Color.White, surfaceVariant = Color(0xFFE5EEFB), onSurface = Navy, onBackground = Navy, primaryContainer = Color(0xFFDFEBFF), onPrimaryContainer = Navy, secondaryContainer = Color(0xFFDFEBFF), onSecondaryContainer = Navy)
    val font = FontFamily(Font(R.font.vazirmatn))
    val base = Typography()
    val typography = Typography(
        bodyLarge = base.bodyLarge.copy(fontFamily = font, fontSize = 16.sp),
        bodyMedium = base.bodyMedium.copy(fontFamily = font), bodySmall = base.bodySmall.copy(fontFamily = font),
        titleLarge = base.titleLarge.copy(fontFamily = font), titleMedium = base.titleMedium.copy(fontFamily = font),
        headlineSmall = base.headlineSmall.copy(fontFamily = font), labelLarge = base.labelLarge.copy(fontFamily = font),
        labelMedium = base.labelMedium.copy(fontFamily = font), labelSmall = base.labelSmall.copy(fontFamily = font)
    )
    MaterialTheme(colorScheme = colors, typography = typography) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            BackHandler(enabled = focusOpen || pathOpen || settingsOpen || selected != 0) { when { focusOpen -> focusOpen=false; pathOpen -> pathOpen=false; settingsOpen -> settingsOpen=false; else -> selected=0 } }
            Scaffold(
                snackbarHost = { SnackbarHost(snackbar) },
                topBar = { if(!focusOpen) AppHeader(profile?.name ?: "شهریار", onSettings = { settingsOpen = true; pathOpen = false }, onInfo = { info = it }) },
                bottomBar = { if (!settingsOpen && !focusOpen) NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    destinations.forEachIndexed { index, item -> NavigationBarItem(
                        colors = NavigationBarItemDefaults.colors(indicatorColor = MaterialTheme.colorScheme.primaryContainer),
                        selected = selected == index, onClick = { selected = index; pathOpen = false },
                        icon = { Icon(item.icon, contentDescription = null) }, label = { Text(item.label, maxLines = 1) }
                    ) }
                } }, containerColor = MaterialTheme.colorScheme.background
            ) { padding ->
                if (focusOpen) FocusScreen(Modifier.padding(padding),tasks.firstOrNull{it.id==active?.taskId},active,
                    subtasks.filter{it.taskId==active?.taskId},clock,busy,operationError,
                    onBack={note->mutate{engine.note(note);focusOpen=false}},onToggle={mutate{engine.toggle()}},onReset={note->mutate{engine.note(note);engine.reset()}},
                    onClose={note->mutate{engine.note(note);engine.closeReady();focusOpen=false}},
                    onFinish={success,note->active?.let{s->mutate{engine.note(note);engine.finish(s.taskId,success);focusOpen=false}}},
                    onNote={text->scope.launch{runCatching{engine.note(text)}}},onCheck={sub,value->mutate{engine.checkSubtask(sub,value)}},
                    musicEnabled=musicEnabled,onMusic={FocusService.music(context,it)},endSound=endSound,onEndSound={value->scope.launch{settings.setEndSound(value)}})
                else if (pathOpen) PathScreen(Modifier.padding(padding),tasks,groups,missions,edges,subtasks,active,operationError,
                    onBack={pathOpen=false},onOpen={openTask(it)},onFocus={startFocus(it)},
                    onAddGroup={title,success->mutate{db.executionDao().putGroup(PathGroup(title=title));success()}},
                    onRenameGroup={group,title,success->mutate{db.executionDao().putGroup(group.copy(title=title));success()}},
                    onAddMission={title,minutes,priority,group,success->mutate{engine.addMission(title,minutes,priority,group);success()}},
                    onLink={task,group,success->mutate{engine.attach(task,group);success()}})
                else if (settingsOpen) SettingsPage(Modifier.padding(padding), profile?.name ?: "شهریار", theme,
                    onSave = { name -> scope.launch { db.profileDao().save(Profile(name = name)) } },
                    onTheme = { value -> scope.launch { settings.setTheme(value) } }, onBack = { settingsOpen = false })
                else if (selected == 0) pageState.SaveableStateProvider("home") { HomeScreen(Modifier.padding(padding),tasks,choice,today,active,edges,
                    onFocus={startFocus(it)},onPath={pathOpen=true},
                    onNew={openTask("new")}, onOpen={openTask(it)},
                    onList={taskFilter=it;selected=3}, onExclude={ id -> mutate { db.taskDao().exclude(id,today) } },
                    onClearChoice={mutate { db.taskDao().putChoice(ActionChoice()) }}, onDone={id,value->finishTask(id,value)}) }
                else if (selected == 1) pageState.SaveableStateProvider("network") { NetworkScreen(Modifier.padding(padding),db,profile?.name?:"شهریار",tasks,today,onOpenTask={openTask(it)}) }
                else if (selected == 3) pageState.SaveableStateProvider("tasks") { TaskListScreen(Modifier.padding(padding),tasks,today,taskFilter,listState,
                    onFilter={taskFilter=it},onNew={openTask("new")},onOpen={openTask(it)},onDone={id,value->finishTask(id,value)}) }
                else key(selected) {
                    Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        when (selected) {
                            
                            2 -> EmptySection("هدف‌های من", "از هدف ماه تا قدم امروز", "ثبت عملکرد و هدف‌گذاری در نسخه‌های ۱۲ و ۱۳ اضافه می‌شوند.", Icons.Outlined.Flag)
                            4 -> {
                                Text("بخش‌های مسیر من", style = MaterialTheme.typography.headlineSmall)
                                Card(onClick={pathOpen=true},colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) {
                                    Row(Modifier.fillMaxWidth().padding(18.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Outlined.Route,null);Spacer(Modifier.width(12.dp));Text("مسیر پیشرفت",style=MaterialTheme.typography.titleMedium)}
                                }
                                FeatureCard("زمان‌بندی و تایم‌شیت", "در نسخه ۱۴", Icons.Outlined.Schedule)
                                FeatureCard("تابلو آرزوها", "در نسخه ۱۵", Icons.Outlined.FavoriteBorder)
                                FeatureCard("پاداش‌ها و دستاوردها", "در نسخه‌های ۱۶ و ۱۷", Icons.Outlined.EmojiEvents)
                                OutlinedButton(onClick = { settingsOpen = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Outlined.Settings, null); Spacer(Modifier.width(8.dp)); Text("تنظیمات") }
                            }
                        }
                    }
                }
            }
            if (editorId != null && (editorId == "new" || editingTask != null)) key(editorId) {
                TaskEditor(editingTask,events,today,busy,operationError,
                    onDismiss={editorId=null},onSave={task -> mutate(true) {
                        db.taskDao().save(task)
                        scope.launch { snackbar.showSnackbar(if(task.dueDay==null) "کار ذخیره شد؛ در فهرست بدون موعد" else "کار ذخیره شد") }
                    }},
                    onDone={value -> editingTask?.let { t -> mutate(true) { engine.complete(t.id,value) } }},
                    onArchive={value -> editingTask?.let { t -> mutate(true) { db.taskDao().archive(t.id,value) } }},
                    onFocus={editingTask?.let{startFocus(it.id)}},
                    extra={editingTask?.let { task ->
                        TaskPersonPanel(task,people,owners,busy,onAssign={person->mutate{networkEngine.assign(task.id,person)}},sourceLabel=crmLinks.firstOrNull{it.taskId==task.id}?.let{link->val c=crmContacts.firstOrNull{it.id==link.contactId};"مسئول از پرونده: "+(people.firstOrNull{it.id==c?.ownerId}?.name?:"خودم")})
                        TaskContactPanel(task,crmContacts.map{displayedContact(it,people)},crmLinks,busy,onAssign={contact->mutate{crmEngine.assign(task.id,contact)}})
                        if(crmLinks.any{it.taskId==task.id}) Text("مسئول کار از پرونده مرتبط تعیین می‌شود؛ انتخاب فرد، ارتباط پرونده را جایگزین می‌کند.",style=MaterialTheme.typography.bodySmall)
                        SubtaskPanel(subtasks.filter{it.taskId==task.id},active?.taskId==task.id,
                            onCheck={sub,value->mutate{engine.checkSubtask(sub,value)}},
                            onAdd={title,required,success->mutate{engine.addSubtask(task.id,title,required);success()}},
                            onRemove={sub->mutate{engine.removeSubtask(sub)}})
                        RelationsPanel(task,tasks,groups,missions,edges,active?.taskId==task.id,
                            onAttach={group->mutate{engine.attach(task.id,group)}},onDetach={mutate{engine.detach(task.id)}},
                            onEdge={dependency->mutate{engine.edge(task.id,dependency)}},onRemoveEdge={edge->mutate{engine.removeEdge(edge)}})
                    }},
                    onPick={ editingTask?.let { t ->
                        if(t.dueDay==null || t.dueDay>today) bringToToday=t.id
                        else mutate(true) { db.taskDao().pick(t.id,today,false) }
                    } })
            }
            if(bringToToday!=null) AlertDialog(onDismissRequest={bringToToday=null},title={Text("آوردن کار به امروز")},text={Text("موعد ذخیره‌شده این کار به امروز تغییر کند و قدم بعدی شود؟ تغییرات ذخیره‌نشده فرم اعمال نمی‌شوند.")},confirmButton={TextButton(onClick={val id=bringToToday!!;bringToToday=null;mutate(true){db.taskDao().pick(id,today,true)}}){Text("امروز و قدم بعدی")}},dismissButton={TextButton(onClick={bringToToday=null}){Text("انصراف")}})
            if (info.isNotEmpty()) AlertDialog(onDismissRequest = { info = "" }, title = { Text(info) }, text = { Text("این بخش در نسخه‌های پاداش فعال می‌شود. تا زمان فعال‌شدن پاداش‌ها، تکمیل کار فقط نتیجه کار را ثبت می‌کند.") }, confirmButton = { TextButton(onClick = { info = "" }) { Text("باشه") } })
        }
    }
}
@Composable private fun AppHeader(name: String, onSettings: () -> Unit, onInfo: (String) -> Unit) {
    Surface(shadowElevation = 2.dp) {
        Column(Modifier.statusBarsPadding().fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(44.dp)) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Outlined.Person, "پروفایل") }
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("مسیر شخصی رشد", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = onSettings) { Icon(Icons.Outlined.Settings, "تنظیمات") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = { onInfo("سکه‌ها") }, label = { Text("سکه —") }, leadingIcon = { Icon(Icons.Outlined.Paid, null, Modifier.size(18.dp)) })
                AssistChip(onClick = { onInfo("کمبو") }, label = { Text("کمبو —") }, leadingIcon = { Icon(Icons.Outlined.LocalFireDepartment, null, Modifier.size(18.dp)) })
                AssistChip(onClick = { onInfo("سطح و تجربه") }, label = { Text("سطح —") })
            }
        }
    }
}
@Composable private fun SectionTitle(text: String) { Text(text, style = MaterialTheme.typography.titleMedium) }
@Composable private fun QuickTile(title: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Text(title)
        }
    }
}
@Composable private fun FeatureCard(title: String, subtitle: String, icon: ImageVector) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
@Composable private fun EmptySection(title: String, subtitle: String, detail: String, icon: ImageVector) {
    Text(title, style = MaterialTheme.typography.headlineSmall)
    Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
    FeatureCard("در مسیر ساخت", detail, icon)
}
@Composable private fun SettingsPage(modifier: Modifier, name: String, theme: String, onSave: (String) -> Unit, onTheme: (String) -> Unit, onBack: () -> Unit) {
    var draft by rememberSaveable(name) { mutableStateOf(name) }
    var saved by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        TextButton(onClick = onBack) { Icon(Icons.Outlined.ArrowForward, null); Text("بازگشت") }
        Text("تنظیمات", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(value = draft, onValueChange = { draft = it; saved = false }, label = { Text("نام من") }, singleLine = true, modifier = Modifier.fillMaxWidth(), isError = draft.isBlank(), supportingText = { Text(if (draft.isBlank()) "نام را وارد کن" else "نام در هدر همه صفحه‌ها نمایش داده می‌شود") })
        Button(onClick = { onSave(draft.trim()); saved = true }, enabled = draft.isNotBlank() && draft.length <= 80) { Text("ذخیره نام") }
        if (saved) Text("نام ذخیره شد", color = MaterialTheme.colorScheme.primary)
        SectionTitle("ظاهر اپ")
        listOf("system" to "هماهنگ با گوشی", "light" to "روشن", "dark" to "تاریک").forEach { (value, label) ->
            Surface(onClick = { onTheme(value) }, shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = theme == value, onClick = { onTheme(value) }); Text(label)
                }
            }
        }
        FeatureCard("ذخیره روی دستگاه", "نام در پایگاه داده و تم در تنظیمات ماندگار ذخیره می‌شوند. پشتیبان‌گیری در نسخه ۱۸ اضافه خواهد شد.", Icons.Outlined.Storage)
        Text("مسیر من · نسخه ۰٫۱۰٫۰\nپایه پروژه · Kotlin / Compose", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
