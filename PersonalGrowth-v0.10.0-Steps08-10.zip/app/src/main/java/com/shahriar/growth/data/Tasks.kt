package com.shahriar.growth.data

import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val title: String, val note: String = "", val dueDay: Long? = null,
    val dueMinute: Int? = null, val priority: Int = 1, val duration: Int? = null,
    @ColumnInfo(defaultValue = "0") val failed: Boolean = false, val done: Boolean = false, val archived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(), val updatedAt: Long = createdAt,
    val completedAt: Long? = null, val excludedDay: Long? = null
)
@Entity(tableName = "task_events")
data class TaskEvent(@PrimaryKey val id: String = java.util.UUID.randomUUID().toString(), val taskId: String, val description: String, val at: Long = System.currentTimeMillis())
@Entity(tableName = "action_choice")
data class ActionChoice(@PrimaryKey val id: Int = 1, val taskId: String? = null, val day: Long? = null)
@Dao abstract class TaskDao {
    @Query("SELECT * FROM tasks ORDER BY createdAt DESC") abstract fun observe(): Flow<List<Task>>
    @Query("SELECT * FROM action_choice WHERE id=1") abstract fun choice(): Flow<ActionChoice?>
    @Query("SELECT * FROM task_events WHERE taskId=:id ORDER BY at DESC") abstract fun history(id: String): Flow<List<TaskEvent>>
    @Query("SELECT * FROM tasks WHERE id=:id") abstract suspend fun get(id: String): Task?
    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun put(task: Task)
    @Insert abstract suspend fun event(event: TaskEvent)
    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun putChoice(choice: ActionChoice)
    @Query("SELECT COUNT(*) FROM focus_sessions WHERE taskId=:id AND closedAt IS NULL") abstract suspend fun hasFocus(id: String): Int
    @Transaction open suspend fun save(task: Task) {
        val old = get(task.id)
        require(old == null || hasFocus(task.id) == 0 || (old.duration == task.duration && old.priority == task.priority)) { "مدت و اهمیت در جلسه باز قابل تغییر نیستند." }
        // Completion/archive are changed only by dedicated operations, never by a stale editor.
        val saved = task.copy(failed = old?.failed ?: false, done = old?.done ?: false, archived = old?.archived ?: false,
            completedAt = old?.completedAt, excludedDay = old?.excludedDay,
            createdAt = old?.createdAt ?: task.createdAt, updatedAt = System.currentTimeMillis())
        put(saved); event(TaskEvent(taskId = task.id, description = if (old == null) "ساخت کار" else "ویرایش کار"))
    }
    @Transaction open suspend fun archive(id: String, value: Boolean) {
        val task = get(id) ?: return
        if (task.archived == value) return
        require(hasFocus(id)==0) { "ابتدا جلسه تمرکز این کار را ببند." }
        put(task.copy(archived = value, updatedAt = System.currentTimeMillis()))
        event(TaskEvent(taskId = id, description = if (value) "بایگانی کار" else "بازگردانی از بایگانی"))
    }
    @Transaction open suspend fun pick(id: String, day: Long, bring: Boolean) {
        val task = get(id) ?: return
        if(task.done || task.archived) return
        if(!bring && (task.dueDay == null || task.dueDay > day)) return
        put(task.copy(dueDay = if(bring)day else task.dueDay, excludedDay = null, updatedAt = System.currentTimeMillis()))
        putChoice(ActionChoice(taskId = id, day = day))
        event(TaskEvent(taskId = id, description = if(bring)"تغییر موعد به امروز و انتخاب قدم بعدی" else "انتخاب قدم بعدی"))
    }
    @Transaction open suspend fun exclude(id: String, day: Long) {
        val task = get(id) ?: return
        put(task.copy(excludedDay = day)); putChoice(ActionChoice())
        event(TaskEvent(taskId = id, description = "کنارگذاشتن از پیشنهادهای امروز"))
    }
}
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS tasks (id TEXT NOT NULL, title TEXT NOT NULL, note TEXT NOT NULL, dueDay INTEGER, dueMinute INTEGER, priority INTEGER NOT NULL, duration INTEGER, done INTEGER NOT NULL, archived INTEGER NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL, completedAt INTEGER, excludedDay INTEGER, PRIMARY KEY(id))")
        db.execSQL("CREATE TABLE IF NOT EXISTS task_events (id TEXT NOT NULL, taskId TEXT NOT NULL, description TEXT NOT NULL, at INTEGER NOT NULL, PRIMARY KEY(id))")
        db.execSQL("CREATE TABLE IF NOT EXISTS action_choice (id INTEGER NOT NULL, taskId TEXT, day INTEGER, PRIMARY KEY(id))")
    }
}
fun nextAction(tasks: List<Task>, choice: ActionChoice?, today: Long, edges: List<Prerequisite> = emptyList()): Task? {
    val eligible = tasks.filter { !it.done && !it.archived && it.dueDay != null && it.dueDay <= today && it.excludedDay != today && !blocked(it.id,tasks,edges) }
    return eligible.firstOrNull { choice?.day == today && choice.taskId == it.id }
        ?: eligible.sortedWith(compareBy<Task> { if (it.dueDay!! < today) 0 else 1 }.thenByDescending { it.priority }.thenBy { it.dueDay }.thenBy { it.dueMinute ?: 1440 }.thenBy { it.createdAt }).firstOrNull()
}
fun taskMatches(t: Task, filter: Int, today: Long): Boolean = when(filter) {
    0 -> !t.archived && !t.done && t.dueDay == today
    1 -> !t.archived && !t.done && t.dueDay != null && t.dueDay < today
    2 -> !t.archived && !t.done && t.dueDay != null && t.dueDay > today
    3 -> !t.archived && !t.done && t.dueDay == null
    4 -> !t.archived && t.done
    5 -> t.archived
    7 -> !t.archived && t.done && t.completedAt?.let { java.time.Instant.ofEpochMilli(it).atZone(java.time.ZoneId.systemDefault()).toLocalDate().toEpochDay() == today } == true
    else -> !t.archived && !t.done
}
fun normalizeText(s: String): String = s.replace('ي','ی').replace('ك','ک').map { c ->
    when(c) { in '۰'..'۹' -> ('0'.code + c.code - '۰'.code).toChar(); in '٠'..'٩' -> ('0'.code + c.code - '٠'.code).toChar(); else -> c }
}.joinToString("").lowercase()
