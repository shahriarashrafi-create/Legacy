package com.shahriar.growth.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

@Entity(tableName = "profile")
data class Profile(@PrimaryKey val id: Int = 1, val name: String = "شهریار")
@Dao interface ProfileDao {
    @Query("SELECT * FROM profile WHERE id = 1") fun observe(): Flow<Profile?>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun save(profile: Profile)
}
@Database(entities = [Profile::class], version = 1, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun profileDao(): ProfileDao
    companion object {
        @Volatile private var instance: AppDatabase? = null
        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "growth.db").build().also { instance = it }
        }
    }
}
private val Context.preferences by preferencesDataStore("settings")
class Settings(private val context: Context) {
    private val themeKey = stringPreferencesKey("theme")
    val theme: Flow<String> = context.preferences.data.map { it[themeKey] ?: "system" }
    suspend fun setTheme(value: String) { context.preferences.edit { it[themeKey] = value } }
}
