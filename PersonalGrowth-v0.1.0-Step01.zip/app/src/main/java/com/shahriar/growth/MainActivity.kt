package com.shahriar.growth

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shahriar.growth.data.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val database = AppDatabase.get(this)
        val settings = Settings(applicationContext)
        setContent { GrowthApp(database, settings) }
    }
}
private val Navy = Color(0xFF193553)
private val Blue = Color(0xFF285BCD)
private val Cyan = Color(0xFF247D86)
private val Gold = Color(0xFF9A6B0C)
private data class Destination(val label: String, val icon: ImageVector)
private val destinations = listOf(
    Destination("خانه", Icons.Outlined.Home), Destination("شبکه", Icons.Outlined.AccountTree),
    Destination("هدف‌ها", Icons.Outlined.Flag), Destination("کارها", Icons.Outlined.CheckCircle),
    Destination("بخش‌ها", Icons.Outlined.GridView)
)
@Composable private fun GrowthApp(db: AppDatabase, settings: Settings) {
    val profile by db.profileDao().observe().collectAsState(initial = null)
    val theme by settings.theme.collectAsState(initial = "system")
    val scope = rememberCoroutineScope()
    var selected by rememberSaveable { mutableIntStateOf(0) }
    var settingsOpen by rememberSaveable { mutableStateOf(false) }
    var info by rememberSaveable { mutableStateOf("") }
    val dark = theme == "dark" || (theme == "system" && isSystemInDarkTheme())
    val colors = if (dark) darkColorScheme(primary = Color(0xFFA8C7FF), secondary = Color(0xFF77D9D2), background = Color(0xFF101B2B), surface = Color(0xFF1B2C42), surfaceVariant = Color(0xFF273C56))
    else lightColorScheme(primary = Blue, secondary = Cyan, background = Color(0xFFF0F5FC), surface = Color.White, surfaceVariant = Color(0xFFE5EEFB), onSurface = Navy, onBackground = Navy)
    val font = FontFamily(Font(R.font.vazirmatn))
    val base = Typography()
    val typography = Typography(
        bodyLarge = base.bodyLarge.copy(fontFamily = font, fontSize = 16.sp),
        bodyMedium = base.bodyMedium.copy(fontFamily = font), bodySmall = base.bodySmall.copy(fontFamily = font),
        titleLarge = base.titleLarge.copy(fontFamily = font), titleMedium = base.titleMedium.copy(fontFamily = font),
        headlineSmall = base.headlineSmall.copy(fontFamily = font), labelLarge = base.labelLarge.copy(fontFamily = font),
        labelMedium = base.labelMedium.copy(fontFamily = font), labelSmall = base.labelSmall.copy(fontFamily = font)
    )
    MaterialTheme(colorScheme = colors, typography = typography) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            BackHandler(enabled = settingsOpen || selected != 0) { if (settingsOpen) settingsOpen = false else selected = 0 }
            Scaffold(
                topBar = { AppHeader(profile?.name ?: "شهریار", onSettings = { settingsOpen = true }, onInfo = { info = it }) },
                bottomBar = { if (!settingsOpen) NavigationBar {
                    destinations.forEachIndexed { index, item -> NavigationBarItem(
                        selected = selected == index, onClick = { selected = index },
                        icon = { Icon(item.icon, contentDescription = null) }, label = { Text(item.label, maxLines = 1) }
                    ) }
                } }, containerColor = MaterialTheme.colorScheme.background
            ) { padding ->
                if (settingsOpen) SettingsPage(Modifier.padding(padding), profile?.name ?: "شهریار", theme,
                    onSave = { name -> scope.launch { db.profileDao().save(Profile(name = name)) } },
                    onTheme = { value -> scope.launch { settings.setTheme(value) } }, onBack = { settingsOpen = false })
                else key(selected) {
                    Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        when (selected) {
                            0 -> {
                                Text("امروز، یک قدم جلوتر", style = MaterialTheme.typography.headlineSmall)
                                Text("فضایی برای برنامه‌ریزی، پیگیری و رشد تو", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = RoundedCornerShape(24.dp)) {
                                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Icon(Icons.Outlined.AutoAwesome, null, Modifier.size(32.dp))
                                        Text("قدم بعدی تو", style = MaterialTheme.typography.titleLarge)
                                        Text("با اولین کارت شروع می‌کنیم", style = MaterialTheme.typography.titleMedium)
                                        Text("پایه اپ آماده است. ساخت کار و انتخاب قدم بعدی در نسخه‌های بعد اضافه می‌شود.")
                                        FilledTonalButton(onClick = { selected = 3 }) { Text("رفتن به کارها") }
                                    }
                                }
                                SectionTitle("دسترسی سریع")
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    QuickTile("شبکه من", Icons.Outlined.AccountTree, Modifier.weight(1f)) { selected = 1 }
                                    QuickTile("هدف‌های من", Icons.Outlined.Flag, Modifier.weight(1f)) { selected = 2 }
                                }
                                FeatureCard("برنامه امروز", "هنوز برنامه‌ای ثبت نشده است.", Icons.Outlined.CalendarMonth)
                                FeatureCard("پایه رشد آماده است", "نسخه ۰٫۱٫۰ · اطلاعات روی همین دستگاه نگهداری می‌شوند.", Icons.Outlined.Verified)
                            }
                            1 -> EmptySection("شبکه من", "آدم‌ها و ارتباط‌ها، در یک جای مشخص", "ساخت افراد، نقش‌ها و درختواره از نسخه ۶ آغاز می‌شود.", Icons.Outlined.AccountTree)
                            2 -> EmptySection("هدف‌های من", "از هدف ماه تا قدم امروز", "ثبت عملکرد و هدف‌گذاری در نسخه‌های ۱۲ و ۱۳ اضافه می‌شوند.", Icons.Outlined.Flag)
                            3 -> EmptySection("کارهای من", "یک فهرست برای تمام اقدام‌ها", "ساخت، ویرایش و نگهداری کارها در نسخه ۲ اضافه می‌شود.", Icons.Outlined.CheckCircle)
                            4 -> {
                                Text("بخش‌های مسیر من", style = MaterialTheme.typography.headlineSmall)
                                FeatureCard("مسیر پیشرفت", "در نسخه ۵", Icons.Outlined.Route)
                                FeatureCard("زمان‌بندی و تایم‌شیت", "در نسخه ۱۴", Icons.Outlined.Schedule)
                                FeatureCard("تابلو آرزوها", "در نسخه ۱۵", Icons.Outlined.FavoriteBorder)
                                FeatureCard("پاداش‌ها و دستاوردها", "در نسخه‌های ۱۶ و ۱۷", Icons.Outlined.EmojiEvents)
                                OutlinedButton(onClick = { settingsOpen = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Outlined.Settings, null); Spacer(Modifier.width(8.dp)); Text("تنظیمات") }
                            }
                        }
                    }
                }
            }
            if (info.isNotEmpty()) AlertDialog(onDismissRequest = { info = "" }, title = { Text(info) }, text = { Text("این بخش در نسخه‌های پاداش فعال می‌شود. در نسخه اول، امتیاز و موجودی نمایشی اضافه نشده است.") }, confirmButton = { TextButton(onClick = { info = "" }) { Text("باشه") } })
        }
    }
}
@Composable private fun AppHeader(name: String, onSettings: () -> Unit, onInfo: (String) -> Unit) {
    Surface(shadowElevation = 2.dp) {
        Column(Modifier.statusBarsPadding().fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(44.dp)) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Outlined.Person, "پروفایل") }
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("مسیر شخصی رشد", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = onSettings) { Icon(Icons.Outlined.Settings, "تنظیمات") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = { onInfo("سکه‌ها") }, label = { Text("سکه —") }, leadingIcon = { Icon(Icons.Outlined.Paid, null, Modifier.size(18.dp)) })
                AssistChip(onClick = { onInfo("کمبو") }, label = { Text("کمبو —") }, leadingIcon = { Icon(Icons.Outlined.LocalFireDepartment, null, Modifier.size(18.dp)) })
                AssistChip(onClick = { onInfo("سطح و تجربه") }, label = { Text("سطح —") })
            }
        }
    }
}
@Composable private fun SectionTitle(text: String) { Text(text, style = MaterialTheme.typography.titleMedium) }
@Composable private fun QuickTile(title: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Text(title)
        }
    }
}
@Composable private fun FeatureCard(title: String, subtitle: String, icon: ImageVector) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
@Composable private fun EmptySection(title: String, subtitle: String, detail: String, icon: ImageVector) {
    Text(title, style = MaterialTheme.typography.headlineSmall)
    Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
    FeatureCard("در مسیر ساخت", detail, icon)
}
@Composable private fun SettingsPage(modifier: Modifier, name: String, theme: String, onSave: (String) -> Unit, onTheme: (String) -> Unit, onBack: () -> Unit) {
    var draft by rememberSaveable(name) { mutableStateOf(name) }
    var saved by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        TextButton(onClick = onBack) { Icon(Icons.Outlined.ArrowForward, null); Text("بازگشت") }
        Text("تنظیمات", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(value = draft, onValueChange = { draft = it; saved = false }, label = { Text("نام من") }, singleLine = true, modifier = Modifier.fillMaxWidth(), isError = draft.isBlank(), supportingText = { Text(if (draft.isBlank()) "نام را وارد کن" else "نام در هدر همه صفحه‌ها نمایش داده می‌شود") })
        Button(onClick = { onSave(draft.trim()); saved = true }, enabled = draft.isNotBlank() && draft.length <= 80) { Text("ذخیره نام") }
        if (saved) Text("نام ذخیره شد", color = MaterialTheme.colorScheme.primary)
        SectionTitle("ظاهر اپ")
        listOf("system" to "هماهنگ با گوشی", "light" to "روشن", "dark" to "تاریک").forEach { (value, label) ->
            Surface(onClick = { onTheme(value) }, shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = theme == value, onClick = { onTheme(value) }); Text(label)
                }
            }
        }
        FeatureCard("ذخیره روی دستگاه", "نام در پایگاه داده و تم در تنظیمات ماندگار ذخیره می‌شوند. پشتیبان‌گیری در نسخه ۱۸ اضافه خواهد شد.", Icons.Outlined.Storage)
        Text("مسیر من · نسخه ۰٫۱٫۰\nپایه پروژه · Kotlin / Compose", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
