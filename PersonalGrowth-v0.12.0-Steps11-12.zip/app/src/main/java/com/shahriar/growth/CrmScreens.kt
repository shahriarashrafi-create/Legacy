package com.shahriar.growth

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.shahriar.growth.data.*
import kotlinx.coroutines.launch

@Composable fun CrmScreen(modifier:Modifier,db:AppDatabase,people:List<Person>,tasks:List<Task>,today:Long,kind:String,initialOwner:String="all",onOpenTask:(String)->Unit,onOpenPerson:(String)->Unit,onMeetings:(String,String)->Unit){
    val raw by db.crmDao().contacts().collectAsState(initial=emptyList());val contacts=raw.map{displayedContact(it,people)}
    val links by db.crmDao().links().collectAsState(initial=emptyList());val notes by db.crmDao().notes().collectAsState(initial=emptyList())
    val orders by db.crmDao().orders().collectAsState(initial=emptyList());val engine=remember(db){CrmEngine(db)};val scope=rememberCoroutineScope()
    var selected by rememberSaveable{mutableStateOf<String?>(null)};var editing by rememberSaveable{mutableStateOf<String?>(null)}
    var owner by rememberSaveable(initialOwner){mutableStateOf(initialOwner)};var pickOwner by remember{mutableStateOf(false)}
    var query by rememberSaveable{mutableStateOf("")};var stage by rememberSaveable{mutableStateOf("all")};var archived by rememberSaveable{mutableStateOf(false)}
    var dueOnly by rememberSaveable{mutableStateOf(false)};var busy by remember{mutableStateOf(false)};var error by remember{mutableStateOf("")}
    var confirm by remember{mutableStateOf("")};var taskDialog by rememberSaveable{mutableStateOf<String?>(null)};var orderEditor by rememberSaveable{mutableStateOf<String?>(null)}
    fun change(action:suspend()->Unit){if(busy)return;busy=true;error="";scope.launch{try{action()}catch(e:Exception){if(e is kotlinx.coroutines.CancellationException)throw e;error=if(e is IllegalArgumentException)e.message?:"تغییر انجام نشد" else "ذخیره انجام نشد؛ دوباره تلاش کن."}finally{busy=false}}}
    val c=contacts.firstOrNull{it.id==selected}
    BackHandler(enabled=selected!=null && editing==null && taskDialog==null && orderEditor==null){selected=null;error=""}
    Column(modifier.fillMaxSize()){
        if(error.isNotEmpty())Text(error,Modifier.padding(12.dp),color=MaterialTheme.colorScheme.error)
        if(c==null){
            val filtered=contacts.filter{it.kind==kind && it.archived==archived && (owner=="all" || it.ownerId==(if(owner=="self")null else owner)) && (stage=="all" || it.stage==stage) && matchesContact(it,query) && (!dueOnly || followupState(it,tasks,today)=="due")}
            LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
                item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text(if(kind=="customer")"مشتریان" else "پراسپکت‌ها",style=MaterialTheme.typography.headlineSmall);Button(onClick={editing="new";error=""},enabled=!busy){Text("+ جدید")}}}
                item{OutlinedTextField(query,{query=it},label={Text("نام، تلفن، شهر، منبع یا علاقه")},singleLine=true,modifier=Modifier.fillMaxWidth())}
                item{Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                    FilterChip(owner=="all",{owner="all"},label={Text("همه مسئول‌ها")})
                    FilterChip(owner!="all",{pickOwner=true},label={Text("مسئول: "+(people.firstOrNull{it.id==owner}?.name?:if(owner=="self")"خودم" else "انتخاب"))})
                    FilterChip(archived,{archived=!archived},label={Text("بایگانی")})
                    FilterChip(dueOnly,{dueOnly=!dueOnly},label={Text("پیگیری امروز و عقب‌افتاده")})
                }}
                item{Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                    FilterChip(stage=="all",{stage="all"},label={Text("همه مراحل")})
                    (if(kind=="customer")listOf("active","inactive") else prospectStages).forEach{s->FilterChip(stage==s,{stage=s},label={Text(contactStageLabel(s))})}
                }}
                item{Text("${faNumber(filtered.size)} پرونده",style=MaterialTheme.typography.bodySmall)}
                if(filtered.isEmpty())item{Text("پرونده‌ای با این فیلترها نیست.");TextButton(onClick={query="";stage="all";owner="all";archived=false;dueOnly=false}){Text("پاک‌کردن فیلترها")}}
                items(filtered,key={it.id}){r->Card(onClick={selected=r.id},modifier=Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){
                    Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
                        Text(r.name,style=MaterialTheme.typography.titleMedium);Text(contactStageLabel(r.stage)+" · مسئول: "+(people.firstOrNull{it.id==r.ownerId}?.name?:"خودم"),style=MaterialTheme.typography.bodySmall)
                        if(r.phone.isNotBlank())Text(r.phone,style=MaterialTheme.typography.bodySmall)
                        val t=tasks.firstOrNull{it.id==r.nextTaskId};Text(if(t==null)"بدون کار پیگیری" else "پیگیری: "+if(t.done)"انجام شده" else if(t.archived)"بایگانی" else dueLabel(t,today),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.primary)
                    }
                }}
            }
        }else{
            val history by remember(c.id){db.crmDao().history(c.id)}.collectAsState(initial=emptyList())
            val related=tasks.filter{t->links.any{it.taskId==t.id && it.contactId==c.id}}
            LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
                item{TextButton(onClick={selected=null;error=""}){Text("بازگشت به فهرست")};Text(c.name,style=MaterialTheme.typography.headlineSmall);Text((if(c.kind=="customer")"مشتری" else "پراسپکت")+" · "+contactStageLabel(c.stage)+(if(c.archived)" · بایگانی" else ""))}
                item{Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    Button(onClick={editing=c.id;error=""},enabled=!busy && !c.archived && c.memberId==null){Text("ویرایش")}
                    OutlinedButton(onClick={confirm="archive"},enabled=!busy){Text(if(c.archived)"بازگردانی" else "بایگانی")}
                    if(c.kind=="prospect" && c.memberId==null && !c.archived){OutlinedButton(onClick={confirm="customer"},enabled=!busy){Text("تبدیل به مشتری")};OutlinedButton(onClick={confirm="member"},enabled=!busy){Text("تبدیل به عضو")}}
                }}
                item{Text("تلفن: ${c.phone.ifBlank{"ثبت نشده"}}\nشهر: ${c.city.ifBlank{"ثبت نشده"}}\nمنبع آشنایی: ${c.source.ifBlank{"ثبت نشده"}}\nعلاقه/نیاز: ${c.interest.ifBlank{"ثبت نشده"}}")}
                item{val p=people.firstOrNull{it.id==c.ownerId};TextButton(onClick={p?.let{onOpenPerson(it.id)}},enabled=p!=null){Text("مسئول: "+(p?.name?:"خودم")+(if(p?.archived==true)" (بایگانی)" else ""))}}
                c.memberId?.let{pid->item{OutlinedButton(onClick={onOpenPerson(pid)}){Text("پرونده عضو شبکه")};Text("نام و تماس از پرونده عضو نمایش داده می‌شود.",style=MaterialTheme.typography.bodySmall)}}
                if(c.summary.isNotBlank())item{Text(c.summary)}
                item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={val next=tasks.firstOrNull{it.id==c.nextTaskId};if(next!=null && reusableFollowup(c,next,links.firstOrNull{it.taskId==next.id}))onOpenTask(next.id) else taskDialog="followup"},enabled=!busy && !c.archived){Text(if(tasks.any{it.id==c.nextTaskId && !it.done && !it.archived})"بازکردن پیگیری" else "قدم پیگیری")};OutlinedButton(onClick={taskDialog="related"},enabled=!busy && !c.archived){Text("کار جدید")}}}
                if(c.nextTaskId!=null)item{val next=tasks.firstOrNull{it.id==c.nextTaskId};if(next!=null)Card(onClick={onOpenTask(next.id)},modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text("قدم پیگیری: "+next.title);Text(if(next.done)"انجام شده" else if(next.archived)"بایگانی" else dueLabel(next,today),style=MaterialTheme.typography.bodySmall)}}}
                item{Text("همه کارهای مرتبط · ${faNumber(related.size)}",style=MaterialTheme.typography.titleMedium)}
                items(related,key={"task"+it.id}){t->Card(onClick={onOpenTask(t.id)},modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text(t.title);Text(if(t.done)"انجام شده" else if(t.archived)"بایگانی" else dueLabel(t,today),style=MaterialTheme.typography.bodySmall)}}}
                item{OutlinedButton(onClick={onMeetings("contact",c.id)}){Text("جلسات و نتایج این پرونده")}}
                item{RecordNotesPanel("contact",c.id,notes.filter{it.recordType=="contact" && it.recordId==c.id},!busy && !c.archived,busy,error,onSave={n,success->change{engine.note(n);success()}},onArchive={n,v->change{engine.archiveNote(n.id,v)}})}
                if(c.kind=="customer")item{OrdersPanel(c,orders.filter{it.contactId==c.id},!busy && !c.archived,onEdit={orderEditor=it?:"new"},onArchive={o,v->change{engine.archiveOrder(o.id,v)}})}
                item{Text("تاریخچه پرونده",style=MaterialTheme.typography.titleMedium)}
                items(history,key={"event"+it.id}){e->Text(e.text+" · "+eventDay(e.at),style=MaterialTheme.typography.bodySmall)}
            }
        }
    }
    if(pickOwner)PersonPicker("فیلتر مسئول پرونده",people,if(owner=="self" || owner=="all")null else owner,"خودم",onDismiss={pickOwner=false},onPick={owner=it?:"self";pickOwner=false})
    if(editing!=null)key(editing){ContactEditor(contacts.firstOrNull{it.id==editing},contacts.firstOrNull{it.id==editing}?.kind?:kind,if(owner=="all" || owner=="self")null else owner,people,contacts,busy,error,onDismiss={if(!busy)editing=null},onSave={r->change{engine.save(r);selected=r.id;editing=null}})}
    if(c!=null && taskDialog!=null)OwnedTaskDialog(if(taskDialog=="followup")"پیگیری ${c.name}" else "",today,busy,error,onDismiss={if(!busy)taskDialog=null},onSave={title,day->change{val id=engine.contactTask(c.id,title,day,taskDialog=="followup");taskDialog=null;onOpenTask(id)}})
    if(c!=null && orderEditor!=null)key(orderEditor){OrderEditor(c.id,orders.firstOrNull{it.id==orderEditor},today,busy,error,onDismiss={if(!busy)orderEditor=null},onSave={o->change{engine.order(o);orderEditor=null}})}
    if(confirm.isNotEmpty() && c!=null)AlertDialog(onDismissRequest={if(!busy)confirm=""},title={Text(when(confirm){"member"->"تبدیل به عضو";"customer"->"تبدیل به مشتری";else->if(c.archived)"بازگردانی پرونده" else "بایگانی پرونده"})},text={Text(when(confirm){"member"->"یک عضو زیرمجموعه مسئول پرونده ساخته می‌شود. پرونده پراسپکت و سوابق آن حفظ می‌شوند.";"customer"->"همین پرونده با همان یادداشت‌ها و کارها به فهرست مشتریان منتقل می‌شود.";else->"سوابق، خریدها و کارهای مرتبط حفظ می‌شوند. کارهای باز همچنان در برنامه روزانه می‌مانند."})},confirmButton={TextButton(onClick={val action=confirm;confirm="";change{when(action){"member"->{val id=engine.member(c.id);onOpenPerson(id)};"customer"->engine.customer(c.id);else->engine.archive(c.id,!c.archived)}}},enabled=!busy){Text("تأیید")}},dismissButton={TextButton(onClick={confirm=""},enabled=!busy){Text("انصراف")}})
}
fun eventDay(at:Long)=persianDay(java.time.Instant.ofEpochMilli(at).atZone(java.time.ZoneId.systemDefault()).toLocalDate().toEpochDay())
@Composable private fun ContactEditor(old:ContactRecord?,kind:String,owner:String?,people:List<Person>,contacts:List<ContactRecord>,busy:Boolean,error:String,onDismiss:()->Unit,onSave:(ContactRecord)->Unit){
    val id=rememberSaveable{old?.id?:java.util.UUID.randomUUID().toString()}
    var name by rememberSaveable{mutableStateOf(old?.name?:"")};var phone by rememberSaveable{mutableStateOf(old?.phone?:"")};var city by rememberSaveable{mutableStateOf(old?.city?:"")}
    var source by rememberSaveable{mutableStateOf(old?.source?:"")};var interest by rememberSaveable{mutableStateOf(old?.interest?:"")};var summary by rememberSaveable{mutableStateOf(old?.summary?:"")}
    var responsible by rememberSaveable{mutableStateOf(if(old!=null)old.ownerId else owner)};var stage by rememberSaveable{mutableStateOf(old?.stage?:if(kind=="customer")"active" else "new")};var picking by remember{mutableStateOf(false)}
    Dialog(onDismissRequest=onDismiss,properties=DialogProperties(usePlatformDefaultWidth=false,dismissOnBackPress=!busy,dismissOnClickOutside=!busy)){Surface(Modifier.fillMaxSize().imePadding(),color=MaterialTheme.colorScheme.background){Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text((if(old==null)"ثبت " else "ویرایش ")+(if(kind=="customer")"مشتری" else "پراسپکت"),style=MaterialTheme.typography.headlineSmall)
        if(error.isNotEmpty())Text(error,color=MaterialTheme.colorScheme.error)
        OutlinedTextField(name,{if(it.length<=80)name=it},label={Text("نام *")},singleLine=true,enabled=!busy,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(phone,{if(it.length<=30)phone=it},label={Text("تلفن")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Phone),singleLine=true,enabled=!busy,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(city,{if(it.length<=80)city=it},label={Text("شهر")},singleLine=true,enabled=!busy,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(source,{if(it.length<=120)source=it},label={Text("منبع آشنایی")},singleLine=true,enabled=!busy,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(interest,{if(it.length<=120)interest=it},label={Text("علاقه یا نیاز")},singleLine=true,enabled=!busy,modifier=Modifier.fillMaxWidth())
        OutlinedButton(onClick={picking=true},enabled=!busy){Text("مسئول: "+(people.firstOrNull{it.id==responsible}?.name?:"خودم"))}
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){(if(kind=="customer")listOf("active","inactive") else prospectStages.filter{it!="joined"}).forEach{s->FilterChip(stage==s,{stage=s},enabled=!busy,label={Text(contactStageLabel(s))})}}
        OutlinedTextField(summary,{if(it.length<=4000)summary=it},label={Text("توضیح پرونده")},minLines=3,enabled=!busy,modifier=Modifier.fillMaxWidth())
        if(phone.isNotBlank() && contacts.any{it.id!=id && normalizeText(it.phone).trim()==normalizeText(phone).trim()})Text("این تلفن در پرونده دیگری هم ثبت شده؛ قبل از ذخیره بررسی کن.",color=MaterialTheme.colorScheme.error)
        Row{Button(onClick={onSave(ContactRecord(id=id,kind=old?.kind?:kind,name=name,phone=phone,city=city,source=source,interest=interest,summary=summary,ownerId=responsible,stage=stage))},enabled=!busy && name.isNotBlank()){Text(if(busy)"در حال ذخیره…" else "ذخیره")};TextButton(onClick=onDismiss,enabled=!busy){Text("انصراف")}}
    }}}
    if(picking)PersonPicker("مسئول پرونده",people.filter{!it.archived},responsible,"خودم",onDismiss={picking=false},onPick={responsible=it;picking=false})
}
@Composable fun OwnedTaskDialog(initialTitle:String,today:Long,busy:Boolean,error:String,onDismiss:()->Unit,onSave:(String,Long?)->Unit){
    var title by rememberSaveable{mutableStateOf(initialTitle)};var date by rememberSaveable{mutableStateOf(persianDay(today,true))};var undated by rememberSaveable{mutableStateOf(false)}
    AlertDialog(onDismissRequest={if(!busy)onDismiss()},title={Text("ثبت کار مشترک")},text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
        if(error.isNotEmpty())Text(error,color=MaterialTheme.colorScheme.error)
        OutlinedTextField(title,{if(it.length<=120)title=it},label={Text("عنوان")},enabled=!busy)
        Row(verticalAlignment=Alignment.CenterVertically){Checkbox(undated,{undated=it},enabled=!busy);Text("بدون موعد")}
        if(!undated)OutlinedTextField(date,{date=it},label={Text("تاریخ شمسی: سال/ماه/روز")},enabled=!busy,isError=parsePersianDay(date)==null)
        Text("پس از ساخت، جزئیات همان کار باز می‌شود. پیگیری باز موجود دوباره ساخته نمی‌شود.",style=MaterialTheme.typography.bodySmall)
    }},confirmButton={TextButton(enabled=!busy && title.isNotBlank() && (undated || parsePersianDay(date)!=null),onClick={onSave(title,if(undated)null else parsePersianDay(date))}){Text("ساخت / بازکردن")}},dismissButton={TextButton(onClick=onDismiss,enabled=!busy){Text("انصراف")}})
}
@Composable fun RecordNotesPanel(type:String,id:String,notes:List<RecordNote>,enabled:Boolean,busy:Boolean,error:String,onSave:(RecordNote,()->Unit)->Unit,onArchive:(RecordNote,Boolean)->Unit){
    var editing by rememberSaveable(type,id){mutableStateOf<String?>(null)};var archived by rememberSaveable(type,id){mutableStateOf(false)};var confirm by remember{mutableStateOf<RecordNote?>(null)}
    Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        Text("یادداشت‌های پرونده",style=MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={editing="new"},enabled=enabled){Text("+ یادداشت")};FilterChip(archived,{archived=!archived},label={Text("بایگانی یادداشت‌ها")})}
        notes.filter{it.archived==archived}.forEach{n->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){
            Text(n.text);Text(eventDay(n.updatedAt),style=MaterialTheme.typography.bodySmall)
            Row{if(!n.archived)TextButton(onClick={editing=n.id},enabled=enabled){Text("ویرایش")};TextButton(onClick={confirm=n},enabled=enabled){Text(if(n.archived)"بازگردانی" else "بایگانی")}}
        }}}
    }
    if(editing!=null)key(editing){val old=notes.firstOrNull{it.id==editing};var text by rememberSaveable{mutableStateOf(old?.text?:"")}
        AlertDialog(onDismissRequest={if(!busy)editing=null},title={Text("یادداشت")},text={Column{if(error.isNotEmpty())Text(error,color=MaterialTheme.colorScheme.error);OutlinedTextField(text,{if(it.length<=4000)text=it},modifier=Modifier.fillMaxWidth().heightIn(max=300.dp),minLines=4,enabled=!busy)}},confirmButton={TextButton(enabled=!busy && text.isNotBlank(),onClick={onSave(RecordNote(id=old?.id?:java.util.UUID.randomUUID().toString(),recordType=type,recordId=id,text=text)){editing=null}}){Text("ذخیره")}},dismissButton={TextButton(onClick={editing=null},enabled=!busy){Text("انصراف")}})
    }
    confirm?.let{n->AlertDialog(onDismissRequest={confirm=null},title={Text(if(n.archived)"بازگردانی یادداشت" else "بایگانی یادداشت")},text={Text("متن یادداشت حفظ می‌شود و تغییر در تاریخچه ثبت خواهد شد.")},confirmButton={TextButton(onClick={confirm=null;onArchive(n,!n.archived)},enabled=enabled){Text("تأیید")}},dismissButton={TextButton(onClick={confirm=null}){Text("انصراف")}})}
}
@Composable fun TaskContactPanel(task:Task,contacts:List<ContactRecord>,links:List<TaskContact>,busy:Boolean,onAssign:(String?)->Unit){
    var picking by remember{mutableStateOf(false)};var query by remember{mutableStateOf("")};val c=contacts.firstOrNull{r->links.any{it.taskId==task.id && it.contactId==r.id}}
    OutlinedButton(onClick={picking=true},enabled=!busy,modifier=Modifier.fillMaxWidth()){Text("پرونده مرتبط: "+(c?.let{it.name+(if(it.archived)" (بایگانی)" else "")}?:"انتخاب مشتری یا پراسپکت"))}
    if(picking)Dialog(onDismissRequest={picking=false}){Surface{Column(Modifier.padding(16.dp).heightIn(max=500.dp)){
        Text("انتخاب پرونده");OutlinedTextField(query,{query=it},label={Text("جست‌وجو")},modifier=Modifier.fillMaxWidth())
        LazyColumn(Modifier.weight(1f,false)){item{TextButton(onClick={onAssign(null);picking=false}){Text("حذف ارتباط پرونده")}};items(contacts.filter{!it.archived && matchesContact(it,query)},key={it.id}){r->TextButton(onClick={onAssign(r.id);picking=false}){Text(r.name+" · "+if(r.kind=="customer")"مشتری" else "پراسپکت")}}}
        TextButton(onClick={picking=false}){Text("بستن")}
    }}}
}
