package com.shahriar.growth.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName="meetings",indices=[Index(value=["taskId"],unique=true)])
data class Meeting(@PrimaryKey val id:String=java.util.UUID.randomUUID().toString(),val taskId:String,val kind:String="other",val location:String="",val agenda:String="",val result:String="",val outcome:String="planned",val createdAt:Long=System.currentTimeMillis(),val updatedAt:Long=createdAt)
@Entity(tableName="meeting_events",indices=[Index("meetingId")])
data class MeetingEvent(@PrimaryKey val id:String=java.util.UUID.randomUUID().toString(),val meetingId:String,val text:String,val at:Long=System.currentTimeMillis())
@Dao interface MeetingDao {
    @Query("SELECT * FROM meetings ORDER BY createdAt DESC,id") fun observe():Flow<List<Meeting>>
    @Query("SELECT * FROM meetings WHERE id=:id") suspend fun get(id:String):Meeting?
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(meeting:Meeting)
    @Insert suspend fun event(event:MeetingEvent)
    @Query("SELECT * FROM meeting_events WHERE meetingId=:id ORDER BY at DESC,id") fun history(id:String):Flow<List<MeetingEvent>>
}
val meetingKinds=listOf("intro","followup","training","sale","other")
fun meetingKindLabel(kind:String)=when(kind){"intro"->"معرفی / ارائه";"followup"->"پیگیری";"training"->"آموزش";"sale"->"فروش";else->"سایر"}
fun meetingStatus(m:Meeting,t:Task?):String=when {
    t==null->"missing"
    t.archived->if(m.outcome in listOf("cancelled","noshow"))m.outcome else "archived"
    t.done->if(m.outcome=="held")"held" else "needs_result"
    m.outcome!="planned"->"reopened"
    else->"planned"
}
fun meetingStatusLabel(status:String)=when(status){"held"->"برگزار شده";"cancelled"->"لغو شده";"noshow"->"عدم حضور";"archived"->"بایگانی";"needs_result"->"کار انجام شده؛ نتیجه جلسه ثبت نشده";"reopened"->"بازگشایی؛ نتیجه قبلی حفظ شده";"missing"->"کار پیدا نشد";else->"برنامه‌ریزی شده"}
fun meetingRecord(taskId:String,owners:List<TaskOwner>,links:List<TaskContact>):Pair<String,String> = links.firstOrNull{it.taskId==taskId}?.let{"contact" to it.contactId}
    ?:owners.firstOrNull{it.taskId==taskId}?.let{"person" to it.personId}?: ("self" to "")
fun validateMeetingDraft(title:String,day:Long,minute:Int,duration:Int,m:Meeting){
    require(title.trim().length in 1..120 && m.location.length<=200 && m.agenda.length<=4000 && m.result.length<=4000){"عنوان یا طول متن معتبر نیست."}
    require(day in java.time.LocalDate.of(1900,1,1).toEpochDay()..java.time.LocalDate.of(2300,1,1).toEpochDay() && minute in 0..1439 && duration in 1..240){"تاریخ، ساعت یا مدت معتبر نیست."}
    require(minute+duration<=1440){"جلسه باید پیش از پایان همان روز تمام شود."}
    require(m.kind in meetingKinds){"نوع جلسه معتبر نیست."}
}
class MeetingEngine(private val db:AppDatabase,private val context:Context){
    private val dao get()=db.meetingDao()
    suspend fun save(draft:Meeting,title:String,day:Long,minute:Int,duration:Int,recordType:String,recordId:String)=db.withTransaction{
        validateMeetingDraft(title,day,minute,duration,draft)
        val old=dao.get(draft.id);val task=if(old==null)null else requireNotNull(db.taskDao().get(old.taskId)){"کار جلسه پیدا نشد."}
        require(task?.archived!=true){"ابتدا جلسه را بازگشایی کن."}
        require(task==null || db.taskDao().hasFocus(task.id)==0){"ابتدا جلسه تمرکز این کار را ببند."}
        val t=(task?:Task(id=draft.taskId,title=title)).copy(title=title.trim(),dueDay=day,dueMinute=minute,duration=duration)
        db.taskDao().save(t)
        val currentLink=db.crmDao().link(t.id);val currentPerson=db.networkDao().owner(t.id)
        val currentRecord=currentLink?.let{"contact" to it.contactId}?:currentPerson?.let{"person" to it.personId}?: ("self" to "")
        if(currentRecord!=(recordType to recordId)) when(recordType){
            "person"->NetworkEngine(db).assign(t.id,recordId)
            "contact"->CrmEngine(db).assign(t.id,recordId)
            "self"->NetworkEngine(db).assign(t.id,null)
            else->throw IllegalArgumentException("پرونده معتبر نیست.")
        }
        val m=draft.copy(taskId=t.id,location=draft.location.trim(),agenda=draft.agenda.trim(),result=draft.result.trim(),outcome=old?.outcome?:"planned",createdAt=old?.createdAt?:draft.createdAt,updatedAt=System.currentTimeMillis())
        dao.put(m);audit(m,if(old==null)"ثبت جلسه و ساخت کار مشترک" else "ویرایش جلسه و کار مشترک")
    }
    suspend fun finish(id:String,outcome:String,result:String)=db.withTransaction{
        val m=requireNotNull(dao.get(id)){"جلسه پیدا نشد."};val task=requireNotNull(db.taskDao().get(m.taskId))
        require(result.trim().length in 1..4000){"خلاصه نتیجه را بنویس."};require(outcome in listOf("held","cancelled","noshow")){"نتیجه معتبر نیست."}
        if(outcome=="held"){
            require(!task.archived){"ابتدا جلسه را بازگشایی کن."};ExecutionEngine(db,context).complete(task.id,true)
        }else{
            require(!task.done){"برای لغو یا عدم حضور، ابتدا جلسه انجام‌شده را بازگشایی کن."}
            db.taskDao().archive(task.id,true)
        }
        val updated=m.copy(result=result.trim(),outcome=outcome,updatedAt=System.currentTimeMillis());dao.put(updated);audit(updated,"ثبت نتیجه: "+meetingStatusLabel(outcome))
    }
    suspend fun reopen(id:String)=db.withTransaction{
        val m=requireNotNull(dao.get(id));val t=requireNotNull(db.taskDao().get(m.taskId))
        require(db.taskDao().hasFocus(t.id)==0){"ابتدا تمرکز را ببند."}
        db.taskDao().archive(t.id,false);ExecutionEngine(db,context).complete(t.id,false)
        dao.put(m.copy(outcome="planned",updatedAt=System.currentTimeMillis()));audit(m,"بازگشایی جلسه؛ متن نتیجه قبلی حفظ شد")
    }
    private suspend fun audit(m:Meeting,text:String){
        dao.event(MeetingEvent(meetingId=m.id,text=text))
        val link=db.crmDao().link(m.taskId);val person=db.networkDao().owner(m.taskId)
        if(link!=null)db.crmDao().event(ContactEvent(contactId=link.contactId,text="جلسه: $text"))
        else if(person!=null)db.networkDao().event(PersonEvent(personId=person.personId,text="جلسه: $text"))
    }
}
val MIGRATION_5_6=object:Migration(5,6){override fun migrate(db:SupportSQLiteDatabase){
    db.execSQL("CREATE TABLE IF NOT EXISTS meetings (id TEXT NOT NULL, taskId TEXT NOT NULL, kind TEXT NOT NULL, location TEXT NOT NULL, agenda TEXT NOT NULL, result TEXT NOT NULL, outcome TEXT NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL, PRIMARY KEY(id))")
    db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_meetings_taskId ON meetings(taskId)")
    db.execSQL("CREATE TABLE IF NOT EXISTS meeting_events (id TEXT NOT NULL, meetingId TEXT NOT NULL, text TEXT NOT NULL, at INTEGER NOT NULL, PRIMARY KEY(id))")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_meeting_events_meetingId ON meeting_events(meetingId)")
    db.execSQL("CREATE TABLE IF NOT EXISTS performance_entries (id TEXT NOT NULL, personId TEXT, day INTEGER NOT NULL, pv REAL NOT NULL, gv REAL NOT NULL, invitations INTEGER NOT NULL, presentations INTEGER NOT NULL, followups INTEGER NOT NULL, note TEXT NOT NULL, archived INTEGER NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL, PRIMARY KEY(id))")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_performance_entries_personId_day ON performance_entries(personId,day)")
    db.execSQL("CREATE TABLE IF NOT EXISTS activity_credits (sourceType TEXT NOT NULL, sourceId TEXT NOT NULL, personId TEXT, PRIMARY KEY(sourceType,sourceId))")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_activity_credits_personId ON activity_credits(personId)")
    db.execSQL("CREATE TABLE IF NOT EXISTS performance_events (id TEXT NOT NULL, text TEXT NOT NULL, at INTEGER NOT NULL, PRIMARY KEY(id))")
    db.execSQL("INSERT INTO activity_credits (sourceType,sourceId,personId) SELECT 'order',o.id,c.ownerId FROM customer_orders o LEFT JOIN contacts c ON c.id=o.contactId")
    db.execSQL("INSERT INTO activity_credits (sourceType,sourceId,personId) SELECT 'task',t.id,CASE WHEN tc.taskId IS NOT NULL THEN c.ownerId ELSE ow.personId END FROM tasks t LEFT JOIN task_contacts tc ON tc.taskId=t.id LEFT JOIN contacts c ON c.id=tc.contactId LEFT JOIN task_owners ow ON ow.taskId=t.id WHERE t.done=1")
    db.execSQL("INSERT INTO activity_credits (sourceType,sourceId,personId) SELECT 'join',id,parentId FROM people")
    db.execSQL("INSERT INTO activity_credits (sourceType,sourceId,personId) SELECT 'contact',id,ownerId FROM contacts")
    db.execSQL("INSERT OR IGNORE INTO activity_credits (sourceType,sourceId,personId) SELECT 'followup',nextTaskId,ownerId FROM contacts WHERE nextTaskId IS NOT NULL")
}}
