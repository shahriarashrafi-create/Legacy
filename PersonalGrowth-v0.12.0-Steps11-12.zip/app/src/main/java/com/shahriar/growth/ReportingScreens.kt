package com.shahriar.growth

import android.icu.util.Calendar
import android.icu.util.ULocale
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.shahriar.growth.data.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId

fun reportRange(day:Long,period:String):DayRange = when(period){
    "week"->weekRange(day)
    "month"->{val c=Calendar.getInstance(ULocale("fa_IR@calendar=persian"));c.timeInMillis=LocalDate.ofEpochDay(day).atTime(12,0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();val start=day-c.get(Calendar.DAY_OF_MONTH)+1;DayRange(start,start+c.getActualMaximum(Calendar.DAY_OF_MONTH))}
    else->DayRange(day,day+1)
}
fun metricNumber(value:Double)=faNumber(java.math.BigDecimal.valueOf(value).stripTrailingZeros().toPlainString())
@Composable fun ReportingScreen(modifier:Modifier,db:AppDatabase,today:Long,initialOwner:String?,onOpenTask:(String)->Unit){
    val people by db.networkDao().observe().collectAsState(initial=emptyList());val contacts by db.crmDao().contacts().collectAsState(initial=emptyList());val orders by db.crmDao().orders().collectAsState(initial=emptyList())
    val tasks by db.taskDao().observe().collectAsState(initial=emptyList());val meetings by db.meetingDao().observe().collectAsState(initial=emptyList());val entries by db.reportingDao().entries().collectAsState(initial=emptyList());val credits by db.reportingDao().credits().collectAsState(initial=emptyList());val history by db.reportingDao().history().collectAsState(initial=emptyList())
    val engine=remember(db){ReportingEngine(db)};val scope=rememberCoroutineScope()
    var owner by rememberSaveable(initialOwner){mutableStateOf(initialOwner)};var picking by remember{mutableStateOf(false)};var team by rememberSaveable{mutableStateOf(false)}
    var date by rememberSaveable{mutableStateOf(persianDay(today,true))};var period by rememberSaveable{mutableStateOf("month")};var tab by rememberSaveable{mutableStateOf(0)};var archived by rememberSaveable{mutableStateOf(false)}
    var editor by rememberSaveable{mutableStateOf<String?>(null)};var orderCredit by remember{mutableStateOf<String?>(null)};var archiveEntry by remember{mutableStateOf<PerformanceEntry?>(null)}
    var busy by remember{mutableStateOf(false)};var error by remember{mutableStateOf("")}
    fun change(block:suspend()->Unit){if(busy)return;busy=true;error="";scope.launch{try{block()}catch(e:Exception){if(e is kotlinx.coroutines.CancellationException)throw e;error=if(e is IllegalArgumentException)e.message?:"عملیات انجام نشد" else "ثبت تغییر انجام نشد؛ دوباره تلاش کن."}finally{busy=false}}}
    val day=parsePersianDay(date);val range=reportRange(day?:today,period);val set=metricScope(owner,team,people)
    val totals=computePerformance(owner,team,range,people,contacts,orders,tasks,meetings,entries,credits)
    val ownerName=people.firstOrNull{it.id==owner}?.name?:"خودم"
    LazyColumn(modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{Text("عملکرد من و شبکه",style=MaterialTheme.typography.headlineSmall);Text("ثبت عملکرد فعال است؛ هدف‌گذاری در نسخه ۱۳ اضافه می‌شود.",style=MaterialTheme.typography.bodySmall)}
        item{Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedButton(onClick={picking=true}){Text(ownerName+(if(people.firstOrNull{it.id==owner}?.archived==true)" (بایگانی)" else ""))}
            FilterChip(team,{team=!team},label={Text("همراه زیرمجموعه")})
            Button(onClick={editor="new";error=""},enabled=!busy && (owner==null || people.any{it.id==owner && !it.archived})){Text("+ ثبت عملکرد")}
        }}
        item{Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("day" to "روز","week" to "هفته","month" to "ماه شمسی").forEach{(v,l)->FilterChip(period==v,{period=v},label={Text(l)})}}}
        item{OutlinedTextField(date,{date=it},label={Text("تاریخ شمسی مبنا: سال/ماه/روز")},isError=day==null,singleLine=true,modifier=Modifier.fillMaxWidth())}
        item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){TextButton(onClick={date=persianDay(range.start-1,true)},enabled=day!=null){Text("قبلی")};TextButton(onClick={date=persianDay(today,true)}){Text("امروز")};TextButton(onClick={date=persianDay(range.end,true)},enabled=day!=null){Text("بعدی")}};if(day!=null)Text(persianDay(range.start)+" تا "+persianDay(range.end-1),style=MaterialTheme.typography.bodySmall)}
        item{Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("خلاصه","ثبت‌های دستی","PV خریدها","تاریخچه").forEachIndexed{i,l->FilterChip(tab==i,{tab=i},label={Text(l)})}}}
        if(error.isNotEmpty())item{Text(error,color=MaterialTheme.colorScheme.error)}
        if(day==null)item{Text("تاریخ معتبر وارد کن تا گزارش نمایش داده شود.")}
        else when(tab){
            0->{
                item{MetricCards(listOf((if(team)"PV محدوده شاخه" else "PV شخصی") to metricNumber(totals.pv),"GV ثبت‌شده $ownerName" to metricNumber(totals.gv),"PV گروه با خود فرد" to metricNumber(totals.groupPv),"کار تکمیل‌شده" to faNumber(totals.completedTasks),"دعوت" to faNumber(totals.invitations),"ارائه" to faNumber(totals.presentations),"پیگیری" to faNumber(totals.followups),"جلسه برگزارشده" to faNumber(totals.heldMeetings),"عضو معرفی‌شده" to faNumber(totals.newMembers),"پرونده ساخته‌شده" to faNumber(totals.newRecords)))}
                item{Text("منبع محاسبه",style=MaterialTheme.typography.titleMedium);Text("PV = خریدهای معتبر + PV دستی خارج از خریدها. ارائه و پیگیری، جلسات/کارهای خودکار را با ثبت‌های دستی خارج از آن‌ها جمع می‌کنند. هر کار خودکار فقط یک بار شمرده می‌شود.")}
                item{Text("GV گزارش‌شده فقط از ثبت‌های همین فرد خوانده می‌شود و در حالت شاخه جمع نمی‌شود؛ PV گروه جمع PV فرد و زیرمجموعه بر اساس ساختار فعلی است. فرمول امتیاز شرکت را فرض نمی‌کنیم.",style=MaterialTheme.typography.bodySmall)}
                item{Text("اعتبار تاریخی خرید و کارِ تکمیل‌شده با انتقال مسئول پرونده عوض نمی‌شود. خریدهای قبل از نسخه ۱۲ یک بار به نام مسئول هنگام ارتقا ثبت شده‌اند؛ اصلاح اعتبار خرید در تب PV خریدهاست.",style=MaterialTheme.typography.bodySmall)}
            }
            1->{
                item{FilterChip(archived,{archived=!archived},label={Text("بایگانی ثبت‌های دستی")})}
                val rows=entries.filter{it.archived==archived && it.personId in set && range.contains(it.day)}
                if(rows.isEmpty())item{Text("ثبت دستی در این بازه نیست.")}
                items(rows,key={it.id}){e->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){
                    Text((people.firstOrNull{it.id==e.personId}?.name?:"خودم")+" · "+persianDay(e.day),style=MaterialTheme.typography.titleMedium)
                    Text("PV خارج از خریدها: ${metricNumber(e.pv)} · GV: ${metricNumber(e.gv)}")
                    Text("دعوت ${faNumber(e.invitations)} · ارائه خارج از جلسات ${faNumber(e.presentations)} · پیگیری خارج از خودکار ${faNumber(e.followups)}",style=MaterialTheme.typography.bodySmall)
                    if(e.note.isNotBlank())Text(e.note)
                    Row{if(!e.archived)TextButton(onClick={editor=e.id},enabled=!busy){Text("ویرایش")};TextButton(onClick={archiveEntry=e},enabled=!busy){Text(if(e.archived)"بازگردانی" else "بایگانی")}}
                }}}
            }
            2->{
                item{Text("این فهرست فقط خریدهای غیربایگانی در بازه و محدوده انتخابی را نشان می‌دهد. ویرایش مقدار خرید از پرونده مشتری انجام می‌شود.",style=MaterialTheme.typography.bodySmall)}
                val rows=orders.filter{o->!o.archived && range.contains(o.day) && credits.any{it.sourceType=="order" && it.sourceId==o.id && it.personId in set}}
                if(rows.isEmpty())item{Text("خریدی در این بازه نیست.")}
                items(rows,key={it.id}){o->val credit=credits.firstOrNull{it.sourceType=="order" && it.sourceId==o.id};Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){
                    Text(o.item,style=MaterialTheme.typography.titleMedium);Text((contacts.firstOrNull{it.id==o.contactId}?.let{displayedContact(it,people).name}?:"پرونده")+" · "+persianDay(o.day));Text("PV: ${metricNumber(o.pv)} · اعتبار: "+(people.firstOrNull{it.id==credit?.personId}?.name?:"خودم"))
                    TextButton(onClick={orderCredit=o.id},enabled=!busy){Text("اصلاح صاحب اعتبار خرید")}
                }}}
            }
            3->{item{Text("تاریخچه سراسری تغییرات عملکرد (۱۰۰ مورد آخر)",style=MaterialTheme.typography.bodySmall)};items(history,key={it.id}){e->Text(e.text+" · "+eventDay(e.at))}}
        }
    }
    if(picking)PersonPicker("فرد گزارش",people,owner,"خودم",onDismiss={picking=false},onPick={owner=it;picking=false})
    if(editor!=null)key(editor){PerformanceEditor(entries.firstOrNull{it.id==editor},owner,people,day?:today,busy,error,onDismiss={if(!busy)editor=null},onSave={e->change{engine.save(e);editor=null}})}
    orderCredit?.let{id->PersonPicker("ثبت اعتبار تاریخی خرید به نام",people.filter{!it.archived},credits.firstOrNull{it.sourceType=="order" && it.sourceId==id}?.personId,"خودم",onDismiss={orderCredit=null},onPick={pid->orderCredit=null;change{engine.creditOrder(id,pid)}})}
    archiveEntry?.let{e->AlertDialog(onDismissRequest={archiveEntry=null},title={Text(if(e.archived)"بازگردانی عملکرد" else "بایگانی عملکرد")},text={Text("ثبت بایگانی در جمع عملکرد لحاظ نمی‌شود؛ سابقه آن حفظ می‌شود.")},confirmButton={TextButton(onClick={archiveEntry=null;change{engine.archive(e.id,!e.archived)}},enabled=!busy){Text("تأیید")}},dismissButton={TextButton(onClick={archiveEntry=null}){Text("انصراف")}})}
}
@Composable private fun MetricCards(values:List<Pair<String,String>>){Column(verticalArrangement=Arrangement.spacedBy(8.dp)){values.chunked(2).forEach{row->Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){row.forEach{(label,value)->Card(Modifier.weight(1f)){Column(Modifier.padding(14.dp)){Text(label,style=MaterialTheme.typography.bodySmall);Text(value,style=MaterialTheme.typography.titleLarge)}}}}}}}
@Composable private fun PerformanceEditor(old:PerformanceEntry?,defaultOwner:String?,people:List<Person>,day:Long,busy:Boolean,error:String,onDismiss:()->Unit,onSave:(PerformanceEntry)->Unit){
    val id=rememberSaveable{old?.id?:java.util.UUID.randomUUID().toString()};var owner by rememberSaveable{mutableStateOf(if(old!=null)old.personId else defaultOwner)};var picking by remember{mutableStateOf(false)}
    var date by rememberSaveable{mutableStateOf(persianDay(old?.day?:day,true))};var pv by rememberSaveable{mutableStateOf(old?.pv?.toString()?:"0")};var gv by rememberSaveable{mutableStateOf(old?.gv?.toString()?:"0")}
    var invites by rememberSaveable{mutableStateOf(old?.invitations?.toString()?:"0")};var presentations by rememberSaveable{mutableStateOf(old?.presentations?.toString()?:"0")};var followups by rememberSaveable{mutableStateOf(old?.followups?.toString()?:"0")};var note by rememberSaveable{mutableStateOf(old?.note?:"")}
    fun decimal(raw:String)=normalizeText(raw).trim().replace('٫','.').toDoubleOrNull()
    val p=decimal(pv);val g=decimal(gv);val i=normalizeText(invites).trim().toIntOrNull();val pr=normalizeText(presentations).trim().toIntOrNull();val f=normalizeText(followups).trim().toIntOrNull();val d=parsePersianDay(date)
    val valid=p!=null && g!=null && p.isFinite() && g.isFinite() && p in 0.0..1000000000.0 && g in 0.0..1000000000.0 && i!=null && pr!=null && f!=null && i in 0..1000000 && pr in 0..1000000 && f in 0..1000000 && d!=null && (p>0 || g>0 || i>0 || pr>0 || f>0)
    Dialog(onDismissRequest=onDismiss,properties=DialogProperties(usePlatformDefaultWidth=false,dismissOnBackPress=!busy,dismissOnClickOutside=!busy)){Surface(Modifier.fillMaxSize().imePadding(),color=MaterialTheme.colorScheme.background){Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("ثبت عملکرد دستی",style=MaterialTheme.typography.headlineSmall);if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
        OutlinedButton(onClick={picking=true},enabled=!busy){Text(people.firstOrNull{it.id==owner}?.name?:"خودم")}
        OutlinedTextField(date,{date=it},label={Text("تاریخ شمسی: سال/ماه/روز")},isError=d==null,modifier=Modifier.fillMaxWidth(),enabled=!busy)
        Text("خریدها، جلسات ارائه و پیگیری‌های خودکار دوباره ثبت نشوند. فقط مقدارهای خارج از آن‌ها را وارد کن.",style=MaterialTheme.typography.bodySmall)
        OutlinedTextField(pv,{if(it.length<=18)pv=it},label={Text("PV خارج از خریدهای ثبت‌شده")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.fillMaxWidth(),enabled=!busy)
        OutlinedTextField(gv,{if(it.length<=18)gv=it},label={Text("GV همین روز برای این فرد")},supportingText={Text("جمع ماه را در روزهای مختلف دوباره وارد نکن.")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.fillMaxWidth(),enabled=!busy)
        OutlinedTextField(invites,{if(it.length<=8)invites=it},label={Text("تعداد دعوت")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),modifier=Modifier.fillMaxWidth(),enabled=!busy)
        OutlinedTextField(presentations,{if(it.length<=8)presentations=it},label={Text("ارائه خارج از جلسات ثبت‌شده")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),modifier=Modifier.fillMaxWidth(),enabled=!busy)
        OutlinedTextField(followups,{if(it.length<=8)followups=it},label={Text("پیگیری خارج از کارها/جلسات خودکار")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),modifier=Modifier.fillMaxWidth(),enabled=!busy)
        OutlinedTextField(note,{if(it.length<=4000)note=it},label={Text("یادداشت و منبع گزارش")},minLines=3,modifier=Modifier.fillMaxWidth(),enabled=!busy)
        Row{Button(onClick={onSave(PerformanceEntry(id=id,personId=owner,day=d!!,pv=p!!,gv=g!!,invitations=i!!,presentations=pr!!,followups=f!!,note=note))},enabled=!busy && valid){Text("ذخیره")};TextButton(onClick=onDismiss,enabled=!busy){Text("انصراف")}}
    }}}
    if(picking)PersonPicker("ثبت به نام",people.filter{!it.archived},owner,"خودم",onDismiss={picking=false},onPick={owner=it;picking=false})
}
