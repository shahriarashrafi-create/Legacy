package com.shahriar.growth

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shahriar.growth.data.*
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private val HomeBlue=Color(0xFF355CDE)
private val HomeInk=Color(0xFF17223B)
private val HomeMuted=Color(0xFF78849A)

@Composable
fun RedesignedHome(modifier:Modifier,tasks:List<Task>,choice:ActionChoice?,today:Long,active:FocusSession?,edges:List<Prerequisite>,meetings:List<Meeting>,wallet:List<WalletEntry>,name:String?,onFocus:(String)->Unit,onSchedule:()->Unit,onMeetings:(String)->Unit,onNew:()->Unit,onOpen:(String)->Unit,onList:(Int)->Unit) {
    val xp=wallet.sumOf{it.xp}.coerceAtLeast(0)
    val coins=wallet.sumOf{it.coins}
    val level=levelFor(xp)
    val xpInLevel=xp%100
    val doneToday=tasks.count{!it.archived && it.done && it.completedAt?.let{stamp->localDay(stamp,ZoneId.systemDefault())==today}==true}
    val totalToday=tasks.count{!it.archived && (it.dueDay==today || (it.done && it.completedAt?.let{stamp->localDay(stamp,ZoneId.systemDefault())==today}==true))}
    val combo=streakDays(tasks.filter{it.done}.mapNotNull{it.completedAt?.let{stamp->localDay(stamp,ZoneId.systemDefault())}}.toSet(),today)
    val first=tasks.firstOrNull{it.id==active?.taskId} ?: nextAction(tasks,choice,today,edges)
    val candidates=tasks.filter{!it.archived && !it.done && it.id!=first?.id && (it.dueDay==null || it.dueDay<=today)}
        .filter{task->edges.none{edge->edge.taskId==task.id && tasks.any{it.id==edge.dependsOnId && !it.done}}}
        .sortedWith(compareByDescending<Task>{it.priority}.thenBy{it.dueDay?:Long.MAX_VALUE}.thenBy{it.dueMinute?:1440})
    val suggested=(listOfNotNull(first)+candidates).distinctBy{it.id}.take(3)
    val upcoming=meetings.mapNotNull{m->tasks.firstOrNull{it.id==m.taskId}?.let{t->if(!t.archived && !t.done && t.dueDay!=null && t.dueDay>=today) m to t else null}}
        .sortedWith(compareBy<Pair<Meeting,Task>>{it.second.dueDay}.thenBy{it.second.dueMinute?:1440}).take(3)
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=16.dp,vertical=16.dp),verticalArrangement=Arrangement.spacedBy(22.dp)) {
        Card(colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(17.dp),verticalArrangement=Arrangement.spacedBy(17.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(47.dp).background(Color(0xFFEEF2FF),RoundedCornerShape(14.dp)),contentAlignment=Alignment.Center){Icon(Icons.Outlined.EmojiEvents,null,tint=HomeBlue)}
                    Spacer(Modifier.width(10.dp))
                    Text("Level $level: ${levelName(level)}",Modifier.weight(1f),color=HomeInk,fontWeight=FontWeight.Bold,fontSize=15.sp,maxLines=1)
                    Box(Modifier.size(43.dp).background(Color(0xFFE9EDF5),CircleShape),contentAlignment=Alignment.Center){Icon(Icons.Outlined.Person,"تصویر پروفایل",tint=HomeMuted)}
                }
                LinearProgressIndicator(progress={xpInLevel/100f},modifier=Modifier.fillMaxWidth().height(9.dp),color=HomeBlue,trackColor=Color(0xFFE9EEFA))
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                    Metric(Icons.Outlined.Bolt,"${xpInLevel}/100")
                    Metric(Icons.Outlined.Paid,"$coins")
                    Box(Modifier.size(38.dp),contentAlignment=Alignment.Center){CircularProgressIndicator(progress={if(totalToday==0)0f else doneToday.toFloat()/totalToday},color=HomeBlue,trackColor=Color(0xFFE9EEFA),strokeWidth=4.dp,modifier=Modifier.fillMaxSize());Text("$doneToday",fontWeight=FontWeight.Bold,fontSize=13.sp)}
                    Metric(Icons.Outlined.LocalFireDepartment,"$combo")
                }
            }
        }
        Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("قدم بعدی",fontWeight=FontWeight.Bold,color=HomeInk);TextButton(onClick={onList(6)}){Text("مشاهده همه",fontSize=12.sp)}}
            if(suggested.isEmpty()) Card(colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.fillMaxWidth().padding(18.dp)){Text("فعلاً کار آماده‌ای وجود ندارد.");TextButton(onClick=onNew){Text("افزودن کار")}}}
            suggested.firstOrNull()?.let{task->HomeTaskRow(task,true,{onOpen(task.id)})}
            if(suggested.size>1) Card(colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(20.dp)) {
                Column {suggested.drop(1).forEachIndexed{index,task->if(index>0)HorizontalDivider(color=Color(0xFFF0F2F8));HomeTaskRow(task,false,{onOpen(task.id)})}}
            }
        }
        Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("جلسه بعدی",fontWeight=FontWeight.Bold,color=HomeInk);TextButton(onClick=onSchedule){Text("تایم‌شیت",fontSize=12.sp)}}
            if(upcoming.isEmpty()) Card(colors=CardDefaults.cardColors(containerColor=Color.White)){Text("جلسه آینده‌ای ثبت نشده است.",Modifier.fillMaxWidth().padding(18.dp),color=HomeMuted)}
            else Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                upcoming.forEach{(meeting,task)->
                    Card(onClick={onMeetings(meeting.id)},modifier=Modifier.weight(1f),shape=RoundedCornerShape(15.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
                        Column(Modifier.fillMaxWidth().padding(horizontal=6.dp,vertical=14.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(8.dp)) {
                            Text(java.time.LocalDate.ofEpochDay(task.dueDay!!).dayOfWeek.let{listOf("دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه","شنبه","یکشنبه")[it.value-1]},fontSize=11.sp,color=HomeInk)
                            Text(task.dueMinute?.let{"%02d:%02d".format(it/60,it%60)}?:"—",fontSize=12.sp,color=HomeBlue,fontWeight=FontWeight.Bold)
                            Text(task.title,fontSize=10.sp,maxLines=1,overflow=TextOverflow.Ellipsis,color=HomeInk)
                        }
                    }
                }
            }
        }
    }
}

private fun levelName(level:Int):String = when(level){1->"Beginner";2->"Explorer";3->"Learner";4->"Builder";5->"Achiever";6->"Rising Star";7->"Challenger";8->"Expert";9->"Champion";10->"Elite";11->"Legend";12->"Master";else->"Level $level"}

@Composable private fun Metric(icon:androidx.compose.ui.graphics.vector.ImageVector,value:String){Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(3.dp)){Icon(icon,null,tint=HomeBlue,modifier=Modifier.size(17.dp));Text(value,fontSize=12.sp,fontWeight=FontWeight.Bold,color=HomeInk)}}

@Composable private fun HomeTaskRow(task:Task,featured:Boolean,onStart:()->Unit){
    val fg=if(featured)Color.White else HomeInk
    val coins=rewardFor(task.priority)
    Row(Modifier.fillMaxWidth().then(if(featured)Modifier.background(HomeBlue,RoundedCornerShape(20.dp)) else Modifier).padding(14.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)) {
        Icon(Icons.Outlined.ListAlt,null,tint=if(featured)Color.White else HomeBlue,modifier=Modifier.size(24.dp))
        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            Text(task.title,color=fg,fontWeight=FontWeight.SemiBold,fontSize=13.sp,maxLines=2,overflow=TextOverflow.Ellipsis)
            Text("⚡ 20 XP    🪙 $coins",fontSize=11.sp,color=if(featured)Color(0xFFE9EEFF) else HomeMuted)
        }
        Button(onClick=onStart,contentPadding=PaddingValues(horizontal=12.dp,vertical=3.dp),colors=ButtonDefaults.buttonColors(containerColor=if(featured)Color.White else Color(0xFFEEF2FF),contentColor=HomeBlue)){Text("شروع",fontSize=12.sp)}
    }
}
