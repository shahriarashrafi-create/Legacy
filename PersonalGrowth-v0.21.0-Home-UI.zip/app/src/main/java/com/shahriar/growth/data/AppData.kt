package com.shahriar.growth.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

@Entity(tableName = "profile")
data class Profile(@PrimaryKey val id: Int = 1, val name: String = "شهریار")
@Dao interface ProfileDao {
    @Query("SELECT * FROM profile WHERE id = 1") fun observe(): Flow<Profile?>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun save(profile: Profile)
}
@Database(entities = [Profile::class, Task::class, TaskEvent::class, ActionChoice::class, FocusSession::class, Subtask::class, PathGroup::class, Mission::class, Prerequisite::class, Person::class, PersonEvent::class, TaskOwner::class, ContactRecord::class, ContactEvent::class, RecordNote::class, TaskContact::class, CustomerOrder::class, Meeting::class, MeetingEvent::class, PerformanceEntry::class, ActivityCredit::class, PerformanceEvent::class, Goal::class, GoalTask::class, TimeLog::class, RepeatPlan::class, RepeatRun::class, Dream::class, WalletEntry::class, Prize::class, Redemption::class, TaskReminder::class], version = 7, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun profileDao(): ProfileDao
    abstract fun taskDao(): TaskDao
    abstract fun executionDao(): ExecutionDao
    abstract fun networkDao(): NetworkDao
    abstract fun crmDao(): CrmDao
    abstract fun meetingDao(): MeetingDao
    abstract fun reportingDao(): ReportingDao
    abstract fun finalDao(): FinalDao
    companion object {
        @Volatile private var instance: AppDatabase? = null
        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "growth.db").addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7).build().also { instance = it }
        }
    }
}
private val Context.preferences by preferencesDataStore("settings")
class Settings(private val context: Context) {
    private val endSoundKey = booleanPreferencesKey("focus_end_sound")
    val endSound: Flow<Boolean> = context.preferences.data.map { it[endSoundKey] ?: true }
    suspend fun setEndSound(value:Boolean) { context.preferences.edit { it[endSoundKey]=value } }
    private val bottomKey = stringPreferencesKey("bottom_shortcuts")
    val bottomShortcuts: Flow<List<Int>> = context.preferences.data.map { prefs ->
        (prefs[bottomKey] ?: "2,3").split(',').mapNotNull { it.toIntOrNull() }.distinct().take(3)
    }
    suspend fun setBottomShortcuts(ids:List<Int>) { context.preferences.edit { it[bottomKey]=ids.distinct().take(3).joinToString(",") } }
    private val themeKey = stringPreferencesKey("theme")
    val theme: Flow<String> = context.preferences.data.map { it[themeKey] ?: "system" }
    suspend fun setTheme(value: String) { context.preferences.edit { it[themeKey] = value } }
}
