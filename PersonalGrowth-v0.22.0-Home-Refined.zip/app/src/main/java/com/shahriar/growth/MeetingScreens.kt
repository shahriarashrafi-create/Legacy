package com.shahriar.growth

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.shahriar.growth.data.*
import kotlinx.coroutines.launch

fun parseMeetingTime(raw:String):Int?{val parts=normalizeText(raw).trim().split(':');if(parts.size!=2)return null;val h=parts[0].toIntOrNull()?:return null;val m=parts[1].toIntOrNull()?:return null;return if(h in 0..23 && m in 0..59)h*60+m else null}
fun recordLabel(type:String,id:String,people:List<Person>,contacts:List<ContactRecord>)=when(type){"person"->people.firstOrNull{it.id==id}?.name?:"فرد ناموجود";"contact"->contacts.firstOrNull{it.id==id}?.name?:"پرونده ناموجود";"all"->"همه جلسات";else->"خودم"}
@Composable fun MeetingsScreen(modifier:Modifier,db:AppDatabase,today:Long,initialType:String,initialId:String,initialMeeting:String?,onBack:()->Unit,onOpenTask:(String)->Unit){
    val people by db.networkDao().observe().collectAsState(initial=emptyList());val raw by db.crmDao().contacts().collectAsState(initial=emptyList());val contacts=raw.map{displayedContact(it,people)}
    val owners by db.networkDao().owners().collectAsState(initial=emptyList());val links by db.crmDao().links().collectAsState(initial=emptyList());val tasks by db.taskDao().observe().collectAsState(initial=emptyList())
    val meetings by db.meetingDao().observe().collectAsState(initial=emptyList());val context=LocalContext.current;val engine=remember(db){MeetingEngine(db,context)};val scope=rememberCoroutineScope()
    var selected by rememberSaveable(initialMeeting){mutableStateOf(initialMeeting)};var editor by rememberSaveable{mutableStateOf<String?>(null)};var action by remember{mutableStateOf("")}
    var recordType by rememberSaveable(initialType,initialId){mutableStateOf(initialType)};var recordId by rememberSaveable(initialType,initialId){mutableStateOf(initialId)};var picking by remember{mutableStateOf(false)}
    var query by rememberSaveable{mutableStateOf("")};var state by rememberSaveable{mutableStateOf("all")};var dateFilter by rememberSaveable{mutableStateOf("all")}
    var busy by remember{mutableStateOf(false)};var error by remember{mutableStateOf("")}
    fun change(block:suspend()->Unit){if(busy)return;busy=true;error="";scope.launch{try{block()}catch(e:Exception){if(e is kotlinx.coroutines.CancellationException)throw e;error=if(e is IllegalArgumentException)e.message?:"عملیات انجام نشد" else "ذخیره انجام نشد؛ دوباره تلاش کن."}finally{busy=false}}}
    val current=meetings.firstOrNull{it.id==selected};val task=tasks.firstOrNull{it.id==current?.taskId}
    BackHandler(enabled=editor==null && action.isBlank()){if(selected!=null)selected=null else onBack()}
    Column(modifier.fillMaxSize()){
        if(error.isNotEmpty())Text(error,Modifier.padding(16.dp),color=MaterialTheme.colorScheme.error)
        if(current!=null){
            val events by remember(current.id){db.meetingDao().history(current.id)}.collectAsState(initial=emptyList())
            val record=meetingRecord(current.taskId,owners,links)
            LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
                item{TextButton(onClick={selected=null}){Text("بازگشت به جلسات")};Text(task?.title?:"جلسه",style=MaterialTheme.typography.headlineSmall);Text(meetingStatusLabel(meetingStatus(current,task)))}
                item{Text("پرونده: "+recordLabel(record.first,record.second,people,contacts));Text(meetingKindLabel(current.kind));task?.let{Text(dueLabel(it,today)+" · "+faNumber(it.duration?:0)+" دقیقه")}}
                if(current.location.isNotBlank())item{Text("مکان / لینک: "+current.location)}
                item{Text("دستور جلسه",style=MaterialTheme.typography.titleMedium);Text(current.agenda.ifBlank{"ثبت نشده"})}
                item{Text("یادداشت و نتیجه جلسه",style=MaterialTheme.typography.titleMedium);Text(current.result.ifBlank{"هنوز نتیجه‌ای ثبت نشده"})}
                item{Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    Button(onClick={editor=current.id},enabled=!busy && task?.archived==false){Text("ویرایش")}
                    OutlinedButton(onClick={onOpenTask(current.taskId)},enabled=task!=null){Text("کار و تمرکز")}
                    OutlinedButton(onClick={action="held"},enabled=!busy && task?.archived==false){Text("ثبت نتیجه / برگزار شد")}
                    OutlinedButton(onClick={action="cancelled"},enabled=!busy && task?.done==false && !task.archived){Text("لغو")}
                    OutlinedButton(onClick={action="noshow"},enabled=!busy && task?.done==false && !task.archived){Text("عدم حضور")}
                    OutlinedButton(onClick={action="reopen"},enabled=!busy){Text("بازگشایی")}
                }}
                item{Text("تاریخچه جلسه",style=MaterialTheme.typography.titleMedium)}
                items(events,key={it.id}){e->Text(e.text+" · "+eventDay(e.at),style=MaterialTheme.typography.bodySmall)}
            }
        }else{
            val filtered=meetings.filter{m->val t=tasks.firstOrNull{it.id==m.taskId};val r=meetingRecord(m.taskId,owners,links)
                (recordType=="all" || (recordType=="person" && effectiveOwner(m.taskId,owners,links,raw)==recordId) || (recordType=="contact" && r==("contact" to recordId)) || (recordType=="self" && effectiveOwner(m.taskId,owners,links,raw)==null)) &&
                normalizeText((t?.title?:"")+" "+m.agenda+" "+m.result+" "+m.location).contains(normalizeText(query.trim())) &&
                (state=="all" || meetingStatus(m,t)==state) && when(dateFilter){"today"->t?.dueDay==today;"future"->t?.dueDay?.let{it>today}==true;"past"->t?.dueDay?.let{it<today}==true;else->true}
            }.sortedWith(compareBy<Meeting>{tasks.firstOrNull{t->t.id==it.taskId}?.dueDay?:Long.MAX_VALUE}.thenBy{tasks.firstOrNull{t->t.id==it.taskId}?.dueMinute?:1440})
            LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
                item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){TextButton(onClick=onBack){Text("بازگشت")};Button(onClick={editor="new";error=""},enabled=!busy){Text("+ جلسه")}};Text("جلسات",style=MaterialTheme.typography.headlineSmall)}
                item{OutlinedTextField(query,{query=it},label={Text("عنوان، مکان، دستور یا نتیجه")},modifier=Modifier.fillMaxWidth(),singleLine=true)}
                item{Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(onClick={picking=true}){Text(recordLabel(recordType,recordId,people,contacts))};TextButton(onClick={recordType="all";recordId=""}){Text("همه")}}}
                item{Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("all" to "همه تاریخ‌ها","today" to "امروز","future" to "آینده","past" to "گذشته").forEach{(v,l)->FilterChip(dateFilter==v,{dateFilter=v},label={Text(l)})}}}
                item{Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(state=="all",{state="all"},label={Text("همه وضعیت‌ها")});listOf("planned","held","needs_result","reopened","cancelled","noshow","archived").forEach{v->FilterChip(state==v,{state=v},label={Text(meetingStatusLabel(v))})}}}
                if(filtered.isEmpty())item{Text("جلسه‌ای با این فیلترها نیست.")}
                items(filtered,key={it.id}){m->val t=tasks.firstOrNull{it.id==m.taskId};val r=meetingRecord(m.taskId,owners,links)
                    Card(onClick={selected=m.id;error=""},modifier=Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Column(Modifier.padding(14.dp)){
                        Text(t?.title?:"جلسه",style=MaterialTheme.typography.titleMedium);Text(recordLabel(r.first,r.second,people,contacts)+" · "+meetingKindLabel(m.kind),style=MaterialTheme.typography.bodySmall)
                        t?.let{Text(dueLabel(it,today),style=MaterialTheme.typography.bodySmall)};Text(meetingStatusLabel(meetingStatus(m,t)),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.primary)
                    }}
                }
            }
        }
    }
    if(picking)RecordPicker(people,contacts,onDismiss={picking=false},onPick={type,id->recordType=type;recordId=id;picking=false})
    if(editor!=null)key(editor){val old=meetings.firstOrNull{it.id==editor};val oldTask=tasks.firstOrNull{it.id==old?.taskId};val r=old?.let{meetingRecord(it.taskId,owners,links)}?:(if(recordType=="all")"self" to "" else recordType to recordId)
        MeetingEditor(old,oldTask,r,people,contacts,today,busy,error,onDismiss={if(!busy)editor=null},onSave={m,title,day,minute,duration,type,id->change{engine.save(m,title,day,minute,duration,type,id);selected=m.id;editor=null}})
    }
    if(action.isNotBlank() && current!=null)key(action){var result by rememberSaveable{mutableStateOf(current.result)}
        AlertDialog(onDismissRequest={if(!busy)action=""},title={Text(if(action=="reopen")"بازگشایی جلسه" else meetingStatusLabel(action))},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
            if(error.isNotEmpty())Text(error,color=MaterialTheme.colorScheme.error)
            if(action=="reopen")Text("کار جلسه دوباره باز می‌شود؛ متن نتیجه قبلی حفظ خواهد شد.") else{
                Text(if(action=="held")"کار مشترک تکمیل می‌شود؛ زیرکارها و پیش‌نیازها باید آماده باشند." else "کار مشترک بایگانی می‌شود تا در برنامه امروز پیشنهاد نشود.")
                OutlinedTextField(result,{if(it.length<=4000)result=it},label={Text("یادداشت و نتیجه *")},modifier=Modifier.heightIn(max=300.dp),minLines=4,enabled=!busy)
            }
        }},confirmButton={TextButton(onClick={val a=action;change{if(a=="reopen")engine.reopen(current.id) else engine.finish(current.id,a,result);action=""}},enabled=!busy && (action=="reopen" || result.isNotBlank())){Text("تأیید")}},dismissButton={TextButton(onClick={action=""},enabled=!busy){Text("انصراف")}})
    }
}
@Composable fun RecordPicker(people:List<Person>,contacts:List<ContactRecord>,onDismiss:()->Unit,onPick:(String,String)->Unit){
    var query by rememberSaveable{mutableStateOf("")};var type by rememberSaveable{mutableStateOf("person")}
    Dialog(onDismissRequest=onDismiss){Surface{Column(Modifier.padding(16.dp).heightIn(max=540.dp)){
        Text("پرونده مرتبط",style=MaterialTheme.typography.titleMedium);TextButton(onClick={onPick("self","")}){Text("خودم")}
        Row{FilterChip(type=="person",{type="person"},label={Text("افراد")});Spacer(Modifier.width(6.dp));FilterChip(type=="contact",{type="contact"},label={Text("مشتری / پراسپکت")})}
        OutlinedTextField(query,{query=it},label={Text("جست‌وجو")},singleLine=true,modifier=Modifier.fillMaxWidth())
        LazyColumn(Modifier.weight(1f,false)){
            if(type=="person")items(people.filter{!it.archived && matchesPerson(it,query)},key={it.id}){p->TextButton(onClick={onPick("person",p.id)},modifier=Modifier.fillMaxWidth()){Text(p.name)}}
            else items(contacts.filter{!it.archived && matchesContact(it,query)},key={it.id}){c->TextButton(onClick={onPick("contact",c.id)},modifier=Modifier.fillMaxWidth()){Text(c.name+if(c.kind=="customer")" · مشتری" else " · پراسپکت")}}
        };TextButton(onClick=onDismiss){Text("بستن")}
    }}}
}
@Composable private fun MeetingEditor(old:Meeting?,task:Task?,record:Pair<String,String>,people:List<Person>,contacts:List<ContactRecord>,today:Long,busy:Boolean,error:String,onDismiss:()->Unit,onSave:(Meeting,String,Long,Int,Int,String,String)->Unit){
    val id=rememberSaveable{old?.id?:java.util.UUID.randomUUID().toString()};val taskId=rememberSaveable{task?.id?:java.util.UUID.randomUUID().toString()}
    var title by rememberSaveable{mutableStateOf(task?.title?:"")};var date by rememberSaveable{mutableStateOf(persianDay(task?.dueDay?:today,true))};var time by rememberSaveable{mutableStateOf(task?.dueMinute?.let{"%02d:%02d".format(java.util.Locale.ROOT,it/60,it%60)}?:"10:00")}
    var duration by rememberSaveable{mutableStateOf((task?.duration?:30).toString())};var kind by rememberSaveable{mutableStateOf(old?.kind?:"other")};var location by rememberSaveable{mutableStateOf(old?.location?:"")}
    var agenda by rememberSaveable{mutableStateOf(old?.agenda?:"")};var result by rememberSaveable{mutableStateOf(old?.result?:"")};var type by rememberSaveable{mutableStateOf(record.first)};var rid by rememberSaveable{mutableStateOf(record.second)};var picking by remember{mutableStateOf(false)}
    val day=parsePersianDay(date);val minute=parseMeetingTime(time);val minutes=normalizeText(duration).trim().toIntOrNull();val valid=title.isNotBlank() && day!=null && minute!=null && minutes!=null && minutes in 1..240 && minute+minutes<=1440
    Dialog(onDismissRequest=onDismiss,properties=DialogProperties(usePlatformDefaultWidth=false,dismissOnBackPress=!busy,dismissOnClickOutside=!busy)){Surface(Modifier.fillMaxSize().imePadding(),color=MaterialTheme.colorScheme.background){Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text(if(old==null)"جلسه جدید" else "ویرایش جلسه",style=MaterialTheme.typography.headlineSmall);if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
        OutlinedTextField(title,{if(it.length<=120)title=it},label={Text("عنوان *")},modifier=Modifier.fillMaxWidth(),enabled=!busy)
        OutlinedButton(onClick={picking=true},enabled=!busy){Text(recordLabel(type,rid,people,contacts))}
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){meetingKinds.forEach{k->FilterChip(kind==k,{kind=k},enabled=!busy,label={Text(meetingKindLabel(k))})}}
        OutlinedTextField(date,{date=it},label={Text("تاریخ شمسی: سال/ماه/روز")},modifier=Modifier.fillMaxWidth(),isError=day==null,enabled=!busy)
        OutlinedTextField(time,{if(it.length<=8)time=it},label={Text("ساعت: ۲۴ ساعته HH:mm")},modifier=Modifier.fillMaxWidth(),isError=minute==null,enabled=!busy)
        OutlinedTextField(duration,{if(it.length<=4)duration=it},label={Text("مدت (۱ تا ۲۴۰ دقیقه)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),isError=minutes==null || minutes !in 1..240,modifier=Modifier.fillMaxWidth(),enabled=!busy)
        if(minute!=null && minutes!=null && minute+minutes>1440)Text("جلسه باید پیش از پایان همان روز تمام شود.",color=MaterialTheme.colorScheme.error)
        OutlinedTextField(location,{if(it.length<=200)location=it},label={Text("مکان یا لینک")},modifier=Modifier.fillMaxWidth(),enabled=!busy)
        OutlinedTextField(agenda,{if(it.length<=4000)agenda=it},label={Text("دستور و نکته‌های قبل جلسه")},minLines=3,modifier=Modifier.fillMaxWidth(),enabled=!busy)
        OutlinedTextField(result,{if(it.length<=4000)result=it},label={Text("یادداشت و خلاصه نتیجه")},minLines=3,modifier=Modifier.fillMaxWidth(),enabled=!busy)
        Text("ذخیره یادداشت، وضعیت جلسه را تغییر نمی‌دهد؛ برگزاری یا لغو را در پرونده جلسه ثبت کن.",style=MaterialTheme.typography.bodySmall)
        Row{Button(onClick={onSave(Meeting(id=id,taskId=taskId,kind=kind,location=location,agenda=agenda,result=result),title,day!!,minute!!,minutes!!,type,rid)},enabled=!busy && valid){Text("ذخیره")};TextButton(onClick=onDismiss,enabled=!busy){Text("انصراف")}}
    }}}
    if(picking)RecordPicker(people,contacts,onDismiss={picking=false},onPick={t,r->type=t;rid=r;picking=false})
}
