package com.shahriar.growth

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shahriar.growth.data.*
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private val HomeBlue=Color(0xFF355CDE)
private val HomeInk=Color(0xFF17223B)
private val HomeMuted=Color(0xFF78849A)
private val HomeSurface=Color.White
private val HomePale=Color(0xFFEEF2FF)
private val HomeShape=RoundedCornerShape(24.dp)

@Composable
fun RedesignedHome(
    modifier:Modifier,tasks:List<Task>,choice:ActionChoice?,today:Long,active:FocusSession?,
    edges:List<Prerequisite>,meetings:List<Meeting>,wallet:List<WalletEntry>,name:String?,
    onFocus:(String)->Unit,onSchedule:()->Unit,onMeetings:(String)->Unit,onNew:()->Unit,
    onOpen:(String)->Unit,onList:(Int)->Unit
) {
    // Render only real database values. Name and focus are handled in the host navigation/header.
    val xp=wallet.sumOf { it.xp }.coerceAtLeast(0L)
    val coins=wallet.sumOf { it.coins }
    val level=levelFor(xp)
    val xpInLevel=(xp%100).toInt()
    val finished=tasks.filter { !it.archived && it.done && it.completedAt?.let { stamp -> localDay(stamp,ZoneId.systemDefault())==today }==true }
    val doneToday=finished.size
    val totalToday=tasks.count { !it.archived && (it.dueDay==today || it in finished) }
    val combo=streakDays(tasks.filter { it.done }.mapNotNull { it.completedAt?.let { stamp->localDay(stamp,ZoneId.systemDefault()) } }.toSet(),today)
    val first=tasks.firstOrNull { it.id==active?.taskId } ?: nextAction(tasks,choice,today,edges)
    val candidates=tasks.filter { !it.archived && !it.done && it.id!=first?.id && it.excludedDay!=today }
        .filter { candidate->edges.none { edge->edge.taskId==candidate.id && tasks.any { it.id==edge.dependsOnId && !it.done } } }
        .sortedWith(compareBy<Task> { if(it.dueDay==null) 2 else if(it.dueDay<today) 0 else if(it.dueDay==today) 1 else 3 }
            .thenByDescending { it.priority }.thenBy { it.dueDay?:Long.MAX_VALUE }.thenBy { it.dueMinute?:1440 }.thenBy { it.createdAt })
    val suggested=(listOfNotNull(first)+candidates).distinctBy { it.id }.take(3)
    val upcoming=meetings.mapNotNull { meeting->tasks.firstOrNull { it.id==meeting.taskId }?.let { task->
        if(!task.archived && !task.done && task.dueDay!=null && (task.dueDay>today || (task.dueDay==today && (task.dueMinute?:1440)>=java.time.LocalTime.now().toSecondOfDay()/60))) meeting to task else null
    } }.sortedWith(compareBy<Pair<Meeting,Task>> { it.second.dueDay }.thenBy { it.second.dueMinute?:1440 }).take(3)

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=16.dp,vertical=18.dp),verticalArrangement=Arrangement.spacedBy(26.dp)) {
        Card(modifier=Modifier.fillMaxWidth().shadow(5.dp,HomeShape,ambientColor=HomeBlue.copy(alpha=.06f),spotColor=HomeBlue.copy(alpha=.06f)),shape=HomeShape,colors=CardDefaults.cardColors(containerColor=HomeSurface)) {
            Column(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=19.dp),verticalArrangement=Arrangement.spacedBy(22.dp)) {
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                    LevelBadge(level)
                    Text("Level $level: ${homeLevelName(level)}",modifier=Modifier.weight(1f),color=HomeInk,fontWeight=FontWeight.Bold,fontSize=16.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                    Box(Modifier.size(56.dp).background(Color(0xFFE9EDF5),CircleShape),contentAlignment=Alignment.Center) {
                        Icon(Icons.Outlined.PersonOutline,"تصویر جایگزین پروفایل",tint=Color(0xFF8290A6),modifier=Modifier.size(29.dp))
                    }
                }
                // LTR ensures a single continuous progress fill regardless of the app RTL direction.
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    LinearProgressIndicator(progress={xpInLevel/100f},modifier=Modifier.fillMaxWidth().height(9.dp).clip(CircleShape),color=HomeBlue,trackColor=Color(0xFFE9EEFA))
                }
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.weight(1f),contentAlignment=Alignment.CenterStart){HomeMetric(Icons.Outlined.Bolt,"$xpInLevel/100")}
                    Box(Modifier.weight(.85f),contentAlignment=Alignment.Center){HomeMetric(Icons.Outlined.Paid,"$coins")}
                    Box(Modifier.weight(.8f),contentAlignment=Alignment.Center){
                        Box(Modifier.size(42.dp),contentAlignment=Alignment.Center) {
                            CircularProgressIndicator(progress={if(totalToday==0)0f else (doneToday.toFloat()/totalToday).coerceIn(0f,1f)},modifier=Modifier.fillMaxSize(),strokeWidth=4.dp,color=HomeBlue,trackColor=Color(0xFFE6EBF6))
                            Text("$doneToday",fontWeight=FontWeight.Bold,fontSize=14.sp,color=HomeInk)
                        }
                    }
                    Box(Modifier.weight(.7f),contentAlignment=Alignment.CenterEnd){HomeMetric(Icons.Outlined.LocalFireDepartment,"$combo")}
                }
            }
        }
        Column(verticalArrangement=Arrangement.spacedBy(11.dp)) {
            HomeSectionTitle("قدم بعدی","مشاهده همه",onClick={onList(6)})
            if(suggested.isEmpty()) {
                Card(colors=CardDefaults.cardColors(containerColor=HomeSurface),shape=HomeShape) {
                    Row(Modifier.fillMaxWidth().padding(18.dp),verticalAlignment=Alignment.CenterVertically) {
                        Text("فعلاً کاری برای شروع وجود ندارد.",modifier=Modifier.weight(1f),color=HomeMuted,fontSize=12.sp)
                        TextButton(onClick=onNew){Text("افزودن کار")}
                    }
                }
            }
            suggested.firstOrNull()?.let { task -> HomeTaskRow(task,true,onStart={onOpen(task.id)}) }
            if(suggested.size>1) {
                Card(modifier=Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=HomeSurface),shape=HomeShape) {
                    Column {
                        suggested.drop(1).forEachIndexed { index,task ->
                            if(index>0) HorizontalDivider(Modifier.padding(horizontal=16.dp),color=Color(0xFFEFF1F7))
                            HomeTaskRow(task,false,onStart={onOpen(task.id)})
                        }
                    }
                }
            }
        }
        Column(verticalArrangement=Arrangement.spacedBy(11.dp)) {
            HomeSectionTitle("جلسه بعدی","تایم‌شیت",onClick=onSchedule)
            if(upcoming.isEmpty()) {
                Card(colors=CardDefaults.cardColors(containerColor=HomeSurface),shape=HomeShape) {
                    Text("جلسه آینده‌ای ثبت نشده است.",Modifier.fillMaxWidth().padding(18.dp),color=HomeMuted,fontSize=12.sp)
                }
            } else {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    upcoming.forEach { (meeting,task)->
                        Card(onClick={onMeetings(meeting.id)},modifier=Modifier.weight(1f).height(112.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=HomeSurface)) {
                            Column(Modifier.fillMaxSize().padding(horizontal=6.dp,vertical=13.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.SpaceBetween) {
                                Text(homeWeekday(task.dueDay!!),fontSize=11.sp,color=HomeInk,fontWeight=FontWeight.SemiBold)
                                Text(task.dueMinute?.let { String.format(Locale.ROOT,"%02d:%02d",it/60,it%60) }?:"—",fontSize=13.sp,color=HomeBlue,fontWeight=FontWeight.Bold)
                                HomeMeetingTitle(task.title)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun HomeMeetingTitle(title:String) {
    var textSize by remember(title) { mutableStateOf(11.sp) }
    Text(title,modifier=Modifier.fillMaxWidth(),fontSize=textSize,maxLines=1,softWrap=false,
        overflow=TextOverflow.Ellipsis,color=HomeMuted,
        onTextLayout={layout->if(layout.didOverflowWidth && textSize.value>9f) textSize=(textSize.value-.5f).sp})
}

private fun homeWeekday(day:Long):String=when(LocalDate.ofEpochDay(day).dayOfWeek.value){1->"دوشنبه";2->"سه‌شنبه";3->"چهارشنبه";4->"پنجشنبه";5->"جمعه";6->"شنبه";else->"یکشنبه"}

// The level system is unbounded: badges remain individual for every level, with the number
// and geometry determined by the level, and without changing levelFor() or earned XP.
private fun homeLevelName(level:Int):String= when(level){
    1->"Beginner";2->"Explorer";3->"Learner";4->"Builder";5->"Achiever";6->"Rising Star";
    7->"Challenger";8->"Expert";9->"Champion";10->"Elite";11->"Legend";12->"Master";
    else->"Ascendant $level"
}

@Composable private fun LevelBadge(level:Int) {
    val tones=listOf(Color(0xFF355CDE),Color(0xFF007B91),Color(0xFF6951C5),Color(0xFFB67A20),Color(0xFF1F8A71),Color(0xFFC25E6E))
    val hue=tones[(level-1).coerceAtLeast(0)%tones.size]
    Box(Modifier.size(56.dp).background(HomePale,RoundedCornerShape(17.dp)),contentAlignment=Alignment.Center) {
        Canvas(Modifier.size(43.dp)) {
            val center=Offset(size.width/2,size.height/2)
            val corners=5+(level%7)
            val outline=Path()
            val radius=min(size.width,size.height)*.47f
            for(i in 0 until corners) {
                val angle=2*PI*i/corners-PI/2
                val x=center.x+(radius*cos(angle)).toFloat()
                val y=center.y+(radius*sin(angle)).toFloat()
                if(i==0)outline.moveTo(x,y) else outline.lineTo(x,y)
            }
            outline.close()
            drawPath(outline,hue)
            drawPath(outline,Color.White.copy(alpha=.75f),style=Stroke(width=2.3.dp.toPx()))
        }
        Text("$level",fontWeight=FontWeight.ExtraBold,fontSize=14.sp,color=Color.White)
    }
}

@Composable private fun HomeSectionTitle(title:String,action:String,onClick:()->Unit) {
    Row(Modifier.fillMaxWidth().height(38.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween) {
        Text(title,fontWeight=FontWeight.ExtraBold,fontSize=17.sp,color=HomeInk)
        TextButton(onClick=onClick,contentPadding=PaddingValues(horizontal=4.dp,vertical=0.dp)) {
            Text(action,fontSize=12.sp,fontWeight=FontWeight.SemiBold,color=HomeBlue)
            Spacer(Modifier.width(3.dp))
            Icon(Icons.Outlined.ArrowBack,null,tint=HomeBlue,modifier=Modifier.size(14.dp))
        }
    }
}

@Composable private fun HomeMetric(icon:ImageVector,value:String) {
    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(3.dp)) {
        Icon(icon,null,tint=HomeBlue,modifier=Modifier.size(17.dp))
        Text(value,fontSize=12.sp,fontWeight=FontWeight.Bold,color=HomeInk,maxLines=1)
    }
}

@Composable private fun HomeTaskRow(task:Task,featured:Boolean,onStart:()->Unit) {
    val ink=if(featured)Color.White else HomeInk
    val rewardCoins=rewardFor(task.priority)
    val content: @Composable () -> Unit = {
        Row(Modifier.fillMaxWidth().heightIn(min=if(featured)94.dp else 87.dp).padding(horizontal=15.dp,vertical=12.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(43.dp).background(if(featured)Color(0xFF5274ED) else HomePale,RoundedCornerShape(13.dp)),contentAlignment=Alignment.Center) {
                Icon(Icons.Outlined.ListAlt,null,tint=if(featured)Color.White else HomeBlue,modifier=Modifier.size(25.dp))
            }
            Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                Text(task.title,color=ink,fontWeight=FontWeight.SemiBold,fontSize=13.sp,maxLines=2,overflow=TextOverflow.Ellipsis,lineHeight=18.sp)
                Row(horizontalArrangement=Arrangement.spacedBy(9.dp),verticalAlignment=Alignment.CenterVertically) {
                    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(2.dp)) {
                        Icon(Icons.Outlined.Bolt,null,Modifier.size(14.dp),tint=if(featured)Color.White else HomeBlue)
                        Text("$TASK_COMPLETION_XP XP",fontSize=11.sp,color=if(featured)Color.White.copy(alpha=.9f) else HomeMuted,maxLines=1)
                    }
                    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(2.dp)) {
                        Icon(Icons.Outlined.Paid,null,Modifier.size(14.dp),tint=if(featured)Color.White else HomeBlue)
                        Text("$rewardCoins",fontSize=11.sp,color=if(featured)Color.White.copy(alpha=.9f) else HomeMuted,maxLines=1)
                    }
                }
            }
            Button(onClick=onStart,modifier=Modifier.width(74.dp).height(43.dp),shape=RoundedCornerShape(13.dp),contentPadding=PaddingValues(0.dp),colors=ButtonDefaults.buttonColors(containerColor=if(featured)Color.White else HomePale,contentColor=HomeBlue),elevation=ButtonDefaults.buttonElevation(defaultElevation=0.dp)) {
                Text("شروع",fontSize=12.sp,fontWeight=FontWeight.Bold)
            }
        }
    }
    if(featured) Surface(shape=RoundedCornerShape(24.dp),color=HomeBlue,modifier=Modifier.fillMaxWidth()) { content() }
    else content()
}
