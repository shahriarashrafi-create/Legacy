package com.shahriar.growth

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shahriar.growth.data.*
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import android.graphics.Paint

private val HomeBlue = Color(0xFF355CDE)
private val HomeInk = Color(0xFF17223B)
private val HomeMuted = Color(0xFF78849A)
private val HomePale = Color(0xFFEEF2FF)
private val HomeShape = RoundedCornerShape(21.dp)
private val CoinGold = Color(0xFFF1BE47)
private val DoneGreen = Color(0xFF229E65)
private val ComboOrange = Color(0xFFF07732)

/** All graphics are drawn locally. No image assets or network image requests. */
@Composable
fun HomeRouteLogo(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val track = Path().apply {
            moveTo(.16f*w,.78f*h)
            cubicTo(.36f*w,.58f*h,.49f*w,.40f*h,.60f*w,.18f*h)
            lineTo(.59f*w,.59f*h)
            cubicTo(.65f*w,.66f*h,.75f*w,.72f*h,.85f*w,.80f*h)
            cubicTo(.68f*w,.78f*h,.56f*w,.75f*h,.45f*w,.76f*h)
            cubicTo(.34f*w,.78f*h,.25f*w,.81f*h,.16f*w,.78f*h)
            close()
        }
        drawPath(track, Color.White)
        val flag = Path().apply {
            moveTo(.62f*w,.19f*h)
            lineTo(.82f*w,.19f*h)
            lineTo(.75f*w,.28f*h)
            lineTo(.82f*w,.37f*h)
            lineTo(.62f*w,.37f*h)
            close()
        }
        drawPath(flag, Color.White)
    }
}

@Composable
fun RedesignedHome(
    modifier: Modifier,
    tasks: List<Task>, choice: ActionChoice?, today: Long, active: FocusSession?,
    edges: List<Prerequisite>, meetings: List<Meeting>,
    onFocus: (String) -> Unit, onSchedule: () -> Unit, onMeetings: (String) -> Unit,
    onNewMeeting: () -> Unit, onNew: () -> Unit, onOpen: (String) -> Unit, onList: (Int) -> Unit
) {
    // Meetings have a linked Task. Keep them out of regular task suggestions.
    val meetingTaskIds = meetings.map { it.taskId }.toSet()
    val regularTasks = tasks.filterNot { it.id in meetingTaskIds }
    val first = regularTasks.firstOrNull { it.id == active?.taskId } ?: nextAction(regularTasks, choice, today, edges)
    val candidates = regularTasks.filter { !it.archived && !it.done && it.id != first?.id && it.excludedDay != today }
        .filter { candidate -> edges.none { edge -> edge.taskId == candidate.id && tasks.any { it.id == edge.dependsOnId && !it.done } } }
        .sortedWith(compareBy<Task> { if (it.dueDay == null) 2 else if (it.dueDay < today) 0 else if (it.dueDay == today) 1 else 3 }
            .thenByDescending { it.priority }.thenBy { it.dueDay ?: Long.MAX_VALUE }.thenBy { it.dueMinute ?: 1440 }.thenBy { it.createdAt })
    val suggested = (listOfNotNull(first) + candidates).distinctBy { it.id }.take(3)

    val nowMinute = LocalTime.now().toSecondOfDay() / 60
    val upcoming = meetings.mapNotNull { meeting ->
        tasks.firstOrNull { it.id == meeting.taskId }?.let { task ->
            if (!task.archived && !task.done && task.dueDay != null &&
                (task.dueDay > today || (task.dueDay == today && (task.dueMinute ?: 1440) >= nowMinute))) {
                meeting to task
            } else null
        }
    }.sortedWith(compareBy<Pair<Meeting, Task>> { it.second.dueDay }.thenBy { it.second.dueMinute ?: 1440 }).take(3)

    // The white premium Level card occupies the real Scaffold topBar slot.
    // The body is independently measured only AFTER Scaffold reserves top/bottom bars.
    BoxWithConstraints(modifier.fillMaxSize().background(
        Brush.verticalGradient(listOf(Color(0xFFFCFDFF), Color(0xFFF7F9FD), Color(0xFFF0F4FD))))) {
        val short = maxHeight < 425.dp
        val veryShort = maxHeight < 335.dp
        val pad = if (veryShort) 4.dp else if (short) 6.dp else 9.dp
        val between = if (veryShort) 5.dp else if (short) 7.dp else 10.dp
        val usable = (maxHeight - pad * 2 - between).coerceAtLeast(0.dp)
        // Meetings size to content first; all remaining space is assigned to the
        // higher-priority three task cards. There are no invisible spacer slots.
        val sessionsHeight = if (upcoming.isEmpty())
            (usable * .23f).coerceAtMost(93.dp)
        else (usable * .34f).coerceAtMost(157.dp)
        val stepsHeight = (usable - sessionsHeight).coerceAtLeast(0.dp)
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = pad),
            verticalArrangement = Arrangement.spacedBy(between)) {
            HomeTasksSection(Modifier.fillMaxWidth().height(stepsHeight), suggested, veryShort,
                onAll = { onList(6) }, onNew = onNew, onOpen = onOpen)
            HomeMeetingsSection(Modifier.fillMaxWidth().height(sessionsHeight), upcoming, veryShort,
                onSchedule = onSchedule, onMeetings = onMeetings, onAdd = onNewMeeting)
        }
    }


}

/** A SINGLE distinct, premium Level card; Compose drawing only, no downloaded images.
 * RTL: medal right, local avatar left. User name right / Level label left
 * ABOVE the XP line between the two portraits, then four colored game chips.
 */
@Composable
fun HomePremiumLevelCard(name: String?, tasks: List<Task>, wallet: List<WalletEntry>, today: Long) {
    val earnedXp = wallet.sumOf { it.xp }.coerceAtLeast(0L)
    val level = levelFor(earnedXp)
    val progress = (earnedXp % 100L).toInt()
    val animatedProgress by animateFloatAsState(
        targetValue = progress / 100f, animationSpec = tween(durationMillis = 540), label = "XP progress")
    val coins = wallet.sumOf { it.coins }
    val doneToday = tasks.count { task -> !task.archived && task.done &&
        task.completedAt?.let { localDay(it, ZoneId.systemDefault()) == today } == true }
    val combo = streakDays(tasks.filter { it.done }.mapNotNull { task ->
        task.completedAt?.let { localDay(it, ZoneId.systemDefault()) }
    }.toSet(), today)
    val context = LocalContext.current
    val localAvatar = remember(context) { LocalProfileAvatar.load(context) }
    val compact = LocalConfiguration.current.screenHeightDp < 695
    val tiny = LocalConfiguration.current.screenHeightDp < 600
    val portraitSize = if (tiny) 41.dp else if (compact) 49.dp else 55.dp
    val medalSize = if (tiny) 45.dp else if (compact) 54.dp else 61.dp
    val infoHeight = if (tiny) 43.dp else if (compact) 49.dp else 55.dp
    val metricHeight = if (tiny) 45.dp else if (compact) 53.dp else 61.dp
    val pad = if (tiny) 6.dp else if (compact) 7.dp else 9.dp
    Column(Modifier.fillMaxWidth().statusBarsPadding().padding(
        horizontal = 13.dp, vertical = if (tiny) 2.dp else 3.dp)) {
        Surface(Modifier.fillMaxWidth().shadow(6.dp, RoundedCornerShape(23.dp)),
            shape = RoundedCornerShape(23.dp), color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE9D4A3))) {
            Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(
                listOf(Color.White, Color(0xFFFEFCF7), Color.White)))
                .padding(start = pad, end = pad, top = pad, bottom = if (tiny) 3.dp else 4.dp),
                verticalArrangement = Arrangement.spacedBy(if (tiny) 3.dp else 4.dp)) {
                Row(Modifier.fillMaxWidth().height(infoHeight),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(if (tiny) 5.dp else 9.dp)) {
                    HomeMedal(level, medalSize)
                    Column(Modifier.weight(1f).fillMaxHeight(),
                        verticalArrangement = Arrangement.Center) {
                        Row(Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Text(name?.takeIf { it.isNotBlank() } ?: "نام کاربر",
                                modifier = Modifier.weight(.9f), color = HomeInk,
                                fontWeight = FontWeight.ExtraBold, fontSize = if (tiny) 10.sp else 12.sp,
                                textAlign = TextAlign.Right, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                            Text("Level $level: ${homeLevelName(level)}",
                                modifier = Modifier.weight(1.45f), color = Color(0xFF273C78),
                                fontWeight = FontWeight.ExtraBold, fontSize = if (tiny) 9.sp else 11.sp,
                                textAlign = TextAlign.Left, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                        }
                        Spacer(Modifier.height(if (tiny) 4.dp else 6.dp))
                        // LTR fill direction even though everything around it is RTL.
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Box(Modifier.fillMaxWidth().height(if (tiny) 8.dp else 11.dp)
                                .clip(CircleShape).background(Color(0xFFDDE6FA))) {
                                // The empty state is a truly empty track: no rounded zero dot.
                                if (progress > 0) {
                                    Box(Modifier.fillMaxWidth(animatedProgress.coerceIn(0f, 1f))
                                        .fillMaxHeight().clip(CircleShape)
                                        .background(Brush.horizontalGradient(listOf(
                                            Color(0xFF2048C2), Color(0xFF4776F0), Color(0xFF91B8FF)))))
                                    Box(Modifier.fillMaxWidth(animatedProgress.coerceIn(0f, 1f))
                                        .height(2.dp).padding(horizontal = 2.dp)
                                        .background(Color.White.copy(alpha = .38f)))
                                }
                            }
                        }
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                Text("$progress/100 XP", color = Color(0xFF63728A),
                                    fontSize = if (tiny) 8.sp else 9.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1)
                            }
                        }
                    }
                    Box(Modifier.size(portraitSize).clip(CircleShape)
                        .background(Color(0xFFE8EDF7)), contentAlignment = Alignment.Center) {
                        if (localAvatar != null) {
                            Image(bitmap = localAvatar, contentDescription = "عکس پروفایل کاربر",
                                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        } else {
                            Icon(Icons.Outlined.PersonOutline, "آواتار پیش‌فرض", tint = Color(0xFF8796AE),
                                modifier = Modifier.size(portraitSize * .66f))
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().height(metricHeight),
                    horizontalArrangement = Arrangement.spacedBy(if (tiny) 3.dp else 6.dp)) {
                    HomeGameMetric(Modifier.weight(1f).fillMaxHeight(), HomeBlue, Color.White, "xp", "$progress/100")
                    HomeGameMetric(Modifier.weight(1f).fillMaxHeight(), CoinGold, Color(0xFF483006), "coin", "$coins")
                    HomeGameMetric(Modifier.weight(1f).fillMaxHeight(), DoneGreen, Color.White, "done", "$doneToday")
                    HomeGameMetric(Modifier.weight(1f).fillMaxHeight(), ComboOrange, Color.White, "combo", "$combo")
                }
            }
        }
    }
}


@Composable
private fun HomeGameMetric(modifier: Modifier, background: Color, foreground: Color,
                           kind: String, value: String) {
    val highlight = when (kind) {
        "xp" -> Color(0xFF70ADFF)
        "coin" -> Color(0xFFFFE280)
        "done" -> Color(0xFF61E9A2)
        else -> Color(0xFFFFBA62)
    }
    BoxWithConstraints(modifier.clip(RoundedCornerShape(12.dp))
        .background(Brush.verticalGradient(listOf(highlight, background, background)))) {
        val slim = maxWidth < 70.dp
        val glyph = if (slim) 19.dp else 26.dp
        Box(Modifier.fillMaxWidth().height(1.dp).align(Alignment.TopCenter)
            .background(Color.White.copy(alpha = .53f)))
        Box(Modifier.fillMaxWidth().height(9.dp).align(Alignment.TopCenter)
            .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = .17f),Color.Transparent))))
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(Modifier.fillMaxSize().padding(horizontal = if (slim) 1.dp else 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center) {
                HomeGameGlyph(kind, Modifier.size(glyph))
                Spacer(Modifier.width(if (slim) 1.dp else 2.dp))
                val label = when(kind) {"done"->"DONE";"combo"->"COMBO";"coin"->"COIN";else->"XP"}
                Text(label, fontSize = if(slim) 6.5.sp else 8.sp,
                    fontWeight = FontWeight.Black, color = foreground,
                    maxLines = 1)
                Spacer(Modifier.width(if (slim) 1.dp else 2.dp))
                Box(Modifier.width(.8.dp).height(15.dp).background(foreground.copy(alpha=.44f)))
                Spacer(Modifier.width(if (slim) 1.dp else 2.dp))
                var valueSize by remember(value, slim) {
                    mutableStateOf(if (slim || value.length > 5) 8.5f else 11f)
                }
                Text(value, fontSize = valueSize.sp,
                    fontWeight = FontWeight.Black, color = foreground,
                    maxLines = 1, softWrap = false, overflow = TextOverflow.Clip,
                    onTextLayout = { result ->
                        if (result.didOverflowWidth && valueSize > 6.5f) {
                            valueSize = (valueSize - .5f).coerceAtLeast(6.5f)
                        }
                    })
            }
        }
    }
}

/** Small premium-style, offline Canvas glyphs; no image files or external requests. */
@Composable
private fun HomeGameGlyph(kind: String, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val c = Offset(.5f*w, .51f*h)
        val r = min(w,h)*.46f
        when (kind) {
            "xp" -> {
                drawCircle(brush=Brush.radialGradient(listOf(Color(0xFFAFEAFF).copy(alpha=.62f),Color.Transparent),center=c,radius=r),radius=r,center=c)
                val bolt = Path().apply {
                    moveTo(w*.59f,h*.04f);lineTo(w*.20f,h*.54f);lineTo(w*.47f,h*.54f)
                    lineTo(w*.36f,h*.96f);lineTo(w*.85f,h*.39f);lineTo(w*.58f,h*.39f);close()
                }
                drawPath(bolt, brush=Brush.linearGradient(listOf(Color(0xFFEEFFFF), Color(0xFF84EAFF),Color(0xFF39A3F9))))
                drawPath(bolt, Color(0xFF2D72CA),style=Stroke(width=1.dp.toPx()))
                drawLine(Color.White.copy(alpha=.75f),Offset(w*.56f,h*.14f),Offset(w*.33f,h*.49f),strokeWidth=.8.dp.toPx())
            }
            "coin" -> {
                drawCircle(Color(0xFFA16A12),r,Offset(c.x,c.y+1.dp.toPx()))
                drawCircle(brush=Brush.radialGradient(listOf(Color(0xFFFFFAAE),Color(0xFFFFC738),Color(0xFFD18B16)),center=Offset(w*.28f,h*.20f),radius=r*1.8f),radius=r*.93f,center=c)
                drawCircle(Color(0xFFFFE9A2),r*.74f,c,style=Stroke(width=1.7.dp.toPx()))
                val crown=Path().apply {
                    moveTo(w*.25f,h*.43f);lineTo(w*.37f,h*.57f);lineTo(w*.49f,h*.34f)
                    lineTo(w*.62f,h*.56f);lineTo(w*.76f,h*.43f);lineTo(w*.70f,h*.69f)
                    lineTo(w*.31f,h*.69f);close()
                }
                drawPath(crown,Color(0xFF9D6310))
                drawPath(crown,Brush.verticalGradient(listOf(Color(0xFFFFF1A2),Color(0xFFE1A11D))))
                drawCircle(Color.White.copy(alpha=.85f),r*.10f,Offset(w*.28f,h*.23f))
            }
            "done" -> {
                val petals=10
                repeat(petals){i->
                    val angle=2*PI*i/petals
                    drawCircle(Color(0xFF086F45),radius=r*.28f,
                        center=Offset(c.x+(r*.67f*cos(angle)).toFloat(),c.y+(r*.67f*sin(angle)).toFloat()))
                }
                drawCircle(brush=Brush.radialGradient(listOf(Color(0xFFBEFFD9),Color(0xFF25C87E),Color(0xFF067445)),center=Offset(w*.36f,h*.29f),radius=r*1.7f),radius=r*.78f,center=c)
                drawCircle(Color(0xFFAAFFE1).copy(alpha=.7f),radius=r*.61f,center=c,style=Stroke(width=1.3.dp.toPx()))
                val check=Path().apply { moveTo(w*.27f,h*.51f);lineTo(w*.43f,h*.66f);lineTo(w*.74f,h*.35f) }
                drawPath(check,Color(0xFF075737),style=Stroke(width=3.2.dp.toPx()))
                drawPath(check,Color(0xFFEAFFEE),style=Stroke(width=1.7.dp.toPx()))
            }
            "combo" -> {
                val fire=Path().apply {
                    moveTo(w*.49f,h*.02f)
                    cubicTo(w*.62f,h*.25f,w*.70f,h*.32f,w*.72f,h*.47f)
                    cubicTo(w*.90f,h*.31f,w*.94f,h*.55f,w*.86f,h*.76f)
                    cubicTo(w*.73f,h*1.06f,w*.25f,h*1.04f,w*.14f,h*.75f)
                    cubicTo(w*.06f,h*.53f,w*.23f,h*.38f,w*.32f,h*.31f)
                    cubicTo(w*.34f,h*.49f,w*.46f,h*.33f,w*.49f,h*.02f)
                    close()
                }
                drawPath(fire,Color(0xFF9C301D))
                drawPath(fire,Brush.verticalGradient(listOf(Color(0xFFFFF36A),Color(0xFFFF941F),Color(0xFFF25513))))
                val centre=Path().apply {
                    moveTo(w*.52f,h*.43f);cubicTo(w*.61f,h*.60f,w*.74f,h*.72f,w*.58f,h*.87f)
                    cubicTo(w*.42f,h*.99f,w*.29f,h*.77f,w*.39f,h*.62f);close()
                }
                drawPath(centre,Brush.verticalGradient(listOf(Color.White,Color(0xFFFFE870),Color(0xFFFFB02F))))
            }
        }
    }
}

/** Gilded achievement medallion with red ribbon tails and laurel edging (Canvas-only). */
@Composable
private fun HomeMedal(level: Int, boxSize: Dp) {
    Box(Modifier.size(boxSize), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(2.dp)) {
            val w = size.width
            val h = size.height
            val centre = Offset(w*.50f, h*.42f)
            val radius = min(w, h)*.286f
            // Red satin award ribbons hang BELOW the golden disc.
            val leftRibbon = Path().apply {
                moveTo(w*.28f,h*.49f);lineTo(w*.47f,h*.52f)
                lineTo(w*.39f,h*.98f);lineTo(w*.26f,h*.85f)
                lineTo(w*.13f,h*.89f);close()
            }
            val rightRibbon = Path().apply {
                moveTo(w*.53f,h*.52f);lineTo(w*.73f,h*.49f)
                lineTo(w*.87f,h*.89f);lineTo(w*.73f,h*.85f)
                lineTo(w*.61f,h*.98f);close()
            }
            drawPath(leftRibbon,Brush.horizontalGradient(listOf(Color(0xFF9E1D28),Color(0xFFF4474A),Color(0xFFA31827))))
            drawPath(rightRibbon,Brush.horizontalGradient(listOf(Color(0xFFC1272F),Color(0xFFFF665C),Color(0xFF981D2C))))
            drawLine(Color.White.copy(alpha=.35f),Offset(w*.33f,h*.56f),Offset(w*.30f,h*.82f),strokeWidth=1.dp.toPx())
            drawLine(Color.White.copy(alpha=.27f),Offset(w*.68f,h*.57f),Offset(w*.74f,h*.82f),strokeWidth=1.dp.toPx())
            // Offset scallops and subtle laurel branches are drawn behind the disk.
            for (i in 0 until 14) {
                val angle = 2*PI*i/14
                val petal = Offset(centre.x + (radius*.95f*cos(angle)).toFloat(),
                    centre.y + (radius*.95f*sin(angle)).toFloat())
                drawCircle(brush=Brush.radialGradient(listOf(Color(0xFFFFF0A4),
                    Color(0xFFDEA023),Color(0xFFA96E16)),center=petal,radius=radius*.29f),
                    radius=radius*.275f,center=petal)
            }
            drawCircle(Color(0xFF895313),radius=radius*1.04f,center=centre)
            drawCircle(brush=Brush.radialGradient(listOf(Color(0xFFFFFBD9),
                Color(0xFFFFD452), Color(0xFFCA8516)),
                center=Offset(w*.32f,h*.20f),radius=radius*2.1f),
                radius=radius,center=centre)
            drawCircle(Color(0xFFFFE89E),radius=radius*.85f,center=centre,
                style=Stroke(width=1.5.dp.toPx()))
            drawCircle(brush=Brush.radialGradient(listOf(Color(0xFFFFF8D4),
                Color(0xFFFFDF80), Color(0xFFE7B139)),
                center=Offset(w*.37f,h*.28f),radius=radius*1.35f),
                radius=radius*.70f,center=centre)
            drawCircle(Color(0xFFB98025),radius=radius*.68f,center=centre,
                style=Stroke(width=.9.dp.toPx()))
            drawCircle(Color.White.copy(alpha=.82f),radius=radius*.12f,
                center=Offset(centre.x-radius*.40f,centre.y-radius*.37f))
            val shine = Path().apply {
                moveTo(w*.86f,h*.04f);lineTo(w*.89f,h*.13f)
                lineTo(w*.97f,h*.17f);lineTo(w*.89f,h*.20f)
                lineTo(w*.86f,h*.29f);lineTo(w*.83f,h*.20f)
                lineTo(w*.75f,h*.17f);lineTo(w*.83f,h*.13f);close()
            }
            drawPath(shine,Brush.verticalGradient(listOf(Color.White,Color(0xFFFFD24E))))
            // The numeral and the medal share the EXACT same Canvas center.
            // Android Paint font metrics give a baseline aligned to the disc's optical center,
            // independently of one-, two- or three-digit level numbers.
            val sizeSp = when {
                level >= 100 -> if (boxSize < 48.dp) 9.sp else 11.sp
                level >= 10 -> if (boxSize < 48.dp) 10.sp else 13.sp
                else -> if (boxSize < 48.dp) 12.sp else 16.sp
            }
            val numeralPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textAlign = Paint.Align.CENTER
                textSize = sizeSp.toPx()
                color = android.graphics.Color.rgb(141, 83, 15)
                typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.BOLD)
                setShadowLayer(.45.dp.toPx(), 0f, .35.dp.toPx(), android.graphics.Color.argb(95, 255, 255, 213))
            }
            val baseline = centre.y - (numeralPaint.ascent() + numeralPaint.descent()) / 2f
            drawContext.canvas.nativeCanvas.drawText(level.toString(), centre.x, baseline, numeralPaint)
        }

    }
}

/**
 * Animated Energy Crystal (کریستال انرژی), entirely generated in Compose Canvas.
 * Faceted sapphire/cyan stone, open golden orbital halo, tiny stars and restrained
 * 2.4-second breathing light. No shield, checkmark, notebook, image or network asset.
 * Only visual values animate; layout dimensions and click behavior stay unchanged.
 */
@Composable
private fun HomeTaskGlyph(featured: Boolean, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "energy crystal ambient light")
    val shimmer by transition.animateFloat(
        initialValue = .18f,
        targetValue = .56f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "gentle crystal glow"
    )
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val unit = min(w, h)
        val cx = w * .50f
        val cy = h * .49f
        val gemTop = Offset(cx, h * .13f)
        val gemLeft = Offset(w * .22f, h * .40f)
        val gemRight = Offset(w * .78f, h * .40f)
        val gemBottom = Offset(cx, h * .85f)
        // A soft energy aura breathes slowly, without moving the icon itself.
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Color(0xFF99F8FF).copy(alpha = shimmer * if (featured) .72f else .59f),
                    Color(0xFF387EFF).copy(alpha = shimmer * .38f), Color.Transparent),
                center = Offset(cx, cy), radius = unit * .51f
            ),
            radius = unit * .51f, center = Offset(cx, cy)
        )
        drawOval(
            color = Color(0xFF123474).copy(alpha = .16f),
            topLeft = Offset(w * .26f, h * .87f),
            size = Size(w * .48f, h * .065f)
        )
        // Gold orbit: staggered arcs pass BEHIND the sapphire rather than becoming a badge.
        drawArc(
            brush = Brush.sweepGradient(listOf(Color(0xFF8C4C11), Color(0xFFFFEA9C),
                Color(0xFFFFBF45), Color(0xFF8C4C11))),
            startAngle = 183f, sweepAngle = 173f, useCenter = false,
            topLeft = Offset(w * .08f, h * .25f), size = Size(w * .84f, h * .49f),
            style = Stroke(width = unit * .048f, cap = StrokeCap.Round)
        )
        drawArc(
            color = Color(0xFFFFF5CC).copy(alpha = .73f),
            startAngle = 196f, sweepAngle = 54f, useCenter = false,
            topLeft = Offset(w * .08f, h * .25f), size = Size(w * .84f, h * .49f),
            style = Stroke(width = unit * .012f, cap = StrokeCap.Round)
        )
        // A non-book faceted jewel with a clear angular silhouette at small DP sizes.
        val silhouette = Path().apply {
            moveTo(cx, h * .13f)
            lineTo(w * .70f, h * .22f)
            lineTo(w * .79f, h * .42f)
            lineTo(w * .62f, h * .72f)
            lineTo(cx, h * .85f)
            lineTo(w * .38f, h * .72f)
            lineTo(w * .21f, h * .42f)
            lineTo(w * .30f, h * .22f)
            close()
        }
        drawPath(silhouette, color = Color(0xFF13489A), style = Stroke(width = unit * .065f))
        drawPath(silhouette, brush = Brush.verticalGradient(listOf(
            Color(0xFFCCFFFF), Color(0xFF43CBF9), Color(0xFF1A60C8), Color(0xFF15328D)
        )))
        val leftFacet = Path().apply {
            moveTo(cx, h*.13f);lineTo(w*.30f,h*.22f);lineTo(w*.21f,h*.42f)
            lineTo(w*.38f,h*.72f);lineTo(w*.44f,h*.40f);close()
        }
        drawPath(leftFacet, Brush.linearGradient(listOf(Color(0xFFB8FFFF),Color(0xFF44C9FA),Color(0xFF1673CB))))
        val rightFacet = Path().apply {
            moveTo(cx,h*.13f);lineTo(w*.70f,h*.22f);lineTo(w*.79f,h*.42f)
            lineTo(w*.62f,h*.72f);lineTo(w*.56f,h*.40f);close()
        }
        drawPath(rightFacet, Brush.linearGradient(listOf(Color(0xFF2A9CEA),Color(0xFF2163C6),Color(0xFF152F87))))
        val coreFacet = Path().apply {
            moveTo(cx,h*.13f);lineTo(w*.56f,h*.40f);lineTo(cx,h*.85f)
            lineTo(w*.44f,h*.40f);close()
        }
        drawPath(coreFacet, Brush.verticalGradient(listOf(Color(0xFFD7FFFF),Color(0xFF7CF7FF),Color(0xFF2FA7ED),Color(0xFF1B54C0))))
        val innerGlow = Path().apply {
            moveTo(cx,h*.24f);lineTo(w*.57f,h*.42f);lineTo(cx,h*.69f)
            lineTo(w*.43f,h*.42f);close()
        }
        drawPath(innerGlow, Brush.radialGradient(listOf(
            Color.White.copy(alpha = .37f + shimmer * .40f),
            Color(0xFF66FCFF).copy(alpha = .31f + shimmer * .31f), Color.Transparent),
            center = Offset(cx,h*.41f), radius=unit*.34f
        ))
        // Thin hand-cut edges, a diagonal highlight and a glint on the north facet.
        drawPath(silhouette, Color(0xFFBEF8FF).copy(alpha = .87f),
            style = Stroke(width = unit * .016f))
        drawLine(Color.White.copy(alpha=.89f), gemTop, Offset(w*.42f,h*.38f),
            strokeWidth=unit*.020f, cap=StrokeCap.Round)
        drawLine(Color(0xFFA5F4FF).copy(alpha=.72f), Offset(w*.22f,h*.41f),
            Offset(w*.38f,h*.72f), strokeWidth=unit*.010f)
        // Foreground gold orbit fragment creates a convincing layered 3D appearance.
        drawArc(
            brush = Brush.sweepGradient(listOf(Color(0xFFFFE9A7),Color(0xFFB67A20),Color(0xFFFFDA73))),
            startAngle = 9f, sweepAngle = 157f, useCenter = false,
            topLeft = Offset(w * .08f, h * .25f), size = Size(w * .84f, h * .49f),
            style = Stroke(width = unit * .041f, cap = StrokeCap.Round)
        )
        // Restrained star points: fixed positions; luminosity gently oscillates.
        fun star(x: Float, y: Float, r: Float, opacity: Float) {
            val px = w * x
            val py = h * y
            val sr = unit * r
            val starPath = Path().apply {
                moveTo(px,py-sr);lineTo(px+sr*.20f,py-sr*.19f)
                lineTo(px+sr,py);lineTo(px+sr*.20f,py+sr*.19f)
                lineTo(px,py+sr);lineTo(px-sr*.20f,py+sr*.19f)
                lineTo(px-sr,py);lineTo(px-sr*.20f,py-sr*.19f);close()
            }
            drawPath(starPath,Color(0xFFFFE9A4).copy(alpha=opacity))
        }
        star(.83f,.17f,.065f,.45f+shimmer*.52f)
        star(.14f,.59f,.039f,.32f+shimmer*.34f)
        star(.72f,.86f,.031f,.35f+shimmer*.40f)
    }
}

/** A small etched calendar, aligned with the weekday label. */
@Composable
private fun HomeMeetingGlyph(modifier: Modifier = Modifier) {
    // Compact calendar, designed to sit on the SAME line as the weekday.
    Canvas(modifier) {
        val w=size.width;val h=size.height
        val topLeft=Offset(w*.13f,h*.18f)
        drawRoundRect(brush=Brush.verticalGradient(listOf(Color(0xFFFFFFFF),Color(0xFFEAF1FF))),
            topLeft=topLeft,size=androidx.compose.ui.geometry.Size(w*.74f,h*.70f),
            cornerRadius=androidx.compose.ui.geometry.CornerRadius(w*.11f))
        drawRoundRect(Color(0xFF6C82AD),topLeft=topLeft,size=androidx.compose.ui.geometry.Size(w*.74f,h*.70f),
            cornerRadius=androidx.compose.ui.geometry.CornerRadius(w*.11f),style=Stroke(width=1.3.dp.toPx()))
        drawRoundRect(Color(0xFF5277D9),topLeft=topLeft,
            size=androidx.compose.ui.geometry.Size(w*.74f,h*.20f),
            cornerRadius=androidx.compose.ui.geometry.CornerRadius(w*.09f))
        for(x in listOf(.31f,.69f)) {
            drawLine(Color(0xFF405C92),Offset(w*x,h*.07f),Offset(w*x,h*.31f),strokeWidth=2.3.dp.toPx(),cap=androidx.compose.ui.graphics.StrokeCap.Round)
        }
        for (x in listOf(.30f,.52f,.73f)) for(y in listOf(.53f,.72f)) {
            drawCircle(Color(0xFF7594D6),radius=w*.046f,center=Offset(w*x,h*y))
        }
    }
}

@Composable
private fun HomeTasksSection(
    modifier: Modifier, suggested: List<Task>, veryShort: Boolean,
    onAll: () -> Unit, onNew: () -> Unit, onOpen: (String) -> Unit
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(if (veryShort) 4.dp else 6.dp)) {
        HomeSectionTitle("قدم بعدی", "مشاهده همه", Icons.Outlined.TrackChanges, onAll, veryShort)
        if (suggested.isEmpty()) {
            Card(Modifier.fillMaxWidth().weight(1f), shape = HomeShape,
                colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.fillMaxSize().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("فعلاً کاری برای شروع وجود ندارد.", modifier = Modifier.weight(1f),
                        color = HomeMuted, fontSize = 12.sp)
                    TextButton(onClick = onNew) { Text("افزودن کار") }
                }
            }
        } else {
            // Three fully independent cards. Keep 80:73:73 when all three exist.
            suggested.forEachIndexed { index, task ->
                HomeTaskRow(task, featured = index == 0,
                    modifier = Modifier.fillMaxWidth().weight(if (index == 0) 80f else 73f),
                    veryShort = veryShort, onStart = { onOpen(task.id) })
            }
        }
    }
}

@Composable
private fun HomeTaskRow(task: Task, featured: Boolean, modifier: Modifier,
                        veryShort: Boolean, onStart: () -> Unit) {
    val ink = if (featured) Color.White else HomeInk
    val payout = rewardFor(task.priority)
    Surface(modifier = modifier.shadow(if (featured) 3.dp else 1.5.dp, RoundedCornerShape(21.dp)),
        shape = RoundedCornerShape(21.dp), color = if (featured) HomeBlue else Color.White,
        border = if (featured) BorderStroke(.7.dp, Color(0xFF6499FC))
                 else BorderStroke(.7.dp, Color(0xFFE4EAF5))) {
        BoxWithConstraints(Modifier.fillMaxSize().then(if (featured) Modifier.background(
            Brush.horizontalGradient(listOf(Color(0xFF2352DB),HomeBlue,Color(0xFF4F90FF)))) else Modifier)) {
            if (featured) {
                Canvas(Modifier.fillMaxSize()) {
                    val w=size.width; val h=size.height
                    val light=Path().apply {
                        moveTo(w*.06f,h);lineTo(w*.53f,0f)
                        lineTo(w*.78f,0f);lineTo(w*.28f,h);close()
                    }
                    drawPath(light,Brush.horizontalGradient(listOf(Color.White.copy(alpha=.015f),
                        Color.White.copy(alpha=.034f),Color.Transparent)))
                    drawCircle(Brush.radialGradient(listOf(Color(0xFF8FD4FF).copy(alpha=.13f),
                        Color.Transparent),center=Offset(w*.72f,h*.18f),radius=w*.55f),
                        radius=w*.55f,center=Offset(w*.72f,h*.18f))
                }
            }
            val compact = maxHeight < 74.dp || veryShort
            val tight = maxWidth < 340.dp
            val iconSize = if (compact) 39.dp else if (featured) 68.dp else 58.dp
            // Native RTL: quest emblem RIGHT, title/rewards middle, Start LEFT.
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Row(Modifier.fillMaxSize().padding(horizontal = if (compact) 8.dp else 12.dp,
                vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(if (compact) 5.dp else 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(iconSize).clip(RoundedCornerShape(12.dp))
                    .background(if (featured) Brush.verticalGradient(listOf(Color(0xFF5F95FF).copy(alpha=.52f),Color(0xFF133DBA).copy(alpha=.80f))) else Brush.verticalGradient(listOf(Color(0xFFF8FAFF),Color(0xFFE7EEFC)))),
                    contentAlignment = Alignment.Center) {
                    HomeTaskGlyph(featured, Modifier.fillMaxSize().padding(if (compact) 3.dp else 5.dp))
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(
                    if (compact) 3.dp else 5.dp)) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        HomeAutoTaskTitle(task.title, ink,
                            if (compact) 12f else if (tight) 13.5f else if (featured) 16f else 15f)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(if (compact) 3.dp else 5.dp)) {
                        HomeTaskReward("xp", "$TASK_COMPLETION_XP XP", compact, featured)
                        HomeTaskReward("coin", "$payout", compact, featured)
                    }
                }
                Button(onClick = onStart, modifier = Modifier.width(if (compact) 49.dp else 70.dp)
                    .height(if (compact) 37.dp else 43.dp),
                    shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (featured) Color.White else HomeBlue,
                        contentColor = if (featured) HomeBlue else Color.White),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 3.dp,
                        pressedElevation = 0.dp)) {
                    Text("شروع", fontSize = if (compact) 10.sp else 12.sp,
                        fontWeight = FontWeight.ExtraBold)
                    if (!compact) {
                        Spacer(Modifier.width(2.dp))
                        Icon(Icons.Outlined.ChevronLeft, contentDescription = null,
                            modifier = Modifier.size(14.dp))
                    }
                }
            }
            }
        }
    }
}


@Composable
private fun HomeAutoTaskTitle(value: String, color: Color, initialSize: Float) {
    var font by remember(value, initialSize) { mutableStateOf(initialSize) }
    Text(value, modifier = Modifier.fillMaxWidth(), color = color,
        fontWeight = FontWeight.SemiBold, fontSize = font.sp, maxLines = 1,
        softWrap = false, overflow = TextOverflow.Ellipsis,
        onTextLayout = { if (it.didOverflowWidth && font > 10f) font = (font - .5f).coerceAtLeast(10f) })
}

@Composable
private fun HomeTaskReward(kind: String, value: String, compact: Boolean, featured: Boolean) {
    val blue = kind == "xp"
    val fill = when {
        featured && blue -> Brush.horizontalGradient(listOf(Color(0xFF67B4FF).copy(alpha=.34f), Color.White.copy(alpha=.13f)))
        featured -> Brush.horizontalGradient(listOf(Color(0xFFFFD671).copy(alpha=.35f), Color.White.copy(alpha=.11f)))
        blue -> Brush.horizontalGradient(listOf(Color(0xFFEAF2FF), Color(0xFFF4F7FF)))
        else -> Brush.horizontalGradient(listOf(Color(0xFFFFF4D8), Color(0xFFF7F9FC)))
    }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(Modifier.clip(RoundedCornerShape(16.dp)).background(fill)
            .padding(horizontal = if (compact) 4.dp else 6.dp,
                vertical = if (compact) 3.dp else 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(if(compact) 1.dp else 3.dp)) {
            HomeGameGlyph(if (blue) "xp" else "coin", Modifier.size(if (compact) 17.dp else 22.dp))
            Text(value, fontSize = if (compact) 8.5.sp else 10.5.sp,
                fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false,
                color = if (featured) Color.White else if (blue) Color(0xFF25437C) else Color(0xFF68440B))
        }
    }
}


@Composable
private fun HomeMeetingsSection(
    modifier: Modifier, upcoming: List<Pair<Meeting, Task>>, veryShort: Boolean,
    onSchedule: () -> Unit, onMeetings: (String) -> Unit, onAdd: () -> Unit
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(if (veryShort) 4.dp else 6.dp)) {
        HomeSectionTitle("جلسه بعدی", "تایم‌شیت", Icons.Outlined.CalendarMonth, onSchedule, veryShort)
        if (upcoming.isEmpty()) {
            Surface(onClick = onAdd, modifier = Modifier.fillMaxWidth().weight(1f),
                color = Color.White, shape = RoundedCornerShape(18.dp),
                border = BorderStroke(.8.dp, Color(0xFFE5EBF5)), shadowElevation = 2.dp) {
                Row(Modifier.fillMaxSize().padding(horizontal = 13.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("جلسه آینده‌ای ندارید", modifier = Modifier.weight(1f),
                        maxLines = 1, color = HomeMuted, fontSize = 12.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.AddCircleOutline, null, tint = HomeBlue,
                            modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("افزودن جلسه", color = HomeBlue, fontSize = 11.sp,
                            fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().weight(1f),
                horizontalArrangement = Arrangement.spacedBy(if (veryShort) 4.dp else 7.dp)) {
                // In RTL, index 0 is the rightmost/closest event.
                repeat(3) { index ->
                    val event = upcoming.getOrNull(index)
                    if (event == null) {
                        Surface(onClick = onAdd, modifier = Modifier.weight(1f).fillMaxHeight(),
                            shape = RoundedCornerShape(17.dp), color = Color.White,
                            border = BorderStroke(1.dp, Color(0xFFC9D7F7)), shadowElevation = 2.dp) {
                            Column(Modifier.fillMaxSize().padding(3.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center) {
                                Icon(Icons.Outlined.AddCircleOutline, "افزودن جلسه",
                                    tint = HomeBlue, modifier = Modifier.size(if (veryShort) 19.dp else 25.dp))
                                Spacer(Modifier.height(5.dp))
                                Text("افزودن جلسه", fontSize = if (veryShort) 9.sp else 10.sp,
                                    color = HomeBlue, fontWeight = FontWeight.SemiBold,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    } else {
                        val (meeting, task) = event
                        Card(onClick = { onMeetings(meeting.id) },
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                            shape = RoundedCornerShape(21.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            border = BorderStroke(.7.dp, Color(0xFFE6EBF5))) {
                            Column(Modifier.fillMaxSize().padding(horizontal = 4.dp, vertical = 5.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(
                                    if (veryShort) 2.dp else 7.dp, Alignment.CenterVertically)) {
                                Row(Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center) {
                                    HomeMeetingGlyph(Modifier.size(if (veryShort) 15.dp else 21.dp))
                                    Spacer(Modifier.width(if (veryShort) 2.dp else 4.dp))
                                    Text(homeWeekday(requireNotNull(task.dueDay)),
                                        modifier = Modifier.weight(1f, fill = false),
                                        textAlign = TextAlign.Center,
                                        fontSize = if (veryShort) 9.sp else 11.sp,
                                        color = Color(0xFF68758D), fontWeight = FontWeight.SemiBold,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Text(task.dueMinute?.let { String.format(Locale.ROOT,
                                    "%02d:%02d", it / 60, it % 60) } ?: "—",
                                    fontSize = if (veryShort) 17.sp else 25.sp,
                                    color = HomeBlue, textAlign = TextAlign.Center,
                                    fontWeight = FontWeight.Black, maxLines = 1)
                                HomeMeetingTitle(task.title, veryShort,
                                    Modifier.fillMaxWidth().padding(horizontal = 2.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
private fun HomeMeetingTitle(title: String, veryShort: Boolean, modifier: Modifier = Modifier) {
    var font by remember(title, veryShort) { mutableStateOf(if (veryShort) 10f else 12f) }
    Text(title, modifier = modifier, fontSize = font.sp,
        textAlign = TextAlign.Center, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis,
        fontWeight = FontWeight.SemiBold, color = HomeInk, onTextLayout = {
            if (it.didOverflowWidth && font > 9f) font = (font - .5f).coerceAtLeast(9f)
        })
}

private fun homeWeekday(day: Long): String = when (LocalDate.ofEpochDay(day).dayOfWeek.value) {
    1 -> "دوشنبه"; 2 -> "سه‌شنبه"; 3 -> "چهارشنبه"; 4 -> "پنجشنبه"
    5 -> "جمعه"; 6 -> "شنبه"; else -> "یکشنبه"
}

private fun homeLevelName(level: Int): String = when (level) {
    1 -> "Beginner"; 2 -> "Explorer"; 3 -> "Learner"; 4 -> "Builder"; 5 -> "Achiever";
    6 -> "Rising Star"; 7 -> "Challenger"; 8 -> "Expert"; 9 -> "Champion";
    10 -> "Elite"; 11 -> "Legend"; 12 -> "Master"; else -> "Ascendant $level"
}

@Composable
private fun HomeSectionTitle(title: String, action: String, icon: ImageVector, onClick: () -> Unit, veryShort: Boolean) {
    Row(Modifier.fillMaxWidth().height(if (veryShort) 21.dp else 24.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = HomeBlue,
                modifier = Modifier.size(if (veryShort) 16.dp else 20.dp))
            Spacer(Modifier.width(5.dp))
            Text(title, fontWeight = FontWeight.ExtraBold, fontSize = if (veryShort) 13.sp else 15.sp,
                maxLines = 1, color = HomeInk)
        }
        Row(Modifier.clickable(onClick = onClick).padding(horizontal = 2.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(action, fontSize = if (veryShort) 10.sp else 11.sp,
                fontWeight = FontWeight.SemiBold, color = HomeBlue)
            Spacer(Modifier.width(3.dp))
            Icon(Icons.Outlined.ArrowBack, null, tint = HomeBlue, modifier = Modifier.size(13.dp))
        }
    }
}
