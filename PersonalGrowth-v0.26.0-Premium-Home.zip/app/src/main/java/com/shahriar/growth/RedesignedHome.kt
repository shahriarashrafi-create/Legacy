package com.shahriar.growth

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shahriar.growth.data.*
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private val HomeBlue = Color(0xFF355CDE)
private val HomeInk = Color(0xFF17223B)
private val HomeMuted = Color(0xFF78849A)
private val HomePale = Color(0xFFEEF2FF)
private val HomeShape = RoundedCornerShape(21.dp)
private val CoinGold = Color(0xFFF1BE47)
private val DoneGreen = Color(0xFF229E65)
private val ComboOrange = Color(0xFFF07732)

/** All graphics are drawn locally. No image assets or network image requests. */
@Composable
fun HomeRouteLogo(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val track = Path().apply {
            moveTo(.16f*w,.78f*h)
            cubicTo(.36f*w,.58f*h,.49f*w,.40f*h,.60f*w,.18f*h)
            lineTo(.59f*w,.59f*h)
            cubicTo(.65f*w,.66f*h,.75f*w,.72f*h,.85f*w,.80f*h)
            cubicTo(.68f*w,.78f*h,.56f*w,.75f*h,.45f*w,.76f*h)
            cubicTo(.34f*w,.78f*h,.25f*w,.81f*h,.16f*w,.78f*h)
            close()
        }
        drawPath(track, Color.White)
        val flag = Path().apply {
            moveTo(.62f*w,.19f*h)
            lineTo(.82f*w,.19f*h)
            lineTo(.75f*w,.28f*h)
            lineTo(.82f*w,.37f*h)
            lineTo(.62f*w,.37f*h)
            close()
        }
        drawPath(flag, Color.White)
    }
}

@Composable
fun RedesignedHome(
    modifier: Modifier,
    tasks: List<Task>, choice: ActionChoice?, today: Long, active: FocusSession?,
    edges: List<Prerequisite>, meetings: List<Meeting>,
    onFocus: (String) -> Unit, onSchedule: () -> Unit, onMeetings: (String) -> Unit,
    onNewMeeting: () -> Unit, onNew: () -> Unit, onOpen: (String) -> Unit, onList: (Int) -> Unit
) {
    // Meetings have a linked Task. Keep them out of regular task suggestions.
    val meetingTaskIds = meetings.map { it.taskId }.toSet()
    val regularTasks = tasks.filterNot { it.id in meetingTaskIds }
    val first = regularTasks.firstOrNull { it.id == active?.taskId } ?: nextAction(regularTasks, choice, today, edges)
    val candidates = regularTasks.filter { !it.archived && !it.done && it.id != first?.id && it.excludedDay != today }
        .filter { candidate -> edges.none { edge -> edge.taskId == candidate.id && tasks.any { it.id == edge.dependsOnId && !it.done } } }
        .sortedWith(compareBy<Task> { if (it.dueDay == null) 2 else if (it.dueDay < today) 0 else if (it.dueDay == today) 1 else 3 }
            .thenByDescending { it.priority }.thenBy { it.dueDay ?: Long.MAX_VALUE }.thenBy { it.dueMinute ?: 1440 }.thenBy { it.createdAt })
    val suggested = (listOfNotNull(first) + candidates).distinctBy { it.id }.take(3)

    val nowMinute = LocalTime.now().toSecondOfDay() / 60
    val upcoming = meetings.mapNotNull { meeting ->
        tasks.firstOrNull { it.id == meeting.taskId }?.let { task ->
            if (!task.archived && !task.done && task.dueDay != null &&
                (task.dueDay > today || (task.dueDay == today && (task.dueMinute ?: 1440) >= nowMinute))) {
                meeting to task
            } else null
        }
    }.sortedWith(compareBy<Pair<Meeting, Task>> { it.second.dueDay }.thenBy { it.second.dueMinute ?: 1440 }).take(3)

    // The white premium Level card occupies the real Scaffold topBar slot.
    // The body is independently measured only AFTER Scaffold reserves top/bottom bars.
    BoxWithConstraints(modifier.fillMaxSize().background(
        Brush.verticalGradient(listOf(Color(0xFFFCFDFF), Color(0xFFF7F9FD), Color(0xFFF0F4FD))))) {
        val short = maxHeight < 425.dp
        val veryShort = maxHeight < 335.dp
        val pad = if (veryShort) 4.dp else if (short) 6.dp else 9.dp
        val between = if (veryShort) 5.dp else if (short) 7.dp else 10.dp
        val usable = (maxHeight - pad * 2 - between).coerceAtLeast(0.dp)
        // Meetings size to content first; all remaining space is assigned to the
        // higher-priority three task cards. There are no invisible spacer slots.
        val sessionsHeight = if (upcoming.isEmpty())
            (usable * .23f).coerceAtMost(93.dp)
        else (usable * .34f).coerceAtMost(157.dp)
        val stepsHeight = (usable - sessionsHeight).coerceAtLeast(0.dp)
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = pad),
            verticalArrangement = Arrangement.spacedBy(between)) {
            HomeTasksSection(Modifier.fillMaxWidth().height(stepsHeight), suggested, veryShort,
                onAll = { onList(6) }, onNew = onNew, onOpen = onOpen)
            HomeMeetingsSection(Modifier.fillMaxWidth().height(sessionsHeight), upcoming, veryShort,
                onSchedule = onSchedule, onMeetings = onMeetings, onAdd = onNewMeeting)
        }
    }


}

/** A SINGLE distinct, premium Level card; Compose drawing only, no downloaded images.
 * RTL: medal right, local avatar left. User name right / Level label left
 * ABOVE the XP line between the two portraits, then four colored game chips.
 */
@Composable
fun HomePremiumLevelCard(name: String?, tasks: List<Task>, wallet: List<WalletEntry>, today: Long) {
    val earnedXp = wallet.sumOf { it.xp }.coerceAtLeast(0L)
    val level = levelFor(earnedXp)
    val progress = (earnedXp % 100L).toInt()
    val animatedProgress by animateFloatAsState(
        targetValue = progress / 100f, animationSpec = tween(durationMillis = 540), label = "XP progress")
    val coins = wallet.sumOf { it.coins }
    val doneToday = tasks.count { task -> !task.archived && task.done &&
        task.completedAt?.let { localDay(it, ZoneId.systemDefault()) == today } == true }
    val combo = streakDays(tasks.filter { it.done }.mapNotNull { task ->
        task.completedAt?.let { localDay(it, ZoneId.systemDefault()) }
    }.toSet(), today)
    val context = LocalContext.current
    val localAvatar = remember(context) { LocalProfileAvatar.load(context) }
    val compact = LocalConfiguration.current.screenHeightDp < 695
    val tiny = LocalConfiguration.current.screenHeightDp < 600
    val portraitSize = if (tiny) 38.dp else if (compact) 45.dp else 52.dp
    val medalSize = if (tiny) 41.dp else if (compact) 49.dp else 57.dp
    val infoHeight = if (tiny) 43.dp else if (compact) 51.dp else 57.dp
    val metricHeight = if (tiny) 38.dp else if (compact) 42.dp else 48.dp
    val pad = if (tiny) 8.dp else if (compact) 10.dp else 12.dp
    Column(Modifier.fillMaxWidth().statusBarsPadding().padding(
        horizontal = 13.dp, vertical = if (tiny) 4.dp else 7.dp)) {
        Surface(Modifier.fillMaxWidth().shadow(6.dp, RoundedCornerShape(23.dp)),
            shape = RoundedCornerShape(23.dp), color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE9D4A3))) {
            Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(
                listOf(Color.White, Color(0xFFFEFCF7), Color.White)))
                .padding(horizontal = pad, vertical = pad),
                verticalArrangement = Arrangement.spacedBy(if (tiny) 5.dp else 8.dp)) {
                Row(Modifier.fillMaxWidth().height(infoHeight),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(if (tiny) 5.dp else 9.dp)) {
                    HomeMedal(level, medalSize)
                    Column(Modifier.weight(1f).fillMaxHeight(),
                        verticalArrangement = Arrangement.Center) {
                        Row(Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Text(name?.takeIf { it.isNotBlank() } ?: "نام کاربر",
                                modifier = Modifier.weight(.9f), color = HomeInk,
                                fontWeight = FontWeight.ExtraBold, fontSize = if (tiny) 10.sp else 12.sp,
                                textAlign = TextAlign.Right, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                            Text("Level $level: ${homeLevelName(level)}",
                                modifier = Modifier.weight(1.45f), color = Color(0xFF273C78),
                                fontWeight = FontWeight.ExtraBold, fontSize = if (tiny) 9.sp else 11.sp,
                                textAlign = TextAlign.Left, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                        }
                        Spacer(Modifier.height(if (tiny) 6.dp else 9.dp))
                        // LTR fill direction even though everything around it is RTL.
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Box(Modifier.fillMaxWidth().height(if (tiny) 8.dp else 11.dp)
                                .clip(CircleShape).background(Color(0xFFDDE6FA))) {
                                // The empty state is a truly empty track: no rounded zero dot.
                                if (progress > 0) {
                                    Box(Modifier.fillMaxWidth(animatedProgress.coerceIn(0f, 1f))
                                        .fillMaxHeight().clip(CircleShape)
                                        .background(Brush.horizontalGradient(listOf(
                                            Color(0xFF2048C2), Color(0xFF4776F0), Color(0xFF91B8FF)))))
                                    Box(Modifier.fillMaxWidth(animatedProgress.coerceIn(0f, 1f))
                                        .height(2.dp).padding(horizontal = 2.dp)
                                        .background(Color.White.copy(alpha = .38f)))
                                }
                            }
                        }
                    }
                    Box(Modifier.size(portraitSize).clip(CircleShape)
                        .background(Color(0xFFE8EDF7)), contentAlignment = Alignment.Center) {
                        if (localAvatar != null) {
                            Image(bitmap = localAvatar, contentDescription = "عکس پروفایل کاربر",
                                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        } else {
                            Icon(Icons.Outlined.PersonOutline, "آواتار پیش‌فرض", tint = Color(0xFF8796AE),
                                modifier = Modifier.size(portraitSize * .66f))
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().height(metricHeight),
                    horizontalArrangement = Arrangement.spacedBy(if (tiny) 3.dp else 6.dp)) {
                    HomeGameMetric(Modifier.weight(1f), HomeBlue, Color.White, "xp", "$progress/100")
                    HomeGameMetric(Modifier.weight(1f), CoinGold, Color(0xFF483006), "coin", "$coins")
                    HomeGameMetric(Modifier.weight(1f), DoneGreen, Color.White, "done", "$doneToday")
                    HomeGameMetric(Modifier.weight(1f), ComboOrange, Color.White, "combo", "$combo")
                }
            }
        }
    }
}


@Composable
private fun HomeGameMetric(modifier: Modifier, background: Color, foreground: Color,
                           kind: String, value: String) {
    val highlight = when (kind) {
        "xp" -> Color(0xFF6988FA)
        "coin" -> Color(0xFFFFDF76)
        "done" -> Color(0xFF43CE91)
        else -> Color(0xFFFFAA62)
    }
    Box(modifier.clip(RoundedCornerShape(12.dp))
        .background(Brush.verticalGradient(listOf(highlight, background, background))),
        contentAlignment = Alignment.Center) {
        // The tiny top highlight gives game-UI depth without external assets.
        Box(Modifier.fillMaxWidth().height(1.dp).align(Alignment.TopCenter)
            .background(Color.White.copy(alpha = .48f)))
        Row(Modifier.fillMaxWidth().padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            HomeGameGlyph(kind, Modifier.size(18.dp))
            Spacer(Modifier.width(2.dp))
            val title = when (kind) { "done" -> "DONE"; "combo" -> "COMBO"; else -> "" }
            if (title.isNotEmpty()) {
                Text(title, color = foreground, fontSize = 8.sp, maxLines = 1,
                    fontWeight = FontWeight.Black)
                Spacer(Modifier.width(2.dp))
            }
            Text(value, color = foreground, fontSize = if (value.length > 7) 8.sp else 10.sp,
                fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** Small premium-style, offline Canvas glyphs; no image files or external requests. */
@Composable
private fun HomeGameGlyph(kind: String, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        when (kind) {
            "xp" -> {
                val bolt = Path().apply {
                    moveTo(w*.56f, h*.03f); lineTo(w*.16f,h*.55f)
                    lineTo(w*.47f,h*.55f); lineTo(w*.35f,h*.97f)
                    lineTo(w*.88f,h*.39f); lineTo(w*.57f,h*.39f); close()
                }
                drawPath(bolt, Color(0xFFFFE784))
                drawPath(bolt, Color.White.copy(alpha=.65f), style=Stroke(width=1.dp.toPx()))
            }
            "coin" -> {
                val r = min(w,h)*.46f
                val c = Offset(w*.5f,h*.5f)
                drawCircle(Color(0xFF9C6310), r, c)
                drawCircle(Color(0xFFFFE78B), r*.90f, c)
                drawCircle(Color(0xFFC78C1F), r*.70f, c, style=Stroke(width=1.3.dp.toPx()))
                val star = Path().apply {
                    moveTo(c.x, c.y-r*.54f)
                    lineTo(c.x+r*.20f,c.y-r*.13f)
                    lineTo(c.x+r*.56f,c.y-r*.10f)
                    lineTo(c.x+r*.27f,c.y+r*.17f)
                    lineTo(c.x+r*.36f,c.y+r*.51f)
                    lineTo(c.x,c.y+r*.34f)
                    lineTo(c.x-r*.36f,c.y+r*.51f)
                    lineTo(c.x-r*.27f,c.y+r*.17f)
                    lineTo(c.x-r*.56f,c.y-r*.10f)
                    lineTo(c.x-r*.20f,c.y-r*.13f); close()
                }
                drawPath(star, Color(0xFFB37712))
            }
            "done" -> {
                val shield = Path().apply {
                    moveTo(w*.5f,h*.06f); lineTo(w*.88f,h*.23f)
                    lineTo(w*.82f,h*.67f); lineTo(w*.5f,h*.94f)
                    lineTo(w*.18f,h*.67f); lineTo(w*.12f,h*.23f); close()
                }
                drawPath(shield, Color(0xFFC0FFDC).copy(alpha=.80f))
                val check = Path().apply {
                    moveTo(w*.27f,h*.48f); lineTo(w*.44f,h*.65f); lineTo(w*.75f,h*.32f)
                }
                drawPath(check, Color(0xFF087C41), style=Stroke(width=2.6.dp.toPx()))
            }
            "combo" -> {
                val flame = Path().apply {
                    moveTo(w*.52f,h*.02f)
                    cubicTo(w*.60f,h*.34f,w*.95f,h*.39f,w*.85f,h*.72f)
                    cubicTo(w*.77f,h*1.03f,w*.25f,h*1.03f,w*.15f,h*.73f)
                    cubicTo(w*.05f,h*.43f,w*.37f,h*.30f,w*.52f,h*.02f)
                    close()
                }
                drawPath(flame, Color(0xFFFFE77C))
                val inner = Path().apply {
                    moveTo(w*.48f,h*.45f)
                    cubicTo(w*.62f,h*.63f,w*.69f,h*.72f,w*.59f,h*.84f)
                    cubicTo(w*.47f,h*.97f,w*.28f,h*.79f,w*.36f,h*.65f)
                    close()
                }
                drawPath(inner, Color(0xFFE95D21))
            }
        }
    }
}

/** Ribboned gold medal. Number and geometry make every level individually recognisable. */
@Composable
private fun HomeMedal(level: Int, boxSize: Dp) {
    Box(Modifier.size(boxSize), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(3.dp)) {
            val w = size.width
            val h = size.height
            val ribbonLeft = Path().apply {
                moveTo(.28f*w, .02f*h); lineTo(.45f*w, .02f*h)
                lineTo(.59f*w, .45f*h); lineTo(.44f*w, .54f*h); close()
            }
            val ribbonRight = Path().apply {
                moveTo(.57f*w, .02f*h); lineTo(.74f*w, .02f*h)
                lineTo(.59f*w, .54f*h); lineTo(.43f*w, .46f*h); close()
            }
            drawPath(ribbonLeft, Color(0xFF3465D9))
            drawPath(ribbonRight, Color(0xFFE45F4F))
            // Small scallops vary between adjacent levels; no grouped badge tiers.
            val petals = 9 + (level.coerceAtLeast(1) % 5)
            val centre = Offset(.51f*w, .65f*h)
            val radius = min(w, h) * .265f
            for (i in 0 until petals) {
                val angle = 2 * PI * i / petals
                val dot = Offset(centre.x + (radius * cos(angle)).toFloat(), centre.y + (radius * sin(angle)).toFloat())
                drawCircle(Color(0xFFE8A629), radius = w * .074f, center = dot)
            }
            drawCircle(brush = Brush.radialGradient(listOf(Color(0xFFFFF6BC),
                Color(0xFFF6C34F), Color(0xFFAB691A)), center = centre,
                radius = radius * 1.15f), radius = radius * .96f, center = centre)
            drawCircle(Color(0xFFE6A321), radius = radius * .83f, center = centre, style = Stroke(width = 1.6.dp.toPx()))
            drawCircle(brush = Brush.radialGradient(listOf(Color(0xFFFFFBE0),
                Color(0xFFF7D778)), center = centre, radius = radius),
                radius = radius * .72f, center = centre)
            drawCircle(Color.White.copy(alpha = .75f), radius = radius * .13f,
                center = Offset(centre.x - radius * .34f, centre.y - radius * .32f))
        }
        Text("$level", modifier = Modifier.offset(y = boxSize * .12f),
            color = Color(0xFF966113), fontSize = if (boxSize < 32.dp) 10.sp else 12.sp,
            fontWeight = FontWeight.ExtraBold)
    }
}

/** A single shared, game-styled task emblem, built in Canvas for offline use. */
@Composable
private fun HomeTaskGlyph(featured: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val border = if (featured) Color.White else HomeBlue
        val accent = if (featured) Color(0xFFFFE393) else Color(0xFFE5AA35)
        val sheet = Path().apply {
            moveTo(w*.25f,h*.08f); lineTo(w*.76f,h*.08f)
            lineTo(w*.86f,h*.20f); lineTo(w*.86f,h*.90f)
            lineTo(w*.25f,h*.90f); close()
        }
        drawPath(sheet, brush = Brush.verticalGradient(listOf(
            border.copy(alpha=.22f), border.copy(alpha=.07f))))
        drawPath(sheet,border,style=Stroke(width=1.8.dp.toPx()))
        for (i in 0..2) {
            val y = h*(.34f + i*.19f)
            drawLine(accent,Offset(w*.34f,y),Offset(w*.41f,y),strokeWidth=2.2.dp.toPx())
            drawLine(border,Offset(w*.49f,y),Offset(w*.75f,y),strokeWidth=1.7.dp.toPx())
        }
        drawCircle(Color.White.copy(alpha=.6f), radius=w*.042f, center=Offset(w*.71f,h*.16f))
    }
}

/** Calendar event token with luminous blue rim, rather than an image bitmap. */
@Composable
private fun HomeMeetingGlyph(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val centre=Offset(size.width*.5f,size.height*.5f)
        val r=min(size.width,size.height)*.43f
        drawCircle(brush=Brush.radialGradient(listOf(Color(0xFFEAF2FF),
            Color(0xFFCBD9FF)),center=centre,radius=r),radius=r,center=centre)
        drawCircle(Color(0xFF5474DE),radius=r,center=centre,
            style=Stroke(width=1.2.dp.toPx()))
        drawLine(HomeBlue, centre, Offset(centre.x,centre.y-r*.56f),
            strokeWidth=1.5.dp.toPx())
        drawLine(HomeBlue, centre, Offset(centre.x+r*.47f,centre.y+r*.11f),
            strokeWidth=1.5.dp.toPx())
        drawCircle(Color(0xFFE4AC2D),radius=r*.14f,center=centre)
        drawCircle(Color.White.copy(alpha=.9f),radius=r*.10f,
            center=Offset(centre.x-r*.35f,centre.y-r*.46f))
    }
}

@Composable
private fun HomeTasksSection(
    modifier: Modifier, suggested: List<Task>, veryShort: Boolean,
    onAll: () -> Unit, onNew: () -> Unit, onOpen: (String) -> Unit
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(if (veryShort) 4.dp else 6.dp)) {
        HomeSectionTitle("قدم بعدی", "مشاهده همه", onAll, veryShort)
        if (suggested.isEmpty()) {
            Card(Modifier.fillMaxWidth().weight(1f), shape = HomeShape,
                colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.fillMaxSize().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("فعلاً کاری برای شروع وجود ندارد.", modifier = Modifier.weight(1f),
                        color = HomeMuted, fontSize = 12.sp)
                    TextButton(onClick = onNew) { Text("افزودن کار") }
                }
            }
        } else {
            // Three fully independent cards. Keep 80:73:73 when all three exist.
            suggested.forEachIndexed { index, task ->
                HomeTaskRow(task, featured = index == 0,
                    modifier = Modifier.fillMaxWidth().weight(if (index == 0) 80f else 73f),
                    veryShort = veryShort, onStart = { onOpen(task.id) })
            }
        }
    }
}

@Composable
private fun HomeTaskRow(task: Task, featured: Boolean, modifier: Modifier,
                        veryShort: Boolean, onStart: () -> Unit) {
    val ink = if (featured) Color.White else HomeInk
    val payout = rewardFor(task.priority)
    Surface(modifier = modifier.shadow(if (featured) 5.dp else 3.dp, RoundedCornerShape(19.dp)),
        shape = RoundedCornerShape(19.dp), color = if (featured) HomeBlue else Color.White,
        border = if (featured) null else BorderStroke(.7.dp, Color(0xFFE4EAF5))) {
        BoxWithConstraints(Modifier.fillMaxSize().then(if (featured) Modifier.background(
            Brush.horizontalGradient(listOf(Color(0xFF254ACA), HomeBlue, Color(0xFF4D77E9)))) else Modifier)) {
            val compact = maxHeight < 74.dp || veryShort
            val iconSize = if (compact) 31.dp else 39.dp
            Row(Modifier.fillMaxSize().padding(horizontal = if (compact) 8.dp else 12.dp,
                vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(if (compact) 5.dp else 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(iconSize).clip(RoundedCornerShape(10.dp))
                    .background(if (featured) Color.White.copy(alpha = .16f) else HomePale),
                    contentAlignment = Alignment.Center) {
                    HomeTaskGlyph(featured, Modifier.size(if (compact) 21.dp else 25.dp))
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(
                    if (compact) 3.dp else 5.dp)) {
                    HomeAutoTaskTitle(task.title, ink, if (compact) 12f else 14f)
                    Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(if (compact) 3.dp else 5.dp)) {
                        HomeTaskReward("xp", "$TASK_COMPLETION_XP XP", compact)
                        HomeTaskReward("coin", "$payout", compact)
                    }
                }
                Button(onClick = onStart, modifier = Modifier.width(if (compact) 51.dp else 62.dp)
                    .height(if (compact) 37.dp else 42.dp),
                    shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (featured) Color.White else HomeBlue,
                        contentColor = if (featured) HomeBlue else Color.White),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 3.dp,
                        pressedElevation = 0.dp)) {
                    Text("شروع", fontSize = if (compact) 10.sp else 12.sp,
                        fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}


@Composable
private fun HomeAutoTaskTitle(value: String, color: Color, initialSize: Float) {
    var font by remember(value, initialSize) { mutableStateOf(initialSize) }
    Text(value, modifier = Modifier.fillMaxWidth(), color = color,
        fontWeight = FontWeight.SemiBold, fontSize = font.sp, maxLines = 1,
        softWrap = false, overflow = TextOverflow.Ellipsis,
        onTextLayout = { if (it.didOverflowWidth && font > 10f) font = (font - .5f).coerceAtLeast(10f) })
}

@Composable
private fun HomeTaskReward(kind: String, value: String, compact: Boolean) {
    val blue = kind == "xp"
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(Modifier.clip(RoundedCornerShape(8.dp))
            .background(if (blue) Brush.horizontalGradient(listOf(Color(0xFF365EDF), Color(0xFF688DF8)))
                else Brush.horizontalGradient(listOf(Color(0xFFFFE38C), Color(0xFFF1BB47))))
            .padding(horizontal = if (compact) 4.dp else 6.dp,
                vertical = if (compact) 2.dp else 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            HomeGameGlyph(if (blue) "xp" else "coin", Modifier.size(if (compact) 12.dp else 14.dp))
            Text(value, fontSize = if (compact) 8.sp else 9.sp,
                fontWeight = FontWeight.Bold, maxLines = 1,
                color = if (blue) Color.White else Color(0xFF553706))
        }
    }
}


@Composable
private fun HomeMeetingsSection(
    modifier: Modifier, upcoming: List<Pair<Meeting, Task>>, veryShort: Boolean,
    onSchedule: () -> Unit, onMeetings: (String) -> Unit, onAdd: () -> Unit
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(if (veryShort) 4.dp else 6.dp)) {
        HomeSectionTitle("جلسه بعدی", "تایم‌شیت", onSchedule, veryShort)
        if (upcoming.isEmpty()) {
            Surface(onClick = onAdd, modifier = Modifier.fillMaxWidth().weight(1f),
                color = Color.White, shape = RoundedCornerShape(18.dp),
                border = BorderStroke(.8.dp, Color(0xFFE5EBF5)), shadowElevation = 2.dp) {
                Row(Modifier.fillMaxSize().padding(horizontal = 13.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("جلسه آینده‌ای ندارید", modifier = Modifier.weight(1f),
                        maxLines = 1, color = HomeMuted, fontSize = 12.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.AddCircleOutline, null, tint = HomeBlue,
                            modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("افزودن جلسه", color = HomeBlue, fontSize = 11.sp,
                            fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().weight(1f),
                horizontalArrangement = Arrangement.spacedBy(if (veryShort) 4.dp else 7.dp)) {
                // In RTL, index 0 is the rightmost/closest event.
                repeat(3) { index ->
                    val event = upcoming.getOrNull(index)
                    if (event == null) {
                        Surface(onClick = onAdd, modifier = Modifier.weight(1f).fillMaxHeight(),
                            shape = RoundedCornerShape(17.dp), color = Color.White,
                            border = BorderStroke(1.dp, Color(0xFFC9D7F7)), shadowElevation = 2.dp) {
                            Column(Modifier.fillMaxSize().padding(3.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center) {
                                Icon(Icons.Outlined.AddCircleOutline, "افزودن جلسه",
                                    tint = HomeBlue, modifier = Modifier.size(if (veryShort) 19.dp else 25.dp))
                                Spacer(Modifier.height(5.dp))
                                Text("افزودن جلسه", fontSize = if (veryShort) 9.sp else 10.sp,
                                    color = HomeBlue, fontWeight = FontWeight.SemiBold,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    } else {
                        val (meeting, task) = event
                        Card(onClick = { onMeetings(meeting.id) },
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                            shape = RoundedCornerShape(17.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                            border = BorderStroke(.7.dp, Color(0xFFE6EBF5))) {
                            Column(Modifier.fillMaxSize().padding(horizontal = 4.dp, vertical = 5.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.SpaceEvenly) {
                                HomeMeetingGlyph(Modifier.size(if (veryShort) 15.dp else 20.dp))
                                Text(homeWeekday(requireNotNull(task.dueDay)),
                                    fontSize = if (veryShort) 10.sp else 11.sp,
                                    color = HomeInk, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Text(task.dueMinute?.let { String.format(Locale.ROOT,
                                    "%02d:%02d", it / 60, it % 60) } ?: "—",
                                    fontSize = if (veryShort) 13.sp else 16.sp,
                                    color = HomeBlue, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                                HomeMeetingTitle(task.title, veryShort)
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
private fun HomeMeetingTitle(title: String, veryShort: Boolean) {
    var font by remember(title, veryShort) { mutableStateOf(if (veryShort) 10f else 11.5f) }
    Text(title, modifier = Modifier.fillMaxWidth(), fontSize = font.sp,
        maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis,
        color = HomeMuted, onTextLayout = {
            if (it.didOverflowWidth && font > 9f) font = (font - .5f).coerceAtLeast(9f)
        })
}

private fun homeWeekday(day: Long): String = when (LocalDate.ofEpochDay(day).dayOfWeek.value) {
    1 -> "دوشنبه"; 2 -> "سه‌شنبه"; 3 -> "چهارشنبه"; 4 -> "پنجشنبه"
    5 -> "جمعه"; 6 -> "شنبه"; else -> "یکشنبه"
}

private fun homeLevelName(level: Int): String = when (level) {
    1 -> "Beginner"; 2 -> "Explorer"; 3 -> "Learner"; 4 -> "Builder"; 5 -> "Achiever";
    6 -> "Rising Star"; 7 -> "Challenger"; 8 -> "Expert"; 9 -> "Champion";
    10 -> "Elite"; 11 -> "Legend"; 12 -> "Master"; else -> "Ascendant $level"
}

@Composable
private fun HomeSectionTitle(title: String, action: String, onClick: () -> Unit, veryShort: Boolean) {
    Row(Modifier.fillMaxWidth().height(if (veryShort) 21.dp else 24.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, fontWeight = FontWeight.ExtraBold, fontSize = if (veryShort) 13.sp else 15.sp,
            maxLines = 1, color = HomeInk)
        Row(Modifier.clickable(onClick = onClick).padding(horizontal = 2.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(action, fontSize = if (veryShort) 10.sp else 11.sp,
                fontWeight = FontWeight.SemiBold, color = HomeBlue)
            Spacer(Modifier.width(3.dp))
            Icon(Icons.Outlined.ArrowBack, null, tint = HomeBlue, modifier = Modifier.size(13.dp))
        }
    }
}
