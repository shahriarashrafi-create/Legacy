# مسیر من — نسخه 0.3.0

نسخه تجمیعی مراحل ۱ تا ۳ از برنامه ۲۰ نسخه‌ای؛ اپ بومی Kotlin / Jetpack Compose و آفلاین.

## امکانات این نسخه
پایه نسخه اول همراه با تودولیست واقعی و هوم متصل به کارها. امکانات دقیق در CHANGELOG.md و سناریوهای بررسی در TESTING.md آمده‌اند.
تاریخ‌های ورودی شمسی با قالب سال/ماه/روز هستند؛ اعداد فارسی، عربی و لاتین پذیرفته می‌شوند.
تمرکز در مرحله ۴ و زیرکار/تکرار در مراحل بعدی اضافه خواهند شد.

## ساخت با ورک‌فلوی درخواستی
1. فایل `.github/workflows/build-apk.yml` را از این ZIP در همان مسیر ریپوزیتوری GitHub قرار دهید. وجود ورک‌فلو فقط داخل ZIP باعث اجرای GitHub Actions نمی‌شود.
2. ZIP پروژه را در ریشه ریپوزیتوری با شاخه main آپلود کنید.
3. از Actions نتیجه Build Android APK From ZIP را مشاهده کنید.
4. APK در Artifact و Releases منتشر می‌شود؛ لینک ثابت releases/latest/download/app-debug.apk است.
5. برای اجرای دستی از workflow_dispatch استفاده کنید. در اجرای دستی، ورک‌فلوی درخواستی نخستین ZIP به ترتیب نام را انتخاب می‌کند؛ برای جلوگیری از ساخت نسخه قدیمی فقط ZIP نسخه مطلوب را نگه دارید.

## ابزارهای ثابت
JDK 17, Gradle 8.7, AGP 8.6.1, Kotlin/Compose compiler 2.0.21, compile/target SDK 35, min SDK 26.
فرمان محلی: `./gradlew assembleDebug` با Android SDK نصب‌شده و sdk.dir در local.properties یا ANDROID_HOME.
خروجی: app/build/outputs/apk/debug/app-debug.apk

## امضای ثابت
کلید اختصاصی همین پروژه در signing/personal-growth.jks قرار دارد. نسخه‌های بعد همین فایل و applicationId=com.shahriar.growth را حفظ کنند.
کلید و رمز ساخت همراه سورس هستند و برای پروژه شخصی تحویل داده شده‌اند؛ آن را عمومی منتشر نکنید.
این کلید جدید است و سازگاری نصب روی اپ‌های قدیمی Legacy ادعا نمی‌شود.

## وضعیت اعتبارسنجی
گزارش بررسی‌ها در TESTING.md است. کامپایل مستقیم Kotlin/Compose و ۷ تست JUnit موفق بودند؛ assembleDebug در این محیط به مشکل کش Gradle متوقف شد. جزئیات در BUILD-REPORT.md آمده است.

## ادامه
مرحله ۴: تمرکز و بازیابی جلسه؛ سپس مسیر پیشرفت.
