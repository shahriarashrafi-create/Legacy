package com.shahriar.growth

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shahriar.growth.data.*
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private val HomeBlue=Color(0xFF355CDE)
private val HomeInk=Color(0xFF17223B)
private val HomeMuted=Color(0xFF78849A)
private val HomeSurface=Color.White
private val HomePale=Color(0xFFEEF2FF)
private val HomeShape=RoundedCornerShape(24.dp)

@Composable
fun RedesignedHome(
    modifier:Modifier,tasks:List<Task>,choice:ActionChoice?,today:Long,active:FocusSession?,
    edges:List<Prerequisite>,meetings:List<Meeting>,wallet:List<WalletEntry>,name:String?,
    onFocus:(String)->Unit,onSchedule:()->Unit,onMeetings:(String)->Unit,onNew:()->Unit,
    onOpen:(String)->Unit,onList:(Int)->Unit
) {
    // The Home screen is a dashboard, not a scrolling page. The height below the
    // fixed app bar / above the fixed bottom bar is divided among the three sections.
    // Tasks get the largest share; meetings are second; level metrics are compact.
    val xp=wallet.sumOf { it.xp }.coerceAtLeast(0L)
    val coins=wallet.sumOf { it.coins }
    val level=levelFor(xp)
    val xpInLevel=(xp%100).toInt()
    val finished=tasks.filter { !it.archived && it.done && it.completedAt?.let { stamp -> localDay(stamp,ZoneId.systemDefault())==today }==true }
    val doneToday=finished.size
    val totalToday=tasks.count { !it.archived && (it.dueDay==today || it in finished) }
    val combo=streakDays(tasks.filter { it.done }.mapNotNull { it.completedAt?.let { stamp->localDay(stamp,ZoneId.systemDefault()) } }.toSet(),today)

    // Meeting records have a shared Task in the existing database. They belong to
    // the timesheet, not to the three regular task recommendations on Home.
    val meetingTaskIds=meetings.map { it.taskId }.toSet()
    val regularTasks=tasks.filterNot { it.id in meetingTaskIds }
    val first=regularTasks.firstOrNull { it.id==active?.taskId } ?: nextAction(regularTasks,choice,today,edges)
    val candidates=regularTasks.filter { !it.archived && !it.done && it.id!=first?.id && it.excludedDay!=today }
        .filter { candidate->edges.none { edge->edge.taskId==candidate.id && tasks.any { it.id==edge.dependsOnId && !it.done } } }
        .sortedWith(compareBy<Task> { if(it.dueDay==null) 2 else if(it.dueDay<today) 0 else if(it.dueDay==today) 1 else 3 }
            .thenByDescending { it.priority }.thenBy { it.dueDay?:Long.MAX_VALUE }.thenBy { it.dueMinute?:1440 }.thenBy { it.createdAt })
    val suggested=(listOfNotNull(first)+candidates).distinctBy { it.id }.take(3)
    val upcoming=meetings.mapNotNull { meeting->tasks.firstOrNull { it.id==meeting.taskId }?.let { task->
        if(!task.archived && !task.done && task.dueDay!=null && (task.dueDay>today || (task.dueDay==today && (task.dueMinute?:1440)>=java.time.LocalTime.now().toSecondOfDay()/60))) meeting to task else null
    } }.sortedWith(compareBy<Pair<Meeting,Task>> { it.second.dueDay }.thenBy { it.second.dueMinute?:1440 }).take(3)

    BoxWithConstraints(modifier.fillMaxSize()) {
        val compact = maxHeight < 535.dp
        val tight = maxHeight < 455.dp
        val sectionSpace=if(tight) 5.dp else if(compact) 8.dp else 12.dp
        val verticalInset=if(tight) 4.dp else 8.dp
        Column(
            Modifier.fillMaxSize().padding(horizontal=16.dp,vertical=verticalInset),
            verticalArrangement=Arrangement.spacedBy(sectionSpace)
        ) {
            HomeLevelCard(
                modifier=Modifier.fillMaxWidth().weight(if(tight) .22f else .235f),
                level=level,xpInLevel=xpInLevel,coins=coins,doneToday=doneToday,totalToday=totalToday,combo=combo,
                compact=compact,tight=tight
            )
            HomeTasksSection(
                modifier=Modifier.fillMaxWidth().weight(if(tight) .525f else .505f),
                suggested=suggested,compact=compact,tight=tight,
                onAll={onList(6)},onNew=onNew,onOpen=onOpen
            )
            HomeMeetingsSection(
                modifier=Modifier.fillMaxWidth().weight(if(tight) .255f else .26f),
                upcoming=upcoming,compact=compact,tight=tight,onSchedule=onSchedule,onMeetings=onMeetings
            )
        }
    }
}

@Composable private fun HomeLevelCard(
    modifier:Modifier,level:Int,xpInLevel:Int,coins:Long,doneToday:Int,totalToday:Int,combo:Int,
    compact:Boolean,tight:Boolean
) {
    val avatarSize=if(tight) 32.dp else if(compact) 38.dp else 42.dp
    Card(
        modifier=modifier.shadow(4.dp,HomeShape,ambientColor=HomeBlue.copy(alpha=.04f),spotColor=HomeBlue.copy(alpha=.04f)),
        shape=HomeShape,colors=CardDefaults.cardColors(containerColor=HomeSurface)
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal=14.dp,vertical=if(tight) 7.dp else 10.dp),
            verticalArrangement=Arrangement.SpaceBetween
        ) {
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                LevelBadge(level,avatarSize)
                Text("Level $level: ${homeLevelName(level)}",modifier=Modifier.weight(1f),color=HomeInk,
                    fontWeight=FontWeight.Bold,fontSize=if(tight) 12.sp else 14.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                Box(Modifier.size(avatarSize).background(Color(0xFFE9EDF5),CircleShape),contentAlignment=Alignment.Center) {
                    Icon(Icons.Outlined.PersonOutline,"تصویر جایگزین پروفایل",tint=Color(0xFF8290A6),modifier=Modifier.size(avatarSize*.55f))
                }
            }
            // Empty progress means empty: do not draw a rounded blue dot at 0 XP.
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Box(Modifier.fillMaxWidth().height(if(tight) 6.dp else 8.dp).clip(CircleShape).background(Color(0xFFE9EEFA))) {
                    if(xpInLevel>0) {
                        Box(Modifier.fillMaxWidth(xpInLevel/100f).fillMaxHeight().background(HomeBlue,CircleShape))
                    }
                }
            }
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                Box(Modifier.weight(1.05f),contentAlignment=Alignment.CenterStart){HomeMetric(Icons.Outlined.Bolt,"$xpInLevel/100",tight)}
                Box(Modifier.weight(.85f),contentAlignment=Alignment.Center){HomeMetric(Icons.Outlined.Paid,"$coins",tight)}
                Box(Modifier.weight(.75f),contentAlignment=Alignment.Center){
                    Box(Modifier.size(if(tight) 30.dp else 36.dp),contentAlignment=Alignment.Center) {
                        CircularProgressIndicator(progress={if(totalToday==0)0f else (doneToday.toFloat()/totalToday).coerceIn(0f,1f)},
                            modifier=Modifier.fillMaxSize(),strokeWidth=if(tight) 3.dp else 3.5.dp,
                            color=HomeBlue,trackColor=Color(0xFFE6EBF6))
                        Text("$doneToday",fontWeight=FontWeight.Bold,fontSize=if(tight) 11.sp else 13.sp,color=HomeInk)
                    }
                }
                Box(Modifier.weight(.7f),contentAlignment=Alignment.CenterEnd){HomeMetric(Icons.Outlined.LocalFireDepartment,"$combo",tight)}
            }
        }
    }
}

@Composable private fun HomeTasksSection(
    modifier:Modifier,suggested:List<Task>,compact:Boolean,tight:Boolean,
    onAll:()->Unit,onNew:()->Unit,onOpen:(String)->Unit
) {
    Column(modifier,verticalArrangement=Arrangement.spacedBy(if(tight) 4.dp else 7.dp)) {
        HomeSectionTitle("قدم بعدی","مشاهده همه",onAll,tight)
        if(suggested.isEmpty()) {
            Card(Modifier.fillMaxWidth().weight(1f),shape=HomeShape,colors=CardDefaults.cardColors(containerColor=HomeSurface)) {
                Row(Modifier.fillMaxSize().padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                    Text("فعلاً کاری برای شروع وجود ندارد.",modifier=Modifier.weight(1f),color=HomeMuted,fontSize=12.sp)
                    TextButton(onClick=onNew){Text("افزودن کار")}
                }
            }
        } else {
            suggested.firstOrNull()?.let { task ->
                HomeTaskRow(task,true,Modifier.fillMaxWidth().weight(if(tight) 1.18f else 1.32f),tight,onStart={onOpen(task.id)})
            }
            if(suggested.size>1) {
                Card(
                    modifier=Modifier.fillMaxWidth().weight(if(tight) 1.82f else 1.68f),
                    colors=CardDefaults.cardColors(containerColor=HomeSurface),shape=HomeShape
                ) {
                    Column(Modifier.fillMaxSize()) {
                        suggested.drop(1).forEachIndexed { index,task ->
                            if(index>0) HorizontalDivider(Modifier.padding(horizontal=15.dp),color=Color(0xFFEFF1F7))
                            HomeTaskRow(task,false,Modifier.fillMaxWidth().weight(1f),tight,onStart={onOpen(task.id)})
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun HomeMeetingsSection(
    modifier:Modifier,upcoming:List<Pair<Meeting,Task>>,compact:Boolean,tight:Boolean,
    onSchedule:()->Unit,onMeetings:(String)->Unit
) {
    Column(modifier,verticalArrangement=Arrangement.spacedBy(if(tight) 4.dp else 7.dp)) {
        HomeSectionTitle("جلسه بعدی","تایم‌شیت",onSchedule,tight)
        if(upcoming.isEmpty()) {
            Card(
                modifier=Modifier.fillMaxWidth().weight(1f),
                colors=CardDefaults.cardColors(containerColor=HomeSurface),shape=HomeShape
            ) {
                Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center) {
                    Text("جلسه آینده‌ای ثبت نشده است.",color=HomeMuted,fontSize=12.sp)
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().weight(1f),horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                upcoming.forEach { (meeting,task) ->
                    Card(
                        onClick={onMeetings(meeting.id)},modifier=Modifier.weight(1f).fillMaxHeight(),
                        shape=RoundedCornerShape(if(tight) 15.dp else 18.dp),
                        colors=CardDefaults.cardColors(containerColor=HomeSurface),
                        elevation=CardDefaults.cardElevation(defaultElevation=1.dp)
                    ) {
                        Column(
                            Modifier.fillMaxSize().padding(horizontal=5.dp,vertical=if(tight) 6.dp else 10.dp),
                            horizontalAlignment=Alignment.CenterHorizontally,
                            verticalArrangement=Arrangement.SpaceEvenly
                        ) {
                            Text(homeWeekday(requireNotNull(task.dueDay)),fontSize=if(tight) 10.sp else 12.sp,
                                color=HomeInk,fontWeight=FontWeight.SemiBold,maxLines=1)
                            Text(task.dueMinute?.let { String.format(Locale.ROOT,"%02d:%02d",it/60,it%60) }?:"—",
                                fontSize=if(tight) 12.sp else 14.sp,color=HomeBlue,fontWeight=FontWeight.Bold,maxLines=1)
                            HomeMeetingTitle(task.title,tight)
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun HomeMeetingTitle(title:String,tight:Boolean) {
    var textSize by remember(title,tight) { mutableStateOf(if(tight) 10.sp else 12.sp) }
    Text(title,modifier=Modifier.fillMaxWidth(),fontSize=textSize,maxLines=1,softWrap=false,
        overflow=TextOverflow.Ellipsis,color=HomeMuted,
        onTextLayout={layout->if(layout.didOverflowWidth && textSize.value>9f) textSize=(textSize.value-.5f).sp})
}

private fun homeWeekday(day:Long):String=when(LocalDate.ofEpochDay(day).dayOfWeek.value){1->"دوشنبه";2->"سه‌شنبه";3->"چهارشنبه";4->"پنجشنبه";5->"جمعه";6->"شنبه";else->"یکشنبه"}

// The level system is unbounded: badges remain individual for every level, with the number
// and geometry determined by the level, and without changing levelFor() or earned XP.
private fun homeLevelName(level:Int):String= when(level){
    1->"Beginner";2->"Explorer";3->"Learner";4->"Builder";5->"Achiever";6->"Rising Star";
    7->"Challenger";8->"Expert";9->"Champion";10->"Elite";11->"Legend";12->"Master";
    else->"Ascendant $level"
}

@Composable private fun LevelBadge(level:Int,boxSize:androidx.compose.ui.unit.Dp) {
    val tones=listOf(Color(0xFF355CDE),Color(0xFF007B91),Color(0xFF6951C5),Color(0xFFB67A20),Color(0xFF1F8A71),Color(0xFFC25E6E))
    val hue=tones[(level-1).coerceAtLeast(0)%tones.size]
    Box(Modifier.size(boxSize).background(HomePale,RoundedCornerShape(12.dp)),contentAlignment=Alignment.Center) {
        Canvas(Modifier.size(boxSize*.78f)) {
            val center=Offset(size.width/2,size.height/2)
            val corners=5+(level%7)
            val outline=Path()
            val radius=min(size.width,size.height)*.47f
            for(i in 0 until corners) {
                val angle=2*PI*i/corners-PI/2
                val x=center.x+(radius*cos(angle)).toFloat()
                val y=center.y+(radius*sin(angle)).toFloat()
                if(i==0)outline.moveTo(x,y) else outline.lineTo(x,y)
            }
            outline.close()
            drawPath(outline,hue)
            drawPath(outline,Color.White.copy(alpha=.75f),style=Stroke(width=2.3.dp.toPx()))
        }
        Text("$level",fontWeight=FontWeight.ExtraBold,fontSize=if(boxSize<36.dp) 11.sp else 13.sp,color=Color.White)
    }
}

@Composable private fun HomeSectionTitle(title:String,action:String,onClick:()->Unit,tight:Boolean) {
    Row(Modifier.fillMaxWidth().height(if(tight) 25.dp else 29.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween) {
        Text(title,fontWeight=FontWeight.ExtraBold,fontSize=if(tight) 14.sp else 16.sp,color=HomeInk)
        Row(Modifier.clickable(onClick=onClick).padding(horizontal=3.dp,vertical=4.dp),verticalAlignment=Alignment.CenterVertically) {
            Text(action,fontSize=if(tight) 10.sp else 11.sp,fontWeight=FontWeight.SemiBold,color=HomeBlue)
            Spacer(Modifier.width(3.dp))
            Icon(Icons.Outlined.ArrowBack,null,tint=HomeBlue,modifier=Modifier.size(13.dp))
        }
    }
}

@Composable private fun HomeMetric(icon:ImageVector,value:String,tight:Boolean) {
    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(2.dp)) {
        Icon(icon,null,tint=HomeBlue,modifier=Modifier.size(if(tight) 14.dp else 16.dp))
        Text(value,fontSize=if(tight) 10.sp else 12.sp,fontWeight=FontWeight.Bold,color=HomeInk,maxLines=1)
    }
}

@Composable private fun HomeTaskRow(task:Task,featured:Boolean,modifier:Modifier,tight:Boolean,onStart:()->Unit) {
    val ink=if(featured)Color.White else HomeInk
    val rewardCoins=rewardFor(task.priority)
    val content: @Composable () -> Unit = {
        Row(
            Modifier.fillMaxSize().padding(horizontal=if(tight) 10.dp else 13.dp,vertical=if(tight) 4.dp else 7.dp),
            verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(if(tight) 6.dp else 9.dp)
        ) {
            Box(Modifier.size(if(tight) 33.dp else 40.dp).background(if(featured)Color(0xFF5274ED) else HomePale,RoundedCornerShape(12.dp)),contentAlignment=Alignment.Center) {
                Icon(Icons.Outlined.ListAlt,null,tint=if(featured)Color.White else HomeBlue,modifier=Modifier.size(if(tight) 19.dp else 23.dp))
            }
            Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(if(tight) 2.dp else 5.dp)) {
                Text(task.title,color=ink,fontWeight=FontWeight.SemiBold,fontSize=if(tight) 11.sp else 13.sp,
                    maxLines=if(tight) 1 else 2,overflow=TextOverflow.Ellipsis,lineHeight=if(tight) 14.sp else 17.sp)
                Row(horizontalArrangement=Arrangement.spacedBy(if(tight) 5.dp else 8.dp),verticalAlignment=Alignment.CenterVertically) {
                    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(2.dp)) {
                        Icon(Icons.Outlined.Bolt,null,Modifier.size(if(tight) 12.dp else 14.dp),tint=if(featured)Color.White else HomeBlue)
                        Text("$TASK_COMPLETION_XP XP",fontSize=if(tight) 9.sp else 11.sp,color=if(featured)Color.White.copy(alpha=.9f) else HomeMuted,maxLines=1)
                    }
                    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(2.dp)) {
                        Icon(Icons.Outlined.Paid,null,Modifier.size(if(tight) 12.dp else 14.dp),tint=if(featured)Color.White else HomeBlue)
                        Text("$rewardCoins",fontSize=if(tight) 9.sp else 11.sp,color=if(featured)Color.White.copy(alpha=.9f) else HomeMuted,maxLines=1)
                    }
                }
            }
            Button(
                onClick=onStart,modifier=Modifier.width(if(tight) 58.dp else 72.dp).height(if(tight) 34.dp else 41.dp),
                shape=RoundedCornerShape(12.dp),contentPadding=PaddingValues(0.dp),
                colors=ButtonDefaults.buttonColors(containerColor=if(featured)Color.White else HomePale,contentColor=HomeBlue),
                elevation=ButtonDefaults.buttonElevation(defaultElevation=0.dp)
            ) {
                Text("شروع",fontSize=if(tight) 11.sp else 12.sp,fontWeight=FontWeight.Bold)
            }
        }
    }
    if(featured) Surface(shape=HomeShape,color=HomeBlue,modifier=modifier) { content() }
    else Box(modifier) { content() }
}
