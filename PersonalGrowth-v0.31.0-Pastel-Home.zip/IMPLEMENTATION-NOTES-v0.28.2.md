# IMPLEMENTATION NOTES — v0.28.2

Compiler-only hotfix for meeting title sizing in `RedesignedHome.kt`.

Within `BoxWithConstraints`, resolve `maxWidth` to `val meetingTitleMaxWidth` before the nested `Row`. Nested Compose layout DSLs may have a different scope/implicit receiver: using `maxWidth` directly inside `Modifier.widthIn` in a `Row` child triggered the Kotlin compiler error at line 780.

No workflow change; do not update `.github/workflows/build-apk.yml` in GitHub.
