# v0.29.0 — Premium Home: Animated Energy Crystal

- Replaced `HomeTaskGlyph` (quest book) by a fully offline Compose Canvas crystal, with faceted cyan/sapphire faces, sweeping gold halo, glass highlights and three glints. Each task uses the same new mark; `rememberInfiniteTransition` modulates only emitted light intensity, period 2400 ms with Reverse repeat. No image files, downloads, or per-frame layout changes.
- Gold medal numeral is drawn into the same `Canvas` as the medallion via `nativeCanvas.drawText`; baseline follows the measured ascent/descent and font size scales for multi-digit levels. The decorative disc and numeral now share identical center coordinates.
- Removed `HomeMeetingCategoryMark` and the associated adjacent mark from all meeting title rows. `HomeMeetingTitle` now takes the full card width with 2 dp internal margin; the icon on the weekday row is unaffected. Meeting block uses centered, explicit inter-item spacing.
- Header whitespace reduced only by padding and informational row size. Four metric tiles retain their v0.28.2 heights and original data binding. Blue card decorative diagonal and task shadows softened.
- State, XP, coins, levels, focus actions, meetings, task cards, shortcuts, database, Gradle wrapper, original workflow, signing material and application identifier remain unchanged. Only UI file + version metadata change among pre-existing project sources.

## Packaging contract

The ZIP is structured with `gradlew` and `settings.gradle.kts` at the archive root. The repository's existing `build-apk.yml` stays unchanged and extracts this ZIP as-is. With push-triggered builds, upload only this ZIP in that commit on `main` to avoid inadvertently building an old ZIP. A manual `workflow_dispatch` may select an older ZIP when several remain in the repository due to the user's original workflow fallback selection.
