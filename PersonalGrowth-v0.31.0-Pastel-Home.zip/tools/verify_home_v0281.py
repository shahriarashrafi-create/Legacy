#!/usr/bin/env python3
"""Static checks for 0.28.1, with original unmodified GitHub workflow."""
from pathlib import Path
import hashlib
import json
import re
import zipfile
import xml.etree.ElementTree as ET
import yaml

root = Path(__file__).resolve().parents[1]
source = root / 'app/src/main/java/com/shahriar/growth'
home = (source / 'RedesignedHome.kt').read_text()
main = (source / 'MainActivity.kt').read_text()
appdata = (source / 'data/AppData.kt').read_text()
gradle = (root / 'app/build.gradle.kts').read_text()
workflow = (root / '.github/workflows/build-apk.yml').read_text()
assert 'versionCode = 29' in gradle and 'versionName = "0.28.1"' in gradle
assert 'applicationId = "com.shahriar.growth"' in gradle
assert 'version = 7' in appdata
assert 'freshDatabase && shouldInsertStarterMeetings' in appdata
assert 'freshDatabase && shouldInsertStarterTasks' in appdata
assert 'HomePremiumLevelCard(profile?.name, tasks, wallet, today)' in main
assert 'SideEffect {' in main and 'APPEARANCE_LIGHT_STATUS_BARS' in main
assert 'LocalProfileAvatar.load(context)' in home
assert 'Text("$progress/100 XP"' in home
assert 'if (progress > 0)' in home
assert home.count('HomeGameMetric(Modifier.weight(1f).fillMaxHeight()') == 4
for metric in ('"xp"', '"coin"', '"done"', '"combo"'):
    assert metric in home
assert 'valueSize = (valueSize - .5f).coerceAtLeast(6.5f)' in home
assert 'overflow = TextOverflow.Clip' in home
assert 'Native RTL: quest emblem RIGHT, title/rewards middle, Start LEFT.' in home
assert re.search(r'CompositionLocalProvider\(LocalLayoutDirection provides LayoutDirection.Rtl\)\s*\{\s*Row\(Modifier.fillMaxSize\(\).padding', home)
taskrow = home.split('private fun HomeTaskRow(', 1)[1].split('private fun HomeAutoTaskTitle(', 1)[0]
assert taskrow.index('HomeTaskGlyph(featured,') < taskrow.index('HomeAutoTaskTitle(task.title') < taskrow.index('Button(onClick = onStart')
assert 'val iconSize = if (compact) 39.dp else if (featured) 68.dp else 58.dp' in home
assert 'A premium Quest Tome emblem' in home and 'sparkle(.83f' in home
assert 'val crest = Path()' in home and 'Brush.radialGradient' in home
assert 'HomeTaskReward("xp", "$TASK_COMPLETION_XP XP", compact, featured)' in home
assert 'HomeTaskReward("coin", "$payout", compact, featured)' in home
assert 'rewardFor(task.priority)' in home
assert 'suggested.forEachIndexed' in home and 'weight(if (index == 0) 80f else 73f)' in home
assert 'HomeSectionTitle("قدم بعدی", "مشاهده همه", Icons.Outlined.TrackChanges' in home
assert 'HomeSectionTitle("جلسه بعدی", "تایم‌شیت", Icons.Outlined.CalendarMonth' in home
assert re.search(r'Row\(Modifier.fillMaxWidth\(\),\s*verticalAlignment = Alignment.CenterVertically,\s*horizontalArrangement = Arrangement.Center\)\s*\{\s*HomeMeetingGlyph', home)
assert 'homeWeekday(requireNotNull(task.dueDay))' in home
assert 'HomeMeetingTitle(task.title, veryShort,' in home
assert 'textAlign = TextAlign.Center' in home
assert 'upcoming.getOrNull(index)' in home and 'repeat(3) { index ->' in home
assert 'verticalScroll(' not in home and 'LazyColumn(' not in home
assert 'navigationBarsPadding()' in main
assert 'shortcuts.filter{it in selectableTabs}' in main
assert 'ZIP_FILE=$(find . -type f -iname' in workflow
assert 'runs-on: ubuntu-latest' in workflow
assert 'gradle/actions/setup-gradle@v4' not in workflow
parsed = yaml.safe_load(workflow)
assert 'jobs' in parsed and 'build' in parsed['jobs']
ET.parse(root / 'app/src/main/res/drawable/ic_launcher.xml')
with zipfile.ZipFile('/mnt/data/PersonalGrowth-v0.27.0-Polished-Premium-Home.zip') as z:
    assert z.read('.github/workflows/build-apk.yml') == workflow.encode(), 'Original workflow differs from v0.27'
with zipfile.ZipFile('/mnt/data/PersonalGrowth-v0.28.0-Cinematic-RTL-Home.zip') as z:
    originals = {name: hashlib.sha256(z.read(name)).hexdigest()
                 for name in z.namelist() if not name.endswith('/')}
    changed = {name for name,digest in originals.items()
               if hashlib.sha256((root/name).read_bytes()).hexdigest() != digest}
    assert changed == {'.github/workflows/build-apk.yml', 'app/build.gradle.kts', 'README.md', 'CHANGELOG.md'},changed
    print('Expected differences from v0.28:', ', '.join(sorted(changed)))
assert not list(root.rglob('*.jpg')) and not list(root.rglob('*.png'))
for screen in range(300,801,5):
    short = screen < 425
    very_short = screen < 335
    pad = 4 if very_short else 6 if short else 9
    between = 5 if very_short else 7 if short else 10
    usable = max(0, screen - 2*pad - between)
    for meetings in (0,1,2,3):
        session = min(usable * (.23 if meetings==0 else .34),93 if meetings==0 else 157)
        steps = usable - session
        assert steps > session
        assert abs(steps+session+2*pad+between-screen)<.001
print('PASS: RTL task layout, quest art, untruncated XP value, aligned meetings, themed icons')
print('PASS: intact data/reward/Room/signing; original untouched GitHub workflow')
print('LIMITATION: tests are static; Android APK build / runner availability cannot be established here.')
