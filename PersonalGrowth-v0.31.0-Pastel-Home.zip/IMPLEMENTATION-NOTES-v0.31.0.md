# Implementation notes — v0.31.0

## Intent

Preserve the working Home and existing data model while reducing visual saturation. Four metric chips use very pale, hue-specific vertical gradients and high-contrast text; the large inline glyph remains anchored at the left. The number is centered in remaining space. Narrow/long-value layouts switch to vertically stacked label and amount **beside** the icon without reducing the icon to a tiny size.

## Exact changes

- `app/src/main/java/com/shahriar/growth/RedesignedHome.kt`: four pastel game metrics and adaptive value alignment; clean five-point-star gold coin used in both Home and task rewards; royal-blue CTA against pale-blue featured task card; unified XP/coin reward pill treatments; slightly smaller task-list tile.
- `app/build.gradle.kts`: versionCode 33, versionName 0.31.0. No signing/target/min SDK modifications.
- `README.md`, `CHANGELOG.md`, and release report: descriptions only.

## Explicit non-changes

- `.github/workflows/build-apk.yml` stays byte-identical to v0.30.0 (and to user's original workflow). No CI configuration changes are required.
- Room schema and migration, persistence, task/reward/XP/coins/combo calculations, meeting order and calendar icon/day/time/title layout, Scaffold safe-area dimensions, and bottom navigation are untouched.
- No downloaded graphics, images, fonts or perpetual animations added.

## Verification boundary

Host static integrity tests and schema6-to-7 migration tests pass. The Kotlin/Android Gradle build was **not run successfully** here because Gradle 8.7 cannot be downloaded (`UnknownHostException: services.gradle.org`). This package is source ZIP, not an APK. Build with the user's existing Actions workflow, and inspect it on target devices. See `BUILD-REPORT-v0.31.0.md`.
