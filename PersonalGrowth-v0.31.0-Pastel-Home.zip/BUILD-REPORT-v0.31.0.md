# Build and verification report — v0.31.0

## Completed checks

- Extracted original v0.30.0 source ZIP into a clean worktree, applied UI-only changes and increased version to 0.31.0 (`versionCode=33`).
- Confirmed original GitHub workflow, Gradle wrapper script and JAR, signing keystore, Room schema JSON, and migration/reward source are byte-identical to v0.30.0.
- Validated Kotlin source lexical delimiter balance and checked that `BoxWithConstraints.maxWidth` is captured in `chipWidth` before entering nested Row/Column receivers (prevents earlier Kotlin implicit-receiver scoping failure).
- Verified design structure: four matching pastel metrics, large icons on the left, centered value text, narrow/long-value fallback, reusable 5-point coin, high-contrast featured task card/CTA, existing three-task ratios, no task-crystal animation, and unchanged meeting layout.
- Measured representative text/background WCAG contrast ratios: XP 6.72:1, COIN 5.04:1, DONE 5.48:1, COMBO 5.43:1, featured title 8.77:1, gold reward text 5.30:1.
- Ran `python tools/check_upgrade.py`: **PASS**, schema 6 → 7, preserving seeded data across 22 old tables and matching the full 32-table schema and indexes.
- Validated generated ZIP CRC/integrity, `gradlew`, `settings.gradle.kts` and `gradle/wrapper/gradle-wrapper.jar` per current `.github/workflows/build-apk.yml` algorithm; checked changed source-file set and no unexpected binary/assets; checked archive workflow matches original byte-for-byte.

## Not verified in this environment

- Android Kotlin compilation / `assembleDebug`: **NOT VERIFIED**. `./gradlew --offline --no-daemon :app:compileDebugKotlin` cannot initialize because Gradle 8.7 is absent locally and `services.gradle.org` is not resolvable. This is an environment limitation, **not** evidence of a successful compile or of a Kotlin failure.
- Device/emulator visual inspection and automated Compose UI tests: **NOT VERIFIED**. Test after GitHub compiles the APK, especially small screen widths, font scale, dynamic amounts and dark-mode inheritance.

## GitHub instructions

The workflow in the repository must not be modified. Upload the new ZIP to `main`. The user's unchanged push-triggered workflow extracts that added ZIP; for manually dispatched builds, its fallback `sort | head -n 1` may select an older ZIP if multiple ZIPs exist in the repository. Avoid manual dispatch when older ZIPs remain; commit the intended ZIP to trigger a push build.
