plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.kapt")
}
android {
    namespace = "com.shahriar.growth"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.shahriar.growth"
        minSdk = 26
        targetSdk = 35
        versionCode = 33
        versionName = "0.31.0"
        javaCompileOptions { annotationProcessorOptions { arguments["room.schemaLocation"] = "$projectDir/schemas" } }
    }
    signingConfigs {
        create("personal") {
            storeFile = rootProject.file("signing/personal-growth.jks")
            storePassword = "personal-growth-build"
            keyAlias = "personal-growth"
            keyPassword = "personal-growth-build"
        }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("personal") }
        release { signingConfig = signingConfigs.getByName("personal"); isMinifyEnabled = false }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    kapt("androidx.room:room-compiler:2.6.1")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
}

 dependencies { testImplementation("junit:junit:4.13.2") }
