# Build and QA report — v0.30.0

- Version: `0.30.0`, `versionCode=32`.
- Source: updated from v0.29.0; no new binary artwork or network requirements.
- Kotlin UI source: revised Level padding, indicator layout, coin glyph, task glyph, featured card overlay and reward styling.
- Repo's existing `.github/workflows/build-apk.yml`: preserved **without byte changes**.
- Checks: ZIP CRC/integrity; original workflow extract algorithm (`find gradlew`, settings, wrapper JAR); file diff from v0.29.0; structural checks for removal of infinite tile animation and previous crystal; constraints limited to BoxWithConstraints; data schema stability.
- Android compile: **NOT VERIFIED**. `./gradlew --offline --no-daemon :app:compileDebugKotlin` fails before Gradle initialization because Gradle 8.7 is not cached and services.gradle.org cannot be reached. No Kotlin compilation was completed locally.
- Device/render checks: **NOT VERIFIED** on emulator/hardware. After uploading ZIP to branch `main`, use the current GitHub Action for the real Kotlin compile; inspect APK screen for long labels and small devices.
