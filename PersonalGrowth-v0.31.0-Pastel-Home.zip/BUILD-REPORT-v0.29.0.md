# Build / QA report — v0.29.0

## Source integrity verified

- ZIP predecessor: `PersonalGrowth-v0.28.2-Kotlin-Compile-Fix.zip`.
- Compared all existing project files against the predecessor archive. Among previous application/configuration files, **only** `app/src/main/java/com/shahriar/growth/RedesignedHome.kt` and `app/build.gradle.kts` changed. `README.md` and `CHANGELOG.md` are updated documentation. New v0.29.0 report and notes were added.
- `build-apk.yml` SHA-256: `e74637e8dc243af5c3111e45a82d3b020bd4cb6757ce8a03d1bf90ef9795b8f2`, identical to v0.28.2 and the original v0.27.0 workflow. No workflow repository change requested.
- Existing `gradlew`, `gradle-wrapper.jar`, `settings.gradle.kts`, signing keystore, Room schema JSON, package identifier, task/meeting repositories and wallet logic remain.

## Static QA

- New Crystal Canvas drawing + 2400-ms pulsing emissive light; no downloaded bitmap.
- Numeral placement uses the medallion Canvas center and font metrics.
- No category icon next to meeting titles. Weekday + calendar glyph remain on the same row.
- Task CTA stays on the left; crystal stays on the right. All three cards remain independently rendered.
- Header internal spacing reduced without shrinking colored counters.
- Parentheses/braces source-balance check passed. Current Kotlin `BoxWithConstraints.maxWidth` scope regression from v0.28.1 is not reintroduced.

## What is *not* certified

A real Android compilation, instrumented device run, and pixel-level screenshot verification were **not** possible in this runtime: Gradle distribution / Android SDK and resolved Compose/Android dependencies are unavailable. The source was not claimed to compile. Run the repo's unchanged `Build and Publish APK` workflow against this ZIP to verify compilation; if it fails, share the first Kotlin compiler error line(s).

GitHub `Queued` state is server-side Runner scheduling and cannot be eliminated by a ZIP. A red failure after `:app:compileDebugKotlin` indicates source errors, as in v0.28.1.
