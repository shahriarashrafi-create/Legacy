# v0.30.0 — Minimal Final Home

Based on `PersonalGrowth-v0.29.0-Energy-Crystal-Home.zip`. All core rewards, tasks, meetings, database schemas, avatar storage, shortcut persistence and signing configuration remain unchanged.

## UI changes

- Header: decrease **top padding only** inside and outside the Level surface, retaining the heights of the four colored indicators, their vertical gaps and bottom padding. Keep the correctly centered Level numeral, XP bar and visible `x/100 XP` text.
- Indicators: anchor each Canvas glyph to the **left** of the indicator; give value labels flex width and bounded auto-shrink at narrow device widths, retaining existing indicator height and their XP/COIN/DONE/COMBO order.
- Coins: redraw a thick embossed outer rim and a higher-contrast, dark-outlined three-point crown with an extra base line; reuse the glyph in Home and task rewards.
- Tasks: replace animated Energy Crystal with a small, *static* task-list tile drawn entirely by Compose Canvas, with three task rows and no book, notebook, crystal, shield or checkmark. Featured tile is 42dp, regular tile is 36dp (and compact tile 27dp), roughly 35–40% smaller than the prior 68/58dp glyphs.
- Retain each independent task card, right tile / center task title and rewards / left Start button, 80:73:73 weights and existing title auto-shrink + ellipsis. Larger space for task title comes from smaller tile.
- Featured task: replace prominent diagonal accents with a very subtle radial glow on a cleaner blue gradient.
- Task XP/coin reward pills: match their heights (32dp normal/25dp compact), capsule radius, horizontal padding and soften gold background for clearer coin.
- Soften Home Level/task/meeting shadow elevation modestly. No vertical changes to meeting cards or type hierarchy; weekday and calendar stay inline, time large blue, title below without its own icon.
- Keep non-scrolling layout, floating bottom navigation, user data, offline-only graphics and original GitHub Actions workflow.

## Technical checks and limitations

- `gradlew`, `gradle/wrapper/gradle-wrapper.jar`, settings and app files are retained for the repository's original GitHub Action workflow.
- Local build attempt could not initialize Gradle 8.7 because the container cannot reach `services.gradle.org` (`java.net.UnknownHostException`). Thus Android/Kotlin compile and on-device layout remain **unverified** here. The workflow and Gradle configuration were **not** changed.
