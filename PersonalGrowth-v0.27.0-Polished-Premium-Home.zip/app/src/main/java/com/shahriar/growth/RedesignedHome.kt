package com.shahriar.growth

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shahriar.growth.data.*
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private val HomeBlue = Color(0xFF355CDE)
private val HomeInk = Color(0xFF17223B)
private val HomeMuted = Color(0xFF78849A)
private val HomePale = Color(0xFFEEF2FF)
private val HomeShape = RoundedCornerShape(21.dp)
private val CoinGold = Color(0xFFF1BE47)
private val DoneGreen = Color(0xFF229E65)
private val ComboOrange = Color(0xFFF07732)

/** All graphics are drawn locally. No image assets or network image requests. */
@Composable
fun HomeRouteLogo(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val track = Path().apply {
            moveTo(.16f*w,.78f*h)
            cubicTo(.36f*w,.58f*h,.49f*w,.40f*h,.60f*w,.18f*h)
            lineTo(.59f*w,.59f*h)
            cubicTo(.65f*w,.66f*h,.75f*w,.72f*h,.85f*w,.80f*h)
            cubicTo(.68f*w,.78f*h,.56f*w,.75f*h,.45f*w,.76f*h)
            cubicTo(.34f*w,.78f*h,.25f*w,.81f*h,.16f*w,.78f*h)
            close()
        }
        drawPath(track, Color.White)
        val flag = Path().apply {
            moveTo(.62f*w,.19f*h)
            lineTo(.82f*w,.19f*h)
            lineTo(.75f*w,.28f*h)
            lineTo(.82f*w,.37f*h)
            lineTo(.62f*w,.37f*h)
            close()
        }
        drawPath(flag, Color.White)
    }
}

@Composable
fun RedesignedHome(
    modifier: Modifier,
    tasks: List<Task>, choice: ActionChoice?, today: Long, active: FocusSession?,
    edges: List<Prerequisite>, meetings: List<Meeting>,
    onFocus: (String) -> Unit, onSchedule: () -> Unit, onMeetings: (String) -> Unit,
    onNewMeeting: () -> Unit, onNew: () -> Unit, onOpen: (String) -> Unit, onList: (Int) -> Unit
) {
    // Meetings have a linked Task. Keep them out of regular task suggestions.
    val meetingTaskIds = meetings.map { it.taskId }.toSet()
    val regularTasks = tasks.filterNot { it.id in meetingTaskIds }
    val first = regularTasks.firstOrNull { it.id == active?.taskId } ?: nextAction(regularTasks, choice, today, edges)
    val candidates = regularTasks.filter { !it.archived && !it.done && it.id != first?.id && it.excludedDay != today }
        .filter { candidate -> edges.none { edge -> edge.taskId == candidate.id && tasks.any { it.id == edge.dependsOnId && !it.done } } }
        .sortedWith(compareBy<Task> { if (it.dueDay == null) 2 else if (it.dueDay < today) 0 else if (it.dueDay == today) 1 else 3 }
            .thenByDescending { it.priority }.thenBy { it.dueDay ?: Long.MAX_VALUE }.thenBy { it.dueMinute ?: 1440 }.thenBy { it.createdAt })
    val suggested = (listOfNotNull(first) + candidates).distinctBy { it.id }.take(3)

    val nowMinute = LocalTime.now().toSecondOfDay() / 60
    val upcoming = meetings.mapNotNull { meeting ->
        tasks.firstOrNull { it.id == meeting.taskId }?.let { task ->
            if (!task.archived && !task.done && task.dueDay != null &&
                (task.dueDay > today || (task.dueDay == today && (task.dueMinute ?: 1440) >= nowMinute))) {
                meeting to task
            } else null
        }
    }.sortedWith(compareBy<Pair<Meeting, Task>> { it.second.dueDay }.thenBy { it.second.dueMinute ?: 1440 }).take(3)

    // The white premium Level card occupies the real Scaffold topBar slot.
    // The body is independently measured only AFTER Scaffold reserves top/bottom bars.
    BoxWithConstraints(modifier.fillMaxSize().background(
        Brush.verticalGradient(listOf(Color(0xFFFCFDFF), Color(0xFFF7F9FD), Color(0xFFF0F4FD))))) {
        val short = maxHeight < 425.dp
        val veryShort = maxHeight < 335.dp
        val pad = if (veryShort) 4.dp else if (short) 6.dp else 9.dp
        val between = if (veryShort) 5.dp else if (short) 7.dp else 10.dp
        val usable = (maxHeight - pad * 2 - between).coerceAtLeast(0.dp)
        // Meetings size to content first; all remaining space is assigned to the
        // higher-priority three task cards. There are no invisible spacer slots.
        val sessionsHeight = if (upcoming.isEmpty())
            (usable * .23f).coerceAtMost(93.dp)
        else (usable * .34f).coerceAtMost(157.dp)
        val stepsHeight = (usable - sessionsHeight).coerceAtLeast(0.dp)
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = pad),
            verticalArrangement = Arrangement.spacedBy(between)) {
            HomeTasksSection(Modifier.fillMaxWidth().height(stepsHeight), suggested, veryShort,
                onAll = { onList(6) }, onNew = onNew, onOpen = onOpen)
            HomeMeetingsSection(Modifier.fillMaxWidth().height(sessionsHeight), upcoming, veryShort,
                onSchedule = onSchedule, onMeetings = onMeetings, onAdd = onNewMeeting)
        }
    }


}

/** A SINGLE distinct, premium Level card; Compose drawing only, no downloaded images.
 * RTL: medal right, local avatar left. User name right / Level label left
 * ABOVE the XP line between the two portraits, then four colored game chips.
 */
@Composable
fun HomePremiumLevelCard(name: String?, tasks: List<Task>, wallet: List<WalletEntry>, today: Long) {
    val earnedXp = wallet.sumOf { it.xp }.coerceAtLeast(0L)
    val level = levelFor(earnedXp)
    val progress = (earnedXp % 100L).toInt()
    val animatedProgress by animateFloatAsState(
        targetValue = progress / 100f, animationSpec = tween(durationMillis = 540), label = "XP progress")
    val coins = wallet.sumOf { it.coins }
    val doneToday = tasks.count { task -> !task.archived && task.done &&
        task.completedAt?.let { localDay(it, ZoneId.systemDefault()) == today } == true }
    val combo = streakDays(tasks.filter { it.done }.mapNotNull { task ->
        task.completedAt?.let { localDay(it, ZoneId.systemDefault()) }
    }.toSet(), today)
    val context = LocalContext.current
    val localAvatar = remember(context) { LocalProfileAvatar.load(context) }
    val compact = LocalConfiguration.current.screenHeightDp < 695
    val tiny = LocalConfiguration.current.screenHeightDp < 600
    val portraitSize = if (tiny) 41.dp else if (compact) 49.dp else 55.dp
    val medalSize = if (tiny) 45.dp else if (compact) 54.dp else 61.dp
    val infoHeight = if (tiny) 45.dp else if (compact) 52.dp else 59.dp
    val metricHeight = if (tiny) 45.dp else if (compact) 53.dp else 61.dp
    val pad = if (tiny) 7.dp else if (compact) 9.dp else 11.dp
    Column(Modifier.fillMaxWidth().statusBarsPadding().padding(
        horizontal = 13.dp, vertical = if (tiny) 3.dp else 4.dp)) {
        Surface(Modifier.fillMaxWidth().shadow(6.dp, RoundedCornerShape(23.dp)),
            shape = RoundedCornerShape(23.dp), color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE9D4A3))) {
            Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(
                listOf(Color.White, Color(0xFFFEFCF7), Color.White)))
                .padding(start = pad, end = pad, top = pad, bottom = if (tiny) 4.dp else 5.dp),
                verticalArrangement = Arrangement.spacedBy(if (tiny) 4.dp else 5.dp)) {
                Row(Modifier.fillMaxWidth().height(infoHeight),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(if (tiny) 5.dp else 9.dp)) {
                    HomeMedal(level, medalSize)
                    Column(Modifier.weight(1f).fillMaxHeight(),
                        verticalArrangement = Arrangement.Center) {
                        Row(Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Text(name?.takeIf { it.isNotBlank() } ?: "نام کاربر",
                                modifier = Modifier.weight(.9f), color = HomeInk,
                                fontWeight = FontWeight.ExtraBold, fontSize = if (tiny) 10.sp else 12.sp,
                                textAlign = TextAlign.Right, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                            Text("Level $level: ${homeLevelName(level)}",
                                modifier = Modifier.weight(1.45f), color = Color(0xFF273C78),
                                fontWeight = FontWeight.ExtraBold, fontSize = if (tiny) 9.sp else 11.sp,
                                textAlign = TextAlign.Left, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                        }
                        Spacer(Modifier.height(if (tiny) 6.dp else 9.dp))
                        // LTR fill direction even though everything around it is RTL.
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Box(Modifier.fillMaxWidth().height(if (tiny) 8.dp else 11.dp)
                                .clip(CircleShape).background(Color(0xFFDDE6FA))) {
                                // The empty state is a truly empty track: no rounded zero dot.
                                if (progress > 0) {
                                    Box(Modifier.fillMaxWidth(animatedProgress.coerceIn(0f, 1f))
                                        .fillMaxHeight().clip(CircleShape)
                                        .background(Brush.horizontalGradient(listOf(
                                            Color(0xFF2048C2), Color(0xFF4776F0), Color(0xFF91B8FF)))))
                                    Box(Modifier.fillMaxWidth(animatedProgress.coerceIn(0f, 1f))
                                        .height(2.dp).padding(horizontal = 2.dp)
                                        .background(Color.White.copy(alpha = .38f)))
                                }
                            }
                        }
                    }
                    Box(Modifier.size(portraitSize).clip(CircleShape)
                        .background(Color(0xFFE8EDF7)), contentAlignment = Alignment.Center) {
                        if (localAvatar != null) {
                            Image(bitmap = localAvatar, contentDescription = "عکس پروفایل کاربر",
                                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        } else {
                            Icon(Icons.Outlined.PersonOutline, "آواتار پیش‌فرض", tint = Color(0xFF8796AE),
                                modifier = Modifier.size(portraitSize * .66f))
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().height(metricHeight),
                    horizontalArrangement = Arrangement.spacedBy(if (tiny) 3.dp else 6.dp)) {
                    HomeGameMetric(Modifier.weight(1f).fillMaxHeight(), HomeBlue, Color.White, "xp", "$progress/100")
                    HomeGameMetric(Modifier.weight(1f).fillMaxHeight(), CoinGold, Color(0xFF483006), "coin", "$coins")
                    HomeGameMetric(Modifier.weight(1f).fillMaxHeight(), DoneGreen, Color.White, "done", "$doneToday")
                    HomeGameMetric(Modifier.weight(1f).fillMaxHeight(), ComboOrange, Color.White, "combo", "$combo")
                }
            }
        }
    }
}


@Composable
private fun HomeGameMetric(modifier: Modifier, background: Color, foreground: Color,
                           kind: String, value: String) {
    val highlight = when (kind) {
        "xp" -> Color(0xFF70ADFF)
        "coin" -> Color(0xFFFFE280)
        "done" -> Color(0xFF61E9A2)
        else -> Color(0xFFFFBA62)
    }
    BoxWithConstraints(modifier.clip(RoundedCornerShape(12.dp))
        .background(Brush.verticalGradient(listOf(highlight, background, background)))) {
        val slim = maxWidth < 70.dp
        val glyph = if (slim) 22.dp else 27.dp
        Box(Modifier.fillMaxWidth().height(1.dp).align(Alignment.TopCenter)
            .background(Color.White.copy(alpha = .53f)))
        Box(Modifier.fillMaxWidth().height(9.dp).align(Alignment.TopCenter)
            .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = .17f),Color.Transparent))))
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(Modifier.fillMaxSize().padding(horizontal = if (slim) 1.dp else 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center) {
                HomeGameGlyph(kind, Modifier.size(glyph))
                Spacer(Modifier.width(2.dp))
                val label = when(kind) {"done"->"DONE";"combo"->"COMBO";"coin"->"COIN";else->"XP"}
                Text(label, fontSize = if(slim) 7.sp else 8.sp,
                    fontWeight = FontWeight.Black, color = foreground,
                    maxLines = 1)
                Spacer(Modifier.width(2.dp))
                Box(Modifier.width(.8.dp).height(15.dp).background(foreground.copy(alpha=.44f)))
                Spacer(Modifier.width(2.dp))
                Text(value, fontSize = if(slim || value.length > 5) 8.sp else 11.sp,
                    fontWeight = FontWeight.Black, color = foreground,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

/** Small premium-style, offline Canvas glyphs; no image files or external requests. */
@Composable
private fun HomeGameGlyph(kind: String, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val c = Offset(.5f*w, .51f*h)
        val r = min(w,h)*.46f
        when (kind) {
            "xp" -> {
                drawCircle(brush=Brush.radialGradient(listOf(Color(0xFFAFEAFF).copy(alpha=.62f),Color.Transparent),center=c,radius=r),radius=r,center=c)
                val bolt = Path().apply {
                    moveTo(w*.59f,h*.04f);lineTo(w*.20f,h*.54f);lineTo(w*.47f,h*.54f)
                    lineTo(w*.36f,h*.96f);lineTo(w*.85f,h*.39f);lineTo(w*.58f,h*.39f);close()
                }
                drawPath(bolt, brush=Brush.linearGradient(listOf(Color(0xFFEEFFFF), Color(0xFF84EAFF),Color(0xFF39A3F9))))
                drawPath(bolt, Color(0xFF2D72CA),style=Stroke(width=1.dp.toPx()))
                drawLine(Color.White.copy(alpha=.75f),Offset(w*.56f,h*.14f),Offset(w*.33f,h*.49f),strokeWidth=.8.dp.toPx())
            }
            "coin" -> {
                drawCircle(Color(0xFFA16A12),r,Offset(c.x,c.y+1.dp.toPx()))
                drawCircle(brush=Brush.radialGradient(listOf(Color(0xFFFFFAAE),Color(0xFFFFC738),Color(0xFFD18B16)),center=Offset(w*.28f,h*.20f),radius=r*1.8f),radius=r*.93f,center=c)
                drawCircle(Color(0xFFFFE9A2),r*.74f,c,style=Stroke(width=1.7.dp.toPx()))
                val crown=Path().apply {
                    moveTo(w*.25f,h*.43f);lineTo(w*.37f,h*.57f);lineTo(w*.49f,h*.34f)
                    lineTo(w*.62f,h*.56f);lineTo(w*.76f,h*.43f);lineTo(w*.70f,h*.69f)
                    lineTo(w*.31f,h*.69f);close()
                }
                drawPath(crown,Color(0xFF9D6310))
                drawPath(crown,Brush.verticalGradient(listOf(Color(0xFFFFF1A2),Color(0xFFE1A11D))))
                drawCircle(Color.White.copy(alpha=.85f),r*.10f,Offset(w*.28f,h*.23f))
            }
            "done" -> {
                val petals=10
                repeat(petals){i->
                    val angle=2*PI*i/petals
                    drawCircle(Color(0xFF086F45),radius=r*.28f,
                        center=Offset(c.x+(r*.67f*cos(angle)).toFloat(),c.y+(r*.67f*sin(angle)).toFloat()))
                }
                drawCircle(brush=Brush.radialGradient(listOf(Color(0xFFBEFFD9),Color(0xFF25C87E),Color(0xFF067445)),center=Offset(w*.36f,h*.29f),radius=r*1.7f),radius=r*.78f,center=c)
                drawCircle(Color(0xFFAAFFE1).copy(alpha=.7f),radius=r*.61f,center=c,style=Stroke(width=1.3.dp.toPx()))
                val check=Path().apply { moveTo(w*.27f,h*.51f);lineTo(w*.43f,h*.66f);lineTo(w*.74f,h*.35f) }
                drawPath(check,Color(0xFF075737),style=Stroke(width=3.2.dp.toPx()))
                drawPath(check,Color(0xFFEAFFEE),style=Stroke(width=1.7.dp.toPx()))
            }
            "combo" -> {
                val fire=Path().apply {
                    moveTo(w*.49f,h*.02f)
                    cubicTo(w*.62f,h*.25f,w*.70f,h*.32f,w*.72f,h*.47f)
                    cubicTo(w*.90f,h*.31f,w*.94f,h*.55f,w*.86f,h*.76f)
                    cubicTo(w*.73f,h*1.06f,w*.25f,h*1.04f,w*.14f,h*.75f)
                    cubicTo(w*.06f,h*.53f,w*.23f,h*.38f,w*.32f,h*.31f)
                    cubicTo(w*.34f,h*.49f,w*.46f,h*.33f,w*.49f,h*.02f)
                    close()
                }
                drawPath(fire,Color(0xFF9C301D))
                drawPath(fire,Brush.verticalGradient(listOf(Color(0xFFFFF36A),Color(0xFFFF941F),Color(0xFFF25513))))
                val centre=Path().apply {
                    moveTo(w*.52f,h*.43f);cubicTo(w*.61f,h*.60f,w*.74f,h*.72f,w*.58f,h*.87f)
                    cubicTo(w*.42f,h*.99f,w*.29f,h*.77f,w*.39f,h*.62f);close()
                }
                drawPath(centre,Brush.verticalGradient(listOf(Color.White,Color(0xFFFFE870),Color(0xFFFFB02F))))
            }
        }
    }
}

/** Ribboned gold medal. Number and geometry make every level individually recognisable. */
@Composable
private fun HomeMedal(level: Int, boxSize: Dp) {
    Box(Modifier.size(boxSize), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(3.dp)) {
            val w = size.width
            val h = size.height
            val ribbonLeft = Path().apply {
                moveTo(.28f*w, .02f*h); lineTo(.45f*w, .02f*h)
                lineTo(.59f*w, .45f*h); lineTo(.44f*w, .54f*h); close()
            }
            val ribbonRight = Path().apply {
                moveTo(.57f*w, .02f*h); lineTo(.74f*w, .02f*h)
                lineTo(.59f*w, .54f*h); lineTo(.43f*w, .46f*h); close()
            }
            drawPath(ribbonLeft, Color(0xFF3465D9))
            drawPath(ribbonRight, Color(0xFFE45F4F))
            // Small scallops vary between adjacent levels; no grouped badge tiers.
            val petals = 9 + (level.coerceAtLeast(1) % 5)
            val centre = Offset(.51f*w, .65f*h)
            val radius = min(w, h) * .265f
            for (i in 0 until petals) {
                val angle = 2 * PI * i / petals
                val dot = Offset(centre.x + (radius * cos(angle)).toFloat(), centre.y + (radius * sin(angle)).toFloat())
                drawCircle(Color(0xFFE8A629), radius = w * .074f, center = dot)
            }
            drawCircle(brush = Brush.radialGradient(listOf(Color(0xFFFFF6BC),
                Color(0xFFF6C34F), Color(0xFFAB691A)), center = centre,
                radius = radius * 1.15f), radius = radius * .96f, center = centre)
            drawCircle(Color(0xFFE6A321), radius = radius * .83f, center = centre, style = Stroke(width = 1.6.dp.toPx()))
            drawCircle(brush = Brush.radialGradient(listOf(Color(0xFFFFFBE0),
                Color(0xFFF7D778)), center = centre, radius = radius),
                radius = radius * .72f, center = centre)
            drawCircle(Color.White.copy(alpha = .75f), radius = radius * .13f,
                center = Offset(centre.x - radius * .34f, centre.y - radius * .32f))
        }
        Text("$level", modifier = Modifier.offset(y = boxSize * .12f),
            color = Color(0xFF966113), fontSize = if (boxSize < 32.dp) 10.sp else 12.sp,
            fontWeight = FontWeight.ExtraBold)
    }
}

/** A single shared, game-styled task emblem, built in Canvas for offline use. */
@Composable
private fun HomeTaskGlyph(featured: Boolean, modifier: Modifier = Modifier) {
    // An open book above two stacked, gilt-edged navy books. Drawn at any dpi with Compose.
    Canvas(modifier) {
        val w=size.width
        val h=size.height
        fun book(y:Float, cover:Color) {
            val shadow=Path().apply {
                moveTo(w*.10f,h*(y+.13f));lineTo(w*.78f,h*(y+.13f))
                lineTo(w*.88f,h*(y+.23f));lineTo(w*.21f,h*(y+.23f));close()
            }
            drawPath(shadow,Color(0xFF102B63).copy(alpha=.25f))
            val edge=Path().apply {
                moveTo(w*.16f,h*y);lineTo(w*.78f,h*(y-.05f))
                lineTo(w*.83f,h*(y+.13f));lineTo(w*.22f,h*(y+.18f));close()
            }
            drawPath(edge,Brush.verticalGradient(listOf(Color(0xFFFCF4DF),Color(0xFFF6E8C6),Color(0xFFD6B681))))
            val face=Path().apply {
                moveTo(w*.10f,h*(y-.02f));lineTo(w*.75f,h*(y-.08f))
                lineTo(w*.81f,h*(y+.03f));lineTo(w*.18f,h*(y+.11f));close()
            }
            drawPath(face,Brush.verticalGradient(listOf(Color(0xFF78B6FB),cover,Color(0xFF123D8B))))
            drawPath(face,Color(0xFF0A3274),style=Stroke(width=.8.dp.toPx()))
            drawLine(Color(0xFFFFDA74),Offset(w*.21f,h*(y+.10f)),Offset(w*.77f,h*(y+.035f)),strokeWidth=.9.dp.toPx())
        }
        book(.66f,Color(0xFF195AB1))
        book(.48f,Color(0xFF2679D9))
        // Pages of the open book, outlined with subtly curved top edges.
        val leftPages=Path().apply {
            moveTo(w*.49f,h*.18f)
            cubicTo(w*.38f,h*.07f,w*.21f,h*.09f,w*.08f,h*.16f)
            lineTo(w*.13f,h*.49f)
            cubicTo(w*.29f,h*.42f,w*.39f,h*.43f,w*.50f,h*.54f)
            close()
        }
        val rightPages=Path().apply {
            moveTo(w*.49f,h*.18f)
            cubicTo(w*.65f,h*.07f,w*.81f,h*.10f,w*.94f,h*.16f)
            lineTo(w*.87f,h*.49f)
            cubicTo(w*.71f,h*.44f,w*.62f,h*.45f,w*.50f,h*.54f)
            close()
        }
        drawPath(leftPages,Color(0xFFB78042),style=Stroke(width=2.dp.toPx()))
        drawPath(rightPages,Color(0xFFB78042),style=Stroke(width=2.dp.toPx()))
        drawPath(leftPages,Brush.verticalGradient(listOf(Color.White,Color(0xFFFFF1CE),Color(0xFFE3CEAB))))
        drawPath(rightPages,Brush.verticalGradient(listOf(Color(0xFFFFFFFF),Color(0xFFFFF3DC),Color(0xFFE7D1AC))))
        for (i in 0..3) {
            val y=.21f+i*.064f
            drawLine(Color(0xFFAE9877).copy(alpha=.6f),Offset(w*.18f,h*y),Offset(w*.43f,h*(y+.06f)),strokeWidth=.8.dp.toPx())
            drawLine(Color(0xFFAE9877).copy(alpha=.6f),Offset(w*.57f,h*(y+.06f)),Offset(w*.82f,h*y),strokeWidth=.8.dp.toPx())
        }
        val bookmark=Path().apply {
            moveTo(w*.59f,h*.52f);lineTo(w*.68f,h*.50f)
            lineTo(w*.71f,h*.79f);lineTo(w*.66f,h*.73f)
            lineTo(w*.61f,h*.83f);close()
        }
        drawPath(bookmark,Brush.verticalGradient(listOf(Color(0xFFFFE993),Color(0xFFF4AC2B),Color(0xFFDB7E1B))))
        drawLine(Color.White.copy(alpha=.85f),Offset(w*.49f,h*.18f),Offset(w*.50f,h*.54f),strokeWidth=.9.dp.toPx())
    }
}

/** A small etched calendar, aligned with the weekday label. */
@Composable
private fun HomeMeetingGlyph(modifier: Modifier = Modifier) {
    // Compact calendar, designed to sit on the SAME line as the weekday.
    Canvas(modifier) {
        val w=size.width;val h=size.height
        val topLeft=Offset(w*.13f,h*.18f)
        drawRoundRect(brush=Brush.verticalGradient(listOf(Color(0xFFFFFFFF),Color(0xFFEAF1FF))),
            topLeft=topLeft,size=androidx.compose.ui.geometry.Size(w*.74f,h*.70f),
            cornerRadius=androidx.compose.ui.geometry.CornerRadius(w*.11f))
        drawRoundRect(Color(0xFF6C82AD),topLeft=topLeft,size=androidx.compose.ui.geometry.Size(w*.74f,h*.70f),
            cornerRadius=androidx.compose.ui.geometry.CornerRadius(w*.11f),style=Stroke(width=1.3.dp.toPx()))
        drawRoundRect(Color(0xFF5277D9),topLeft=topLeft,
            size=androidx.compose.ui.geometry.Size(w*.74f,h*.20f),
            cornerRadius=androidx.compose.ui.geometry.CornerRadius(w*.09f))
        for(x in listOf(.31f,.69f)) {
            drawLine(Color(0xFF405C92),Offset(w*x,h*.07f),Offset(w*x,h*.31f),strokeWidth=2.3.dp.toPx(),cap=androidx.compose.ui.graphics.StrokeCap.Round)
        }
        for (x in listOf(.30f,.52f,.73f)) for(y in listOf(.53f,.72f)) {
            drawCircle(Color(0xFF7594D6),radius=w*.046f,center=Offset(w*x,h*y))
        }
    }
}

@Composable
private fun HomeTasksSection(
    modifier: Modifier, suggested: List<Task>, veryShort: Boolean,
    onAll: () -> Unit, onNew: () -> Unit, onOpen: (String) -> Unit
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(if (veryShort) 4.dp else 6.dp)) {
        HomeSectionTitle("قدم بعدی", "مشاهده همه", onAll, veryShort)
        if (suggested.isEmpty()) {
            Card(Modifier.fillMaxWidth().weight(1f), shape = HomeShape,
                colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.fillMaxSize().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("فعلاً کاری برای شروع وجود ندارد.", modifier = Modifier.weight(1f),
                        color = HomeMuted, fontSize = 12.sp)
                    TextButton(onClick = onNew) { Text("افزودن کار") }
                }
            }
        } else {
            // Three fully independent cards. Keep 80:73:73 when all three exist.
            suggested.forEachIndexed { index, task ->
                HomeTaskRow(task, featured = index == 0,
                    modifier = Modifier.fillMaxWidth().weight(if (index == 0) 80f else 73f),
                    veryShort = veryShort, onStart = { onOpen(task.id) })
            }
        }
    }
}

@Composable
private fun HomeTaskRow(task: Task, featured: Boolean, modifier: Modifier,
                        veryShort: Boolean, onStart: () -> Unit) {
    val ink = if (featured) Color.White else HomeInk
    val payout = rewardFor(task.priority)
    Surface(modifier = modifier.shadow(if (featured) 5.dp else 3.dp, RoundedCornerShape(19.dp)),
        shape = RoundedCornerShape(19.dp), color = if (featured) HomeBlue else Color.White,
        border = if (featured) null else BorderStroke(.7.dp, Color(0xFFE4EAF5))) {
        BoxWithConstraints(Modifier.fillMaxSize().then(if (featured) Modifier.background(
            Brush.horizontalGradient(listOf(Color(0xFF254ACA), HomeBlue, Color(0xFF4D77E9)))) else Modifier)) {
            val compact = maxHeight < 74.dp || veryShort
            val iconSize = if (compact) 39.dp else 57.dp
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(Modifier.fillMaxSize().padding(horizontal = if (compact) 8.dp else 12.dp,
                vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(if (compact) 5.dp else 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(iconSize).clip(RoundedCornerShape(12.dp))
                    .background(if (featured) Brush.verticalGradient(listOf(Color(0xFF5F95FF).copy(alpha=.52f),Color(0xFF133DBA).copy(alpha=.80f))) else Brush.verticalGradient(listOf(Color(0xFFF8FAFF),Color(0xFFE7EEFC)))),
                    contentAlignment = Alignment.Center) {
                    HomeTaskGlyph(featured, Modifier.fillMaxSize().padding(if (compact) 3.dp else 5.dp))
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(
                    if (compact) 3.dp else 5.dp)) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        HomeAutoTaskTitle(task.title, ink, if (compact) 12f else 14f)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(if (compact) 3.dp else 5.dp)) {
                        HomeTaskReward("xp", "$TASK_COMPLETION_XP XP", compact)
                        HomeTaskReward("coin", "$payout", compact)
                    }
                }
                Button(onClick = onStart, modifier = Modifier.width(if (compact) 49.dp else 62.dp)
                    .height(if (compact) 37.dp else 42.dp),
                    shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (featured) Color.White else HomeBlue,
                        contentColor = if (featured) HomeBlue else Color.White),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 3.dp,
                        pressedElevation = 0.dp)) {
                    Text("شروع", fontSize = if (compact) 10.sp else 12.sp,
                        fontWeight = FontWeight.ExtraBold)
                }
            }
            }
        }
    }
}


@Composable
private fun HomeAutoTaskTitle(value: String, color: Color, initialSize: Float) {
    var font by remember(value, initialSize) { mutableStateOf(initialSize) }
    Text(value, modifier = Modifier.fillMaxWidth(), color = color,
        fontWeight = FontWeight.SemiBold, fontSize = font.sp, maxLines = 1,
        softWrap = false, overflow = TextOverflow.Ellipsis,
        onTextLayout = { if (it.didOverflowWidth && font > 10f) font = (font - .5f).coerceAtLeast(10f) })
}

@Composable
private fun HomeTaskReward(kind: String, value: String, compact: Boolean) {
    val blue = kind == "xp"
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(Modifier.clip(RoundedCornerShape(8.dp))
            .background(if (blue) Brush.horizontalGradient(listOf(Color(0xFF365EDF), Color(0xFF688DF8)))
                else Brush.horizontalGradient(listOf(Color(0xFFFFE38C), Color(0xFFF1BB47))))
            .padding(horizontal = if (compact) 4.dp else 6.dp,
                vertical = if (compact) 2.dp else 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            HomeGameGlyph(if (blue) "xp" else "coin", Modifier.size(if (compact) 16.dp else 20.dp))
            Text(value, fontSize = if (compact) 8.sp else 10.sp,
                fontWeight = FontWeight.Bold, maxLines = 1,
                color = if (blue) Color.White else Color(0xFF553706))
        }
    }
}


/** Category marks beneath the time stay local; unrelated user meetings use a neutral calendar. */
@Composable
private fun HomeMeetingCategoryMark(title: String) {
    val group = title.contains("برنامه")
    val study = title.contains("مشاوره") || title.contains("تحصیل")
    val color = if (group) Color(0xFF2376D3) else if (study) Color(0xFF7A4CCD) else Color(0xFF159C6C)
    val icon = if (group) Icons.Outlined.Groups else if (study) Icons.Outlined.School else Icons.Outlined.Description
    Box(Modifier.size(20.dp).clip(CircleShape)
        .background(color.copy(alpha=.13f)), contentAlignment=Alignment.Center) {
        Icon(icon, contentDescription=null, tint=color, modifier=Modifier.size(14.dp))
    }
}

@Composable
private fun HomeMeetingsSection(
    modifier: Modifier, upcoming: List<Pair<Meeting, Task>>, veryShort: Boolean,
    onSchedule: () -> Unit, onMeetings: (String) -> Unit, onAdd: () -> Unit
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(if (veryShort) 4.dp else 6.dp)) {
        HomeSectionTitle("جلسه بعدی", "تایم‌شیت", onSchedule, veryShort)
        if (upcoming.isEmpty()) {
            Surface(onClick = onAdd, modifier = Modifier.fillMaxWidth().weight(1f),
                color = Color.White, shape = RoundedCornerShape(18.dp),
                border = BorderStroke(.8.dp, Color(0xFFE5EBF5)), shadowElevation = 2.dp) {
                Row(Modifier.fillMaxSize().padding(horizontal = 13.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("جلسه آینده‌ای ندارید", modifier = Modifier.weight(1f),
                        maxLines = 1, color = HomeMuted, fontSize = 12.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.AddCircleOutline, null, tint = HomeBlue,
                            modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("افزودن جلسه", color = HomeBlue, fontSize = 11.sp,
                            fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().weight(1f),
                horizontalArrangement = Arrangement.spacedBy(if (veryShort) 4.dp else 7.dp)) {
                // In RTL, index 0 is the rightmost/closest event.
                repeat(3) { index ->
                    val event = upcoming.getOrNull(index)
                    if (event == null) {
                        Surface(onClick = onAdd, modifier = Modifier.weight(1f).fillMaxHeight(),
                            shape = RoundedCornerShape(17.dp), color = Color.White,
                            border = BorderStroke(1.dp, Color(0xFFC9D7F7)), shadowElevation = 2.dp) {
                            Column(Modifier.fillMaxSize().padding(3.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center) {
                                Icon(Icons.Outlined.AddCircleOutline, "افزودن جلسه",
                                    tint = HomeBlue, modifier = Modifier.size(if (veryShort) 19.dp else 25.dp))
                                Spacer(Modifier.height(5.dp))
                                Text("افزودن جلسه", fontSize = if (veryShort) 9.sp else 10.sp,
                                    color = HomeBlue, fontWeight = FontWeight.SemiBold,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    } else {
                        val (meeting, task) = event
                        Card(onClick = { onMeetings(meeting.id) },
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                            shape = RoundedCornerShape(17.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                            border = BorderStroke(.7.dp, Color(0xFFE6EBF5))) {
                            Column(Modifier.fillMaxSize().padding(horizontal = 4.dp, vertical = 5.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.SpaceEvenly) {
                                Row(Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center) {
                                    HomeMeetingGlyph(Modifier.size(if (veryShort) 15.dp else 21.dp))
                                    Spacer(Modifier.width(if (veryShort) 2.dp else 4.dp))
                                    Text(homeWeekday(requireNotNull(task.dueDay)),
                                        modifier = Modifier.weight(1f, fill = false),
                                        textAlign = TextAlign.Center,
                                        fontSize = if (veryShort) 9.sp else 11.sp,
                                        color = HomeInk, fontWeight = FontWeight.SemiBold,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Text(task.dueMinute?.let { String.format(Locale.ROOT,
                                    "%02d:%02d", it / 60, it % 60) } ?: "—",
                                    fontSize = if (veryShort) 16.sp else 23.sp,
                                    color = HomeBlue, textAlign = TextAlign.Center,
                                    fontWeight = FontWeight.Black, maxLines = 1)
                                Row(Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically) {
                                    HomeMeetingCategoryMark(task.title)
                                    Spacer(Modifier.width(2.dp))
                                    Box(Modifier.weight(1f)) { HomeMeetingTitle(task.title, veryShort) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
private fun HomeMeetingTitle(title: String, veryShort: Boolean) {
    var font by remember(title, veryShort) { mutableStateOf(if (veryShort) 10f else 11.5f) }
    Text(title, modifier = Modifier.fillMaxWidth(), fontSize = font.sp,
        textAlign = TextAlign.Center, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis,
        color = HomeMuted, onTextLayout = {
            if (it.didOverflowWidth && font > 9f) font = (font - .5f).coerceAtLeast(9f)
        })
}

private fun homeWeekday(day: Long): String = when (LocalDate.ofEpochDay(day).dayOfWeek.value) {
    1 -> "دوشنبه"; 2 -> "سه‌شنبه"; 3 -> "چهارشنبه"; 4 -> "پنجشنبه"
    5 -> "جمعه"; 6 -> "شنبه"; else -> "یکشنبه"
}

private fun homeLevelName(level: Int): String = when (level) {
    1 -> "Beginner"; 2 -> "Explorer"; 3 -> "Learner"; 4 -> "Builder"; 5 -> "Achiever";
    6 -> "Rising Star"; 7 -> "Challenger"; 8 -> "Expert"; 9 -> "Champion";
    10 -> "Elite"; 11 -> "Legend"; 12 -> "Master"; else -> "Ascendant $level"
}

@Composable
private fun HomeSectionTitle(title: String, action: String, onClick: () -> Unit, veryShort: Boolean) {
    Row(Modifier.fillMaxWidth().height(if (veryShort) 21.dp else 24.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, fontWeight = FontWeight.ExtraBold, fontSize = if (veryShort) 13.sp else 15.sp,
            maxLines = 1, color = HomeInk)
        Row(Modifier.clickable(onClick = onClick).padding(horizontal = 2.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(action, fontSize = if (veryShort) 10.sp else 11.sp,
                fontWeight = FontWeight.SemiBold, color = HomeBlue)
            Spacer(Modifier.width(3.dp))
            Icon(Icons.Outlined.ArrowBack, null, tint = HomeBlue, modifier = Modifier.size(13.dp))
        }
    }
}
