package com.shahriar.growth

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.shahriar.growth.data.*

private val JourneyBlue = Color(0xFF355CDE)
private val JourneyText = Color(0xFF17223B)
private val JourneyWhite = Color(0xFFFFFFFF)
private val JourneyCurrent = Color(0xFFDCE8FF)
private val JourneyDone = Color(0xFFE4F5E9)
private val JourneyFailed = Color(0xFFFCE8E8)
private val JourneyLine = Color(0xFFCED9E9)

/** A single continuous journey. There is deliberately NO secondary task list or mission grid.
 * reverseLayout places the first unresolved step near the lower edge of the viewport;
 * older resolved steps are below it, while newer open steps continue upward.
 */
@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun TaskJourneyScreen(
    modifier: Modifier, tasks: List<Task>, today: Long, filter: Int,
    listState: LazyListState, onFilter: (Int) -> Unit,
    onNew: () -> Unit, onOpen: (String) -> Unit
) {
    var search by rememberSaveable { mutableStateOf("") }
    var priority by rememberSaveable { mutableIntStateOf(-1) }
    var filtersOpen by remember { mutableStateOf(false) }
    val labels = listOf("امروز", "عقب‌افتاده", "آینده", "بدون موعد", "انجام‌شده", "بایگانی", "همه بازها", "انجام امروز", "همه مسیر")
    val validCount = tasks.count { !it.archived }
    val completedCount = tasks.count { it.done && !it.archived }
    val progressPercent = if (validCount == 0) 0 else completedCount * 100 / validCount
    val visible = remember(tasks, filter, search, priority, today) {
        tasks.filter { task ->
            (if (filter == 8) !task.archived else taskMatches(task, filter, today)) &&
                (priority == -1 || task.priority == priority) &&
                normalizeText(task.title + " " + task.note).contains(normalizeText(search.trim()))
        }.let(::taskJourneyOrderIncludingArchive)
    }
    val active = remember(tasks) { taskJourneyOrder(tasks).firstOrNull { !it.done && !it.failed } }
    val focusIndex = visible.indexOfFirst { it.id == active?.id }
        .let { if (it < 0) visible.indexOfFirst { !it.done && !it.failed } else it }
    val ids = visible.map { it.id }
    LaunchedEffect(ids, focusIndex) {
        if (visible.isNotEmpty()) {
            val destination = if (focusIndex >= 0) focusIndex else visible.lastIndex
            // Placing this row at the bottom leaves the completed/failed history below it.
            listState.animateScrollToItem(destination)
        }
    }
    Box(modifier.fillMaxSize()) {
        if (visible.isEmpty()) {
            Column(Modifier.fillMaxSize().padding(24.dp),
                verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Outlined.Route, null, modifier = Modifier.size(62.dp), tint = JourneyBlue)
                Spacer(Modifier.height(14.dp))
                Text(if (tasks.isEmpty()) "اولین قدم مسیرت را بساز" else "کاری با این فیلتر پیدا نشد",
                    color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                Button(onClick = onNew) { Text("افزودن کار جدید") }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(), state = listState, reverseLayout = true,
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 32.dp, top = 82.dp)
            ) {
                itemsIndexed(visible, key = { _, task -> task.id }) { index, task ->
                    JourneyStep(modifier = Modifier.animateItem(), task = task, highlighted = task.id == active?.id,
                        hasLower = index > 0, hasUpper = index < visible.lastIndex,
                        onClick = { onOpen(task.id) })
                }
            }
        }
        // An unobtrusive overlay; search/filter do not create a second task listing.
        Surface(Modifier.fillMaxWidth().align(Alignment.TopCenter).padding(horizontal = 14.dp, vertical = 8.dp),
            color = MaterialTheme.colorScheme.surface, shadowElevation = 2.dp,
            shape = RoundedCornerShape(19.dp), border = BorderStroke(1.dp, Color(0xFFE7EAF2))) {
            Row(Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("کارهای من", modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.SemiBold)
                Text("${faNumber(progressPercent)}٪", style = MaterialTheme.typography.labelMedium,
                    color = JourneyBlue)
                IconButton(onClick = { filtersOpen = true }, modifier = Modifier.size(42.dp)) {
                    Icon(Icons.Outlined.Tune, "جست‌وجو و فیلتر", tint = JourneyBlue)
                }
                FilledIconButton(onClick = onNew, shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.size(42.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = JourneyBlue)) {
                    Icon(Icons.Outlined.Add, "کار جدید", tint = Color.White)
                }
            }
        }
    }
    if (filtersOpen) ModalBottomSheet(onDismissRequest = { filtersOpen = false }) {
        Column(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, bottom = 30.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("جست‌وجو و فیلتر", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(search, { search = it }, label = { Text("عنوان یا توضیحات کار") },
                singleLine = true, modifier = Modifier.fillMaxWidth(), leadingIcon = { Icon(Icons.Outlined.Search, null) })
            Text("نمایش", style = MaterialTheme.typography.titleSmall)
            // Wrap the full legacy set rather than removing user-accessible filters.
            androidx.compose.foundation.layout.FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(1.dp)) {
                listOf(8, 6, 0, 4, 1, 2, 3, 5, 7).forEach { id ->
                    FilterChip(selected = filter == id, onClick = { onFilter(id) }, label = { Text(labels[id]) })
                }
            }
            Text("اهمیت", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(-1 to "همه", 0 to "کم", 1 to "متوسط", 2 to "زیاد").forEach { (id, text) ->
                    FilterChip(selected = priority == id, onClick = { priority = id }, label = { Text(text) })
                }
            }
            Button(onClick = { filtersOpen = false }, modifier = Modifier.fillMaxWidth()) { Text("نمایش قدم‌ها") }
        }
    }
}

private fun taskJourneyOrderIncludingArchive(tasks: List<Task>): List<Task> =
    tasks.sortedWith(compareBy<Task> { if (it.done || it.failed) 0 else 1 }
        .thenBy { if (it.stepNumber > 0) it.stepNumber else Long.MAX_VALUE }
        .thenBy { it.createdAt }.thenBy { it.id })

@Composable
private fun JourneyStep(modifier: Modifier = Modifier, task: Task, highlighted: Boolean, hasLower: Boolean, hasUpper: Boolean, onClick: () -> Unit) {
    val left = task.stepNumber % 2L != 0L
    val background by animateColorAsState(
        targetValue = when { task.done -> JourneyDone; task.failed -> JourneyFailed;
            highlighted -> JourneyCurrent; else -> JourneyWhite }, animationSpec = tween(350), label = "task-state")
    val border = when { task.done -> Color(0xFFBDE1C9); task.failed -> Color(0xFFF2CCCC)
        highlighted -> Color(0xFF86A8F2); else -> Color(0xFFE1E7F0) }
    Box(modifier.fillMaxWidth().height(170.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.matchParentSize()) {
            val cardCenterX = size.width * (if(left) .275f else .725f)
            val mid = size.width * .5f
            val top = center.y - 47.dp.toPx()
            val bottom = center.y + 47.dp.toPx()
            // Exactly one visual connection between every pair of adjacent cards;
            // the two half curves meet at the shared item boundary.
            if (hasUpper) {
                val p = Path().apply {
                    moveTo(cardCenterX, top)
                    cubicTo(cardCenterX, top * .35f, mid, top * .55f, mid, 0f)
                }
                drawPath(p, JourneyLine, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
            }
            if (hasLower) {
                val h = size.height
                val p = Path().apply {
                    moveTo(mid, h)
                    cubicTo(mid, (h + bottom) * .5f, cardCenterX, (h + bottom) * .7f, cardCenterX, bottom)
                }
                drawPath(p, JourneyLine, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
            }
        }
        Surface(onClick = onClick, modifier = Modifier.fillMaxWidth(.55f).heightIn(min = 94.dp)
            .align(if (left) Alignment.CenterEnd else Alignment.CenterStart),
            color = background, shape = RoundedCornerShape(22.dp),
            border = BorderStroke(if(highlighted) 1.7.dp else 1.dp, border), shadowElevation = if(highlighted) 5.dp else 2.dp) {
            Column(Modifier.padding(horizontal = 12.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("قدم ${faNumber(task.stepNumber)}", fontWeight = FontWeight.Bold,
                    color = if (highlighted) JourneyBlue else if(task.failed) Color(0xFF93424B)
                    else if(task.done) Color(0xFF286A49) else JourneyText,
                    style = MaterialTheme.typography.labelMedium)
                Text(task.title, color = JourneyText, textAlign = TextAlign.Center,
                    maxLines = 3, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
