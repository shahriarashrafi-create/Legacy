package com.shahriar.growth

import android.os.Bundle
import android.content.Intent
import android.os.Build
import android.Manifest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.ui.platform.LocalContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shahriar.growth.data.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.time.LocalDate

class MainActivity : ComponentActivity() {
    private val focusRequest = mutableStateOf(false)
    private val taskRequest = mutableStateOf<String?>(null)
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); taskRequest.value=intent.getStringExtra("task_id");intent.removeExtra("task_id"); if(intent.getBooleanExtra("focus",false))focusRequest.value=true }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        focusRequest.value = intent.getBooleanExtra("focus",false)
        taskRequest.value=intent.getStringExtra("task_id");intent.removeExtra("task_id")
        val isFreshDatabase = !getDatabasePath("growth.db").exists()
        val database = AppDatabase.get(this)
        val settings = Settings(applicationContext)
        setContent { GrowthApp(database, settings, focusRequest.value,
            { focusRequest.value=false }, taskRequest.value, { taskRequest.value=null }, isFreshDatabase) }
    }
}
private val Navy = Color(0xFF193553)
private val Blue = Color(0xFF355CDE)
private val Cyan = Color(0xFF247D86)
private val Gold = Color(0xFF9A6B0C)
private data class Destination(val label: String, val icon: ImageVector)
private val destinations = listOf(
    Destination("خانه", Icons.Outlined.Home), Destination("شبکه", Icons.Outlined.AccountTree),
    Destination("هدف‌ها", Icons.Outlined.Flag), Destination("کارها", Icons.Outlined.CheckCircle),
    Destination("بخش‌ها", Icons.Outlined.GridView)
)
@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun GrowthApp(db: AppDatabase, settings: Settings, requestFocus:Boolean, onFocusHandled:()->Unit,requestTask:String?,onTaskHandled:()->Unit, freshDatabase: Boolean) {
    var networkRequest by rememberSaveable{mutableIntStateOf(0)}
    var networkType by rememberSaveable{mutableStateOf("")}
    var networkId by rememberSaveable{mutableStateOf("")}
    var goalScope by rememberSaveable{mutableStateOf("all")}
    var extraPage by rememberSaveable{mutableStateOf("")}
    var reportView by rememberSaveable{mutableStateOf(false)}
    val wallet by db.finalDao().wallet().collectAsState(emptyList())
    val reminders by db.finalDao().reminders().collectAsState(emptyList())
    val profile by db.profileDao().observe().collectAsState(initial = null)
    val endSound by settings.endSound.collectAsState(initial=true)
    val theme by settings.theme.collectAsState(initial = "system")
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val people by db.networkDao().observe().collectAsState(initial=emptyList())
    val owners by db.networkDao().owners().collectAsState(initial=emptyList())
    val networkEngine=remember(db){NetworkEngine(db)}
    val crmEngine=remember(db){CrmEngine(db)}
    val crmContacts by db.crmDao().contacts().collectAsState(initial=emptyList())
    val crmLinks by db.crmDao().links().collectAsState(initial=emptyList())
    val engine = remember(db) { ExecutionEngine(db,context.applicationContext) }
    val musicEnabled by FocusService.musicEnabled.collectAsState()
    val active by db.executionDao().observeActive().collectAsState(initial=null)
    val subtasks by db.executionDao().subtasks().collectAsState(initial=emptyList())
    val edges by db.executionDao().prerequisites().collectAsState(initial=emptyList())
    var focusOpen by rememberSaveable { mutableStateOf(false) }
    val meetings by db.meetingDao().observe().collectAsState(initial=emptyList())
    var meetingsOpen by rememberSaveable{mutableStateOf(false)}
    var meetingsType by rememberSaveable{mutableStateOf("all")}
    var meetingsRecord by rememberSaveable{mutableStateOf("")}
    var requestedMeeting by rememberSaveable{mutableStateOf<String?>(null)}
    var requestedMeetingNew by rememberSaveable{mutableStateOf(false)}
    var reportingOwner by rememberSaveable{mutableStateOf<String?>(null)}
    var reportingRequest by rememberSaveable{mutableIntStateOf(0)}
    fun openMeetings(type:String,id:String,meeting:String?=null,createNew:Boolean=false){
        meetingsType=type;meetingsRecord=id;requestedMeeting=meeting;requestedMeetingNew=createNew
        meetingsOpen=true
    }

    var clock by remember { mutableStateOf(readClock(context)) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(requestFocus) { if(requestFocus){focusOpen=true;onFocusHandled()} }
    LaunchedEffect(active?.id) { if(active!=null)runCatching{FocusService.ensure(context)} }
    LaunchedEffect(Unit) { while(true){clock=readClock(context);engine.tick();delay(1000)} }

    val tasks by db.taskDao().observe().collectAsState(initial = emptyList())
    LaunchedEffect(db) {
        val now = java.time.LocalDateTime.now()
        settings.ensureStarterTasks(db, now.toLocalDate().toEpochDay(), freshDatabase)
        settings.ensureStarterMeetings(db, now.toLocalDate(), now.hour * 60 + now.minute, freshDatabase)
    }
    LaunchedEffect(tasks,reminders) { delay(400);runCatching { PlanningAlarm.refresh(context,db) } }
    val choice by db.taskDao().choice().collectAsState(initial = null)
    var today by remember { mutableLongStateOf(LocalDate.now().toEpochDay()) }
    LaunchedEffect(Unit) { while (true) { today = LocalDate.now().toEpochDay(); delay(1000) } }
    val listState = rememberLazyListState()
    val pageState = rememberSaveableStateHolder()
    var taskFilter by rememberSaveable { mutableIntStateOf(8) }
    var editorId by rememberSaveable { mutableStateOf<String?>(null) }
    LaunchedEffect(requestTask,tasks) { if(requestTask!=null && tasks.any{it.id==requestTask}) { editorId=requestTask;onTaskHandled() } }
    var busy by remember { mutableStateOf(false) }
    var operationError by remember { mutableStateOf("") }
    val editingTask = tasks.firstOrNull { it.id == editorId }
    val historyFlow = remember(editorId) { db.taskDao().history(editorId ?: "") }
    val events by historyFlow.collectAsState(initial = emptyList())
    val snackbar = remember { SnackbarHostState() }
    fun mutate(close: Boolean = false, action: suspend () -> Unit) {
        if (busy) return
        busy = true; operationError = ""
        scope.launch {
            try { action(); if(close) editorId = null }
            catch (error: Exception) { if(error is kotlinx.coroutines.CancellationException)throw error; operationError = if(error is IllegalArgumentException)error.message ?: "عملیات انجام نشد" else "ثبت تغییر انجام نشد؛ دوباره تلاش کن."; snackbar.showSnackbar(operationError) }
            finally { busy = false }
        }
    }
    fun openTask(id: String) { operationError = ""; editorId = id }
    var rewardNotice by remember { mutableStateOf<Pair<String, Long>?>(null) }
    LaunchedEffect(rewardNotice) { if(rewardNotice != null) { delay(2300); rewardNotice = null } }
    fun startFocus(id:String) { mutate(true) {
        engine.start(id)
        if(Build.VERSION.SDK_INT>=33)permission.launch(Manifest.permission.POST_NOTIFICATIONS)
        FocusService.ensure(context);focusOpen=true
    } }

    var selected by rememberSaveable { mutableIntStateOf(0) }
    val shortcuts by settings.bottomShortcuts.collectAsState(initial = listOf(2, 6))
    var sectionsOpen by rememberSaveable { mutableStateOf(false) }
    var shortcutMenu by remember { mutableStateOf<Int?>(null) }
    val selectableTabs = listOf(1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 13)
    val shortcutLabels = mapOf(1 to "شبکه من",2 to "اهداف",3 to "کارها",5 to "تقویم",6 to "تمرکز",7 to "عملکرد",8 to "تایم‌شیت",9 to "پاداش‌ها",10 to "جلسات",11 to "مخاطبین",13 to "رویاها")
    val shortcutIcons = mapOf(1 to Icons.Outlined.AccountTree,2 to Icons.Outlined.Flag,3 to Icons.Outlined.CheckCircle,5 to Icons.Outlined.CalendarMonth,6 to Icons.Outlined.Timer,7 to Icons.Outlined.Insights,8 to Icons.Outlined.Schedule,9 to Icons.Outlined.EmojiEvents,10 to Icons.Outlined.EventNote,11 to Icons.Outlined.Contacts,13 to Icons.Outlined.FavoriteBorder)
    fun openShortcut(id:Int) {
        sectionsOpen=false;extraPage="";meetingsOpen=false;reportView=false
        when(id) {
            1,2,3 -> selected=id
            5,8 -> extraPage="planning"
            6 -> { selected=0; focusOpen=true }
            7 -> { pageState.removeState("reporting:$reportingRequest");reportingOwner=null;reportingRequest++;reportView=true;selected=2 }
            9 -> extraPage="rewards"
            10 -> openMeetings("all","")
            11 -> { selected=1;networkType="contacts";networkId="";networkRequest++ }
            12 -> selected=3 // Keep legacy shortcuts working as an alias for the single journey
            13 -> extraPage="dreams"
        }
    }
    var settingsOpen by rememberSaveable { mutableStateOf(false) }
    var info by rememberSaveable { mutableStateOf("") }
    val dark = theme == "dark" || (theme == "system" && isSystemInDarkTheme())
    val colors = if (dark) darkColorScheme(primary = Color(0xFFA8C7FF), secondary = Color(0xFF77D9D2), background = Color(0xFF101B2B), surface = Color(0xFF1B2C42), surfaceVariant = Color(0xFF273C56), primaryContainer = Color(0xFF25466E), onPrimaryContainer = Color(0xFFEAF2FF), secondaryContainer = Color(0xFF25466E), onSecondaryContainer = Color(0xFFEAF2FF), onSurface = Color(0xFFEAF2FF))
    else lightColorScheme(primary = Blue, secondary = Cyan, background = Color(0xFFF7F9FD), surface = Color.White, surfaceVariant = Color(0xFFEEF2FF), onSurface = Navy, onBackground = Navy, primaryContainer = Color(0xFFDFEBFF), onPrimaryContainer = Navy, secondaryContainer = Color(0xFFDFEBFF), onSecondaryContainer = Navy)
    val font = FontFamily(Font(R.font.vazirmatn))
    val base = Typography()
    val typography = Typography(
        bodyLarge = base.bodyLarge.copy(fontFamily = font, fontSize = 16.sp),
        bodyMedium = base.bodyMedium.copy(fontFamily = font), bodySmall = base.bodySmall.copy(fontFamily = font),
        titleLarge = base.titleLarge.copy(fontFamily = font), titleMedium = base.titleMedium.copy(fontFamily = font),
        headlineSmall = base.headlineSmall.copy(fontFamily = font), labelLarge = base.labelLarge.copy(fontFamily = font),
        labelMedium = base.labelMedium.copy(fontFamily = font), labelSmall = base.labelSmall.copy(fontFamily = font)
    )
    // Keep status bar text readable against the light premium Home background.
    // The app can still use dark surfaces on other screens; those follow the theme.
    SideEffect {
        (context as? android.app.Activity)?.window?.let { window ->
            val darkStatusIcons = true // All screens use the white premium Home header
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val mask = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                window.insetsController?.setSystemBarsAppearance(if (darkStatusIcons) mask else 0, mask)
            } else {
                @Suppress("DEPRECATION")
                val old = window.decorView.systemUiVisibility
                @Suppress("DEPRECATION")
                val flag = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = if (darkStatusIcons) old or flag else old and flag.inv()
            }
        }
    }
    MaterialTheme(colorScheme = colors, typography = typography) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            BackHandler(enabled = editorId != null || extraPage.isNotEmpty() || focusOpen  || meetingsOpen || settingsOpen || selected != 0) { when { editorId != null -> editorId=null; extraPage.isNotEmpty() -> extraPage=""; focusOpen -> focusOpen=false; meetingsOpen -> meetingsOpen=false; settingsOpen -> settingsOpen=false; else -> selected=0 } }
            val editorPanel: @Composable (Modifier, Boolean) -> Unit = { editorModifier, quick ->
                key(editorId) {
                    TaskEditor(editorModifier, editingTask, events, today, busy, operationError,
                        onDismiss = { editorId = null },
                        onSave = { task -> mutate(true) {
                            db.taskDao().save(task)
                            scope.launch { snackbar.showSnackbar("کار ذخیره شد") }
                        } },
                        onDone = { value -> editingTask?.let { task -> mutate(true) {
                            engine.complete(task.id, value)
                            if(value && !task.done) rewardNotice = task.title to rewardFor(task.priority)
                        } } },
                        onFail = { editingTask?.let { task -> mutate(true) { engine.finish(task.id, false) } } },
                        onArchive = { value -> editingTask?.let { task -> mutate(true) { db.taskDao().archive(task.id,value) } } },
                        onFocus = { editingTask?.let { startFocus(it.id) } },
                        quick = quick,
                    extra={editingTask?.let { task ->
                        TaskPlanningPanel(db,task,today)
                        TaskGoalsPanel(db,task){editorId=null;extraPage="";selected=2;reportView=false}
                        meetings.firstOrNull{it.taskId==task.id}?.let{meeting->
                            Text("جلسه: "+meetingStatusLabel(meetingStatus(meeting,task)),style=MaterialTheme.typography.bodySmall)
                            OutlinedButton(onClick={editorId=null;openMeetings("all","",meeting.id)}){Text("پرونده و نتیجه جلسه")}
                        }
                        TaskPersonPanel(task,people,owners,busy,onAssign={person->mutate{networkEngine.assign(task.id,person)}},sourceLabel=crmLinks.firstOrNull{it.taskId==task.id}?.let{link->val c=crmContacts.firstOrNull{it.id==link.contactId};"مسئول از پرونده: "+(people.firstOrNull{it.id==c?.ownerId}?.name?:"خودم")})
                        TaskContactPanel(task,crmContacts.map{displayedContact(it,people)},crmLinks,busy,onAssign={contact->mutate{crmEngine.assign(task.id,contact)}})
                        if(crmLinks.any{it.taskId==task.id}) Text("مسئول کار از پرونده مرتبط تعیین می‌شود؛ انتخاب فرد، ارتباط پرونده را جایگزین می‌کند.",style=MaterialTheme.typography.bodySmall)
                        SubtaskPanel(subtasks.filter{it.taskId==task.id},active?.taskId==task.id,
                            onCheck={sub,value->mutate{engine.checkSubtask(sub,value)}},
                            onAdd={title,required,success->mutate{engine.addSubtask(task.id,title,required);success()}},
                            onRemove={sub->mutate{engine.removeSubtask(sub)}})
                    }}
                    )
                }
            }
            Scaffold(
                snackbarHost = { SnackbarHost(snackbar) },
                topBar = { HomePremiumLevelCard(profile?.name, tasks, wallet, today) },
                bottomBar = {
                    // Floating bar lives INSIDE Scaffold.bottomBar. Its own inset is
                    // reserved, so meeting cards never enter the system navigation area.
                    Box(Modifier.fillMaxWidth().navigationBarsPadding()
                        .padding(horizontal = 13.dp, vertical = 6.dp)) {
                        Surface(modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(23.dp), color = Color.White,
                            shadowElevation = 7.dp,
                            border = BorderStroke(.8.dp, Color(0xFFE5EAF5))) {
                            Row(Modifier.fillMaxWidth().height(61.dp).padding(horizontal = 7.dp,
                                vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                                val tabs = listOf(0) + shortcuts.map { if(it==12) 3 else it }.filter{it in selectableTabs}
                                    .distinct().take(3) + listOf(4)
                                tabs.forEach { id ->
                                    val label = if(id==0) "خانه" else if(id==4) "بخش‌ها" else shortcutLabels[id] ?: "بخش"
                                    val icon = if(id==0) Icons.Outlined.Home else if(id==4)
                                        Icons.Outlined.GridView else shortcutIcons[id] ?: Icons.Outlined.GridView
                                    val isActive = if (id == 0)
                                        selected == 0 && extraPage.isEmpty() && !meetingsOpen
                                    else id == selected && extraPage.isEmpty() && !meetingsOpen
                                    val iconTint = if(isActive) Blue else Color(0xFF8290A5)
                                    val itemModifier=Modifier.weight(1f).fillMaxHeight()
                                        .padding(horizontal=2.dp)
                                    Surface(onClick={if(id==4) sectionsOpen=true else if(id==0){
                                            selected=0;extraPage="";meetingsOpen=false;reportView=false
                                        } else openShortcut(id)},
                                        modifier=itemModifier,shape=RoundedCornerShape(16.dp),
                                        color=if(isActive)Color(0xFFEEF2FF) else Color.White) {
                                        Column(Modifier.fillMaxSize(),
                                            horizontalAlignment=Alignment.CenterHorizontally,
                                            verticalArrangement=Arrangement.Center) {
                                            Box(Modifier.size(25.dp).then(if(id!=0 && id!=4) Modifier.pointerInput(id) {
                                                detectTapGestures(onLongPress={shortcutMenu=id})
                                            } else Modifier), contentAlignment=Alignment.Center) {
                                                Icon(icon,null,tint=iconTint,modifier=Modifier.size(22.dp))
                                            }
                                            Spacer(Modifier.height(2.dp))
                                            Text(label,color=iconTint,
                                                fontWeight=if(isActive)FontWeight.Bold else FontWeight.Normal,
                                                fontSize=10.sp,maxLines=1,
                                                overflow=TextOverflow.Ellipsis)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }, containerColor = MaterialTheme.colorScheme.background
            ) { padding ->
                if(editorId != null && editorId != "new" && editingTask != null) editorPanel(Modifier.padding(padding), false)
                else if(extraPage=="planning") PlanningPage(Modifier.padding(padding),db,today,{extraPage=""},{openTask(it)})
                else if(extraPage=="dreams") DreamsPage(Modifier.padding(padding),db,{extraPage=""},{extraPage="";selected=2;reportView=false})
                else if(extraPage=="rewards") RewardsPage(Modifier.padding(padding),db,today,{extraPage=""})
                else if(extraPage=="backup") BackupPage(Modifier.padding(padding),db,settings,{extraPage=""},{(context as? android.app.Activity)?.recreate()})
                else if(extraPage=="help") GuidePage(Modifier.padding(padding),{extraPage=""})
                else if(extraPage=="search") GlobalSearchPage(Modifier.padding(padding),db,today,{extraPage=""},{openTask(it)},{type,id->pageState.removeState("network:$networkRequest");networkRequest++;networkType=type;networkId=id;extraPage="";selected=1})
                else if (focusOpen) FocusScreen(Modifier.padding(padding),tasks.firstOrNull{it.id==active?.taskId},active,
                    subtasks.filter{it.taskId==active?.taskId},clock,busy,operationError,
                    onBack={note->mutate{engine.note(note);focusOpen=false}},onToggle={mutate{engine.toggle()}},onReset={note->mutate{engine.note(note);engine.reset()}},
                    onClose={note->mutate{engine.note(note);engine.closeReady();focusOpen=false}},
                    onFinish={success,note->active?.let{session->mutate{
                        engine.note(note)
                        val task = tasks.firstOrNull { it.id == session.taskId }
                        engine.finish(session.taskId,success)
                        if(success && task != null && !task.done) rewardNotice = task.title to rewardFor(task.priority)
                        focusOpen=false
                    }}},
                    onNote={text->scope.launch{runCatching{engine.note(text)}}},onCheck={sub,value->mutate{engine.checkSubtask(sub,value)}},
                    musicEnabled=musicEnabled,onMusic={FocusService.music(context,it)},endSound=endSound,onEndSound={value->scope.launch{settings.setEndSound(value)}})
                else if (meetingsOpen) MeetingsScreen(Modifier.padding(padding),db,today,meetingsType,meetingsRecord,requestedMeeting,requestedMeetingNew,onBack={meetingsOpen=false;requestedMeetingNew=false},onOpenTask={openTask(it)})
                else if (settingsOpen) SettingsPage(Modifier.padding(padding), profile?.name ?: "شهریار", theme,
                    onSave = { name -> scope.launch { db.profileDao().save(Profile(name = name)) } },
                    onTheme = { value -> scope.launch { settings.setTheme(value) } }, onBackup={extraPage="backup"}, onBack = { settingsOpen = false })
                else if (selected == 0) pageState.SaveableStateProvider("home") { RedesignedHome(Modifier.padding(padding),tasks,choice,today,active,edges,meetings,
                    onFocus={startFocus(it)},onSchedule={extraPage="planning"},onMeetings={openMeetings("all","",it)},
                    onNewMeeting={openMeetings("all","",createNew=true)},onNew={openTask("new")}, onOpen={openTask(it)},
                    onList={taskFilter=it;selected=3}) }
                else if (selected == 1) pageState.SaveableStateProvider("network:$networkRequest") { NetworkScreen(Modifier.padding(padding),db,profile?.name?:"شهریار",tasks,today,onOpenTask={openTask(it)},onMeetings={type,id->openMeetings(type,id)},onReport={id->pageState.removeState("reporting:$reportingRequest");reportingOwner=id;reportingRequest++;reportView=true;selected=2},onGoals={id->goalScope=id;reportView=false;selected=2},requestedType=networkType,requestedId=networkId) }
                else if(selected==2 && !reportView) GoalsPage(Modifier.padding(padding),db,today,{openTask(it)},{reportView=true},goalScope)
                else if (selected == 2) Column(Modifier.padding(padding)) { TextButton(onClick={reportView=false}){Text("بازگشت به هدف‌ها")};pageState.SaveableStateProvider("reporting:$reportingRequest") { ReportingScreen(Modifier,db,today,reportingOwner,onOpenTask={openTask(it)}) } }
                else if (selected == 3) pageState.SaveableStateProvider("tasks") { TaskJourneyScreen(Modifier.padding(padding),tasks,today,taskFilter,listState,
                    onFilter={taskFilter=it},onNew={openTask("new")},onOpen={openTask(it)}) }
                else key(selected) {
                    Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        when (selected) {
                            

                            4 -> {
                                Text("بخش‌های مسیر من", style = MaterialTheme.typography.headlineSmall)
                                Card(onClick={selected=3},colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) {
                                    Row(Modifier.fillMaxWidth().padding(18.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Outlined.Route,null);Spacer(Modifier.width(12.dp));Text("کارهای من",style=MaterialTheme.typography.titleMedium)}
                                }
                                Card(onClick={openMeetings("all","")},colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){
                                    Row(Modifier.fillMaxWidth().padding(18.dp)){Icon(Icons.Outlined.EventNote,null);Spacer(Modifier.width(12.dp));Text("جلسات و یادداشت جلسه")}
                                }
                                Card(onClick={pageState.removeState("reporting:$reportingRequest");reportingOwner=null;reportingRequest++;reportView=true;selected=2},colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){
                                    Row(Modifier.fillMaxWidth().padding(18.dp)){Icon(Icons.Outlined.Insights,null);Spacer(Modifier.width(12.dp));Text("ثبت عملکرد و گزارش شبکه")}
                                }
                                FinalSection("زمان‌بندی و تایم‌شیت",Icons.Outlined.Schedule){extraPage="planning"}
                                FinalSection("تابلو آرزوها",Icons.Outlined.FavoriteBorder){extraPage="dreams"}
                                FinalSection("پاداش‌ها و دستاوردها",Icons.Outlined.EmojiEvents){extraPage="rewards"}
                                FinalSection("پشتیبان‌گیری و بازیابی",Icons.Outlined.Backup){extraPage="backup"}
                                FinalSection("جست‌وجوی یکپارچه",Icons.Outlined.Search){extraPage="search"}
                                FinalSection("راهنمای شروع",Icons.Outlined.HelpOutline){extraPage="help"}
                                OutlinedButton(onClick = { settingsOpen = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Outlined.Settings, null); Spacer(Modifier.width(8.dp)); Text("تنظیمات") }
                            }
                        }
                    }
                }
            }
            if(editorId == "new") ModalBottomSheet(onDismissRequest = { if(!busy) editorId = null }) {
                editorPanel(Modifier, true)
            }
            rewardNotice?.let { notice ->
                TaskRewardCelebration(notice.first, notice.second) { rewardNotice = null }
            }
            shortcutMenu?.let { id -> AlertDialog(onDismissRequest={shortcutMenu=null},title={Text(shortcutLabels[id] ?: "میان‌بر")},text={Text("این میان‌بر از نوار پایین حذف شود؟ خود بخش و اطلاعاتش باقی می‌مانند.")},confirmButton={TextButton(onClick={scope.launch{settings.setBottomShortcuts(shortcuts.filterNot{it==id})};shortcutMenu=null}){Text("حذف از نوار پایین")}},dismissButton={TextButton(onClick={shortcutMenu=null}){Text("انصراف")}}) }
            if(sectionsOpen) ModalBottomSheet(onDismissRequest={sectionsOpen=false}) {
                var search by remember { mutableStateOf("") }
                var dropBounds by remember { mutableStateOf<Rect?>(null) }
                var dragId by remember { mutableIntStateOf(-1) }
                var dragPoint by remember { mutableStateOf(Offset.Zero) }
                Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal=18.dp).padding(bottom=28.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                    Text("بخش‌ها",style=MaterialTheme.typography.titleLarge)
                    OutlinedTextField(search,{search=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("جستجو در بخش‌ها")})
                    Text("بخش دلخواه را نگه‌دار و به نوار میان‌بر زیر بکش؛ یا روی + بزن.",style=MaterialTheme.typography.bodySmall)
                    Surface(modifier=Modifier.fillMaxWidth().onGloballyPositioned{dropBounds=it.boundsInWindow()},shape=RoundedCornerShape(18.dp),color=Color(0xFFEEF2FF)) {
                        Row(Modifier.fillMaxWidth().height(75.dp).padding(horizontal=6.dp),verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Outlined.Home,null,tint=Blue);Text("خانه",fontSize=10.sp)}
                            shortcuts.forEach { id ->
                                var from by remember(id) { mutableStateOf(Offset.Zero) }
                                val icon=shortcutIcons[id] ?: Icons.Outlined.GridView
                                Column(
                                    Modifier.weight(1f).onGloballyPositioned{from=it.positionInWindow()}
                                        .pointerInput(id,shortcuts) {
                                            detectDragGesturesAfterLongPress(
                                                onDragStart={start->dragId=id;dragPoint=from+start},
                                                onDrag={change,amount->change.consume();dragPoint+=amount},
                                                onDragEnd={
                                                    val rect=dropBounds
                                                    if(rect!=null && rect.contains(dragPoint)) {
                                                        val original=shortcuts.filter{it in selectableTabs}.distinct().toMutableList()
                                                        val old=original.indexOf(id)
                                                        if(old>=0) {
                                                            original.removeAt(old)
                                                            val fraction=((rect.right-dragPoint.x)/rect.width).coerceIn(0f,1f)
                                                            val insert=(fraction*(original.size+1)).toInt().coerceIn(0,original.size)
                                                            original.add(insert,id)
                                                            scope.launch{settings.setBottomShortcuts(original)}
                                                        }
                                                    }
                                                    dragId=-1
                                                },onDragCancel={dragId=-1}
                                            )
                                        },
                                    horizontalAlignment=Alignment.CenterHorizontally
                                ) {
                                    Icon(icon,null,tint=Blue)
                                    Text(shortcutLabels[id]?:"",fontSize=10.sp,maxLines=1)
                                }
                            }
                            Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Outlined.GridView,null,tint=Blue);Text("بخش‌ها",fontSize=10.sp)}
                        }
                    }
                    if(dragId>=0) Text("${shortcutLabels[dragId]} · برای تغییر ترتیب روی جای جدید در نوار رها کن",color=Blue,fontSize=11.sp)
                    Column(Modifier.heightIn(max=280.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        selectableTabs.filter{shortcutLabels[it]?.contains(search,true)==true}.chunked(3).forEach { row ->
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                row.forEach { id ->
                                    var from by remember(id) { mutableStateOf(Offset.Zero) }
                                    Surface(Modifier.weight(1f).onGloballyPositioned{from=it.positionInWindow()}.pointerInput(id,shortcuts) {
                                        detectDragGesturesAfterLongPress(
                                            onDragStart={start->dragId=id;dragPoint=from+start},
                                            onDrag={change,amount->change.consume();dragPoint+=amount},
                                            onDragEnd={
                                                val rect=dropBounds
                                                if(rect!=null && rect.contains(dragPoint) && id !in shortcuts && shortcuts.size<3) {
                                                    val fraction=((rect.right-dragPoint.x)/rect.width).coerceIn(0f,1f)
                                                    val pos=(fraction*(shortcuts.size+2)-1).toInt().coerceIn(0,shortcuts.size)
                                                    val revised=shortcuts.toMutableList().apply{add(pos,id)}
                                                    scope.launch{settings.setBottomShortcuts(revised)}
                                                }
                                                dragId=-1
                                            },onDragCancel={dragId=-1}
                                        )
                                    },shape=RoundedCornerShape(14.dp),color=if(id in shortcuts)Color(0xFFEEF2FF) else Color(0xFFF7F9FD)) {
                                        Column(Modifier.fillMaxWidth().padding(8.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                                            Icon(shortcutIcons[id] ?: Icons.Outlined.GridView,null,tint=Blue,modifier=Modifier.size(26.dp))
                                            Text(shortcutLabels[id] ?: "",fontSize=11.sp,maxLines=1)
                                            IconButton(onClick={scope.launch{settings.setBottomShortcuts(if(id in shortcuts)shortcuts.filterNot{it==id} else (shortcuts+id).take(3))}},enabled=id in shortcuts || shortcuts.size<3){Icon(if(id in shortcuts)Icons.Outlined.RemoveCircleOutline else Icons.Outlined.AddCircleOutline,null,tint=Blue)}
                                        }
                                    }
                                }
                                repeat(3-row.size){Spacer(Modifier.weight(1f))}
                            }
                        }
                    }
                    Text("ترتیب میان‌برهای وسط را با نگه‌داشتن و کشیدن در نوار بالا تغییر بده.",fontSize=11.sp,color=Color(0xFF78849A))
                    Text("خانه در راست و بخش‌ها در چپ ثابت‌اند؛ همه تغییرات آفلاین ذخیره می‌شوند.",fontSize=11.sp,color=Color(0xFF78849A))
                    OutlinedButton(onClick={sectionsOpen=false;settingsOpen=true},
                        modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(14.dp)) {
                        Icon(Icons.Outlined.ManageAccounts, null, modifier=Modifier.size(19.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("پروفایل و تنظیمات")
                    }
                }
            }
            if (info.isNotEmpty()) AlertDialog(onDismissRequest = { info = "" }, title = { Text(info) }, text = { Text("این بخش در نسخه‌های پاداش فعال می‌شود. تا زمان فعال‌شدن پاداش‌ها، تکمیل کار فقط نتیجه کار را ثبت می‌کند.") }, confirmButton = { TextButton(onClick = { info = "" }) { Text("باشه") } })
        }
    }
}
@Composable private fun SectionTitle(text: String) { Text(text, style = MaterialTheme.typography.titleMedium) }
@Composable private fun QuickTile(title: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Text(title)
        }
    }
}
@Composable private fun FeatureCard(title: String, subtitle: String, icon: ImageVector) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
@Composable private fun EmptySection(title: String, subtitle: String, detail: String, icon: ImageVector) {
    Text(title, style = MaterialTheme.typography.headlineSmall)
    Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
    FeatureCard("در مسیر ساخت", detail, icon)
}
@Composable private fun SettingsPage(modifier: Modifier, name: String, theme: String, onSave: (String) -> Unit, onTheme: (String) -> Unit, onBackup:()->Unit,onBack: () -> Unit) {
    var draft by rememberSaveable(name) { mutableStateOf(name) }
    var saved by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        TextButton(onClick = onBack) { Icon(Icons.Outlined.ArrowForward, null); Text("بازگشت") }
        Text("تنظیمات", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(value = draft, onValueChange = { draft = it; saved = false }, label = { Text("نام من") }, singleLine = true, modifier = Modifier.fillMaxWidth(), isError = draft.isBlank(), supportingText = { Text(if (draft.isBlank()) "نام را وارد کن" else "نام در هدر همه صفحه‌ها نمایش داده می‌شود") })
        Button(onClick = { onSave(draft.trim()); saved = true }, enabled = draft.isNotBlank() && draft.length <= 80) { Text("ذخیره نام") }
        if (saved) Text("نام ذخیره شد", color = MaterialTheme.colorScheme.primary)
        SectionTitle("ظاهر اپ")
        listOf("system" to "هماهنگ با گوشی", "light" to "روشن", "dark" to "تاریک").forEach { (value, label) ->
            Surface(onClick = { onTheme(value) }, shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = theme == value, onClick = { onTheme(value) }); Text(label)
                }
            }
        }
        OutlinedButton(onClick=onBackup,modifier=Modifier.fillMaxWidth()){Icon(Icons.Outlined.Backup,null);Spacer(Modifier.width(8.dp));Text("پشتیبان‌گیری و بازیابی")}
        Text("اطلاعات روی همین دستگاه ذخیره می‌شوند؛ برای انتقال به گوشی دیگر خروجی پشتیبان بگیر.",style=MaterialTheme.typography.bodySmall)
        Text("مسیر من · نسخه ۰٫۳۲٫۰\nپایه پروژه · Kotlin / Compose", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
