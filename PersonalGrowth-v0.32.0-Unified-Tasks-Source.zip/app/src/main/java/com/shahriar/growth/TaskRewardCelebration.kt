package com.shahriar.growth

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog

/** Shown only AFTER ExecutionEngine commits successfully, never as an optimistic reward. */
@Composable
fun TaskRewardCelebration(title: String, coins: Long, onDismiss: () -> Unit) {
    var appeared by remember(title, coins) { mutableStateOf(false) }
    LaunchedEffect(title, coins) { appeared = true }
    val scale by animateFloatAsState(
        targetValue = if(appeared) 1f else .78f,
        animationSpec = tween(durationMillis = 450), label = "reward celebration")
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth().graphicsLayer(scaleX = scale, scaleY = scale),
            shape = RoundedCornerShape(26.dp), color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE9D4A3)), shadowElevation = 12.dp
        ) {
            Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Outlined.EmojiEvents, contentDescription = null,
                    tint = Color(0xFFBD8B32), modifier = Modifier.size(56.dp))
                Text("آفرین! یک قدم جلوتر رفتی", fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge,
                    color = Color(0xFF17223B), textAlign = TextAlign.Center)
                Text(title, color = Color(0xFF5B6780), textAlign = TextAlign.Center)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(16.dp), color = Color(0xFFEAF1FF)) {
                        Text("+۲۰ XP", color = Color(0xFF355CDE), fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 19.dp, vertical = 12.dp))
                    }
                    Surface(shape = RoundedCornerShape(16.dp), color = Color(0xFFFFF3DC)) {
                        Text("+${faNumber(coins)} سکه", color = Color(0xFF89591B), fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 19.dp, vertical = 12.dp))
                    }
                }
                TextButton(onClick=onDismiss) { Text("ادامه مسیر") }
            }
        }
    }
}
