package com.shahriar.growth.data

import org.junit.Assert.*
import org.junit.Test

class NetworkRulesTest {
    private val a=Person(id="a",name="علی")
    private val b=Person(id="b",name="بهار",parentId="a")
    private val c=Person(id="c",name="سارا",parentId="b")
    private val people=listOf(a,b,c)
    @Test fun descendantsIncludeAllLevelsButNotSelf(){assertEquals(setOf("b","c"),descendants("a",people))}
    @Test fun selfCannotBeParent(){assertFalse(validParent("a","a",people))}
    @Test fun childCannotBecomeAncestor(){assertFalse(validParent("a","c",people))}
    @Test fun movingToRootIsValid(){assertTrue(validParent("c",null,people))}
    @Test fun movingToSiblingIsValid(){assertTrue(validParent("c","a",people))}
    @Test fun missingParentIsRejected(){assertFalse(validParent("a","missing",people))}
    @Test fun archivedParentIsRejected(){assertFalse(validParent("c","a",listOf(a.copy(archived=true),b,c)))}
    @Test fun corruptCycleTraversalTerminates(){assertEquals(setOf("b","c"),descendants("a",listOf(a.copy(parentId="c"),b,c)))}
    @Test fun searchNormalizesArabicAndPersian(){assertTrue(matchesPerson(a.copy(name="کیان",phone="۰۹۱۲"),"كيان"));assertTrue(matchesPerson(a.copy(phone="۰۹۱۲"),"0912"))}
    @Test fun treeContainsVirtualRootAndRealHierarchy(){val n=treeNodes(people,null);assertEquals(listOf("","a","b","c"),n.map{it.id});assertEquals(listOf(0,1,2,3),n.map{it.depth})}
    @Test fun collapseDoesNotRemoveParent(){assertEquals(listOf("","a"),treeNodes(people,null,setOf("a")).map{it.id})}
    @Test fun subtreeHasIndependentRoot(){assertEquals(listOf("b","c"),treeNodes(people,"b").map{it.id})}
    @Test fun archivedPeopleAreNotRendered(){assertEquals(listOf("","a","b"),treeNodes(people.map{if(it.id=="c")it.copy(archived=true) else it},null).map{it.id})}
    @Test fun hugeTreesHaveBoundedViewport(){assertEquals(201,treeNodes((1..1000).map{Person(id="$it",name="$it")},null).size)}
    @Test(expected=IllegalArgumentException::class) fun blankNameRejected(){validatePerson(a.copy(name="  "),people)}
    @Test(expected=IllegalArgumentException::class) fun unknownRoleRejected(){validatePerson(a.copy(role="admin"),people)}
    @Test fun validRecordAccepted(){validatePerson(c,people)}
    @Test(expected=IllegalArgumentException::class) fun parentWithActiveChildCannotArchive(){validateArchive(a,true,people)}
    @Test fun leafCanArchive(){validateArchive(c,true,people)}
    @Test(expected=IllegalArgumentException::class) fun restoreRequiresAvailableParent(){validateArchive(c.copy(archived=true),false,listOf(a,b.copy(archived=true),c))}
    @Test fun rootCanRestore(){validateArchive(a.copy(archived=true),false,people)}
}
