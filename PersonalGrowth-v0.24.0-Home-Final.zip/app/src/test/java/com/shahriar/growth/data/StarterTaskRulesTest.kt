package com.shahriar.growth.data

import org.junit.Assert.*
import org.junit.Test

class StarterTaskRulesTest {
    @Test fun onlyEmptyNeverInitializedDatabaseGetsExamples() {
        assertTrue(shouldInsertStarterTasks(false, 0))
        assertFalse(shouldInsertStarterTasks(false, 1))
        assertFalse(shouldInsertStarterTasks(true, 0))
        assertFalse(shouldInsertStarterTasks(true, 9))
    }

    @Test fun draftsAreRealTasksUsingExistingRewardSystem() {
        val today = 21000L
        val drafts = starterTaskDrafts(today)
        assertEquals(listOf("مطالعه فصل سوم کتاب", "مرور یادداشت‌های امروز", "تمرین زبان انگلیسی"), drafts.map { it.title })
        assertEquals(listOf(2, 1, 0), drafts.map { it.priority })
        assertTrue(drafts.all { it.dueDay == today && !it.done && !it.archived })
        assertEquals(listOf(20L, 15L, 10L), drafts.map { rewardFor(it.priority) })
        assertEquals(20L, TASK_COMPLETION_XP)
        assertEquals(3, drafts.distinctBy { it.id }.size)
    }
}
