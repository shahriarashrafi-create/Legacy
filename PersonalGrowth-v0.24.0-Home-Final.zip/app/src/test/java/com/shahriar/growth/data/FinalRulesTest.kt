package com.shahriar.growth.data
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate
class FinalRulesTest {
 private val day=LocalDate.of(2026,10,19).toEpochDay()
 private fun goal()=Goal(id="p",title="PV ماه",startDay=day,endDay=day+30,target=100.0)
 private fun rejects(f:()->Unit){try{f();fail("Expected validation failure")}catch(_:IllegalArgumentException){}}
 @Test fun validGoal(){validateGoal(goal(),emptyList())}
 @Test fun positiveTarget(){listOf(0.0,-1.0,Double.NaN,Double.POSITIVE_INFINITY,1e10).forEach{rejects{validateGoal(goal().copy(target=it),emptyList())}}}
 @Test fun countInteger(){rejects{validateGoal(goal().copy(metric="tasks",target=1.2),emptyList())}}
 @Test fun periodBounded(){rejects{validateGoal(goal().copy(endDay=day),emptyList())};rejects{validateGoal(goal().copy(endDay=day+367),emptyList())}}
 @Test fun gvNotTeamSum(){rejects{validateGoal(goal().copy(metric="gv",team=true),emptyList())}}
 @Test fun childContained(){val p=goal();val c=p.copy(id="c",parentId="p",endDay=day+7,target=20.0);validateGoal(c,listOf(p));rejects{validateGoal(c.copy(startDay=day-1),listOf(p))}}
 @Test fun childSameMetricAndScope(){val p=goal();val c=p.copy(id="c",parentId="p",endDay=day+7,target=20.0);rejects{validateGoal(c.copy(metric="gv"),listOf(p))};rejects{validateGoal(c.copy(ownerId="other"),listOf(p))}}
 @Test fun noGoalCycles(){val p=goal().copy(parentId="c");val c=p.copy(id="c",parentId="p");rejects{validateGoal(p,listOf(c))}}
 @Test fun disjointSiblings(){val p=goal();val c=p.copy(id="c",parentId="p",endDay=day+7,target=50.0);val d=c.copy(id="d",startDay=day+6,endDay=day+14);rejects{validateGoal(d,listOf(p,c))};validateGoal(d.copy(startDay=day+7),listOf(p,c))}
 @Test fun childSumBound(){val p=goal();val c=p.copy(id="c",parentId="p",endDay=day+7,target=60.0);val d=c.copy(id="d",startDay=day+7,endDay=day+14);rejects{validateGoal(d,listOf(p,c))};validateGoal(d.copy(target=40.0),listOf(p,c))}
 @Test fun parentCantBreakChildren(){val p=goal();val c=p.copy(id="c",parentId="p",endDay=day+7,target=60.0);rejects{validateGoal(p.copy(target=50.0),listOf(c))};rejects{validateGoal(p.copy(metric="gv"),listOf(c))}}
 @Test fun archivedSiblingIgnored(){val p=goal();val c=p.copy(id="c",parentId="p",target=100.0,archived=true);validateGoal(c.copy(id="d",archived=false),listOf(p,c))}
 @Test fun parentMustBeActive(){val p=goal().copy(archived=true);rejects{validateGoal(p.copy(id="c",parentId="p",archived=false),listOf(p))}}
 @Test fun progressClamped(){assertEquals(1f,goalRatio(200.0,100.0));assertEquals(0f,goalRatio(-5.0,100.0));assertEquals(.5f,goalRatio(50.0,100.0))}
 private fun log()=TimeLog(id="a",title="کار",day=day,startMinute=540,minutes=30)
 @Test fun validLog(){validateTimeLog(log(),emptyList(),day,600)}
 @Test fun noFutureLog(){rejects{validateTimeLog(log().copy(day=day+1),emptyList(),day,600)};rejects{validateTimeLog(log().copy(minutes=90),emptyList(),day,600)}}
 @Test fun noDuplicateTime(){val l=log();rejects{validateTimeLog(l.copy(id="b",startMinute=550),listOf(l),day,900)};validateTimeLog(l.copy(id="b",startMinute=570),listOf(l),day,900)}
 @Test fun sameLogEditable(){val l=log();validateTimeLog(l.copy(minutes=40),listOf(l),day,900)}
 @Test fun differentOwnersMayOverlap(){val l=log();validateTimeLog(l.copy(id="b",ownerId="p"),listOf(l),day,900)}
 @Test fun archivedLogExcluded(){val l=log();validateTimeLog(l.copy(id="b"),listOf(l.copy(archived=true)),day,900)}
 @Test fun noMidnightOverflow(){rejects{validateTimeLog(log().copy(startMinute=1430,minutes=30),emptyList(),day+1,0)}}
 @Test fun touchingNotOverlapping(){assertFalse(timeOverlap(10,20,30,20));assertTrue(timeOverlap(10,21,30,20))}
 @Test fun streakGraceToday(){assertEquals(2,streakDays(setOf(day-2,day-1),day));assertEquals(3,streakDays(setOf(day-2,day-1,day),day));assertEquals(0,streakDays(setOf(day-2),day))}
 @Test fun futureDoesNotExtendStreak(){assertEquals(1,streakDays(setOf(day,day+1),day))}
 @Test fun emptyStreak(){assertEquals(0,streakDays(emptySet(),day))}
 @Test fun levelBoundaries(){assertEquals(1,levelFor(0));assertEquals(1,levelFor(99));assertEquals(2,levelFor(100));assertEquals(1,levelFor(-200))}
 @Test fun priorityRewardBounded(){assertEquals(10L,rewardFor(-1));assertEquals(15L,rewardFor(1));assertEquals(20L,rewardFor(8))}
 @Test fun goalMetricMapsTotals(){val t=PerformanceTotals(1.2,5.0,7.0,2,3,4,5,6,7,8);assertEquals(1.2,goalActual(goal(),t,45),0.0);assertEquals(45.0,goalActual(goal().copy(metric="minutes"),t,45),0.0);assertEquals(5.0,goalActual(goal().copy(metric="tasks"),t,0),0.0)}
}

class PlanningMathTest {
 @Test fun freeWindowMergesOverlap(){assertEquals(listOf(480 to 540,660 to 1320),freeSlots(listOf(540 to 90,600 to 60)))}
 @Test fun noFalseFreeGapInsideOverlap(){assertEquals(listOf(720 to 1320),freeSlots(listOf(480 to 240,540 to 30)))}
 @Test fun outsideWorkdayClipped(){assertEquals(listOf(480 to 1320),freeSlots(listOf(60 to 30,1400 to 20)))}
 @Test fun noTinyFreeSlots(){assertEquals(listOf(500 to 1320),freeSlots(listOf(490 to 10)))}
 @Test fun wholeDayBusy(){assertTrue(freeSlots(listOf(0 to 1440)).isEmpty())}
 @Test fun focusIncludesResetTime(){val s=FocusSession(taskId="t",durationMs=600000,accruedMs=120000,previousMs=180000);assertEquals(5L,sessionMinutes(s))}
 @Test fun minutesUseClosingDayAndImmutableOwner(){val d=LocalDate.of(2026,10,19).toEpochDay();val at=LocalDate.ofEpochDay(d).atTime(14,0).atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli();val g=Goal(title="تمرکز",metric="minutes",startDay=d,endDay=d+1,target=30.0);val s=FocusSession(id="s",taskId="t",durationMs=600000,accruedMs=300000,closedAt=at);val credits=listOf(ActivityCredit("focus","s",null));assertEquals(5L,measuredMinutes(g,emptyList(),listOf(s),credits,emptyList()));assertEquals(0L,measuredMinutes(g.copy(ownerId="other"),emptyList(),listOf(s),credits,emptyList()));assertEquals(0L,measuredMinutes(g.copy(startDay=d+1,endDay=d+2),emptyList(),listOf(s),credits,emptyList()))}
 @Test fun legacyFocusNotAssignedToSelf(){val s=FocusSession(id="s",taskId="t",durationMs=600000,accruedMs=300000,closedAt=System.currentTimeMillis());val d=LocalDate.now().toEpochDay();val g=Goal(title="زمان",metric="minutes",startDay=d,endDay=d+1,target=30.0);assertEquals(0L,measuredMinutes(g,emptyList(),listOf(s),emptyList(),emptyList()))}
 @Test fun manualMinutesExcludeArchiveAndOtherOwner(){val d=LocalDate.now().toEpochDay();val g=Goal(title="زمان",metric="minutes",startDay=d,endDay=d+1,target=30.0);val l=TimeLog(title="کار",day=d,startMinute=0,minutes=10);assertEquals(10L,measuredMinutes(g,listOf(l,l.copy(id="b",archived=true),l.copy(id="c",ownerId="other")),emptyList(),emptyList(),emptyList()))}
}

class TaskScheduleValidationTest {
 private fun rejects(task:Task){try{validateTaskDraft(task);fail("Expected invalid task")}catch(_:IllegalArgumentException){}}
 @Test fun endAtMidnightAllowed(){validateTaskDraft(Task(title="کار",dueDay=1,dueMinute=1410,duration=30))}
 @Test fun crossingDayRejectedAcrossAllEditors(){rejects(Task(title="کار",dueDay=1,dueMinute=1411,duration=30))}
 @Test fun defaultPlanningDurationThirty(){rejects(Task(title="کار",dueDay=1,dueMinute=1430));validateTaskDraft(Task(title="کار",dueDay=1,dueMinute=1410))}
 @Test fun minuteRequiresDay(){rejects(Task(title="کار",dueMinute=600))}
 @Test fun noInvalidPriorityOrDuration(){rejects(Task(title="کار",priority=3));rejects(Task(title="کار",duration=0))}
}
