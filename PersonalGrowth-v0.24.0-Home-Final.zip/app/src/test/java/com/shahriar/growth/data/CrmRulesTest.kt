package com.shahriar.growth.data

import org.junit.Assert.*
import org.junit.Test

class CrmRulesTest {
    private val p=Person(id="p",name="علی")
    private val c=ContactRecord(id="c",kind="prospect",name="کیان",phone="۰۹۱۲",ownerId="p",summary="یادداشت",nextTaskId="t",createdAt=123)
    private val t=Task(id="t",title="پیگیری",dueDay=100)
    private val link=TaskContact("t","c")
    @Test fun conversionPreservesIdentityAndLinks(){val x=toCustomer(c);assertEquals(c.id,x.id);assertEquals(c.nextTaskId,x.nextTaskId);assertEquals(c.ownerId,x.ownerId);assertEquals(c.summary,x.summary);assertEquals(c.createdAt,x.createdAt);assertEquals("customer",x.kind);assertEquals("active",x.stage)}
    @Test fun customerConversionIsIdempotent(){val x=toCustomer(c);assertEquals(x,toCustomer(x))}
    @Test(expected=IllegalArgumentException::class) fun joinedProspectCannotBecomeCustomer(){toCustomer(c.copy(memberId="m",stage="joined"))}
    @Test(expected=IllegalArgumentException::class) fun archivedCannotConvert(){toCustomer(c.copy(archived=true))}
    @Test fun membershipCopiesSponsorAndContactData(){val x=memberFromProspect(c);assertEquals("p",x.parentId);assertEquals(c.name,x.name);assertEquals(c.phone,x.phone);assertEquals(c.summary,x.note)}
    @Test(expected=IllegalArgumentException::class) fun joinedCannotCreateSecondMemberSnapshot(){memberFromProspect(c.copy(memberId="m"))}
    @Test fun linkedMemberNameStaysLive(){val x=displayedContact(c.copy(memberId="p"),listOf(p.copy(name="نام جدید")));assertEquals("نام جدید",x.name);assertEquals(c.id,x.id)}
    @Test fun contactTaskUsesCurrentResponsible(){assertEquals("p",effectiveOwner("t",listOf(TaskOwner("t","wrong")),listOf(link),listOf(c)))}
    @Test fun transferContactMovesDerivedTaskOwner(){assertEquals("new",effectiveOwner("t",emptyList(),listOf(link),listOf(c.copy(ownerId="new"))))}
    @Test fun selfOwnedContactDoesNotFallBackToStaleOwner(){assertNull(effectiveOwner("t",listOf(TaskOwner("t","wrong")),listOf(link),listOf(c.copy(ownerId=null))))}
    @Test fun directTaskStillUsesPersonOwner(){assertEquals("p",effectiveOwner("t",listOf(TaskOwner("t","p")),emptyList(),listOf(c)))}
    @Test fun openFollowupIsReused(){assertTrue(reusableFollowup(c,t,link))}
    @Test fun completedFollowupCanBeReplaced(){assertFalse(reusableFollowup(c,t.copy(done=true),link))}
    @Test fun archivedFollowupCanBeReplaced(){assertFalse(reusableFollowup(c,t.copy(archived=true),link))}
    @Test fun reassignedTaskIsNotReused(){assertFalse(reusableFollowup(c,t,link.copy(contactId="different")))}
    @Test fun missingLinkIsNotReused(){assertFalse(reusableFollowup(c,t,null))}
    @Test fun followupTodayAndOverdueAreDue(){assertEquals("due",followupState(c,listOf(t),100));assertEquals("due",followupState(c,listOf(t),101))}
    @Test fun futureNotSuggestedAsDue(){assertEquals("future",followupState(c,listOf(t),99))}
    @Test fun doneAndArchivedDoNotAppearDue(){assertEquals("done",followupState(c,listOf(t.copy(done=true)),101));assertEquals("archived",followupState(c,listOf(t.copy(archived=true)),101))}
    @Test fun missingAndUndatedHaveDistinctStates(){assertEquals("none",followupState(c,emptyList(),100));assertEquals("undated",followupState(c,listOf(t.copy(dueDay=null)),100))}
    @Test fun normalizedContactSearch(){assertTrue(matchesContact(c,"كيان"));assertTrue(matchesContact(c,"0912"))}
    @Test fun validContactAccepted(){validateContact(c,listOf(p))}
    @Test(expected=IllegalArgumentException::class) fun archivedResponsibleRejected(){validateContact(c,listOf(p.copy(archived=true)))}
    @Test(expected=IllegalArgumentException::class) fun customerCannotUseProspectStage(){validateContact(c.copy(kind="customer",stage="new"),listOf(p))}
    @Test fun zeroValuePurchaseIsAllowed(){validateOrder(CustomerOrder(contactId="c",item="محصول",day=20000))}
    @Test(expected=IllegalArgumentException::class) fun negativeAmountRejected(){validateOrder(CustomerOrder(contactId="c",item="محصول",day=20000,totalToman=-1))}
    @Test(expected=IllegalArgumentException::class) fun nanPvRejected(){validateOrder(CustomerOrder(contactId="c",item="محصول",day=20000,pv=Double.NaN))}
    @Test(expected=IllegalArgumentException::class) fun zeroQuantityRejected(){validateOrder(CustomerOrder(contactId="c",item="محصول",day=20000,quantity=0))}
    @Test(expected=IllegalArgumentException::class) fun emptyProductRejected(){validateOrder(CustomerOrder(contactId="c",item=" ",day=20000))}
}
