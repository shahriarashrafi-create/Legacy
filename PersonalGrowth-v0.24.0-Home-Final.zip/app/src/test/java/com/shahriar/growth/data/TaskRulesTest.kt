package com.shahriar.growth.data
import org.junit.Assert.*
import org.junit.Test
class TaskRulesTest {
    private val today=20000L
    @Test fun excludesClosedFutureAndUndated() {
        val tasks=listOf(Task(title="closed",done=true,dueDay=today),Task(title="future",dueDay=today+1),Task(title="no date"),Task(title="archive",dueDay=today,archived=true))
        assertNull(nextAction(tasks,null,today))
    }
    @Test fun overdueBeforeImportantToday() {
        val old=Task(title="old",dueDay=today-1,priority=0)
        assertEquals(old,nextAction(listOf(Task(title="new",dueDay=today,priority=2),old),null,today))
    }
    @Test fun manualSelectionExpiresNextDay() {
        val first=Task(title="first",dueDay=today-2,priority=2)
        val chosen=Task(title="chosen",dueDay=today,priority=0)
        val choice=ActionChoice(taskId=chosen.id,day=today)
        assertEquals(chosen,nextAction(listOf(first,chosen),choice,today))
        assertEquals(first,nextAction(listOf(first,chosen),choice,today+1))
    }
    @Test fun exclusionIsTemporary() {
        val t=Task(title="later",dueDay=today,excludedDay=today)
        assertNull(nextAction(listOf(t),null,today))
        assertEquals(t,nextAction(listOf(t),null,today+1))
    }
    @Test fun completedSelectionFallsBack() {
        val t=Task(title="done",done=true,dueDay=today)
        val open=Task(title="open",dueDay=today)
        assertEquals(open,nextAction(listOf(t,open),ActionChoice(taskId=t.id,day=today),today))
    }
    @Test fun filtersKeepArchivedSeparate() {
        val t=Task(title="archived",dueDay=today,done=true,archived=true)
        assertFalse(taskMatches(t,4,today));assertTrue(taskMatches(t,5,today))
    }
    @Test fun arabicAndPersianSearchMatch() { assertEquals(normalizeText("علي ١٢"),normalizeText("علی ۱۲")) }
}
