package com.shahriar.growth.data

import com.shahriar.growth.parseMeetingTime
import org.junit.Assert.*
import org.junit.Test

class MeetingRulesTest {
    private val t=Task(id="t",title="جلسه")
    private val m=Meeting(taskId="t")
    @Test fun plannedIsDerivedFromOpenTask(){assertEquals("planned",meetingStatus(m,t))}
    @Test fun checkboxCompletionStillRequiresMeetingResult(){assertEquals("needs_result",meetingStatus(m,t.copy(done=true)))}
    @Test fun heldRequiresTaskCompletion(){assertEquals("held",meetingStatus(m.copy(outcome="held"),t.copy(done=true)))}
    @Test fun reopenedTaskPreservesPriorResult(){assertEquals("reopened",meetingStatus(m.copy(outcome="held",result="متن"),t))}
    @Test fun cancelledNeedsArchivedTask(){assertEquals("cancelled",meetingStatus(m.copy(outcome="cancelled"),t.copy(archived=true)));assertEquals("reopened",meetingStatus(m.copy(outcome="cancelled"),t))}
    @Test fun genericArchiveDoesNotClaimCancellation(){assertEquals("archived",meetingStatus(m,t.copy(archived=true)))}
    @Test fun missingTaskIsExplicit(){assertEquals("missing",meetingStatus(m,null))}
    @Test fun linkedContactWinsOverStaleDirectOwner(){assertEquals("contact" to "c",meetingRecord("t",listOf(TaskOwner("t","p")),listOf(TaskContact("t","c"))))}
    @Test fun noLinksMeansSelf(){assertEquals("self" to "",meetingRecord("t",emptyList(),emptyList()))}
    @Test fun parsePersianAndArabicTime(){assertEquals(620,parseMeetingTime("۱۰:۲۰"));assertEquals(620,parseMeetingTime("١٠:٢٠"))}
    @Test fun invalidClockRejected(){assertNull(parseMeetingTime("24:00"));assertNull(parseMeetingTime("10:60"));assertNull(parseMeetingTime("no"))}
    @Test fun lastMinuteMeetingAllowed(){validateMeetingDraft("جلسه",20000,1439,1,m)}
    @Test(expected=IllegalArgumentException::class) fun crossingMidnightRejected(){validateMeetingDraft("جلسه",20000,1439,2,m)}
    @Test(expected=IllegalArgumentException::class) fun blankTitleRejected(){validateMeetingDraft(" ",20000,600,30,m)}
    @Test(expected=IllegalArgumentException::class) fun invalidKindRejected(){validateMeetingDraft("جلسه",20000,600,30,m.copy(kind="invalid"))}
    @Test(expected=IllegalArgumentException::class) fun excessiveDurationRejected(){validateMeetingDraft("جلسه",20000,600,241,m)}
}
