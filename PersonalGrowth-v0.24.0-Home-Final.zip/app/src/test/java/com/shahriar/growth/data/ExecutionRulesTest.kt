package com.shahriar.growth.data
import org.junit.Assert.*
import org.junit.Test
class ExecutionRulesTest {
    private fun session(state:String="running")=FocusSession(taskId="a",durationMs=60000,accruedMs=10000,anchorWall=100000,anchorElapsed=50000,boot=3,state=state)
    @Test fun monotonicTimeSurvivesWallClockChange(){assertEquals(20000,focusSpent(session(),ClockReading(1,60000,3)))}
    @Test fun pauseDoesNotAccumulate(){assertEquals(10000,focusSpent(session("paused"),ClockReading(900000,900000,3)))}
    @Test fun recoveryAfterRebootUsesWallClock(){assertEquals(25000,focusSpent(session(),ClockReading(115000,2000,4)))}
    @Test fun waitingDoesNotAccumulate(){assertEquals(10000,focusSpent(session("waiting"),ClockReading(900000,900000,3)))}
    @Test fun timerNeverExceedsDuration(){assertEquals(60000,focusSpent(session(),ClockReading(900000,900000,3)))}
    @Test fun clockGoingBackDoesNotProduceNegative(){assertEquals(10000,focusSpent(session(),ClockReading(90000,2000,4)))}
    @Test fun rejectsDirectAndIndirectCycles(){val edges=listOf(Prerequisite("b","c"),Prerequisite("c","a"));assertTrue(wouldCycle("a","b",edges));assertTrue(wouldCycle("a","a",emptyList()));assertFalse(wouldCycle("x","b",edges))}
    @Test fun unresolvedPrerequisiteBlocksNextAction(){val t=Task(id="a",title="locked",dueDay=100);assertNull(nextAction(listOf(t),null,100,listOf(Prerequisite("a","b"))))}
    @Test fun completedPrerequisiteUnlocks(){val t=Task(id="a",title="ready",dueDay=100);val d=Task(id="b",title="done",done=true);assertEquals(t,nextAction(listOf(t,d),null,100,listOf(Prerequisite("a","b"))))}
    @Test fun resetKeepsPreviousFocusSeparateFromTimer(){val s=session().copy(previousMs=45000);assertEquals(20000,focusSpent(s,ClockReading(110000,60000,3)));assertEquals(65000,s.previousMs+focusSpent(s,ClockReading(110000,60000,3)))}
}
