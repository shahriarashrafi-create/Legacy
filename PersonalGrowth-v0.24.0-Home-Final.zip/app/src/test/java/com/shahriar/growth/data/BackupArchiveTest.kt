package com.shahriar.growth.data
import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipOutputStream
import java.util.zip.ZipEntry
class BackupArchiveTest {
 private fun zip(vararg names:String):ByteArray{val out=ByteArrayOutputStream();ZipOutputStream(out).use{z->names.forEach{z.putNextEntry(ZipEntry(it));z.write("{}".toByteArray());z.closeEntry()}};return out.toByteArray()}
 private fun rejects(f:()->Unit){try{f();fail("Expected validation rejection")}catch(_:IllegalArgumentException){}}
 @Test fun roundtripPersian(){val content="{\"title\":\"شهریار؛ هدف امروز\"}".toByteArray();val out=ByteArrayOutputStream();BackupArchive.write(content,out);assertArrayEquals(content,BackupArchive.read(ByteArrayInputStream(out.toByteArray())))}
 @Test fun rejectsSourceProjectZip(){rejects{BackupArchive.read(ByteArrayInputStream(zip("settings.gradle.kts","app/build.gradle.kts")))}}
 @Test fun noTraversal(){rejects{BackupArchive.read(ByteArrayInputStream(zip("../growth.json")))}}
 @Test fun noExtraEntry(){rejects{BackupArchive.read(ByteArrayInputStream(zip("growth.json","other.txt")))}}
 @Test fun inflatedSizeBounded(){val out=ByteArrayOutputStream();BackupArchive.write(ByteArray(1000){65},out);rejects{BackupArchive.read(ByteArrayInputStream(out.toByteArray()),100)}}
 @Test fun exportBounded(){rejects{BackupArchive.write(ByteArray(101),ByteArrayOutputStream(),100)}}
 @Test fun noEmptyExport(){rejects{BackupArchive.write(ByteArray(0),ByteArrayOutputStream())}}
 @Test fun noEmptyArchive(){rejects{BackupArchive.read(ByteArrayInputStream(zip()))}}
 @Test fun rejectsDirectoryEntry(){rejects{BackupArchive.read(ByteArrayInputStream(zip("growth.json/")))}}
}
