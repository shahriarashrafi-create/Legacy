package com.shahriar.growth.data

import org.junit.Assert.*
import org.junit.Test
import java.time.*

class ReportingRulesTest {
    private val day=LocalDate.of(2026,10,18).toEpochDay()
    private val at=LocalDate.ofEpochDay(day).atTime(12,0).toInstant(ZoneOffset.UTC).toEpochMilli()
    private val a=Person(id="a",name="الف",createdAt=at)
    private val b=Person(id="b",name="ب",parentId="a",createdAt=at)
    private val c=ContactRecord(id="c",kind="customer",name="مشتری",ownerId="a",createdAt=at)
    private val order=CustomerOrder(id="o",contactId="c",item="محصول",day=day,pv=10.5)
    private val task=Task(id="t",title="ارائه",done=true,completedAt=at)
    private fun total(owner:String?="a",team:Boolean=false,entries:List<PerformanceEntry> = emptyList(),orders:List<CustomerOrder> = emptyList(),tasks:List<Task> = emptyList(),meetings:List<Meeting> = emptyList(),credits:List<ActivityCredit> = emptyList(),contacts:List<ContactRecord> = listOf(c),people:List<Person> = listOf(a,b))=computePerformance(owner,team,DayRange(day,day+1),people,contacts,orders,tasks,meetings,entries,credits,ZoneOffset.UTC)
    @Test fun pvAddsOrdersAndExtraManualOnly(){assertEquals(12.5,total(entries=listOf(PerformanceEntry(personId="a",day=day,pv=2.0)),orders=listOf(order),credits=listOf(ActivityCredit("order","o","a"))).pv,0.0001)}
    @Test fun historicSaleCreditSurvivesResponsibleTransfer(){assertEquals(10.5,total(orders=listOf(order),contacts=listOf(c.copy(ownerId="b")),credits=listOf(ActivityCredit("order","o","a"))).pv,0.0001)}
    @Test fun missingSaleCreditDoesNotBecomeSelfCredit(){assertEquals(0.0,total(owner=null,orders=listOf(order)).pv,0.0)}
    @Test fun explicitNullIsSelfCredit(){assertEquals(10.5,total(owner=null,orders=listOf(order),credits=listOf(ActivityCredit("order","o",null))).pv,0.0)}
    @Test fun archivedSaleDoesNotCount(){assertEquals(0.0,total(orders=listOf(order.copy(archived=true)),credits=listOf(ActivityCredit("order","o","a"))).pv,0.0)}
    @Test fun archivingContactDoesNotEraseHistoricalSale(){assertEquals(10.5,total(orders=listOf(order),contacts=listOf(c.copy(archived=true)),credits=listOf(ActivityCredit("order","o","a"))).pv,0.0)}
    @Test fun endOfRangeIsExclusive(){assertEquals(0.0,total(entries=listOf(PerformanceEntry(personId="a",day=day+1,pv=3.0)),orders=listOf(order.copy(day=day+1)),credits=listOf(ActivityCredit("order","o","a"))).pv,0.0)}
    @Test fun archivedManualDoesNotCount(){assertEquals(0.0,total(entries=listOf(PerformanceEntry(personId="a",day=day,pv=3.0,archived=true))).pv,0.0)}
    @Test fun personalAndGroupPvDiffer(){val es=listOf(PerformanceEntry(personId="a",day=day,pv=2.0),PerformanceEntry(personId="b",day=day,pv=3.0));val t=total(entries=es);assertEquals(2.0,t.pv,0.0);assertEquals(5.0,t.groupPv,0.0);assertEquals(5.0,total(team=true,entries=es).pv,0.0)}
    @Test fun groupDoesNotSumOverlappingGvReports(){val es=listOf(PerformanceEntry(personId="a",day=day,gv=100.0),PerformanceEntry(personId="b",day=day,gv=50.0));assertEquals(100.0,total(team=true,entries=es).gv,0.0)}
    @Test fun archivedDescendantsRemainInHistoricalScope(){assertTrue("b" in metricScope("a",true,listOf(a,b.copy(archived=true))))}
    @Test fun completedTaskUsesCompletionCredit(){assertEquals(1,total(tasks=listOf(task),credits=listOf(ActivityCredit("task","t","a"))).completedTasks);assertEquals(0,total(owner="b",tasks=listOf(task),credits=listOf(ActivityCredit("task","t","a"))).completedTasks)}
    @Test fun archivingCompletedTaskKeepsCompletionHistory(){assertEquals(1,total(tasks=listOf(task.copy(archived=true)),credits=listOf(ActivityCredit("task","t","a"))).completedTasks)}
    @Test fun reopeningTaskRemovesCurrentCompletionCount(){assertEquals(0,total(tasks=listOf(task.copy(done=false,completedAt=null)),credits=listOf(ActivityCredit("task","t","a"))).completedTasks)}
    @Test fun uncheckedMeetingResultDoesNotCountHeld(){val t=total(tasks=listOf(task),meetings=listOf(Meeting(taskId="t")),credits=listOf(ActivityCredit("task","t","a")));assertEquals(0,t.heldMeetings);assertEquals(0,t.presentations)}
    @Test fun heldIntroCountsOneAutomaticPresentation(){val t=total(tasks=listOf(task),meetings=listOf(Meeting(taskId="t",kind="intro",outcome="held")),credits=listOf(ActivityCredit("task","t","a")));assertEquals(1,t.heldMeetings);assertEquals(1L,t.presentations)}
    @Test fun followupMeetingAndMarkerAreDeduplicated(){val t=total(tasks=listOf(task),meetings=listOf(Meeting(taskId="t",kind="followup",outcome="held")),credits=listOf(ActivityCredit("task","t","a"),ActivityCredit("followup","t","a")));assertEquals(1L,t.followups)}
    @Test fun extraManualCountsAddToAutomatic(){val t=total(entries=listOf(PerformanceEntry(personId="a",day=day,invitations=2,presentations=3,followups=4)),tasks=listOf(task),meetings=listOf(Meeting(taskId="t",kind="intro",outcome="held")),credits=listOf(ActivityCredit("task","t","a")));assertEquals(2L,t.invitations);assertEquals(4L,t.presentations);assertEquals(4L,t.followups)}
    @Test fun sponsorSnapshotSurvivesParentChange(){val t=total(people=listOf(a,b.copy(parentId=null)),credits=listOf(ActivityCredit("join","b","a"),ActivityCredit("contact","c","a")));assertEquals(1,t.newMembers);assertEquals(1,t.newRecords)}
    @Test fun taskAtMidnightUsesSelectedZone(){val atUtc=LocalDate.ofEpochDay(day-1).atTime(22,0).toInstant(ZoneOffset.UTC).toEpochMilli();assertEquals(day,localDay(atUtc,ZoneOffset.ofHoursMinutes(3,30)))}
    @Test fun saturdayStartsIranianWeek(){val sat=LocalDate.of(2026,10,17).toEpochDay();assertEquals(DayRange(sat,sat+7),weekRange(sat));assertEquals(DayRange(sat,sat+7),weekRange(sat+6))}
    @Test fun weekCrossesYearBoundary(){val d=LocalDate.of(2027,1,1).toEpochDay();val r=weekRange(d);assertEquals(DayOfWeek.SATURDAY,LocalDate.ofEpochDay(r.start).dayOfWeek);assertTrue(r.contains(d));assertEquals(7L,r.end-r.start)}
    @Test fun validExtraPerformanceAccepted(){validatePerformance(PerformanceEntry(day=day,pv=1.5))}
    @Test(expected=IllegalArgumentException::class) fun emptyEntryRejected(){validatePerformance(PerformanceEntry(day=day))}
    @Test(expected=IllegalArgumentException::class) fun negativeMetricRejected(){validatePerformance(PerformanceEntry(day=day,pv=-1.0))}
    @Test(expected=IllegalArgumentException::class) fun infiniteGvRejected(){validatePerformance(PerformanceEntry(day=day,gv=Double.POSITIVE_INFINITY))}
    @Test(expected=IllegalArgumentException::class) fun negativeCountRejected(){validatePerformance(PerformanceEntry(day=day,invitations=-1))}
    @Test fun decimalPointsAvoidBinarySumArtifacts(){assertEquals(0.3,total(entries=listOf(PerformanceEntry(personId="a",day=day,pv=0.1)),orders=listOf(order.copy(pv=0.2)),credits=listOf(ActivityCredit("order","o","a"))).pv,0.0)}
}
