package com.shahriar.growth.data

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class StarterMeetingRulesTest {
    @Test fun onlyEmptyUninitializedTimesheetIsSeeded() {
        assertTrue(shouldInsertStarterMeetings(false,0))
        assertFalse(shouldInsertStarterMeetings(false,1))
        assertFalse(shouldInsertStarterMeetings(true,0))
    }

    @Test fun threeDistinctFutureDaysWithMatchingTimes() {
        val monday = LocalDate.of(2026,10,19)
        val slots = starterMeetingSlots(monday, 17*60)
        assertEquals(listOf("برنامه‌ریزی هفتگی","مشاوره تحصیلی","مرور مطالب"),slots.map{it.title})
        assertEquals(listOf(600,870,960),slots.map{it.minute})
        assertEquals(3,slots.map{it.day}.distinct().size)
        assertTrue(slots.all{it.day>=monday.toEpochDay()})
        assertEquals(monday.plusDays(7).toEpochDay(),slots.last().day)
    }

    @Test fun futureTodaySlotKeptAndPassedTodaySlotMovesNextWeek() {
        val monday=LocalDate.of(2026,10,19)
        val early=starterMeetingSlots(monday, 9*60)
        assertEquals(monday.toEpochDay(), early.last().day)
        val late=starterMeetingSlots(monday, 16*60+1)
        assertEquals(monday.plusDays(7).toEpochDay(), late.last().day)
    }
}
