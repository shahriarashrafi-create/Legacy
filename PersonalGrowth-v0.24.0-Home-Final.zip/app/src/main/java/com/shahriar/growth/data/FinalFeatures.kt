package com.shahriar.growth.data

import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.time.LocalDate
import java.time.ZoneId
import java.util.UUID

@Entity(tableName="goals")
data class Goal(@PrimaryKey val id:String=UUID.randomUUID().toString(),val title:String,val ownerId:String?=null,val team:Boolean=false,val metric:String="pv",val startDay:Long,val endDay:Long,val target:Double,val parentId:String?=null,val archived:Boolean=false)
@Entity(tableName="goal_tasks",primaryKeys=["goalId","taskId"])
data class GoalTask(val goalId:String,val taskId:String)
@Entity(tableName="time_logs")
data class TimeLog(@PrimaryKey val id:String=UUID.randomUUID().toString(),val title:String,val ownerId:String?=null,val taskId:String?=null,val day:Long,val startMinute:Int,val minutes:Int,val note:String="",val archived:Boolean=false)
@Entity(tableName="repeat_plans")
data class RepeatPlan(@PrimaryKey val id:String=UUID.randomUUID().toString(),val taskId:String,val intervalDays:Int,val nextDay:Long,val endDay:Long,val enabled:Boolean=true)
@Entity(tableName="repeat_runs",primaryKeys=["planId","day"])
data class RepeatRun(val planId:String,val day:Long,val taskId:String)
@Entity(tableName="dreams")
data class Dream(@PrimaryKey val id:String=UUID.randomUUID().toString(),val title:String,val note:String="",val symbol:String="star",val goalId:String?=null,val archived:Boolean=false)
@Entity(tableName="wallet")
data class WalletEntry(@PrimaryKey val id:String,val label:String,val coins:Long,val xp:Long=0,val at:Long=System.currentTimeMillis())
@Entity(tableName="prizes")
data class Prize(@PrimaryKey val id:String=UUID.randomUUID().toString(),val title:String,val cost:Long,val archived:Boolean=false)
@Entity(tableName="redemptions")
data class Redemption(@PrimaryKey val id:String=UUID.randomUUID().toString(),val prizeId:String,val title:String,val cost:Long,val at:Long=System.currentTimeMillis(),val refunded:Boolean=false)
@Entity(tableName="reminders")
data class TaskReminder(@PrimaryKey val taskId:String,val leadMinutes:Int=0,val enabled:Boolean=true,val sentFor:Long?=null)
@Dao interface FinalDao {
 @Query("SELECT * FROM goals ORDER BY startDay,title") fun goals():Flow<List<Goal>>
 @Query("SELECT * FROM goals") suspend fun allGoals():List<Goal>
 @Query("SELECT * FROM goals WHERE id=:id") suspend fun goal(id:String):Goal?
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(g:Goal)
 @Query("SELECT * FROM goal_tasks") fun links():Flow<List<GoalTask>>
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun link(l:GoalTask)
 @Query("DELETE FROM goal_tasks WHERE goalId=:goal AND taskId=:task") suspend fun unlink(goal:String,task:String)
 @Query("SELECT * FROM time_logs ORDER BY day DESC,startMinute") fun logs():Flow<List<TimeLog>>
 @Query("SELECT * FROM time_logs") suspend fun allLogs():List<TimeLog>
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(l:TimeLog)
 @Query("SELECT * FROM repeat_plans ORDER BY nextDay") fun repeats():Flow<List<RepeatPlan>>
 @Query("SELECT * FROM repeat_plans WHERE enabled=1") suspend fun activeRepeats():List<RepeatPlan>
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(p:RepeatPlan)
 @Query("SELECT * FROM repeat_runs WHERE planId=:id AND day=:day") suspend fun run(id:String,day:Long):RepeatRun?
 @Insert suspend fun put(r:RepeatRun)
 @Query("SELECT * FROM dreams ORDER BY title") fun dreams():Flow<List<Dream>>
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(d:Dream)
 @Query("SELECT * FROM wallet ORDER BY at DESC,id") fun wallet():Flow<List<WalletEntry>>
 @Query("SELECT * FROM wallet WHERE id=:id") suspend fun entry(id:String):WalletEntry?
 @Query("SELECT COALESCE(SUM(coins),0) FROM wallet") suspend fun balance():Long
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(w:WalletEntry)
 @Query("SELECT * FROM prizes ORDER BY cost,title") fun prizes():Flow<List<Prize>>
 @Query("SELECT * FROM prizes WHERE id=:id") suspend fun prize(id:String):Prize?
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(p:Prize)
 @Query("SELECT * FROM redemptions ORDER BY at DESC") fun redemptions():Flow<List<Redemption>>
 @Query("SELECT * FROM redemptions WHERE id=:id") suspend fun redemption(id:String):Redemption?
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(r:Redemption)
 @Query("SELECT * FROM reminders") fun reminders():Flow<List<TaskReminder>>
 @Query("SELECT * FROM reminders WHERE enabled=1") suspend fun activeReminders():List<TaskReminder>
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(r:TaskReminder)
}
val goalMetrics=listOf("pv" to "PV", "gv" to "GV", "tasks" to "کار انجام‌شده", "invitations" to "دعوت", "presentations" to "پرزنت", "followups" to "پیگیری", "meetings" to "جلسه", "members" to "عضو جدید", "minutes" to "دقیقه فعالیت")
fun validateGoal(g:Goal,others:List<Goal>){
 require(g.title.isNotBlank() && g.title.length<=120){"عنوان هدف را تا ۱۲۰ حرف وارد کن."}
 require(goalMetrics.any{it.first==g.metric} && g.target.isFinite() && g.target>0 && g.target<=1e9){"نوع و مقدار هدف معتبر نیست."}
 require(g.metric in listOf("pv","gv") || g.target%1.0==0.0){"برای تعداد، عدد صحیح وارد کن."}
 require(g.startDay>=LocalDate.of(1900,1,1).toEpochDay() && g.endDay<=LocalDate.of(2300,1,1).toEpochDay()){ "تاریخ هدف معتبر نیست." }
 require(g.endDay>g.startDay && g.endDay-g.startDay<=366){"بازه هدف باید ۱ تا ۳۶۶ روز باشد."}
 require(g.metric!="gv" || !g.team){"GV ثبت شرکت است؛ برای مجموع تیم از PV استفاده کن."}
 var parent=g.parentId;val seen=mutableSetOf(g.id)
 while(parent!=null){require(seen.add(parent)){"هدف نمی‌تواند چرخه داشته باشد."};parent=others.firstOrNull{it.id==parent}?.parentId}
 g.parentId?.let{id->val p=requireNotNull(others.firstOrNull{it.id==id}){"هدف مادر پیدا نشد."};require(!p.archived && p.metric==g.metric && p.ownerId==g.ownerId && p.team==g.team && g.startDay>=p.startDay && g.endDay<=p.endDay){"زیرهدف باید داخل بازه و با معیار هدف مادر باشد."}
 val siblings=others.filter{it.parentId==id && it.id!=g.id && !it.archived};require(siblings.none{it.startDay<g.endDay && g.startDay<it.endDay}){"بازه زیرهدف‌ها نباید هم‌پوشانی داشته باشد."};require(siblings.sumOf{it.target}+g.target<=p.target+0.000001){"مجموع زیرهدف‌ها بیشتر از هدف مادر است."}}
 val children=others.filter{it.parentId==g.id && !it.archived};require(children.all{it.metric==g.metric && it.ownerId==g.ownerId && it.team==g.team && it.startDay>=g.startDay && it.endDay<=g.endDay} && children.sumOf{it.target}<=g.target+0.000001){"ابتدا زیرهدف‌های فعال را اصلاح یا بایگانی کن."}
}
fun goalActual(g:Goal,p:PerformanceTotals,minutes:Long):Double=when(g.metric){"pv"->p.pv;"gv"->p.gv;"tasks"->p.completedTasks.toDouble();"invitations"->p.invitations.toDouble();"presentations"->p.presentations.toDouble();"followups"->p.followups.toDouble();"meetings"->p.heldMeetings.toDouble();"members"->p.newMembers.toDouble();"minutes"->minutes.toDouble();else->0.0}
fun goalRatio(actual:Double,target:Double)=if(target>0)(actual/target).coerceIn(0.0,1.0).toFloat() else 0f
fun timeOverlap(a:Int,minutes:Int,b:Int,duration:Int)=a<b+duration && b<a+minutes
fun validateTimeLog(l:TimeLog,logs:List<TimeLog>,nowDay:Long,nowMinute:Int){
 require(l.title.isNotBlank() && l.title.length<=120 && l.note.length<=4000){"عنوان یا یادداشت معتبر نیست."}
 require(l.day in LocalDate.of(1900,1,1).toEpochDay()..LocalDate.of(2300,1,1).toEpochDay()){ "تاریخ معتبر نیست." }
 require(l.startMinute in 0..1439 && l.minutes in 1..1440 && l.startMinute+l.minutes<=1440){"بازه باید داخل یک روز باشد؛ فعالیت شبانه را در دو روز ثبت کن."}
 require(l.day<nowDay || l.day==nowDay && l.startMinute+l.minutes<=nowMinute){"تایم‌شیت فقط برای زمان سپری‌شده است."}
 require(logs.none{it.id!=l.id && !it.archived && it.ownerId==l.ownerId && it.day==l.day && timeOverlap(l.startMinute,l.minutes,it.startMinute,it.minutes)}){"این زمان با ثبت دیگری برای همین فرد هم‌پوشانی دارد."}
}
fun streakDays(days:Set<Long>,today:Long):Int{var day=if(today in days)today else today-1;var count=0;while(day in days){count++;day--};return count}
fun levelFor(xp:Long)=1+(xp.coerceAtLeast(0)/100).toInt()
fun rewardFor(priority:Int)=10L+priority.coerceIn(0,2)*5L
const val TASK_COMPLETION_XP = 20L
class FinalEngine(private val db:AppDatabase){
 private val dao get()=db.finalDao()
 suspend fun save(g:Goal)=db.withTransaction{validateGoal(g,dao.allGoals());require(g.ownerId==null || db.networkDao().get(g.ownerId)?.archived==false){"فرد فعال انتخاب کن."};dao.put(g.copy(title=g.title.trim()))}
 suspend fun archive(g:Goal,value:Boolean)=db.withTransaction{
 val current=requireNotNull(dao.goal(g.id));if(!value)validateGoal(current.copy(archived=false),dao.allGoals())
 if(value){val all=dao.allGoals();val ids=mutableSetOf(g.id);var changed=true;while(changed){changed=false;all.forEach{if(it.parentId in ids && ids.add(it.id))changed=true}};all.filter{it.id in ids}.forEach{dao.put(it.copy(archived=true))}}else dao.put(current.copy(archived=false))}
 suspend fun log(l:TimeLog)=db.withTransaction{val now=java.time.LocalDateTime.now();validateTimeLog(l,dao.allLogs(),now.toLocalDate().toEpochDay(),now.hour*60+now.minute);require(l.ownerId==null || db.networkDao().get(l.ownerId)?.archived==false){"فرد فعال انتخاب کن."};l.taskId?.let{val t=requireNotNull(db.taskDao().get(it));require(currentTaskOwner(db,t.id)==l.ownerId){"مسئول کار و زمان یکسان نیست."};require(db.executionDao().allSessions().none{s->s.taskId==it}){"برای کاری که سابقه تمرکز دارد زمان دستی ثبت نکن؛ در جمع خودکار محاسبه می‌شود."}};val start=LocalDate.ofEpochDay(l.day).atStartOfDay(ZoneId.systemDefault()).plusMinutes(l.startMinute.toLong()).toInstant().toEpochMilli();val end=start+l.minutes*60000L
 val credit=db.reportingDao().credits().first().filter{it.sourceType=="focus"}.associateBy{it.sourceId}
 require(db.executionDao().allSessions().none{f->val who=credit[f.id];who!=null && who.personId==l.ownerId && f.createdAt<end && (f.closedAt?:System.currentTimeMillis())>start}){"این زمان در بازه یک جلسه تمرکز است؛ برای جلوگیری از ثبت دوباره، بازه دیگری انتخاب کن."};dao.put(l)}
 suspend fun reward(task:Task,success:Boolean){val id="task:${task.id}";val old=dao.entry(id);if(!success && old==null)return;dao.put(WalletEntry(id,"کار: ${task.title}",if(success)rewardFor(task.priority)else 0,if(success)TASK_COMPLETION_XP else 0,old?.at?:System.currentTimeMillis()))}
 suspend fun buy(id:String)=db.withTransaction{val p=requireNotNull(dao.prize(id));require(!p.archived && p.cost>0 && dao.balance()>=p.cost){"سکه کافی نیست یا پاداش فعال نیست."};val r=Redemption(prizeId=p.id,title=p.title,cost=p.cost);dao.put(r);dao.put(WalletEntry("buy:${r.id}","دریافت ${p.title}",-p.cost))}
 suspend fun refund(id:String)=db.withTransaction{val r=requireNotNull(dao.redemption(id));require(!r.refunded){"این دریافت قبلاً برگشت خورده است."};dao.put(r.copy(refunded=true));dao.put(WalletEntry("refund:$id","برگشت ${r.title}",r.cost))}
 suspend fun prize(p:Prize){require(p.title.isNotBlank() && p.title.length<=120 && p.cost in 1..1000000){"عنوان و قیمت ۱ تا یک میلیون سکه وارد کن."};dao.put(p)}
 suspend fun dream(d:Dream){require(d.title.isNotBlank() && d.title.length<=120 && d.note.length<=4000){"عنوان یا یادداشت معتبر نیست."};require(d.goalId==null || dao.goal(d.goalId)!=null){"هدف پیدا نشد."};dao.put(d)}
 suspend fun repeat(p:RepeatPlan)=db.withTransaction{require(p.intervalDays in 1..30 && p.endDay>=p.nextDay && p.endDay-p.nextDay<=366){"تکرار: فاصله ۱ تا ۳۰ روز و بازه تا یک سال."};val t=requireNotNull(db.taskDao().get(p.taskId));require(!t.archived){"کار بایگانی شده است."};require(db.meetingDao().forTask(t.id)==null){"جلسه را از پرونده جلسات برنامه‌ریزی کن؛ این تکرار مخصوص کارهاست."};dao.put(p)}
 suspend fun generate(today:Long)=db.withTransaction{dao.activeRepeats().forEach{p->
 val source=db.taskDao().get(p.taskId)?:return@forEach;if(source.archived)return@forEach
 val sourceContact=db.crmDao().link(source.id)?.let{db.crmDao().contact(it.contactId)};val sourcePerson=db.networkDao().owner(source.id)?.let{db.networkDao().get(it.personId)};if(sourceContact?.archived==true || sourcePerson?.archived==true)return@forEach
 var day=p.nextDay;if(day<today)day+=((today-day+p.intervalDays-1)/p.intervalDays)*p.intervalDays;var count=0
 while(day<=minOf(p.endDay,today+30) && count<60){
  if(day==source.dueDay && dao.run(p.id,day)==null)dao.put(RepeatRun(p.id,day,source.id))
  if(day>=today && dao.run(p.id,day)==null){val id=UUID.nameUUIDFromBytes("${p.id}:$day".toByteArray()).toString();val t=source.copy(id=id,dueDay=day,done=false,failed=false,archived=false,completedAt=null,excludedDay=null,createdAt=System.currentTimeMillis(),updatedAt=System.currentTimeMillis());db.taskDao().save(t)
   db.crmDao().link(source.id)?.let{db.crmDao().putLink(TaskContact(id,it.contactId))}?:db.networkDao().owner(source.id)?.let{db.networkDao().putOwner(TaskOwner(id,it.personId))}
   db.executionDao().subtasksFor(source.id).forEach{db.executionDao().putSubtask(it.copy(id=UUID.randomUUID().toString(),taskId=id,checked=false))};dao.put(RepeatRun(p.id,day,id))}
  day+=p.intervalDays;count++
 };dao.put(p.copy(nextDay=day,enabled=day<=p.endDay))}}
}
val MIGRATION_6_7=object:Migration(6,7){override fun migrate(db:SupportSQLiteDatabase){
 db.execSQL("CREATE TABLE IF NOT EXISTS goals (id TEXT NOT NULL PRIMARY KEY,title TEXT NOT NULL,ownerId TEXT,team INTEGER NOT NULL,metric TEXT NOT NULL,startDay INTEGER NOT NULL,endDay INTEGER NOT NULL,target REAL NOT NULL,parentId TEXT,archived INTEGER NOT NULL)")
 db.execSQL("CREATE TABLE IF NOT EXISTS goal_tasks (goalId TEXT NOT NULL,taskId TEXT NOT NULL,PRIMARY KEY(goalId,taskId))")
 db.execSQL("CREATE TABLE IF NOT EXISTS time_logs (id TEXT NOT NULL PRIMARY KEY,title TEXT NOT NULL,ownerId TEXT,taskId TEXT,day INTEGER NOT NULL,startMinute INTEGER NOT NULL,minutes INTEGER NOT NULL,note TEXT NOT NULL,archived INTEGER NOT NULL)")
 db.execSQL("CREATE TABLE IF NOT EXISTS repeat_plans (id TEXT NOT NULL PRIMARY KEY,taskId TEXT NOT NULL,intervalDays INTEGER NOT NULL,nextDay INTEGER NOT NULL,endDay INTEGER NOT NULL,enabled INTEGER NOT NULL)")
 db.execSQL("CREATE TABLE IF NOT EXISTS repeat_runs (planId TEXT NOT NULL,day INTEGER NOT NULL,taskId TEXT NOT NULL,PRIMARY KEY(planId,day))")
 db.execSQL("CREATE TABLE IF NOT EXISTS dreams (id TEXT NOT NULL PRIMARY KEY,title TEXT NOT NULL,note TEXT NOT NULL,symbol TEXT NOT NULL,goalId TEXT,archived INTEGER NOT NULL)")
 db.execSQL("CREATE TABLE IF NOT EXISTS wallet (id TEXT NOT NULL PRIMARY KEY,label TEXT NOT NULL,coins INTEGER NOT NULL,xp INTEGER NOT NULL,at INTEGER NOT NULL)")
 db.execSQL("CREATE TABLE IF NOT EXISTS prizes (id TEXT NOT NULL PRIMARY KEY,title TEXT NOT NULL,cost INTEGER NOT NULL,archived INTEGER NOT NULL)")
 db.execSQL("CREATE TABLE IF NOT EXISTS redemptions (id TEXT NOT NULL PRIMARY KEY,prizeId TEXT NOT NULL,title TEXT NOT NULL,cost INTEGER NOT NULL,at INTEGER NOT NULL,refunded INTEGER NOT NULL)")
 db.execSQL("CREATE TABLE IF NOT EXISTS reminders (taskId TEXT NOT NULL PRIMARY KEY,leadMinutes INTEGER NOT NULL,enabled INTEGER NOT NULL,sentFor INTEGER)")
}}

fun freeSlots(busy:List<Pair<Int,Int>>):List<Pair<Int,Int>>{val result=mutableListOf<Pair<Int,Int>>();var cursor=480;busy.sortedBy{it.first}.forEach{(start,duration)->val a=start.coerceIn(480,1320);val b=(start+duration).coerceIn(480,1320);if(a-cursor>=15)result+=cursor to a;cursor=maxOf(cursor,b)};if(1320-cursor>=15)result+=cursor to 1320;return result}
fun sessionMinutes(s:FocusSession)=((s.previousMs+s.accruedMs)/60000).coerceAtLeast(0)
fun measuredMinutes(g:Goal,logs:List<TimeLog>,sessions:List<FocusSession>,credits:List<ActivityCredit>,people:List<Person>):Long{
 val scope=metricScope(g.ownerId,g.team,people);val range=DayRange(g.startDay,g.endDay);val owners=credits.filter{it.sourceType=="focus"}.associateBy{it.sourceId}
 return logs.filter{!it.archived && it.ownerId in scope && range.contains(it.day)}.sumOf{it.minutes.toLong()}+sessions.filter{it.closedAt!=null && range.contains(localDay(it.closedAt,ZoneId.systemDefault())) && owners[it.id]?.let{c->c.personId in scope}==true}.sumOf{sessionMinutes(it)}
}
