package com.shahriar.growth

import android.app.*
import android.content.*
import android.media.MediaPlayer
import android.os.IBinder
import android.os.PowerManager
import android.media.ToneGenerator
import android.media.AudioManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.shahriar.growth.data.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first

class FocusService:Service(){
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main)
    private var player:MediaPlayer?=null
    private var music=false
    private var wake:PowerManager.WakeLock?=null
    override fun onBind(intent:Intent?):IBinder?=null
    override fun onCreate(){super.onCreate();musicEnabled.value=false;(getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel("focus","تمرکز",NotificationManager.IMPORTANCE_LOW));startForeground(41,notification(null));val db=AppDatabase.get(this);val engine=ExecutionEngine(db,this)
        scope.launch {db.executionDao().observeActive().collectLatest { session->
            if(session==null){stopSelf();return@collectLatest}
            while(isActive){
                engine.tick()
                val current=db.executionDao().active()?:break
                if(current.state=="running"){
                    if(wake?.isHeld!=true){wake=(getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"growth:focus").apply{setReferenceCounted(false);acquire((current.durationMs-focusSpent(current,readClock(this@FocusService))+5000).coerceAtLeast(5000))}}
                }else if(wake?.isHeld==true)wake?.release()
                if(current.state=="running" && music){if(player==null){player=MediaPlayer.create(this@FocusService,R.raw.focus_ambient)?.apply{isLooping=true;setVolume(0.18f,0.18f);start()}}else if(player?.isPlaying==false)player?.start()}
                else if(player?.isPlaying==true)player?.pause()
                if(current.state=="waiting" && engine.claimEndSignal()){player?.pause();if(com.shahriar.growth.data.Settings(applicationContext).endSound.first()){val tone=ToneGenerator(AudioManager.STREAM_NOTIFICATION,35);tone.startTone(ToneGenerator.TONE_PROP_BEEP,250);scope.launch{delay(400);tone.release()}}}
                (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(41,notification(current))
                delay(1000)
            }
        }}
    }
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
        val engine=ExecutionEngine(AppDatabase.get(this),this)
        when(intent?.action){"toggle"->scope.launch{engine.toggle()};"music"->{music=intent.getBooleanExtra("enabled",false);musicEnabled.value=music;if(!music)player?.pause()}}
        return START_STICKY
    }
    private fun notification(s:FocusSession?):Notification{
        val open=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java).putExtra("focus",true).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val remaining=s?.let{((it.durationMs-focusSpent(it,readClock(this)))/1000).coerceAtLeast(0)}?:0
        val title=when(s?.state){"paused"->"تمرکز مکث شده";"waiting"->"زمان تمام شد؛ نتیجه را ثبت کن";else->"تمرکز در حال اجرا"}
        val builder=NotificationCompat.Builder(this,"focus").setSmallIcon(R.drawable.ic_launcher).setContentTitle(title).setContentText(if(s==null)"بازیابی جلسه" else faNumber("%02d:%02d".format(java.util.Locale.ROOT,remaining/60,remaining%60))).setContentIntent(open).setOnlyAlertOnce(true).setOngoing(true)
        if(s?.state!="waiting")builder.addAction(0,if(s?.state=="paused")"ادامه" else "مکث",PendingIntent.getService(this,1,Intent(this,FocusService::class.java).setAction("toggle"),PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        builder.addAction(0,"ثبت نتیجه",open)
        return builder.build()
    }
    override fun onDestroy(){if(wake?.isHeld==true)wake?.release();stopForeground(STOP_FOREGROUND_REMOVE);scope.cancel();player?.release();player=null;musicEnabled.value=false;super.onDestroy()}
    companion object{val musicEnabled=MutableStateFlow(false)
        fun ensure(context:Context){ContextCompat.startForegroundService(context,Intent(context,FocusService::class.java))}
        fun music(context:Context,enabled:Boolean){ContextCompat.startForegroundService(context,Intent(context,FocusService::class.java).setAction("music").putExtra("enabled",enabled))}}
}
