package com.shahriar.growth

import android.icu.text.SimpleDateFormat
import android.icu.util.Calendar
import android.icu.util.ULocale
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.shahriar.growth.data.*
import java.time.LocalDate
import java.time.ZoneId
import java.util.Date

fun faNumber(value: Any): String = value.toString().map { if(it in '0'..'9') ('۰'.code + it.code - '0'.code).toChar() else it }.joinToString("")
fun persianDay(day: Long, numeric: Boolean = false): String {
    val formatter = SimpleDateFormat(if(numeric) "yyyy/MM/dd" else "d MMMM yyyy", ULocale("fa_IR@calendar=persian"))
    return formatter.format(Date.from(LocalDate.ofEpochDay(day).atStartOfDay(ZoneId.systemDefault()).toInstant()))
}
fun parsePersianDay(raw: String): Long? = try {
    val parts = normalizeText(raw).trim().split('/').map { it.toInt() }
    require(parts.size == 3 && parts[0] in 1300..1600)
    val calendar = Calendar.getInstance(ULocale("fa_IR@calendar=persian"))
    calendar.isLenient = false; calendar.clear(); calendar.set(parts[0], parts[1]-1, parts[2], 12, 0, 0)
    java.time.Instant.ofEpochMilli(calendar.timeInMillis).atZone(ZoneId.systemDefault()).toLocalDate().toEpochDay()
} catch (_: Exception) { null }
fun dueLabel(t: Task, today: Long): String {
    val day = t.dueDay ?: return "بدون موعد"
    val date = when { day == today -> "امروز"; day == today + 1 -> "فردا"; else -> persianDay(day) }
    val time = t.dueMinute?.let { " · " + faNumber("%02d:%02d".format(java.util.Locale.ROOT, it/60,it%60)) } ?: ""
    return date + time + if (day < today && !t.done) " · عقب‌افتاده" else ""
}
@Composable fun TaskRow(task: Task, today: Long, onOpen: () -> Unit, onDone: (Boolean) -> Unit) {
    Card(onClick = onOpen, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = task.done, onCheckedChange = if(task.archived) null else onDone)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(task.title, style = MaterialTheme.typography.titleMedium)
                if(task.failed) Text("تلاش قبلی ناموفق · قابل تکرار",style=MaterialTheme.typography.bodySmall)
                Text(dueLabel(task,today), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("اهمیت " + listOf("کم","متوسط","زیاد")[task.priority] + (task.duration?.let { " · ${faNumber(it)} دقیقه" } ?: ""), style = MaterialTheme.typography.bodySmall)
            }
            Icon(Icons.Outlined.ChevronLeft, null)
        }
    }
}
@Composable fun TaskListScreen(modifier: Modifier, tasks: List<Task>, today: Long, filter: Int, listState: LazyListState, onFilter: (Int) -> Unit, onNew: () -> Unit, onOpen: (String) -> Unit, onDone: (String,Boolean) -> Unit) {
    var search by rememberSaveable { mutableStateOf("") }
    var importance by rememberSaveable { mutableIntStateOf(-1) }
    val labels = listOf("امروز","عقب‌افتاده","آینده","بدون موعد","انجام‌شده","بایگانی","همه بازها","انجام امروز")
    val filtered = tasks.filter { taskMatches(it,filter,today) && (importance < 0 || it.priority == importance) && normalizeText(it.title+" "+it.note).contains(normalizeText(search.trim())) }
        .sortedWith(compareBy<Task> { it.dueDay ?: Long.MAX_VALUE }.thenBy { it.dueMinute ?: 1440 }.thenByDescending { it.priority }.thenBy { it.createdAt })
    LazyColumn(modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text("کارهای من", style = MaterialTheme.typography.headlineSmall); Button(onClick=onNew) { Icon(Icons.Outlined.Add,null); Text("کار جدید") } } }
        item { OutlinedTextField(search,{search=it},label={Text("جست‌وجوی عنوان و توضیح")},modifier=Modifier.fillMaxWidth(),singleLine=true) }
        item {
            Column {
                labels.chunked(3).forEachIndexed { group, row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEachIndexed { index, label ->
                            val i = group * 3 + index
                            FilterChip(selected = filter == i, onClick = { onFilter(i) }, label = { Text(label) })
                        }
                    }
                }
            }
        }
        item { Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) { FilterChip(selected=importance<0,onClick={importance=-1},label={Text("همه اهمیت‌ها")}); FilterChip(selected=importance==2,onClick={importance=if(importance==2)-1 else 2},label={Text("فقط مهم‌ها")}) } }
        item { Text("${faNumber(filtered.size)} کار",style=MaterialTheme.typography.bodySmall) }
        if(filtered.isEmpty()) item { Text(if(search.isNotBlank() || importance>=0) "کاری با این فیلتر پیدا نشد." else "در این فهرست کاری نداری؛ می‌توانی کار جدید بسازی.") }
        items(filtered,key={it.id}) { task -> TaskRow(task,today,{onOpen(task.id)},{onDone(task.id,it)}) }
    }
}
@OptIn(ExperimentalLayoutApi::class)
@Composable fun HomeScreen(modifier: Modifier, tasks: List<Task>, choice: ActionChoice?, today: Long, active: FocusSession?, edges: List<Prerequisite>, onFocus:(String)->Unit, onPath:()->Unit,onSchedule:()->Unit,onGoals:()->Unit, onNew: () -> Unit, onOpen: (String) -> Unit, onList: (Int) -> Unit, onExclude: (String) -> Unit, onClearChoice: () -> Unit, onDone: (String,Boolean) -> Unit) {
    val next = tasks.firstOrNull{it.id==active?.taskId} ?: nextAction(tasks,choice,today,edges)
    val todayTasks = tasks.filter { !it.archived && !it.done && it.dueDay==today }.sortedWith(compareBy<Task> { it.dueMinute ?: 1440 }.thenByDescending { it.priority })
    val overdue = tasks.count { taskMatches(it,1,today) }
    val doneToday = tasks.count { !it.archived && it.done && it.completedAt?.let { at -> java.time.Instant.ofEpochMilli(at).atZone(ZoneId.systemDefault()).toLocalDate().toEpochDay()==today }==true }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
        Text("امروز، یک قدم جلوتر",style=MaterialTheme.typography.headlineSmall)
        Text(persianDay(today),color=MaterialTheme.colorScheme.onSurfaceVariant)
        Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer)) {
            Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Outlined.AutoAwesome,null)
                Text("قدم بعدی تو",style=MaterialTheme.typography.titleLarge)
                if(next==null) {
                    Text("قدم آماده‌ای برای پیشنهاد نیست")
                    Text("کارهای امروز و عقب‌افتاده پیشنهاد می‌شوند. برای کار بدون موعد یا آینده، تاریخ امروز را انتخاب کن.")
                    Button(onClick=onNew) { Text("ساخت کار") }
                } else {
                    Text(next.title,style=MaterialTheme.typography.titleLarge)
                    Text(dueLabel(next,today))
                    Text(if(active?.taskId==next.id) "جلسه تمرکز باز" else if(choice?.day==today && choice.taskId==next.id) "انتخاب خودت" else "پیشنهاد بر اساس موعد و اهمیت",style=MaterialTheme.typography.bodySmall)
                    Button(onClick={onFocus(next.id)}) { Text(if(active?.taskId==next.id) "ادامه جلسه تمرکز" else "شروع تمرکز") }
                    TextButton(onClick={onOpen(next.id)}) { Text("جزئیات کار") }
                    if(active==null) TextButton(onClick={onExclude(next.id)}) { Text("فعلاً پیشنهاد نده") }
                }
                if(choice?.day==today && choice.taskId!=null) TextButton(onClick=onClearChoice) { Text("بازگشت به پیشنهاد خودکار") }
            }
        }
        FlowRow(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            AssistChip(onClick={onList(0)},label={Text("امروز ${faNumber(todayTasks.size)}")})
            AssistChip(onClick={onList(1)},label={Text("عقب‌افتاده ${faNumber(overdue)}")})
            AssistChip(onClick={onList(7)},label={Text("انجام امروز ${faNumber(doneToday)}")})
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) { Text("برنامه امروز",style=MaterialTheme.typography.titleMedium); TextButton(onClick={onList(0)}) { Text("همه") } }
        if(todayTasks.isEmpty()) Text("هنوز کار بازی برای امروز تعیین نکرده‌ای.")
        todayTasks.take(4).forEach { t -> TaskRow(t,today,{onOpen(t.id)},{onDone(t.id,it)}) }
        OutlinedButton(onClick=onNew,modifier=Modifier.fillMaxWidth()) { Icon(Icons.Outlined.Add,null); Text("افزودن کار") }
        OutlinedButton(onClick=onPath,modifier=Modifier.fillMaxWidth()) { Icon(Icons.Outlined.Route,null); Text("مسیر پیشرفت") }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick=onSchedule,modifier=Modifier.weight(1f)){Text("زمان من")};OutlinedButton(onClick=onGoals,modifier=Modifier.weight(1f)){Text("هدف‌های من")}}
    }
}
@Composable fun TaskEditor(task: Task?, events: List<TaskEvent>, today: Long, busy: Boolean, externalError: String, onDismiss: () -> Unit, onSave: (Task) -> Unit, onDone: (Boolean) -> Unit, onArchive: (Boolean) -> Unit, onPick: () -> Unit, onFocus:()->Unit, extra:@Composable ()->Unit) {
    val draftId = rememberSaveable { task?.id ?: java.util.UUID.randomUUID().toString() }
    var title by rememberSaveable { mutableStateOf(task?.title ?: "") }
    var note by rememberSaveable { mutableStateOf(task?.note ?: "") }
    var day by rememberSaveable { mutableStateOf(task?.dueDay) }
    var dateText by rememberSaveable { mutableStateOf(task?.dueDay?.let { persianDay(it,true) } ?: "") }
    var time by rememberSaveable { mutableStateOf(task?.dueMinute?.let { "%02d:%02d".format(java.util.Locale.ROOT,it/60,it%60) } ?: "") }
    var priority by rememberSaveable { mutableIntStateOf(task?.priority ?: 1) }
    var duration by rememberSaveable { mutableStateOf(task?.duration?.toString() ?: "") }
    var error by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    val dirty = task != null && (title != task.title || note != task.note || dateText != (task.dueDay?.let { persianDay(it,true) } ?: "") || time != (task.dueMinute?.let { "%02d:%02d".format(java.util.Locale.ROOT,it/60,it%60) } ?: "") || priority != task.priority || duration != (task.duration?.toString() ?: ""))
    Dialog(onDismissRequest={if(!busy)onDismiss()},properties=DialogProperties(usePlatformDefaultWidth=false)) {
        Surface(Modifier.fillMaxWidth().padding(12.dp),shape=MaterialTheme.shapes.large) {
            Column(Modifier.imePadding().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                Text(if(task==null)"کار جدید" else "جزئیات کار",style=MaterialTheme.typography.titleLarge)
                OutlinedTextField(title,{title=it},label={Text("عنوان کار")},modifier=Modifier.fillMaxWidth(),enabled=!busy,singleLine=false)
                OutlinedTextField(note,{note=it},label={Text("توضیحات · اختیاری")},modifier=Modifier.fillMaxWidth(),enabled=!busy,minLines=2)
                Text("موعد · اختیاری")
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick={day=today;dateText=persianDay(today,true)}) { Text("امروز") }
                    TextButton(onClick={day=today+1;dateText=persianDay(today+1,true)}) { Text("فردا") }
                    TextButton(onClick={day=null;dateText="";time=""}) { Text("بدون موعد") }
                }
                OutlinedTextField(dateText,{dateText=it},label={Text("تاریخ شمسی · ۱۴۰۵/۰۷/۲۸")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                OutlinedTextField(time,{time=it},label={Text("ساعت · ۱۸:۳۰ · اختیاری")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) { listOf("کم","متوسط","زیاد").forEachIndexed { i,label -> FilterChip(selected=priority==i,onClick={priority=i},label={Text(label)}) } }
                OutlinedTextField(duration,{duration=it},label={Text("مدت تخمینی دقیقه · ۱ تا ۲۴۰ · اختیاری")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                if(error.isNotEmpty() || externalError.isNotEmpty()) Text(error.ifEmpty{externalError},color=MaterialTheme.colorScheme.error)
                Button(enabled=!busy,onClick={
                    error=""
                    val parsedDay=if(dateText.isBlank()) null else parsePersianDay(dateText)
                    val normalizedTime=normalizeText(time).trim()
                    val minute=if(normalizedTime.isBlank()) null else if(Regex("\\d{1,2}:\\d{2}").matches(normalizedTime)) normalizedTime.split(':').map{it.toInt()}.let{if(it[0] in 0..23 && it[1] in 0..59)it[0]*60+it[1] else -1} else -1
                    val durationValue=if(duration.isBlank())null else normalizeText(duration).toIntOrNull()
                    when {
                        title.isBlank() -> error="عنوان را وارد کن."
                        title.length>300 -> error="عنوان حداکثر ۳۰۰ نویسه باشد."
                        dateText.isNotBlank() && parsedDay==null -> error="تاریخ شمسی معتبر با قالب سال/ماه/روز وارد کن."
                        minute==-1 || (minute!=null && parsedDay==null) -> error="ساعت معتبر و تاریخ مربوط را وارد کن."
                        duration.isNotBlank() && (durationValue==null || durationValue !in 1..240) -> error="مدت بین ۱ تا ۲۴۰ دقیقه باشد."
                        else -> onSave((task ?: Task(id=draftId,title=title.trim())).copy(title=title.trim(),note=note.trim(),dueDay=parsedDay,dueMinute=minute,priority=priority,duration=durationValue))
                    }
                },modifier=Modifier.fillMaxWidth()) { Text(if(busy)"در حال ثبت…" else "ذخیره کار") }
                if(task!=null) {
                    extra()
                    if(dirty) Text("برای تغییر وضعیت یا قدم بعدی، ابتدا ویرایش‌ها را ذخیره کن.",style=MaterialTheme.typography.bodySmall)
                    if(!task.archived) {
                        if(!task.done) Button(enabled=!busy && !dirty,onClick=onFocus,modifier=Modifier.fillMaxWidth()){Text("شروع یا ادامه تمرکز")}
                        OutlinedButton(enabled=!busy && !dirty,onClick={if(task.done)confirm="reopen" else onDone(true)},modifier=Modifier.fillMaxWidth()) { Text(if(task.done)"بازگشایی کار" else "انجام شد") }
                        if(!task.done) OutlinedButton(enabled=!busy && !dirty,onClick={onPick()},modifier=Modifier.fillMaxWidth()) { Text("انتخاب به‌عنوان قدم بعدی") }
                    }
                    TextButton(enabled=!busy && !dirty,onClick={confirm="archive"}) { Text(if(task.archived)"بازگردانی از بایگانی" else "بایگانی کار") }
                    if(events.isNotEmpty()) { Text("تاریخچه",style=MaterialTheme.typography.titleMedium);events.take(20).forEach { Text(it.description+" · "+persianDay(java.time.Instant.ofEpochMilli(it.at).atZone(ZoneId.systemDefault()).toLocalDate().toEpochDay()),style=MaterialTheme.typography.bodySmall) } }
                }
                TextButton(enabled=!busy,onClick=onDismiss) { Text("بستن بدون ذخیره") }
            }
        }
    }
    if(confirm.isNotEmpty()) AlertDialog(onDismissRequest={confirm=""},title={Text("تأیید تغییر")},text={Text(if(confirm=="reopen")"این کار دوباره باز شود؟" else if(task?.archived==true)"کار به فهرست برگردد؟" else "کار با حفظ سابقه بایگانی شود؟")},confirmButton={TextButton(onClick={if(confirm=="reopen")onDone(false) else onArchive(task?.archived!=true);confirm=""}){Text("تأیید")}},dismissButton={TextButton(onClick={confirm=""}){Text("انصراف")}})
}
