package com.shahriar.growth

import androidx.compose.foundation.Canvas
import androidx.activity.compose.BackHandler
import kotlinx.coroutines.delay
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.shahriar.growth.data.*

@Composable fun SubtaskPanel(subtasks:List<Subtask>,frozen:Boolean,onCheck:(Subtask,Boolean)->Unit,onAdd:(String,Boolean,()->Unit)->Unit,onRemove:(Subtask)->Unit){
    var title by rememberSaveable{mutableStateOf("")};var required by rememberSaveable{mutableStateOf(true)}
    Text("زیرکارها",style=MaterialTheme.typography.titleMedium)
    subtasks.forEach { sub->Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Checkbox(sub.checked,{onCheck(sub,it)});Column(Modifier.weight(1f)){Text(sub.title);Text(if(sub.required)"اجباری" else "اختیاری",style=MaterialTheme.typography.bodySmall)};if(!frozen)IconButton(onClick={onRemove(sub)}){Icon(Icons.Outlined.Close,"حذف زیرکار")}} }
    if(frozen)Text("تا پایان جلسه، ساختار زیرکارها ثابت است؛ تیک‌ها قابل تغییرند.",style=MaterialTheme.typography.bodySmall)
    else {
        OutlinedTextField(title,{title=it},label={Text("زیرکار جدید")},modifier=Modifier.fillMaxWidth())
        Row(verticalAlignment=Alignment.CenterVertically){Checkbox(required,{required=it});Text("اجباری");Spacer(Modifier.weight(1f));TextButton(enabled=title.isNotBlank(),onClick={onAdd(title,required){title=""}}){Text("افزودن")}}
    }
}
@Composable fun RelationsPanel(task:Task,tasks:List<Task>,groups:List<PathGroup>,missions:List<Mission>,edges:List<Prerequisite>,frozen:Boolean,onAttach:(String)->Unit,onDetach:()->Unit,onEdge:(String)->Unit,onRemoveEdge:(Prerequisite)->Unit){
    var expanded by remember{mutableStateOf(false)}
    TextButton(onClick={expanded=!expanded}){Text(if(expanded)"بستن تنظیمات مسیر و پیش‌نیاز" else "مسیر پیشرفت و پیش‌نیازها")}
    if(expanded){
        Text("گروه مسیر",style=MaterialTheme.typography.titleMedium)
        val current=missions.firstOrNull{it.taskId==task.id}
        if(groups.isEmpty())Text("ابتدا در مسیر پیشرفت یک گروه بساز.")
        groups.forEach{g->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(current?.groupId==g.id,onClick=if(frozen)null else { {onAttach(g.id)} });Text(g.title)}}
        if(current!=null)TextButton(enabled=!frozen,onClick=onDetach){Text("برداشتن از مسیر؛ خود کار حفظ شود")}
        Text("پیش‌نیازها",style=MaterialTheme.typography.titleMedium)
        edges.filter{it.taskId==task.id}.forEach{e->Row(verticalAlignment=Alignment.CenterVertically){Text(tasks.firstOrNull{it.id==e.dependsOnId}?.title?:"کار ناموجود",Modifier.weight(1f));TextButton(enabled=!frozen,onClick={onRemoveEdge(e)}){Text("برداشتن")}}}
        var show by remember{mutableStateOf(false)}
        TextButton(enabled=!frozen,onClick={show=!show}){Text("انتخاب پیش‌نیاز")}
        if(show)tasks.filter{it.id!=task.id && !it.archived && edges.none{e->e.taskId==task.id && e.dependsOnId==it.id}}.forEach{t->TextButton(onClick={onEdge(t.id);show=false}){Text(t.title)}}
    }
}
@Composable fun FocusScreen(modifier:Modifier,task:Task?,session:FocusSession?,subtasks:List<Subtask>,clock:ClockReading,busy:Boolean,error:String,onBack:(String)->Unit,onToggle:()->Unit,onReset:(String)->Unit,onClose:(String)->Unit,onFinish:(Boolean,String)->Unit,onNote:(String)->Unit,onCheck:(Subtask,Boolean)->Unit,musicEnabled:Boolean,onMusic:(Boolean)->Unit,endSound:Boolean,onEndSound:(Boolean)->Unit){
    var confirm by remember{mutableStateOf("")};var note by rememberSaveable(session?.id){mutableStateOf(session?.note?:"")}
    BackHandler(enabled=!busy){onBack(note)}
    LaunchedEffect(note){delay(500);if(session!=null && note!=session.note)onNote(note)}
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp),horizontalAlignment=Alignment.CenterHorizontally){
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){TextButton(onClick={onBack(note)}){Text("بازگشت")};Text("تمرکز",style=MaterialTheme.typography.titleLarge)}
        if(session==null){Text("جلسه باز ندارید.");return@Column}
        Text(task?.title?:"کار",style=MaterialTheme.typography.headlineSmall)
        Text(when(session.state){"paused"->"مکث‌شده";"waiting"->"زمان تمام شد؛ نتیجه را ثبت کن";else->"در حال اجرا"},color=MaterialTheme.colorScheme.primary)
        val spent=focusSpent(session,clock);val remaining=((session.durationMs-spent+999)/1000).coerceAtLeast(0)
        Box(Modifier.size(210.dp),contentAlignment=Alignment.Center){CircularProgressIndicator(progress={spent.toFloat()/session.durationMs},modifier=Modifier.fillMaxSize(),strokeWidth=7.dp);Column(horizontalAlignment=Alignment.CenterHorizontally){Text(faNumber("%02d:%02d".format(java.util.Locale.ROOT,remaining/60,remaining%60)),fontSize=38.sp,fontWeight=FontWeight.Medium);Text("تمرکز این تلاش ${faNumber((session.previousMs+spent)/60000)} دقیقه",style=MaterialTheme.typography.bodySmall)}}
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){if(session.state!="waiting")Button(enabled=!busy,onClick=onToggle){Text(if(session.state=="paused")"ادامه" else "مکث")};OutlinedButton(enabled=!busy,onClick={confirm="reset"}){Text("شروع دوباره ساعت")}}
        Row(verticalAlignment=Alignment.CenterVertically){Switch(musicEnabled,{onMusic(it)});Text("صدای محیط ملایم")}
        Row(verticalAlignment=Alignment.CenterVertically){Switch(endSound,onEndSound);Text("صدای پایان تایمر")}
        Text("نوار، زمان را نشان می‌دهد؛ موفقیت با ثبت نتیجه مشخص می‌شود.",style=MaterialTheme.typography.bodySmall)
        Column(Modifier.fillMaxWidth()){SubtaskPanel(subtasks,true,onCheck,{_,_,_->},{})}
        OutlinedTextField(note,{note=it},label={Text("یادداشت این جلسه")},modifier=Modifier.fillMaxWidth(),minLines=2)
        TextButton(enabled=!busy,onClick={onNote(note)}){Text("ذخیره یادداشت")}
        if(error.isNotEmpty())Text(error,color=MaterialTheme.colorScheme.error)
        Button(enabled=!busy && subtasks.none{it.required && !it.checked},onClick={onFinish(true,note)},modifier=Modifier.fillMaxWidth()){Text("انجام شد")}
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){OutlinedButton(enabled=!busy,onClick={confirm="fail"}){Text("ناموفق")};TextButton(enabled=!busy,onClick={confirm="close"}){Text("بازگشت به آماده")}}
    }
    if(confirm.isNotEmpty())AlertDialog(onDismissRequest={confirm=""},title={Text("تأیید")},text={Text(when(confirm){"reset"->"فقط ساعت از ابتدا و در حالت مکث شروع شود؟ یادداشت و تیک‌ها حفظ می‌شوند.";"fail"->"این تلاش ناموفق ثبت شود؟";else->"جلسه بدون نتیجه بسته شود؟ یادداشت، زمان این تلاش و تیک‌ها حفظ می‌شوند."})},confirmButton={TextButton(onClick={when(confirm){"reset"->onReset(note);"fail"->onFinish(false,note);else->onClose(note)};confirm=""}){Text("تأیید")}},dismissButton={TextButton(onClick={confirm=""}){Text("انصراف")}})
}
@Composable fun PathScreen(modifier:Modifier,tasks:List<Task>,groups:List<PathGroup>,missions:List<Mission>,edges:List<Prerequisite>,subtasks:List<Subtask>,active:FocusSession?,errorMessage:String,onBack:()->Unit,onOpen:(String)->Unit,onFocus:(String)->Unit,onAddGroup:(String,()->Unit)->Unit,onRenameGroup:(PathGroup,String,()->Unit)->Unit,onAddMission:(String,Int,Int,String,()->Unit)->Unit,onLink:(String,String,()->Unit)->Unit){
    var selected by rememberSaveable{mutableStateOf<String?>(null)}
    val group=groups.firstOrNull{it.id==selected}?:groups.firstOrNull()
    var groupEditor by remember{mutableStateOf(false)};var groupTitle by rememberSaveable{mutableStateOf("")};var rename by remember{mutableStateOf(false)}
    var missionEditor by remember{mutableStateOf(false)}
    val list=missions.filter{it.groupId==group?.id}.mapNotNull{m->tasks.firstOrNull{it.id==m.taskId && !it.archived}}
    LazyColumn(modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        item{Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){Text("مسیر پیشرفت",style=MaterialTheme.typography.headlineSmall);TextButton(onClick=onBack){Text("بازگشت")}}}
        item{Text("هر ایستگاه، همان کار مشترک در تودولیست توست.",style=MaterialTheme.typography.bodySmall)}
        item{Column{groups.forEach{g->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(g.id==group?.id,{selected=g.id});Text(g.title)}}}}
        item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){TextButton(onClick={rename=false;groupTitle="";groupEditor=true}){Text("گروه جدید")};if(group!=null)TextButton(onClick={rename=true;groupTitle=group.title;groupEditor=true}){Text("تغییر نام گروه")}}}
        if(group!=null)item{Button(onClick={missionEditor=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Outlined.Add,null);Text("مأموریت جدید یا کار موجود")}}
        if(list.isEmpty())item{Text("هنوز ایستگاهی در این گروه نیست. اولین مأموریت را اضافه کن.",Modifier.padding(vertical=24.dp))}
        itemsIndexed(list,key={_,t->t.id}){index,t->
            val locked=blocked(t.id,tasks,edges);val required=subtasks.filter{it.taskId==t.id && it.required};val left=(index/2)%2==0
            val road=MaterialTheme.colorScheme.primary.copy(alpha=0.25f);val node=MaterialTheme.colorScheme.primary
            Box(Modifier.fillMaxWidth().heightIn(min=220.dp)){
                Canvas(Modifier.matchParentSize()){
                    val x=if(left)size.width*.14f else size.width*.86f
                    val roadPath=Path().apply{moveTo(size.width*.5f,0f);cubicTo(x,0f,x,size.height*.3f,x,size.height*.5f);cubicTo(x,size.height*.8f,x,size.height,size.width*.5f,size.height)}
                    drawPath(roadPath,road,style=Stroke(width=20.dp.toPx()));drawCircle(node,12.dp.toPx(),Offset(x,size.height*.5f))
                }
                Card(onClick={onOpen(t.id)},modifier=Modifier.fillMaxWidth(.72f).align(if(left)Alignment.CenterStart else Alignment.CenterEnd).padding(vertical=12.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){
                    Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                        Text("ایستگاه ${faNumber(index+1)}",style=MaterialTheme.typography.bodySmall)
                        Text(t.title,style=MaterialTheme.typography.titleMedium)
                        Text(when{t.done->"انجام‌شده";active?.taskId==t.id->if(active.state=="paused")"در حال انجام · مکث" else if(active.state=="waiting")"منتظر نتیجه" else "در حال انجام";locked->"قفل · پیش‌نیاز ناتمام";t.failed->"تلاش ناموفق · قابل تکرار";else->"آماده"},color=MaterialTheme.colorScheme.primary)
                        if(required.isNotEmpty())Text("زیرکار اجباری ${faNumber(required.count{it.checked})} از ${faNumber(required.size)}",style=MaterialTheme.typography.bodySmall)
                        Text("${faNumber(t.duration?:10)} دقیقه",style=MaterialTheme.typography.bodySmall)
                        if(!t.done)Button(enabled=!locked,onClick={onFocus(t.id)}){Text(if(active?.taskId==t.id)"ادامه جلسه" else "تمرکز")}
                    }
                }
            }
        }
    }
    if(groupEditor)AlertDialog(onDismissRequest={groupEditor=false},title={Text(if(rename)"نام گروه" else "گروه جدید")},text={Column{OutlinedTextField(groupTitle,{groupTitle=it},label={Text("عنوان")});if(errorMessage.isNotEmpty())Text(errorMessage,color=MaterialTheme.colorScheme.error)}},confirmButton={TextButton(enabled=groupTitle.isNotBlank(),onClick={if(rename && group!=null)onRenameGroup(group,groupTitle.trim()){groupEditor=false}else onAddGroup(groupTitle.trim()){groupEditor=false}}){Text("ثبت")}},dismissButton={TextButton(onClick={groupEditor=false}){Text("انصراف")}})
    if(missionEditor && group!=null)MissionEditor(errorMessage,tasks.filter{!it.archived && missions.none{m->m.taskId==it.id}},onDismiss={missionEditor=false},onCreate={title,minutes,priority->onAddMission(title,minutes,priority,group.id){missionEditor=false}},onLink={id->onLink(id,group.id){missionEditor=false}})
}
@Composable private fun MissionEditor(externalError:String,tasks:List<Task>,onDismiss:()->Unit,onCreate:(String,Int,Int)->Unit,onLink:(String)->Unit){
    var title by rememberSaveable{mutableStateOf("")};var duration by rememberSaveable{mutableStateOf("۱۰")};var priority by rememberSaveable{mutableIntStateOf(1)};var error by remember{mutableStateOf("")}
    Dialog(onDismissRequest=onDismiss,properties=DialogProperties(usePlatformDefaultWidth=false)){
        Surface(Modifier.fillMaxWidth().padding(16.dp),shape=MaterialTheme.shapes.large){Column(Modifier.imePadding().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
            Text("مأموریت جدید",style=MaterialTheme.typography.titleLarge)
            OutlinedTextField(title,{title=it},label={Text("عنوان")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(duration,{duration=it},label={Text("مدت · ۱ تا ۲۴۰ دقیقه")},modifier=Modifier.fillMaxWidth())
            Row{listOf("کم","متوسط","زیاد").forEachIndexed{i,label->FilterChip(selected=i==priority,onClick={priority=i},label={Text(label)})}}
            if(error.isNotEmpty() || externalError.isNotEmpty())Text(error.ifEmpty{externalError},color=MaterialTheme.colorScheme.error)
            Button(onClick={val minutes=normalizeText(duration).toIntOrNull();if(title.isBlank() || title.length>300 || minutes==null || minutes !in 1..240)error="عنوان و مدت معتبر وارد کن." else onCreate(title,minutes,priority)}){Text("ساخت و افزودن برای امروز")}
            HorizontalDivider();Text("یا اتصال کار موجود",style=MaterialTheme.typography.titleMedium)
            if(tasks.isEmpty())Text("کارِ متصل‌نشده‌ای وجود ندارد.")
            tasks.forEach{t->TextButton(onClick={onLink(t.id)}){Text(t.title)}}
            TextButton(onClick=onDismiss){Text("بستن")}
        }}
    }
}
