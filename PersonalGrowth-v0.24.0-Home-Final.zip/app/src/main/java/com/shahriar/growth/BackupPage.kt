package com.shahriar.growth

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.room.withTransaction
import androidx.sqlite.db.SupportSQLiteDatabase
import com.shahriar.growth.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object GrowthBackup {
 private const val LIMIT=20*1024*1024
 private fun tables(sql:SupportSQLiteDatabase):List<String>{val result=mutableListOf<String>();sql.query("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT IN ('android_metadata','room_master_table') ORDER BY name").use{while(it.moveToNext())result+=it.getString(0)};return result}
 private fun columns(sql:SupportSQLiteDatabase,table:String):List<String>{val result=mutableListOf<String>();sql.query("PRAGMA table_info(`$table`)").use{while(it.moveToNext())result+=it.getString(it.getColumnIndexOrThrow("name"))};return result}
 suspend fun export(context:Context,db:AppDatabase,settings:Settings,uri:Uri)=withContext(Dispatchers.IO){
 val root=JSONObject().put("format","personal-growth").put("schema",7).put("app","0.20.0").put("createdAt",System.currentTimeMillis()).put("theme",settings.theme.first()).put("endSound",settings.endSound.first())
 db.withTransaction{require(db.executionDao().active()==null){"قبل از پشتیبان‌گیری، جلسه تمرکز را ببند."};val sql=db.openHelper.writableDatabase;val data=JSONObject();tables(sql).forEach{table->val names=columns(sql,table);val rows=JSONArray();sql.query("SELECT * FROM `$table`").use{c->while(c.moveToNext()){require(rows.length()<100000){"حجم داده بیشتر از سقف پشتیبان است."};val row=JSONArray();names.indices.forEach{i->row.put(if(c.isNull(i))JSONObject.NULL else when(c.getType(i)){android.database.Cursor.FIELD_TYPE_INTEGER->c.getLong(i);android.database.Cursor.FIELD_TYPE_FLOAT->c.getDouble(i);else->c.getString(i)})};rows.put(row)}};data.put(table,JSONObject().put("columns",JSONArray(names)).put("rows",rows))};root.put("tables",data)}
 val bytes=root.toString().toByteArray(Charsets.UTF_8);require(bytes.size<=LIMIT){"حجم پشتیبان بیشتر از ۲۰ مگابایت است."}
 BackupArchive.write(bytes,requireNotNull(context.contentResolver.openOutputStream(uri,"wt")))
 }
 suspend fun restore(context:Context,db:AppDatabase,settings:Settings,uri:Uri)=withContext(Dispatchers.IO){
 val bytes=BackupArchive.read(requireNotNull(context.contentResolver.openInputStream(uri)))
 val root=JSONObject(bytes.toString(Charsets.UTF_8));require(root.getString("format")=="personal-growth" && root.getInt("schema")==7){"این نسخه پشتیبان پشتیبانی نمی‌شود؛ پشتیبان خروجی نسخه ۲۰ را انتخاب کن."};val theme=root.getString("theme");require(theme in listOf("system","light","dark"));val sound=root.getBoolean("endSound");val data=root.getJSONObject("tables")
 db.withTransaction{
 require(db.executionDao().active()==null){"ابتدا جلسه تمرکز را ببند."};val sql=db.openHelper.writableDatabase;val names=tables(sql);require(data.keys().asSequence().toSet()==names.toSet()){"جدول‌های پشتیبان کامل نیستند."}
 names.forEach{table->val source=data.getJSONObject(table);val expected=columns(sql,table);val cols=source.getJSONArray("columns");require((0 until cols.length()).map{cols.getString(it)}==expected){"ساختار جدول معتبر نیست: $table"};val rows=source.getJSONArray("rows");require(rows.length()<=100000);(0 until rows.length()).forEach{i->require(rows.getJSONArray(i).length()==expected.size)}}
 names.forEach{sql.execSQL("DELETE FROM `$it`")}
 names.forEach{table->val source=data.getJSONObject(table);val cols=columns(sql,table);val rows=source.getJSONArray("rows");val marks=cols.joinToString(","){"?"};sql.compileStatement("INSERT INTO `$table` (${cols.joinToString(","){"`$it`"}}) VALUES ($marks)").use{stmt->(0 until rows.length()).forEach{i->stmt.clearBindings();val row=rows.getJSONArray(i);cols.indices.forEach{j->val v=row.get(j);when(v){JSONObject.NULL->stmt.bindNull(j+1);is Int->stmt.bindLong(j+1,v.toLong());is Long->stmt.bindLong(j+1,v);is Double->{require(v.isFinite());stmt.bindDouble(j+1,v)};is String->{require(v.length<=100000);stmt.bindString(j+1,v)};else->error("نوع داده پشتیبان معتبر نیست")}};stmt.executeInsert()}}}
 require(db.executionDao().active()==null){"پشتیبان دارای تمرکز باز است و قابل بازیابی نیست."}
 fun count(query:String)=sql.query(query).use{it.moveToFirst();it.getLong(0)}
 require(count("SELECT COUNT(*) FROM tasks WHERE length(trim(title))=0 OR priority NOT BETWEEN 0 AND 2 OR (duration IS NOT NULL AND duration NOT BETWEEN 1 AND 240) OR (dueMinute IS NOT NULL AND dueMinute NOT BETWEEN 0 AND 1439)")==0L){"داده کارها معتبر نیست."}
 require(count("SELECT COUNT(*) FROM wallet WHERE abs(coins)>1000000000 OR xp<0 OR xp>1000000000")==0L){"داده پاداش معتبر نیست."}
 require(count("SELECT COUNT(*) FROM repeat_plans WHERE intervalDays NOT BETWEEN 1 AND 30")==0L){"داده تکرار معتبر نیست."}
 require(count("SELECT COUNT(*) FROM time_logs WHERE startMinute<0 OR minutes<1 OR startMinute+minutes>1440")==0L){"داده زمان معتبر نیست."}
 val goals=db.finalDao().allGoals();goals.filter{!it.archived}.forEach{validateGoal(it,goals)}
 sql.query("PRAGMA foreign_key_check").use{require(!it.moveToFirst()){"ارتباط داده‌ها معتبر نیست."}}
 }
 settings.setTheme(theme);settings.setEndSound(sound)
 }
}
@Composable fun BackupPage(modifier:Modifier,db:AppDatabase,settings:Settings,onBack:()->Unit,onRestored:()->Unit){
 val context=LocalContext.current;val scope=rememberCoroutineScope();var busy by remember{mutableStateOf(false)};var message by remember{mutableStateOf("")};var pending by remember{mutableStateOf<Uri?>(null)}
 val export=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")){uri->if(uri!=null){busy=true;message="";scope.launch{try{GrowthBackup.export(context,db,settings,uri);message="پشتیبان ذخیره شد."}catch(e:Exception){message=e.message?:"ساخت پشتیبان انجام نشد."}finally{busy=false}}}}
 val import=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null)pending=uri}
 Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
 TextButton(onClick=onBack,enabled=!busy){Text("بازگشت")};Text("پشتیبان‌گیری",style=MaterialTheme.typography.headlineSmall)
 Text("اطلاعات فقط روی گوشی ذخیره می‌شوند. از کارها، شبکه، جلسات، خریدها، هدف‌ها، زمان‌ها، آرزوها، سکه‌ها و تنظیمات یک فایل ZIP خروجی بگیر.")
 Text("فایل حاوی اطلاعات شخصی و شماره‌هاست؛ در محل شخصی نگه دار. برای بازیابی، فقط ZIP پشتیبانی که از همین صفحه گرفته‌ای انتخاب کن؛ ZIP سورس برنامه قابل بازیابی نیست.",style=MaterialTheme.typography.bodySmall)
 Button(onClick={export.launch("Growth-backup-${java.time.LocalDate.now()}.zip")},enabled=!busy,modifier=Modifier.fillMaxWidth()){Text("ذخیره پشتیبان")}
 OutlinedButton(onClick={import.launch(arrayOf("application/zip","application/octet-stream"))},enabled=!busy,modifier=Modifier.fillMaxWidth()){Text("انتخاب پشتیبان برای بازیابی")}
 if(busy)LinearProgressIndicator(Modifier.fillMaxWidth());if(message.isNotBlank())Text(message)
 Text("بازیابی جایگزین همه اطلاعات فعلی می‌شود. پیش از آن یک خروجی تازه بگیر. تمرکز باز باید بسته شود. پشتیبان این نسخه با ساختار داده ۷ است؛ سقف فایل بازشده ۲۰ مگابایت.",style=MaterialTheme.typography.bodySmall)
 }
 pending?.let{uri->AlertDialog(onDismissRequest={if(!busy)pending=null},title={Text("جایگزینی تمام اطلاعات؟")},text={Text("اطلاعات فعلی با محتوای این پشتیبان جایگزین می‌شود. فایل نامعتبر پیش از تأیید نهایی پایگاه داده رد می‌شود.")},confirmButton={TextButton(onClick={pending=null;busy=true;scope.launch{try{GrowthBackup.restore(context,db,settings,uri);message="بازیابی انجام شد";onRestored()}catch(e:Exception){message=e.message?:"بازیابی انجام نشد؛ داده‌های قبلی حفظ شدند."}finally{busy=false}}},enabled=!busy){Text("جایگزین کن")}},dismissButton={TextButton(onClick={pending=null},enabled=!busy){Text("انصراف")}})}
}
