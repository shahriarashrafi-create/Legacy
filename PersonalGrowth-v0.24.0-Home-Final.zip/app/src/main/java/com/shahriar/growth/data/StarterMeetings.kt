package com.shahriar.growth.data

import java.time.DayOfWeek
import java.time.LocalDate

/** One-time optional examples for an empty timesheet; no sample rows in existing timesheets. */
fun shouldInsertStarterMeetings(alreadyInitialized: Boolean, existingMeetings: Int): Boolean =
    !alreadyInitialized && existingMeetings == 0

data class StarterMeetingSlot(val title: String, val day: Long, val minute: Int)

/**
 * Schedule actual upcoming meetings, never dates that are already in the past.
 * If today's slot passed, take that weekday in the following week.
 */
fun starterMeetingSlots(today: LocalDate, nowMinute: Int): List<StarterMeetingSlot> {
    val entries = listOf(
        Triple("برنامه‌ریزی هفتگی", DayOfWeek.SATURDAY, 10 * 60),
        Triple("مشاوره تحصیلی", DayOfWeek.SUNDAY, 14 * 60 + 30),
        Triple("مرور مطالب", DayOfWeek.MONDAY, 16 * 60)
    )
    return entries.map { (title, weekday, minute) ->
        var delta = (weekday.value - today.dayOfWeek.value + 7) % 7
        if (delta == 0 && nowMinute >= minute) delta = 7
        StarterMeetingSlot(title, today.plusDays(delta.toLong()).toEpochDay(), minute)
    }
}
