package com.shahriar.growth.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.time.Instant
import java.time.ZoneId

@Entity(tableName="performance_entries",indices=[Index(value=["personId","day"])])
data class PerformanceEntry(@PrimaryKey val id:String=java.util.UUID.randomUUID().toString(),val personId:String?=null,val day:Long,
    val pv:Double=0.0,val gv:Double=0.0,val invitations:Int=0,val presentations:Int=0,val followups:Int=0,val note:String="",
    val archived:Boolean=false,val createdAt:Long=System.currentTimeMillis(),val updatedAt:Long=createdAt)
@Entity(tableName="activity_credits",primaryKeys=["sourceType","sourceId"],indices=[Index("personId")])
data class ActivityCredit(val sourceType:String,val sourceId:String,val personId:String?)
@Entity(tableName="performance_events")
data class PerformanceEvent(@PrimaryKey val id:String=java.util.UUID.randomUUID().toString(),val text:String,val at:Long=System.currentTimeMillis())
@Dao interface ReportingDao {
    @Query("SELECT * FROM performance_entries ORDER BY day DESC,createdAt DESC,id") fun entries():Flow<List<PerformanceEntry>>
    @Query("SELECT * FROM performance_entries WHERE id=:id") suspend fun get(id:String):PerformanceEntry?
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(entry:PerformanceEntry)
    @Query("SELECT * FROM activity_credits") fun credits():Flow<List<ActivityCredit>>
    @Query("SELECT * FROM activity_credits WHERE sourceType=:type AND sourceId=:id") suspend fun credit(type:String,id:String):ActivityCredit?
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun putCredit(credit:ActivityCredit)
    @Insert suspend fun event(event:PerformanceEvent)
    @Query("SELECT * FROM performance_events ORDER BY at DESC,id LIMIT 100") fun history():Flow<List<PerformanceEvent>>
}
suspend fun currentTaskOwner(db:AppDatabase,id:String):String? {
    val link=db.crmDao().link(id)
    return if(link!=null)db.crmDao().contact(link.contactId)?.ownerId else db.networkDao().owner(id)?.personId
}
fun validatePerformance(e:PerformanceEntry){
    require(e.day in LocalDate.of(1900,1,1).toEpochDay()..LocalDate.of(2300,1,1).toEpochDay()){"تاریخ معتبر نیست."}
    require(e.pv.isFinite() && e.gv.isFinite() && e.pv in 0.0..1000000000.0 && e.gv in 0.0..1000000000.0){"PV و GV باید عدد متناهی و نامنفی باشند."}
    require(e.invitations in 0..1000000 && e.presentations in 0..1000000 && e.followups in 0..1000000 && e.note.length<=4000){"تعداد یا طول متن معتبر نیست."}
    require(e.pv>0 || e.gv>0 || e.invitations>0 || e.presentations>0 || e.followups>0){"حداقل یک مقدار بیشتر از صفر ثبت کن."}
}
class ReportingEngine(private val db:AppDatabase){
    suspend fun save(draft:PerformanceEntry)=db.withTransaction{
        validatePerformance(draft);val old=db.reportingDao().get(draft.id)
        require(draft.personId==null || db.networkDao().get(draft.personId)?.archived==false){"فرد بایگانی‌شده یا ناموجود را انتخاب نکن."}
        db.reportingDao().put(draft.copy(note=draft.note.trim(),archived=old?.archived?:false,createdAt=old?.createdAt?:draft.createdAt,updatedAt=System.currentTimeMillis()))
        db.reportingDao().event(PerformanceEvent(text=if(old==null)"ثبت عملکرد دستی" else "ویرایش عملکرد دستی"))
    }
    suspend fun archive(id:String,value:Boolean)=db.withTransaction{val old=db.reportingDao().get(id)?:return@withTransaction;db.reportingDao().put(old.copy(archived=value,updatedAt=System.currentTimeMillis()));db.reportingDao().event(PerformanceEvent(text=if(value)"بایگانی عملکرد دستی" else "بازگردانی عملکرد دستی"))}
    suspend fun creditOrder(id:String,personId:String?)=db.withTransaction{
        val order=requireNotNull(db.crmDao().order(id)){"خرید پیدا نشد."}
        require(personId==null || db.networkDao().get(personId)?.archived==false){"فرد نامعتبر یا بایگانی‌شده است."}
        val name=personId?.let{db.networkDao().get(it)?.name}?:"خودم"
        db.reportingDao().putCredit(ActivityCredit("order",id,personId));db.reportingDao().event(PerformanceEvent(text="اصلاح اعتبار خرید «${order.item}» به نام $name"))
        db.crmDao().event(ContactEvent(contactId=order.contactId,text="اعتبار PV خرید «${order.item}» به نام $name ثبت شد"))
    }
}
data class DayRange(val start:Long,val end:Long){fun contains(day:Long)=day>=start && day<end}
fun weekRange(day:Long):DayRange{val offset=(LocalDate.ofEpochDay(day).dayOfWeek.value+1)%7;return DayRange(day-offset,day-offset+7)}
fun metricScope(owner:String?,team:Boolean,people:List<Person>):Set<String?> = if(!team)setOf(owner) else if(owner==null)setOf<String?>(null)+people.map{it.id} else setOf<String?>(owner)+descendants(owner,people)
fun localDay(at:Long,zone:ZoneId)=Instant.ofEpochMilli(at).atZone(zone).toLocalDate().toEpochDay()
data class PerformanceTotals(val pv:Double,val gv:Double,val groupPv:Double,val invitations:Long,val presentations:Long,val followups:Long,val completedTasks:Int,val heldMeetings:Int,val newMembers:Int,val newRecords:Int)
fun computePerformance(owner:String?,team:Boolean,range:DayRange,people:List<Person>,contacts:List<ContactRecord>,orders:List<CustomerOrder>,tasks:List<Task>,meetings:List<Meeting>,entries:List<PerformanceEntry>,credits:List<ActivityCredit>,zone:ZoneId=ZoneId.systemDefault()):PerformanceTotals {
    val scope=metricScope(owner,team,people);val group=metricScope(owner,true,people);val cm=credits.associateBy{it.sourceType to it.sourceId}
    fun belongs(type:String,id:String,set:Set<String?>)=cm[type to id]?.let{it.personId in set}?:false
    val manual=entries.filter{!it.archived && range.contains(it.day)}
    val sale=orders.filter{!it.archived && range.contains(it.day)}
    fun points(values:List<Double>)=values.fold(java.math.BigDecimal.ZERO){sum,value->sum.add(java.math.BigDecimal.valueOf(value))}.toDouble()
    fun pv(set:Set<String?>)=points(manual.filter{it.personId in set}.map{it.pv}+sale.filter{belongs("order",it.id,set)}.map{it.pv})
    val done=tasks.filter{it.done && it.completedAt?.let{at->range.contains(localDay(at,zone))}==true && belongs("task",it.id,scope)}
    val doneIds=done.map{it.id}.toSet();val held=meetings.filter{it.outcome=="held" && it.taskId in doneIds}
    val autoPresent=held.filter{it.kind=="intro"}.map{it.taskId}.toSet()
    val autoFollow=held.filter{it.kind=="followup"}.map{it.taskId}.toSet()+doneIds.filter{cm.containsKey("followup" to it)}
    val selectedManual=manual.filter{it.personId in scope}
    return PerformanceTotals(pv(scope),points(manual.filter{it.personId==owner}.map{it.gv}),pv(group),selectedManual.sumOf{it.invitations.toLong()},selectedManual.sumOf{it.presentations.toLong()}+autoPresent.size,
        selectedManual.sumOf{it.followups.toLong()}+autoFollow.size,done.size,held.size,
        people.count{range.contains(localDay(it.createdAt,zone)) && belongs("join",it.id,scope)},contacts.count{range.contains(localDay(it.createdAt,zone)) && belongs("contact",it.id,scope)})
}
