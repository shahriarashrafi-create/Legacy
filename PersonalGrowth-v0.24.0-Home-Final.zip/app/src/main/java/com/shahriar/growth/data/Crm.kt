package com.shahriar.growth.data

import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName="contacts",indices=[Index("ownerId"),Index("memberId")])
data class ContactRecord(@PrimaryKey val id:String=java.util.UUID.randomUUID().toString(),val kind:String,
    val name:String,val phone:String="",val city:String="",val source:String="",val interest:String="",val summary:String="",
    val ownerId:String?=null,val stage:String=if(kind=="customer")"active" else "new",val nextTaskId:String?=null,val memberId:String?=null,
    val archived:Boolean=false,val createdAt:Long=System.currentTimeMillis(),val updatedAt:Long=createdAt)
@Entity(tableName="contact_events",indices=[Index("contactId")])
data class ContactEvent(@PrimaryKey val id:String=java.util.UUID.randomUUID().toString(),val contactId:String,val text:String,val at:Long=System.currentTimeMillis())
@Entity(tableName="record_notes",indices=[Index(value=["recordType","recordId"])])
data class RecordNote(@PrimaryKey val id:String=java.util.UUID.randomUUID().toString(),val recordType:String,val recordId:String,val text:String,
    val archived:Boolean=false,val createdAt:Long=System.currentTimeMillis(),val updatedAt:Long=createdAt)
@Entity(tableName="task_contacts",indices=[Index("contactId")])
data class TaskContact(@PrimaryKey val taskId:String,val contactId:String)
@Entity(tableName="customer_orders",indices=[Index("contactId")])
data class CustomerOrder(@PrimaryKey val id:String=java.util.UUID.randomUUID().toString(),val contactId:String,val item:String,val quantity:Int=1,
    val totalToman:Long=0,val pv:Double=0.0,val day:Long,val note:String="",val archived:Boolean=false,val createdAt:Long=System.currentTimeMillis())
@Dao interface CrmDao {
    @Query("SELECT * FROM contacts ORDER BY createdAt DESC,id") fun contacts():Flow<List<ContactRecord>>
    @Query("SELECT * FROM contacts WHERE id=:id") suspend fun contact(id:String):ContactRecord?
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun put(contact:ContactRecord)
    @Insert suspend fun event(event:ContactEvent)
    @Query("SELECT * FROM contact_events WHERE contactId=:id ORDER BY at DESC,id") fun history(id:String):Flow<List<ContactEvent>>
    @Query("SELECT * FROM record_notes ORDER BY updatedAt DESC,id") fun notes():Flow<List<RecordNote>>
    @Query("SELECT * FROM record_notes WHERE id=:id") suspend fun note(id:String):RecordNote?
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun putNote(note:RecordNote)
    @Query("SELECT * FROM task_contacts") fun links():Flow<List<TaskContact>>
    @Query("SELECT * FROM task_contacts WHERE taskId=:id") suspend fun link(id:String):TaskContact?
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun putLink(link:TaskContact)
    @Query("DELETE FROM task_contacts WHERE taskId=:id") suspend fun deleteLink(id:String)
    @Query("SELECT * FROM customer_orders ORDER BY day DESC,createdAt DESC,id") fun orders():Flow<List<CustomerOrder>>
    @Query("SELECT * FROM customer_orders WHERE id=:id") suspend fun order(id:String):CustomerOrder?
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun putOrder(order:CustomerOrder)
}
val prospectStages=listOf("new","contacted","presented","followup","paused","closed","joined")
fun contactStageLabel(stage:String)=when(stage){"active"->"فعال";"inactive"->"غیرفعال";"new"->"جدید";"contacted"->"تماس گرفته";"presented"->"معرفی شده";"followup"->"در پیگیری";"paused"->"فعلاً متوقف";"closed"->"عدم تمایل";"joined"->"عضو شده";else->stage}
fun validateContact(c:ContactRecord,people:List<Person>) {
    require(c.kind in listOf("customer","prospect")){"نوع پرونده معتبر نیست."}
    require(c.name.trim().length in 1..80 && c.phone.length<=30 && c.city.length<=80 && c.source.length<=120 && c.interest.length<=120 && c.summary.length<=4000){"نام یا طول ورودی‌ها معتبر نیست."}
    require(c.ownerId==null || people.any{it.id==c.ownerId && !it.archived}){"مسئول پرونده باید از افراد غیربایگانی باشد."}
    require(if(c.kind=="customer")c.stage in listOf("active","inactive") else c.stage in prospectStages){"مرحله پرونده معتبر نیست."}
}
fun matchesContact(c:ContactRecord,query:String)=normalizeText(listOf(c.name,c.phone,c.city,c.source,c.interest).joinToString(" ")).contains(normalizeText(query.trim()))
fun effectiveOwner(taskId:String,owners:List<TaskOwner>,links:List<TaskContact>,contacts:List<ContactRecord>):String? {
    val link=links.firstOrNull{it.taskId==taskId}
    return if(link!=null)contacts.firstOrNull{it.id==link.contactId}?.ownerId else owners.firstOrNull{it.taskId==taskId}?.personId
}
fun displayedContact(c:ContactRecord,people:List<Person>):ContactRecord = people.firstOrNull{it.id==c.memberId}?.let{c.copy(name=it.name,phone=it.phone,city=it.city)}?:c
fun validateOrder(o:CustomerOrder){require(o.item.trim().length in 1..120 && o.note.length<=2000 && o.quantity in 1..1000000 && o.totalToman in 0..1000000000000L && o.pv.isFinite() && o.pv in 0.0..1000000000.0){"عنوان، تعداد، مبلغ یا PV معتبر نیست."};require(o.day in java.time.LocalDate.of(1900,1,1).toEpochDay()..java.time.LocalDate.of(2300,1,1).toEpochDay()){"تاریخ معتبر نیست."}}
suspend fun clearContactLink(db:AppDatabase,taskId:String){
    val dao=db.crmDao();val link=dao.link(taskId)
    if(link!=null){val c=dao.contact(link.contactId);if(c?.nextTaskId==taskId)dao.put(c.copy(nextTaskId=null,updatedAt=System.currentTimeMillis()));dao.deleteLink(taskId)}
}
class CrmEngine(private val db:AppDatabase){
    private val dao get()=db.crmDao()
    private suspend fun editable(id:String):ContactRecord {val c=requireNotNull(dao.contact(id)){"پرونده پیدا نشد."};require(!c.archived){"ابتدا پرونده را از بایگانی برگردان."};return c}
    private suspend fun audit(c:ContactRecord,text:String){dao.event(ContactEvent(contactId=c.id,text=text))}
    suspend fun save(draft:ContactRecord)=db.withTransaction{
        val old=dao.contact(draft.id)
        require(old==null || (!old.archived && old.memberId==null)){"پرونده عضو شده یا بایگانی از این فرم قابل ویرایش نیست."}
        val c=draft.copy(kind=old?.kind?:draft.kind,name=draft.name.trim(),phone=normalizeText(draft.phone).trim(),city=draft.city.trim(),source=draft.source.trim(),interest=draft.interest.trim(),summary=draft.summary.trim(),
            nextTaskId=old?.nextTaskId,memberId=old?.memberId,archived=old?.archived?:false,createdAt=old?.createdAt?:draft.createdAt,updatedAt=System.currentTimeMillis())
        require(c.stage!="joined"){"عضویت را با دکمه تبدیل به عضو ثبت کن."}
        validateContact(c,db.networkDao().all());dao.put(c);if(old==null)db.reportingDao().putCredit(ActivityCredit("contact",c.id,c.ownerId));audit(c,if(old==null)"ساخت پرونده" else if(old.ownerId!=c.ownerId)"ویرایش و تغییر مسئول پرونده؛ کارهای مرتبط منتقل شدند" else "ویرایش پرونده / مرحله")
    }
    suspend fun archive(id:String,value:Boolean)=db.withTransaction{val c=dao.contact(id)?:return@withTransaction;if(c.archived==value)return@withTransaction;dao.put(c.copy(archived=value,updatedAt=System.currentTimeMillis()));audit(c,if(value)"بایگانی پرونده؛ کارها و سوابق حفظ شدند" else "بازگردانی پرونده")}
    suspend fun customer(id:String)=db.withTransaction{val c=editable(id);if(c.kind=="customer")return@withTransaction;require(c.memberId==null){"این پراسپکت قبلاً عضو شده است."};dao.put(toCustomer(c));audit(c,"تبدیل پراسپکت به مشتری با حفظ شناسه، یادداشت‌ها و کارها")}
    suspend fun member(id:String):String=db.withTransaction{
        val c=editable(id);c.memberId?.let{return@withTransaction it};require(c.kind=="prospect"){"فقط پراسپکت قابل تبدیل به عضو است."}
        require(c.ownerId==null || db.networkDao().get(c.ownerId)?.archived==false){"ابتدا مسئول پرونده را اصلاح کن."}
        val p=memberFromProspect(c)
        db.networkDao().put(p);db.reportingDao().putCredit(ActivityCredit("join",p.id,p.parentId));db.networkDao().event(PersonEvent(personId=p.id,text="عضویت از پرونده پراسپکت"))
        dao.put(c.copy(stage="joined",memberId=p.id,updatedAt=System.currentTimeMillis()));audit(c,"تبدیل به عضو شبکه؛ پرونده اولیه و سوابق حفظ شدند");p.id
    }
    suspend fun note(draft:RecordNote)=db.withTransaction{
        require(draft.text.trim().length in 1..4000){"یادداشت باید بین ۱ تا ۴۰۰۰ حرف باشد."}
        val old=dao.note(draft.id);require(old==null || (old.recordType==draft.recordType && old.recordId==draft.recordId)){"ارتباط یادداشت قابل تغییر نیست."}
        requireRecord(draft.recordType,draft.recordId)
        dao.putNote(draft.copy(text=draft.text.trim(),archived=old?.archived?:false,createdAt=old?.createdAt?:draft.createdAt,updatedAt=System.currentTimeMillis()))
        recordEvent(draft.recordType,draft.recordId,if(old==null)"افزودن یادداشت" else "ویرایش یادداشت")
    }
    suspend fun archiveNote(id:String,value:Boolean)=db.withTransaction{val n=dao.note(id)?:return@withTransaction;requireRecord(n.recordType,n.recordId);dao.putNote(n.copy(archived=value,updatedAt=System.currentTimeMillis()));recordEvent(n.recordType,n.recordId,if(value)"بایگانی یادداشت" else "بازگردانی یادداشت")}
    private suspend fun requireRecord(type:String,id:String){when(type){"person"->require(db.networkDao().get(id)?.archived==false){"فرد بایگانی شده یا پیدا نشد."};"contact"->editable(id);else->error("نوع پرونده معتبر نیست.")}}
    private suspend fun recordEvent(type:String,id:String,text:String){if(type=="person")db.networkDao().event(PersonEvent(personId=id,text=text)) else dao.event(ContactEvent(contactId=id,text=text))}
    suspend fun personTask(personId:String,title:String,day:Long?):String=db.withTransaction{requireRecord("person",personId);require(title.trim().length in 1..120){"عنوان معتبر نیست."};val t=Task(title=title.trim(),dueDay=day);db.taskDao().save(t);db.networkDao().putOwner(TaskOwner(t.id,personId));recordEvent("person",personId,"ساخت کار مرتبط");t.id}
    suspend fun contactTask(contactId:String,title:String,day:Long?,followup:Boolean):String=db.withTransaction{
        val c=editable(contactId);require(title.trim().length in 1..120){"عنوان معتبر نیست."}
        if(followup)c.nextTaskId?.let{tid->db.taskDao().get(tid)?.takeIf{reusableFollowup(c,it,dao.link(tid))}?.let{return@withTransaction it.id}}
        val t=Task(title=title.trim(),dueDay=day);db.taskDao().save(t);dao.putLink(TaskContact(t.id,c.id))
        if(followup){dao.put(c.copy(nextTaskId=t.id,updatedAt=System.currentTimeMillis()));db.reportingDao().putCredit(ActivityCredit("followup",t.id,c.ownerId))}
        audit(c,if(followup)"ثبت کار پیگیری" else "ساخت کار مرتبط");t.id
    }
    suspend fun assign(taskId:String,contactId:String?)=db.withTransaction{
        require(db.taskDao().get(taskId)!=null){"کار پیدا نشد."}
        if(contactId!=null)editable(contactId)
        clearContactLink(db,taskId)
        if(contactId!=null){db.networkDao().removeOwner(taskId);dao.putLink(TaskContact(taskId,contactId))}
        db.taskDao().event(TaskEvent(taskId=taskId,description=if(contactId==null)"حذف ارتباط با پرونده" else "ارتباط با پرونده مشتری/پراسپکت"))
    }
    suspend fun order(draft:CustomerOrder)=db.withTransaction{val c=editable(draft.contactId);require(c.kind=="customer"){"خرید فقط برای مشتری ثبت می‌شود."};validateOrder(draft);val old=dao.order(draft.id);require(old==null || old.contactId==draft.contactId){"مشتری خرید قابل تغییر نیست."};dao.putOrder(draft.copy(item=draft.item.trim(),note=draft.note.trim(),archived=old?.archived?:false,createdAt=old?.createdAt?:draft.createdAt));if(old==null)db.reportingDao().putCredit(ActivityCredit("order",draft.id,c.ownerId));audit(c,if(old==null)"ثبت خرید مشتری" else "ویرایش خرید مشتری")}
    suspend fun archiveOrder(id:String,value:Boolean)=db.withTransaction{val o=dao.order(id)?:return@withTransaction;val c=editable(o.contactId);dao.putOrder(o.copy(archived=value));audit(c,if(value)"بایگانی خرید" else "بازگردانی خرید")}
}
val MIGRATION_4_5=object:Migration(4,5){override fun migrate(db:SupportSQLiteDatabase){
    db.execSQL("CREATE TABLE IF NOT EXISTS contacts (id TEXT NOT NULL, kind TEXT NOT NULL, name TEXT NOT NULL, phone TEXT NOT NULL, city TEXT NOT NULL, source TEXT NOT NULL, interest TEXT NOT NULL, summary TEXT NOT NULL, ownerId TEXT, stage TEXT NOT NULL, nextTaskId TEXT, memberId TEXT, archived INTEGER NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL, PRIMARY KEY(id))")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_contacts_ownerId ON contacts(ownerId)")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_contacts_memberId ON contacts(memberId)")
    db.execSQL("CREATE TABLE IF NOT EXISTS contact_events (id TEXT NOT NULL, contactId TEXT NOT NULL, text TEXT NOT NULL, at INTEGER NOT NULL, PRIMARY KEY(id))")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_contact_events_contactId ON contact_events(contactId)")
    db.execSQL("CREATE TABLE IF NOT EXISTS record_notes (id TEXT NOT NULL, recordType TEXT NOT NULL, recordId TEXT NOT NULL, text TEXT NOT NULL, archived INTEGER NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL, PRIMARY KEY(id))")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_record_notes_recordType_recordId ON record_notes(recordType,recordId)")
    db.execSQL("CREATE TABLE IF NOT EXISTS task_contacts (taskId TEXT NOT NULL, contactId TEXT NOT NULL, PRIMARY KEY(taskId))")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_task_contacts_contactId ON task_contacts(contactId)")
    db.execSQL("CREATE TABLE IF NOT EXISTS customer_orders (id TEXT NOT NULL, contactId TEXT NOT NULL, item TEXT NOT NULL, quantity INTEGER NOT NULL, totalToman INTEGER NOT NULL, pv REAL NOT NULL, day INTEGER NOT NULL, note TEXT NOT NULL, archived INTEGER NOT NULL, createdAt INTEGER NOT NULL, PRIMARY KEY(id))")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_customer_orders_contactId ON customer_orders(contactId)")
}}
fun followupState(c:ContactRecord,tasks:List<Task>,today:Long):String {
    val t=tasks.firstOrNull{it.id==c.nextTaskId}?:return "none"
    return when{t.archived->"archived";t.done->"done";t.dueDay==null->"undated";t.dueDay<=today->"due";else->"future"}
}

fun toCustomer(c:ContactRecord):ContactRecord {
    require(!c.archived){"پرونده بایگانی شده است."}
    if(c.kind=="customer")return c
    require(c.kind=="prospect" && c.memberId==null){"این پرونده قابل تبدیل به مشتری نیست."}
    return c.copy(kind="customer",stage="active",updatedAt=System.currentTimeMillis())
}
fun memberFromProspect(c:ContactRecord):Person {
    require(c.kind=="prospect" && c.memberId==null && !c.archived){"این پرونده قابل تبدیل به عضو نیست."}
    return Person(name=c.name,phone=c.phone,city=c.city,parentId=c.ownerId,note=c.summary)
}
fun reusableFollowup(c:ContactRecord,t:Task,link:TaskContact?):Boolean = c.nextTaskId==t.id && link?.taskId==t.id && link.contactId==c.id && !t.done && !t.archived
