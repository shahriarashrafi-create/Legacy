package com.shahriar.growth

import android.app.*
import android.content.*
import android.os.Build
import android.Manifest
import android.content.pm.PackageManager
import androidx.room.withTransaction
import com.shahriar.growth.data.*
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.flow.first
import java.time.*

object PlanningAlarm {
 private val mutex=Mutex()
 suspend fun refresh(context:Context,db:AppDatabase)=mutex.withLock{
  val now=System.currentTimeMillis();val today=LocalDate.now().toEpochDay();FinalEngine(db).generate(today)
  val notification=context.getSystemService(NotificationManager::class.java);notification.createNotificationChannel(NotificationChannel("planning","یادآوری کارها",NotificationManager.IMPORTANCE_DEFAULT))
  val allowed=(Build.VERSION.SDK_INT<33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED) && notification.areNotificationsEnabled()
  var next=LocalDate.now().plusDays(1).atTime(0,5).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
  var delivered=0
  db.withTransaction{db.finalDao().activeReminders().forEach{r->val t=db.taskDao().get(r.taskId)?:return@forEach;if(t.done || t.archived || t.dueDay==null || t.dueMinute==null)return@forEach
   val due=LocalDate.ofEpochDay(t.dueDay).atStartOfDay(ZoneId.systemDefault()).plusMinutes(t.dueMinute.toLong()).toInstant().toEpochMilli();val at=due-r.leadMinutes*60000L
   if(r.sentFor!=due && at<=now && now-at<=86400000L && allowed){if(delivered<5){val intent=Intent(context,MainActivity::class.java).putExtra("task_id",t.id).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP);val open=PendingIntent.getActivity(context,t.id.hashCode(),intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);notification.notify("task:"+t.id,1,Notification.Builder(context,"planning").setSmallIcon(android.R.drawable.ic_menu_my_calendar).setContentTitle(t.title).setContentText("وقت قدم بعدی توست").setContentIntent(open).setAutoCancel(true).build());db.finalDao().put(r.copy(sentFor=due));delivered++}else next=minOf(next,now+60000)}
   if(r.sentFor!=due && at>now)next=minOf(next,at)
  }}
  val alarm=context.getSystemService(AlarmManager::class.java);val operation=PendingIntent.getBroadcast(context,220,Intent(context,PlanningReceiver::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,maxOf(now+1000,next),operation)
 }
}
class PlanningReceiver:BroadcastReceiver(){override fun onReceive(context:Context,intent:Intent){val pending=goAsync();CoroutineScope(SupervisorJob()+Dispatchers.IO).launch{try{PlanningAlarm.refresh(context.applicationContext,AppDatabase.get(context))}catch(_:Exception){}finally{pending.finish()}}}}
class PlanningBootReceiver:BroadcastReceiver(){override fun onReceive(context:Context,intent:Intent){if(intent.action in setOf(Intent.ACTION_BOOT_COMPLETED,Intent.ACTION_TIME_CHANGED,Intent.ACTION_TIMEZONE_CHANGED,Intent.ACTION_MY_PACKAGE_REPLACED)){val pending=goAsync();CoroutineScope(SupervisorJob()+Dispatchers.IO).launch{try{PlanningAlarm.refresh(context.applicationContext,AppDatabase.get(context))}catch(_:Exception){}finally{pending.finish()}}}}}
