package com.shahriar.growth.data

/** New installs only: existing users and users who removed the examples are never re-seeded. */
fun shouldInsertStarterTasks(alreadyInitialized: Boolean, existingTasks: Int): Boolean =
    !alreadyInitialized && existingTasks == 0

fun starterTaskDrafts(today: Long): List<Task> = listOf(
    Task(title = "مطالعه فصل سوم کتاب", dueDay = today, priority = 2),
    Task(title = "مرور یادداشت‌های امروز", dueDay = today, priority = 1),
    Task(title = "تمرین زبان انگلیسی", dueDay = today, priority = 0)
)
