package com.shahriar.growth

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.shahriar.growth.data.*

@Composable fun NetworkTree(people:List<Person>,selfName:String,rootId:String?,onRoot:(String?)->Unit,onOpen:(String)->Unit) {
    var picking by remember{mutableStateOf(false)}
    var scale by rememberSaveable{mutableFloatStateOf(1f)}
    var collapsed by rememberSaveable{mutableStateOf(emptyList<String>())}
    val root=people.firstOrNull{it.id==rootId && !it.archived}
    val all=people.filter{!it.archived}
    val nodes=remember(all,root?.id,collapsed){treeNodes(all,root?.id,collapsed.toSet())}
    Column(Modifier.fillMaxSize().padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
            TextButton(onClick={picking=true}){Text("شاخه: "+(root?.name?:"کل شبکه"),maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.widthIn(max=200.dp))}
            TextButton(onClick={onRoot(null);collapsed=emptyList()}){Text("ریشه")}
        }
        Text("${faNumber(all.size)} فرد در شبکه · برای دیدن مشخصات روی کارت بزن.",style=MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedButton(onClick={scale=(scale-.15f).coerceAtLeast(.7f)}){Text("−")}
            OutlinedButton(onClick={scale=(scale+.15f).coerceAtMost(1.45f)}){Text("+")}
            TextButton(onClick={collapsed=emptyList();scale=1f}){Text("بازکردن شاخه‌ها")}
        }
        Text("برای جابه‌جایی، افقی و عمودی بکش. جمع/باز فقط نمایش را تغییر می‌دهد.",style=MaterialTheme.typography.bodySmall)
        if(nodes.size>=201 || nodes.any{it.depth==50})Text("برای خوانایی، نمایش به ۲۰۰ فرد و ۵۰ سطح محدود شده؛ یک شاخه را انتخاب کن.",color=MaterialTheme.colorScheme.primary,style=MaterialTheme.typography.bodySmall)
        val dx=190f*scale;val dy=124f;val cardW=170f*scale;val cardH=112f
        val width=dx*((nodes.maxOfOrNull{it.depth}?:0)+1)+20f;val height=dy*nodes.size+20f
        val line=MaterialTheme.colorScheme.outlineVariant
        key(root?.id){
            Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(16.dp))){
                // Physical coordinates are identical for connectors and cards; text remains RTL.
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr){
                    Box(Modifier.fillMaxSize().horizontalScroll(rememberScrollState(),reverseScrolling=true)){
                        Box(Modifier.width(width.dp).fillMaxHeight().verticalScroll(rememberScrollState())){
                            Box(Modifier.width(width.dp).height(height.dp)){
                                Canvas(Modifier.fillMaxSize()){
                                    val index=nodes.withIndex().associate{it.value.id to it.index}
                                    nodes.forEachIndexed{i,n->n.parent?.let{pid->index[pid]?.let{j->
                                        val parent=nodes[j];val px=(width-10-parent.depth*dx-cardW).dp.toPx();val py=(10+j*dy+cardH/2).dp.toPx()
                                        val cx=(width-10-n.depth*dx).dp.toPx();val cy=(10+i*dy+cardH/2).dp.toPx();val mid=(px+cx)/2
                                        drawLine(line,Offset(px,py),Offset(mid,py),2.dp.toPx());drawLine(line,Offset(mid,py),Offset(mid,cy),2.dp.toPx());drawLine(line,Offset(mid,cy),Offset(cx,cy),2.dp.toPx())
                                    }}}
                                }
                                nodes.forEachIndexed{i,n->
                                    val p=all.firstOrNull{it.id==n.id};val hasChildren=all.any{it.parentId==n.id || (n.id=="" && it.parentId==null)}
                                    Card(onClick={p?.let{onOpen(it.id)}},modifier=Modifier.offset((width-10-n.depth*dx-cardW).dp,(10+i*dy).dp).size(cardW.dp,cardH.dp),colors=CardDefaults.cardColors(containerColor=if(p==null)MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface)){
                                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl){Column(Modifier.padding(horizontal=8.dp,vertical=4.dp)){
                                            Text(p?.name?:selfName,maxLines=1,overflow=TextOverflow.Ellipsis,style=MaterialTheme.typography.titleSmall)
                                            Text(p?.let{roleLabel(it.role)+if(it.status=="inactive")" · غیرفعال" else ""}?:"خودم",maxLines=1,style=MaterialTheme.typography.bodySmall)
                                            if(hasChildren)TextButton(onClick={collapsed=if(n.id in collapsed)collapsed-n.id else collapsed+n.id},contentPadding=PaddingValues(0.dp),modifier=Modifier.height(32.dp)){Text(if(n.id in collapsed)"بازکردن شاخه" else "جمع‌کردن شاخه",style=MaterialTheme.typography.labelSmall)}
                                        }}
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if(picking)PersonPicker("نمایش شاخه",all,root?.id,"کل شبکه",onDismiss={picking=false},onPick={onRoot(it);collapsed=emptyList();picking=false})
}
