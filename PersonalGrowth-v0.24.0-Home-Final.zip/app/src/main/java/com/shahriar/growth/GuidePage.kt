package com.shahriar.growth

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.unit.dp
import com.shahriar.growth.data.*

@Composable fun FinalSection(title:String,icon:ImageVector,onClick:()->Unit){Card(onClick=onClick,modifier=Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Row(Modifier.padding(18.dp),horizontalArrangement=Arrangement.spacedBy(12.dp)){Icon(icon,null);Text(title)}}}
@Composable fun TaskGoalsPanel(db:AppDatabase,task:Task,onGoals:()->Unit){val links by db.finalDao().links().collectAsState(emptyList());val goals by db.finalDao().goals().collectAsState(emptyList());val related=goals.filter{g->links.any{it.goalId==g.id && it.taskId==task.id}};if(related.isNotEmpty())Column{Text("هدف‌های مرتبط",style=MaterialTheme.typography.titleMedium);related.forEach{Text(it.title+if(it.archived)" (بایگانی)"else"")};TextButton(onClick=onGoals){Text("بررسی هدف‌ها")}}}
@Composable fun GuidePage(modifier:Modifier,onBack:()->Unit){val tips=listOf(
 "شروع ساده" to "از خانه یک کار برای امروز بساز. برای هر روز یک تا سه قدم اصلی کافی است؛ بخش‌های دیگر را وقتی نیاز داشتی باز کن.",
 "پنج مسیر اصلی" to "خانه برای قدم امروز؛ شبکه برای افراد، مشتریان و پراسپکت‌ها؛ هدف‌ها برای سنجش؛ کارها برای همه اقدام‌ها؛ بخش‌ها برای ابزارهای بیشتر.",
 "یک کار، چند نما" to "کار ساخته‌شده در پرونده فرد، جلسات یا مسیر پیشرفت همان کار فهرست اصلی است. موعد و وضعیت را فقط یک بار تغییر می‌دهی.",
 "تمرکز" to "یک جلسه باز داری. تایمر را می‌توانی متوقف و ادامه بدهی. پایان ساعت به‌تنهایی کار را موفق نمی‌کند؛ نتیجه را خودت ثبت می‌کنی. زیرکارهای اجباری و پیش‌نیازها باید کامل باشند.",
 "مشتری و پراسپکت" to "هر پرونده مسئول دارد. کار پرونده از همان مسئول پیروی می‌کند. تبدیل پراسپکت به مشتری سابقه را نگه می‌دارد؛ پیگیری بعدی از پرونده ساخته می‌شود.",
 "PV و GV" to "PV خرید مشتری از سفارش‌ها وارد گزارش می‌شود. در ثبت دستی دوباره همان PV را وارد نکن. GV مقدار ثبت‌شده شرکت است و با جمع PV تیم یکی نیست. تغییر مسئول فعلی، اعتبار تاریخی عملکرد را عوض نمی‌کند.",
 "هدف‌های کوچک" to "هدف ماهانه را بساز و داخل آن زیرهدف هفتگی یا روزانه تعریف کن. بازه زیرهدف‌ها جداست. ارتباط کار با هدف برای برنامه‌ریزی است؛ پیشرفت از کل عملکرد همان مسئول و بازه به دست می‌آید.",
 "زمان من" to "برنامه آینده با موعد کار هماهنگ است؛ تایم‌شیت برای گذشته است. تمرکز بسته‌شده خودکار محاسبه می‌شود. ساعت‌های با تداخل در برنامه مشخص می‌شوند. یادآوری به مجوز اعلان و محدودیت باتری وابسته است.",
 "سکه و کمبو" to "پاداش با موفقیت کار ایجاد می‌شود. بازگشایی کار پاداش را برمی‌گرداند؛ اگر سکه را خرج کرده باشی، موجودی می‌تواند منفی شود و دریافت جدید تا جبران کسری بسته می‌ماند. کمبو روزهای پیاپی فعالیت است.",
 "حفظ اطلاعات" to "برای نصب نسخه جدید، اپ قبلی را پاک نکن. از بخش پشتیبان خروجی بگیر. پشتیبان شامل اطلاعات شخصی است؛ بازیابی همه داده‌های فعلی را جایگزین می‌کند.")
 LazyColumn(modifier.fillMaxSize().padding(horizontal=20.dp),contentPadding=PaddingValues(vertical=16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){item{Row{Text("راهنمای مسیر من",Modifier.weight(1f),style=MaterialTheme.typography.headlineSmall);TextButton(onClick=onBack){Text("بازگشت")}}};items(tips){(title,body)->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text(title,style=MaterialTheme.typography.titleMedium);Text(body)}}}}}
@Composable fun GlobalSearchPage(modifier:Modifier,db:AppDatabase,today:Long,onBack:()->Unit,onTask:(String)->Unit,onRecord:(String,String)->Unit){
 val tasks by db.taskDao().observe().collectAsState(emptyList());val people by db.networkDao().observe().collectAsState(emptyList());val contacts by db.crmDao().contacts().collectAsState(emptyList());val notes by db.crmDao().notes().collectAsState(emptyList());var q by rememberSaveable{mutableStateOf("")};var archives by rememberSaveable{mutableStateOf(false)}
 val query=normalizeText(q.trim());val tt=if(query.isBlank())emptyList()else tasks.filter{(archives || !it.archived) && normalizeText(it.title+" "+it.note).contains(query)};val pp=if(query.isBlank())emptyList()else people.filter{(archives || !it.archived) && normalizeText(it.name+" "+it.phone+" "+it.city).contains(query)};val cc=if(query.isBlank())emptyList()else contacts.filter{(archives || !it.archived) && normalizeText(it.name+" "+it.phone+" "+it.summary).contains(query)};val nn=if(query.isBlank())emptyList()else notes.filter{(archives || !it.archived) && normalizeText(it.text).contains(query)}
 LazyColumn(modifier.fillMaxSize().padding(horizontal=20.dp),contentPadding=PaddingValues(vertical=16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
 item{Row{Text("جست‌وجوی یکپارچه",Modifier.weight(1f),style=MaterialTheme.typography.headlineSmall);TextButton(onClick=onBack){Text("بازگشت")}};TextInput("نام، شماره، کار یا یادداشت",q,{q=it});FilterChip(archives,{archives=!archives},label={Text("شامل بایگانی")});Text(if(query.isBlank())"برای شروع عبارتی بنویس."else"${faNumber(tt.size+pp.size+cc.size+nn.size)} نتیجه؛ تا ۵۰ مورد از هر بخش نمایش داده می‌شود.")}
 if(tt.isNotEmpty())item{Text("کارها",style=MaterialTheme.typography.titleMedium)}
 items(tt.take(50),key={"t:"+it.id}){t->Card(onClick={onTask(t.id)},modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(t.title);Text(dueLabel(t,today),style=MaterialTheme.typography.bodySmall)}}}
 if(pp.isNotEmpty())item{Text("افراد شبکه",style=MaterialTheme.typography.titleMedium)}
 items(pp.take(50),key={"p:"+it.id}){p->Card(onClick={onRecord("person",p.id)},modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(p.name);Text(p.phone+" · "+p.city);Text("بازکردن پرونده",style=MaterialTheme.typography.bodySmall)}}}
 if(cc.isNotEmpty())item{Text("مشتریان و پراسپکت‌ها",style=MaterialTheme.typography.titleMedium)}
 items(cc.take(50),key={"c:"+it.id}){c->Card(onClick={onRecord(c.kind,c.id)},modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(c.name);Text(c.phone);Text(c.summary);Text("بازکردن پرونده",style=MaterialTheme.typography.bodySmall)}}}
 if(nn.isNotEmpty())item{Text("یادداشت‌های پرونده‌ها",style=MaterialTheme.typography.titleMedium)}
 items(nn.take(50),key={"n:"+it.id}){n->Card(onClick={onRecord(if(n.recordType=="person")"person"else contacts.firstOrNull{it.id==n.recordId}?.kind?:"prospect",n.recordId)},modifier=Modifier.fillMaxWidth()){Text(n.text,Modifier.padding(14.dp))}}
 }
}
