package com.shahriar.growth

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shahriar.growth.data.*
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private val HomeBlue = Color(0xFF355CDE)
private val HomeInk = Color(0xFF17223B)
private val HomeMuted = Color(0xFF78849A)
private val HomePale = Color(0xFFEEF2FF)
private val HomeShape = RoundedCornerShape(21.dp)
private val CoinGold = Color(0xFFF1BE47)
private val DoneGreen = Color(0xFF229E65)
private val ComboOrange = Color(0xFFF07732)

/** All graphics are drawn locally. No image assets or network image requests. */
@Composable
fun HomeRouteLogo(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val track = Path().apply {
            moveTo(.16f*w,.78f*h)
            cubicTo(.36f*w,.58f*h,.49f*w,.40f*h,.60f*w,.18f*h)
            lineTo(.59f*w,.59f*h)
            cubicTo(.65f*w,.66f*h,.75f*w,.72f*h,.85f*w,.80f*h)
            cubicTo(.68f*w,.78f*h,.56f*w,.75f*h,.45f*w,.76f*h)
            cubicTo(.34f*w,.78f*h,.25f*w,.81f*h,.16f*w,.78f*h)
            close()
        }
        drawPath(track, Color.White)
        val flag = Path().apply {
            moveTo(.62f*w,.19f*h)
            lineTo(.82f*w,.19f*h)
            lineTo(.75f*w,.28f*h)
            lineTo(.82f*w,.37f*h)
            lineTo(.62f*w,.37f*h)
            close()
        }
        drawPath(flag, Color.White)
    }
}

@Composable
fun RedesignedHome(
    modifier: Modifier,
    tasks: List<Task>, choice: ActionChoice?, today: Long, active: FocusSession?,
    edges: List<Prerequisite>, meetings: List<Meeting>, wallet: List<WalletEntry>, name: String?,
    onFocus: (String) -> Unit, onSchedule: () -> Unit, onMeetings: (String) -> Unit,
    onNewMeeting: () -> Unit, onNew: () -> Unit, onOpen: (String) -> Unit, onList: (Int) -> Unit
) {
    val xp = wallet.sumOf { it.xp }.coerceAtLeast(0L)
    val coins = wallet.sumOf { it.coins }
    val level = levelFor(xp)
    val xpInLevel = (xp % 100).toInt()
    val finished = tasks.filter {
        !it.archived && it.done && it.completedAt?.let { stamp -> localDay(stamp, ZoneId.systemDefault()) == today } == true
    }
    val doneToday = finished.size
    val totalToday = tasks.count { !it.archived && (it.dueDay == today || it in finished) }
    val combo = streakDays(tasks.filter { it.done }.mapNotNull {
        it.completedAt?.let { stamp -> localDay(stamp, ZoneId.systemDefault()) }
    }.toSet(), today)

    // Meetings have a linked Task. Keep them out of regular task suggestions.
    val meetingTaskIds = meetings.map { it.taskId }.toSet()
    val regularTasks = tasks.filterNot { it.id in meetingTaskIds }
    val first = regularTasks.firstOrNull { it.id == active?.taskId } ?: nextAction(regularTasks, choice, today, edges)
    val candidates = regularTasks.filter { !it.archived && !it.done && it.id != first?.id && it.excludedDay != today }
        .filter { candidate -> edges.none { edge -> edge.taskId == candidate.id && tasks.any { it.id == edge.dependsOnId && !it.done } } }
        .sortedWith(compareBy<Task> { if (it.dueDay == null) 2 else if (it.dueDay < today) 0 else if (it.dueDay == today) 1 else 3 }
            .thenByDescending { it.priority }.thenBy { it.dueDay ?: Long.MAX_VALUE }.thenBy { it.dueMinute ?: 1440 }.thenBy { it.createdAt })
    val suggested = (listOfNotNull(first) + candidates).distinctBy { it.id }.take(3)

    val nowMinute = LocalTime.now().toSecondOfDay() / 60
    val upcoming = meetings.mapNotNull { meeting ->
        tasks.firstOrNull { it.id == meeting.taskId }?.let { task ->
            if (!task.archived && !task.done && task.dueDay != null &&
                (task.dueDay > today || (task.dueDay == today && (task.dueMinute ?: 1440) >= nowMinute))) {
                meeting to task
            } else null
        }
    }.sortedWith(compareBy<Pair<Meeting, Task>> { it.second.dueDay }.thenBy { it.second.dueMinute ?: 1440 }).take(3)

    // Scaffold owns both bars. Only divide its safe *remaining* height, never
    // consume the bottom navigation's pixels. No verticalScroll anywhere on Home.
    BoxWithConstraints(modifier.fillMaxSize().clipToBounds()) {
        val short = maxHeight < 540.dp
        val veryShort = maxHeight < 450.dp
        val outerInset = if (veryShort) 3.dp else if (short) 5.dp else 8.dp
        val sectionGap = if (veryShort) 4.dp else if (short) 6.dp else 9.dp
        val usable = (maxHeight - outerInset * 2 - sectionGap * 2).coerceAtLeast(0.dp)
        // Tasks receive all flexible leftover room: they are always the largest
        // section; three meetings are next; level is the compact third section.
        val levelHeight = (usable * .21f).coerceAtMost(if (short) 110.dp else 122.dp)
        // A compact empty state gives unused room back to the tasks section.
        val meetingHeight = if (upcoming.isEmpty())
            (usable * .18f).coerceAtMost(98.dp)
        else (usable * .27f).coerceAtMost(if (short) 138.dp else 162.dp)
        val tasksHeight = (usable - levelHeight - meetingHeight).coerceAtLeast(0.dp)
        Column(
            Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = outerInset),
            verticalArrangement = Arrangement.spacedBy(sectionGap)
        ) {
            HomeLevelCard(Modifier.fillMaxWidth().height(levelHeight), level, xpInLevel, coins, doneToday, totalToday, combo, veryShort)
            HomeTasksSection(Modifier.fillMaxWidth().height(tasksHeight), suggested, veryShort,
                onAll = { onList(6) }, onNew = onNew, onOpen = onOpen)
            HomeMeetingsSection(Modifier.fillMaxWidth().height(meetingHeight), upcoming, veryShort,
                onSchedule = onSchedule, onMeetings = onMeetings, onAdd = onNewMeeting)
        }
    }
}

@Composable
private fun HomeLevelCard(
    modifier: Modifier, level: Int, xpInLevel: Int, coins: Long, doneToday: Int, totalToday: Int,
    combo: Int, veryShort: Boolean
) {
    Card(
        modifier = modifier.shadow(2.dp, HomeShape, ambientColor = HomeBlue.copy(alpha = .035f), spotColor = HomeBlue.copy(alpha = .035f)),
        shape = HomeShape, colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val iconSize = (maxHeight * .30f).coerceIn(27.dp, 39.dp)
            val metricHeight = (maxHeight * .29f).coerceIn(27.dp, 37.dp)
            Column(
                Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = if (veryShort) 5.dp else 8.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    HomeMedal(level, iconSize)
                    Text("Level $level: ${homeLevelName(level)}", modifier = Modifier.weight(1f),
                        color = HomeInk, fontWeight = FontWeight.Bold,
                        fontSize = if (veryShort) 11.sp else 13.sp, maxLines = 1,
                        overflow = TextOverflow.Ellipsis)
                    Box(Modifier.size(iconSize).background(Color(0xFFE9EDF5), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Outlined.PersonOutline, "آواتار پیش‌فرض", tint = Color(0xFF8290A6), modifier = Modifier.size(iconSize * .57f))
                    }
                }
                // Left-to-right progression inside a RTL page; zero is genuinely empty.
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Box(Modifier.fillMaxWidth().height(if (veryShort) 5.dp else 6.dp)
                        .clip(CircleShape).background(Color(0xFFE9EEFA))) {
                        if (xpInLevel > 0) {
                            Box(Modifier.fillMaxWidth(xpInLevel / 100f).fillMaxHeight().background(HomeBlue, CircleShape))
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().height(metricHeight), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    HomeColoredMetric(Modifier.weight(1f), HomeBlue, Color.White,
                        Icons.Outlined.Bolt, "$xpInLevel/100", veryShort)
                    HomeColoredMetric(Modifier.weight(1f), CoinGold, Color(0xFF493000),
                        Icons.Outlined.Paid, "$coins", veryShort)
                    HomeDoneMetric(Modifier.weight(1f), doneToday, totalToday, veryShort)
                    HomeColoredMetric(Modifier.weight(1f), ComboOrange, Color.White,
                        Icons.Outlined.LocalFireDepartment, "$combo", veryShort)
                }
            }
        }
    }
}

@Composable
private fun HomeColoredMetric(
    modifier: Modifier, background: Color, foreground: Color,
    icon: ImageVector, value: String, veryShort: Boolean
) {
    Box(modifier.clip(RoundedCornerShape(10.dp)).background(background), contentAlignment = Alignment.Center) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(icon, null, tint = foreground, modifier = Modifier.size(if (veryShort) 12.dp else 15.dp))
            Spacer(Modifier.width(2.dp))
            Text(value, fontSize = if (value.length > 7 || veryShort) 9.sp else 10.sp,
                fontWeight = FontWeight.Bold, color = foreground, maxLines = 1,
                overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun HomeDoneMetric(modifier: Modifier, done: Int, total: Int, veryShort: Boolean) {
    Box(modifier.clip(RoundedCornerShape(10.dp)).background(DoneGreen), contentAlignment = Alignment.Center) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Icon(Icons.Outlined.Check, null, tint = Color.White, modifier = Modifier.size(if (veryShort) 11.dp else 13.dp))
            Spacer(Modifier.width(3.dp))
            Box(Modifier.size(if (veryShort) 23.dp else 27.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { if (total == 0) 0f else (done.toFloat() / total).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxSize(), strokeWidth = 2.5.dp,
                    color = Color.White, trackColor = Color.White.copy(alpha = .28f)
                )
                Text("$done", fontSize = if (veryShort) 9.sp else 10.sp,
                    fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
            }
        }
    }
}

/** Ribboned gold medal. Number and geometry make every level individually recognisable. */
@Composable
private fun HomeMedal(level: Int, boxSize: Dp) {
    Box(Modifier.size(boxSize).background(HomePale, RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(3.dp)) {
            val w = size.width
            val h = size.height
            val ribbonLeft = Path().apply {
                moveTo(.28f*w, .02f*h); lineTo(.45f*w, .02f*h)
                lineTo(.59f*w, .45f*h); lineTo(.44f*w, .54f*h); close()
            }
            val ribbonRight = Path().apply {
                moveTo(.57f*w, .02f*h); lineTo(.74f*w, .02f*h)
                lineTo(.59f*w, .54f*h); lineTo(.43f*w, .46f*h); close()
            }
            drawPath(ribbonLeft, Color(0xFF3465D9))
            drawPath(ribbonRight, Color(0xFFE45F4F))
            // Small scallops vary between adjacent levels; no grouped badge tiers.
            val petals = 9 + (level.coerceAtLeast(1) % 5)
            val centre = Offset(.51f*w, .65f*h)
            val radius = min(w, h) * .265f
            for (i in 0 until petals) {
                val angle = 2 * PI * i / petals
                val dot = Offset(centre.x + (radius * cos(angle)).toFloat(), centre.y + (radius * sin(angle)).toFloat())
                drawCircle(Color(0xFFE8A629), radius = w * .074f, center = dot)
            }
            drawCircle(Color(0xFFFFD870), radius = radius * .96f, center = centre)
            drawCircle(Color(0xFFE6A321), radius = radius * .83f, center = centre, style = Stroke(width = 1.6.dp.toPx()))
            drawCircle(Color(0xFFFFF0AF), radius = radius * .72f, center = centre)
        }
        Text("$level", modifier = Modifier.offset(y = boxSize * .12f),
            color = Color(0xFF966113), fontSize = if (boxSize < 32.dp) 10.sp else 12.sp,
            fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun HomeTasksSection(
    modifier: Modifier, suggested: List<Task>, veryShort: Boolean,
    onAll: () -> Unit, onNew: () -> Unit, onOpen: (String) -> Unit
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(if (veryShort) 4.dp else 6.dp)) {
        HomeSectionTitle("قدم بعدی", "مشاهده همه", onAll, veryShort)
        if (suggested.isEmpty()) {
            Card(Modifier.fillMaxWidth().weight(1f), shape = HomeShape,
                colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.fillMaxSize().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("فعلاً کاری برای شروع وجود ندارد.", modifier = Modifier.weight(1f), color = HomeMuted, fontSize = 12.sp)
                    TextButton(onClick = onNew) { Text("افزودن کار") }
                }
            }
        } else {
            // 80:73:73 ratio including the actual remaining task area, independent of phone size.
            val weightBlue = 80f
            val weightWhite = 73f * (suggested.size - 1)
            HomeTaskRow(suggested[0], true, Modifier.fillMaxWidth().weight(weightBlue), veryShort) { onOpen(suggested[0].id) }
            if (suggested.size > 1) {
                Card(Modifier.fillMaxWidth().weight(weightWhite), shape = HomeShape,
                    colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.fillMaxSize()) {
                        suggested.drop(1).forEachIndexed { index, task ->
                            if (index > 0) HorizontalDivider(Modifier.padding(horizontal = 12.dp), color = Color(0xFFE9EDF5))
                            HomeTaskRow(task, false, Modifier.fillMaxWidth().weight(1f), veryShort) { onOpen(task.id) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeTaskRow(task: Task, featured: Boolean, modifier: Modifier, veryShort: Boolean, onStart: () -> Unit) {
    val ink = if (featured) Color.White else HomeInk
    val payout = rewardFor(task.priority)
    val inner: @Composable () -> Unit = {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val constrained = maxHeight < 70.dp || veryShort
            val iconDim = if (constrained) 32.dp else 37.dp
            val buttonDim = if (constrained) 50.dp else 61.dp
            Row(
                Modifier.fillMaxSize().padding(horizontal = if (constrained) 8.dp else 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(if (constrained) 5.dp else 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(iconDim).background(if (featured) Color(0xFF5477ED) else HomePale,
                    RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.ListAlt, null, tint = if (featured) Color.White else HomeBlue,
                        modifier = Modifier.size(if (constrained) 20.dp else 22.dp))
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(if (constrained) 2.dp else 4.dp)) {
                    HomeAutoTaskTitle(task.title, ink, if (constrained) 12f else 14f)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        HomeTaskReward(Icons.Outlined.Bolt, "$TASK_COMPLETION_XP XP", featured, constrained)
                        HomeTaskReward(Icons.Outlined.Paid, "$payout", featured, constrained)
                    }
                }
                Button(onClick = onStart, modifier = Modifier.width(buttonDim).height(if (constrained) 37.dp else 43.dp),
                    shape = RoundedCornerShape(11.dp), contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (featured) Color.White else HomePale,
                        contentColor = HomeBlue), elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)) {
                    Text("شروع", fontSize = if (constrained) 11.sp else 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
    if (featured) Surface(shape = HomeShape, color = HomeBlue, modifier = modifier) { inner() }
    else Box(modifier) { inner() }
}

@Composable
private fun HomeAutoTaskTitle(value: String, color: Color, initialSize: Float) {
    var font by remember(value, initialSize) { mutableStateOf(initialSize) }
    Text(value, modifier = Modifier.fillMaxWidth(), color = color,
        fontWeight = FontWeight.SemiBold, fontSize = font.sp, maxLines = 1,
        softWrap = false, overflow = TextOverflow.Ellipsis,
        onTextLayout = { if (it.didOverflowWidth && font > 10f) font = (font - .5f).coerceAtLeast(10f) })
}

@Composable
private fun HomeTaskReward(icon: ImageVector, value: String, featured: Boolean, compact: Boolean) {
    // Force a stable local text direction so Persian+Latin XP labels never swap around.
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            Icon(icon, null, tint = if (featured) Color.White else HomeBlue,
                modifier = Modifier.size(if (compact) 12.dp else 14.dp))
            Text(value, fontSize = if (compact) 9.sp else 10.sp, maxLines = 1,
                color = if (featured) Color.White.copy(alpha = .95f) else HomeMuted)
        }
    }
}

@Composable
private fun HomeMeetingsSection(
    modifier: Modifier, upcoming: List<Pair<Meeting, Task>>, veryShort: Boolean,
    onSchedule: () -> Unit, onMeetings: (String) -> Unit, onAdd: () -> Unit
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(if (veryShort) 4.dp else 6.dp)) {
        HomeSectionTitle("جلسه بعدی", "تایم‌شیت", onSchedule, veryShort)
        if (upcoming.isEmpty()) {
            Surface(Modifier.fillMaxWidth().weight(1f), color = Color.White, shape = HomeShape) {
                Row(Modifier.fillMaxSize().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("جلسه آینده‌ای ندارید", modifier = Modifier.weight(1f), maxLines = 1,
                        color = HomeMuted, fontSize = if (veryShort) 10.sp else 12.sp)
                    TextButton(onClick = onAdd, contentPadding = PaddingValues(horizontal = 4.dp)) {
                        Icon(Icons.Outlined.Add, null, modifier = Modifier.size(16.dp))
                        Text("افزودن جلسه", fontSize = if (veryShort) 10.sp else 11.sp)
                    }
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                // RTL Row starts with the closest meeting on the right.
                repeat(3) { index ->
                    val event = upcoming.getOrNull(index)
                    if (event == null) {
                        Surface(onClick = onAdd, modifier = Modifier.weight(1f).fillMaxHeight(),
                            shape = RoundedCornerShape(16.dp), color = Color.White,
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE1E6F0))) {
                            Column(Modifier.fillMaxSize().padding(3.dp), horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center) {
                                Icon(Icons.Outlined.AddCircleOutline, "افزودن جلسه", tint = HomeBlue,
                                    modifier = Modifier.size(23.dp))
                                Spacer(Modifier.height(5.dp))
                                Text("افزودن جلسه", fontSize = if (veryShort) 9.sp else 10.sp, color = HomeBlue,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    } else {
                        val (meeting, task) = event
                        Card(onClick = { onMeetings(meeting.id) },
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = .7.dp)) {
                            Column(Modifier.fillMaxSize().padding(horizontal = 5.dp, vertical = 7.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.SpaceEvenly) {
                                Text(homeWeekday(requireNotNull(task.dueDay)), fontSize = if (veryShort) 10.sp else 11.sp,
                                    color = HomeInk, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Text(task.dueMinute?.let { String.format(Locale.ROOT, "%02d:%02d", it / 60, it % 60) } ?: "—",
                                    fontSize = if (veryShort) 12.sp else 14.sp, color = HomeBlue,
                                    fontWeight = FontWeight.Bold, maxLines = 1)
                                HomeMeetingTitle(task.title, veryShort)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeMeetingTitle(title: String, veryShort: Boolean) {
    var font by remember(title, veryShort) { mutableStateOf(if (veryShort) 10f else 11.5f) }
    Text(title, modifier = Modifier.fillMaxWidth(), fontSize = font.sp,
        maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis,
        color = HomeMuted, onTextLayout = {
            if (it.didOverflowWidth && font > 9f) font = (font - .5f).coerceAtLeast(9f)
        })
}

private fun homeWeekday(day: Long): String = when (LocalDate.ofEpochDay(day).dayOfWeek.value) {
    1 -> "دوشنبه"; 2 -> "سه‌شنبه"; 3 -> "چهارشنبه"; 4 -> "پنجشنبه"
    5 -> "جمعه"; 6 -> "شنبه"; else -> "یکشنبه"
}

private fun homeLevelName(level: Int): String = when (level) {
    1 -> "Beginner"; 2 -> "Explorer"; 3 -> "Learner"; 4 -> "Builder"; 5 -> "Achiever";
    6 -> "Rising Star"; 7 -> "Challenger"; 8 -> "Expert"; 9 -> "Champion";
    10 -> "Elite"; 11 -> "Legend"; 12 -> "Master"; else -> "Ascendant $level"
}

@Composable
private fun HomeSectionTitle(title: String, action: String, onClick: () -> Unit, veryShort: Boolean) {
    Row(Modifier.fillMaxWidth().height(if (veryShort) 21.dp else 24.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, fontWeight = FontWeight.ExtraBold, fontSize = if (veryShort) 13.sp else 15.sp,
            maxLines = 1, color = HomeInk)
        Row(Modifier.clickable(onClick = onClick).padding(horizontal = 2.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(action, fontSize = if (veryShort) 10.sp else 11.sp,
                fontWeight = FontWeight.SemiBold, color = HomeBlue)
            Spacer(Modifier.width(3.dp))
            Icon(Icons.Outlined.ArrowBack, null, tint = HomeBlue, modifier = Modifier.size(13.dp))
        }
    }
}
