package com.shahriar.growth

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.shahriar.growth.data.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId

fun minuteLabel(n:Int)=faNumber("%02d:%02d".format(n/60,n%60))
@Composable fun PlanningPage(modifier:Modifier,db:AppDatabase,today:Long,onBack:()->Unit,onOpenTask:(String)->Unit){
 val tasks by db.taskDao().observe().collectAsState(emptyList());val people by db.networkDao().observe().collectAsState(emptyList());val owners by db.networkDao().owners().collectAsState(emptyList());val contacts by db.crmDao().contacts().collectAsState(emptyList());val links by db.crmDao().links().collectAsState(emptyList());val logs by db.finalDao().logs().collectAsState(emptyList());val sessions by db.executionDao().allSessionsFlow().collectAsState(emptyList());val credits by db.reportingDao().credits().collectAsState(emptyList());val plans by db.finalDao().repeats().collectAsState(emptyList())
 var timePeriod by rememberSaveable{mutableStateOf("day")};var tab by rememberSaveable{mutableStateOf("agenda")};var day by rememberSaveable{mutableLongStateOf(today)};var owner by rememberSaveable{mutableStateOf<String?>(null)};var all by rememberSaveable{mutableStateOf(true)};var logEdit by remember{mutableStateOf<TimeLog?>(null)};var logOpen by remember{mutableStateOf(false)};var book by remember{mutableStateOf<Task?>(null)};var picker by remember{mutableStateOf(false)};var error by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)}
 val scope=rememberCoroutineScope();val engine=remember(db){FinalEngine(db)}
 fun act(action:suspend()->Unit){if(busy)return;busy=true;error="";scope.launch{try{action()}catch(e:Exception){error=e.message?:"عملیات انجام نشد"}finally{busy=false}}}
 fun own(t:Task)=links.firstOrNull{it.taskId==t.id}?.let{l->contacts.firstOrNull{it.id==l.contactId}?.ownerId}?:if(links.any{it.taskId==t.id})null else owners.firstOrNull{it.taskId==t.id}?.personId
 val booked=tasks.filter{!it.archived && !it.done && it.dueDay==day && it.dueMinute!=null && (all || own(it)==owner)}.sortedBy{it.dueMinute}
 LazyColumn(modifier.fillMaxSize().padding(horizontal=20.dp),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(vertical=16.dp)){
 item{Row{Text("زمان من",Modifier.weight(1f),style=MaterialTheme.typography.headlineSmall);TextButton(onClick=onBack){Text("بازگشت")}}}
 item{ChoiceRow(listOf("agenda" to "برنامه","time" to "تایم‌شیت","repeat" to "تکرارها"),tab,{tab=it})}
 item{if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}
 if(tab!="repeat"){
 item{Row{TextButton(onClick={day--}){Text("قبل")};TextButton(onClick={day=today}){Text("امروز")};TextButton(onClick={day++}){Text("بعد")}};Text(persianDay(day),style=MaterialTheme.typography.titleMedium);Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){val r=weekRange(day);(r.start until r.end).forEach{d->FilterChip(day==d,{day=d},label={Text(persianDay(d).substringBefore(" "))})}}}
 item{FilterChip(all,{all=!all},label={Text("همه افراد")});if(!all)OwnerChoice(people,owner,{owner=it})}
 }
 when(tab){
 "agenda"->{
 item{Button(onClick={picker=true}){Text("زمان‌بندی کار موجود")};Text("زمان برنامه همان موعد و مدت کار است. ویرایش کار، برنامه را هم تغییر می‌دهد.",style=MaterialTheme.typography.bodySmall)}
 if(booked.isEmpty())item{Text("برای این روز زمان رزرو نکرده‌ای.")}
 items(booked,key={it.id}){t->val overlaps=booked.any{it.id!=t.id && own(it)==own(t) && timeOverlap(t.dueMinute!!,t.duration?:30,it.dueMinute!!,it.duration?:30)};Card(onClick={onOpenTask(t.id)},modifier=Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=if(overlaps)MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surface)){Column(Modifier.padding(14.dp)){Text(minuteLabel(t.dueMinute!!)+" تا "+minuteLabel((t.dueMinute!!+(t.duration?:30)).coerceAtMost(1440)),style=MaterialTheme.typography.titleMedium);Text(t.title);Text(people.firstOrNull{it.id==own(t)}?.name?:"خودم",style=MaterialTheme.typography.bodySmall);if(overlaps)Text("تداخل زمانی؛ موعد یکی از کارها را تغییر بده.",color=MaterialTheme.colorScheme.error);TextButton(onClick={book=t}){Text("تغییر زمان")}}}}
 item{Text("زمان‌های آزاد ۸ تا ۲۲",style=MaterialTheme.typography.titleMedium);if(all)Text("برای دیدن زمان آزاد، فیلتر «همه افراد» را خاموش کن.",style=MaterialTheme.typography.bodySmall)else{val windows=freeSlots(booked.map{it.dueMinute!! to (it.duration?:30)});Text(if(windows.isEmpty())"بازه آزاد ۱۵ دقیقه‌ای نیست." else windows.joinToString("   ·   "){minuteLabel(it.first)+"–"+minuteLabel(it.second)},style=MaterialTheme.typography.bodySmall)}}
 item{Text("کارهای بدون ساعت این روز",style=MaterialTheme.typography.titleMedium)}
 items(tasks.filter{!it.archived && !it.done && it.dueDay==day && it.dueMinute==null && (all || own(it)==owner)},key={it.id}){t->OutlinedButton(onClick={book=t},modifier=Modifier.fillMaxWidth()){Text(t.title)}}
 }
 "time"->{
 val timeRange=reportRange(day,timePeriod)
 val shown=logs.filter{!it.archived && timeRange.contains(it.day) && (all || it.ownerId==owner)}
 val focus=sessions.filter{it.closedAt!=null && timeRange.contains(localDay(it.closedAt,ZoneId.systemDefault())) && (all || credits.firstOrNull{c->c.sourceType=="focus" && c.sourceId==it.id}?.let{c->c.personId==owner}==true)}
 val total=shown.sumOf{it.minutes.toLong()}+focus.sumOf{sessionMinutes(it)}
 item{ChoiceRow(listOf("day" to "روز","week" to "هفته","month" to "ماه شمسی"),timePeriod,{timePeriod=it});Text(persianDay(timeRange.start)+" تا "+persianDay(timeRange.end-1),style=MaterialTheme.typography.bodySmall);Text("${faNumber(total)} دقیقه ثبت‌شده",style=MaterialTheme.typography.titleLarge);Text("تمرکز بسته‌شده در روز پایان جلسه منظور می‌شود؛ سابقه قبل از این نسخه بدون انتساب دقیق، جدا نمایش داده می‌شود.",style=MaterialTheme.typography.bodySmall);Button(onClick={logEdit=null;logOpen=true}){Text("+ زمان دستی")}}
 items(shown,key={it.id}){l->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(l.title);Text(persianDay(l.day),style=MaterialTheme.typography.bodySmall);Text("${minuteLabel(l.startMinute)} · ${faNumber(l.minutes)} دقیقه · "+(people.firstOrNull{it.id==l.ownerId}?.name?:"خودم"));if(l.note.isNotBlank())Text(l.note);Row{TextButton(onClick={logEdit=l;logOpen=true}){Text("ویرایش")};TextButton(onClick={act{db.finalDao().put(l.copy(archived=true))}}){Text("بایگانی")}}}}}
 items(focus,key={it.id}){s->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(tasks.firstOrNull{it.id==s.taskId}?.title?:"تمرکز");Text("تمرکز خودکار: ${faNumber(sessionMinutes(s))} دقیقه · "+persianDay(localDay(s.closedAt!!,ZoneId.systemDefault())));if(credits.none{it.sourceType=="focus" && it.sourceId==s.id})Text("سابقه قدیمی؛ خارج از هدف دقیقه‌ای افراد",style=MaterialTheme.typography.bodySmall);TextButton(onClick={onOpenTask(s.taskId)}){Text("کار مرتبط")}}}}
 if(shown.isEmpty() && focus.isEmpty())item{Text("زمانی برای این روز ثبت نشده است.")}
 item{Text("ثبت‌های بایگانی‌شده",style=MaterialTheme.typography.titleMedium)}
 items(logs.filter{it.archived && timeRange.contains(it.day) && (all || it.ownerId==owner)},key={it.id}){l->OutlinedButton(onClick={act{engine.log(l.copy(archived=false))}},enabled=!busy){Text("بازگردانی ${l.title}")}}
 }
 "repeat"->{
 item{Text("تکرار روزانه یا هفتگی را از جزئیات یک کار فعال کن. نمونه‌ها تا ۳۰ روز آینده ساخته می‌شوند؛ خاموش‌کردن، نمونه‌های موجود را حذف نمی‌کند.",style=MaterialTheme.typography.bodySmall)}
 if(plans.isEmpty())item{Text("هنوز تکراری تعریف نشده است.")}
 items(plans,key={it.id}){p->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(tasks.firstOrNull{it.id==p.taskId}?.title?:"کار منبع");Text("هر ${faNumber(p.intervalDays)} روز · تا ${persianDay(p.endDay)}");Row{TextButton(onClick={onOpenTask(p.taskId)}){Text("تنظیمات کار")};TextButton(onClick={act{db.finalDao().put(p.copy(enabled=!p.enabled));engine.generate(today)}},enabled=!busy && (!p.enabled && p.nextDay<=p.endDay || p.enabled)){Text(if(p.enabled)"توقف نمونه‌های بعدی"else if(p.nextDay>p.endDay)"بازه تمام شده"else"فعال‌سازی")}}}}}
 }
 }
 }
 if(picker)TaskSelect(tasks.filter{!it.archived && !it.done},{picker=false}){book=it;picker=false}
 book?.let{t->BookingForm(t,day,busy,error,{book=null}){date,minute,duration,allow->act{
 val current=requireNotNull(db.taskDao().get(t.id));require(!current.done && !current.archived){"کار دیگر باز نیست."};require(db.taskDao().hasFocus(t.id)==0){"ابتدا تمرکز این کار را ببند."}
 require(minute+duration<=1440){"بازه نباید از پایان روز عبور کند."}
 require(allow || tasks.none{it.id!=t.id && !it.archived && !it.done && it.dueDay==date && it.dueMinute!=null && own(it)==own(t) && timeOverlap(minute,duration,it.dueMinute!!,it.duration?:30)}){"این بازه تداخل دارد؛ زمان را اصلاح کن یا ثبت با تداخل را انتخاب کن."}
 db.taskDao().save(current.copy(dueDay=date,dueMinute=minute,duration=duration));book=null
 }}}
 if(logOpen)LogForm(logEdit,day,people,tasks,busy,error,{logOpen=false}){l->act{engine.log(l);logOpen=false}}
}
@Composable fun BookingForm(task:Task,day:Long,busy:Boolean,error:String,onClose:()->Unit,onSave:(Long,Int,Int,Boolean)->Unit){var date by rememberSaveable{mutableStateOf(persianDay(task.dueDay?:day,true))};var time by rememberSaveable{mutableStateOf("%02d:%02d".format((task.dueMinute?:540)/60,(task.dueMinute?:540)%60))};var duration by rememberSaveable{mutableStateOf((task.duration?:30).toString())};var allow by rememberSaveable{mutableStateOf(false)};FormPage("زمان‌بندی ${task.title}",onClose){TextInput("تاریخ شمسی",date,{date=it});TextInput("ساعت: 09:00",time,{time=it});TextInput("مدت دقیقه: ۱ تا ۲۴۰",duration,{duration=it});Row{Checkbox(allow,{allow=it});Text("ثبت با وجود تداخل")};if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error);val d=parsePersianDay(date);val m=parseMeetingTime(time);val n=normalizeText(duration).toIntOrNull();Button(onClick={onSave(d!!,m!!,n!!,allow)},enabled=!busy && d!=null && m!=null && n!=null && n in 1..240){Text("ذخیره زمان")}}}
@Composable fun LogForm(old:TimeLog?,day:Long,people:List<Person>,tasks:List<Task>,busy:Boolean,error:String,onClose:()->Unit,onSave:(TimeLog)->Unit){
 val id=remember{old?.id?:java.util.UUID.randomUUID().toString()};var title by rememberSaveable{mutableStateOf(old?.title?:"")};var date by rememberSaveable{mutableStateOf(persianDay(old?.day?:day,true))};var start by rememberSaveable{mutableStateOf(if(old!=null)"%02d:%02d".format(old.startMinute/60,old.startMinute%60)else"09:00")};var minutes by rememberSaveable{mutableStateOf(old?.minutes?.toString()?:"30")};var owner by rememberSaveable{mutableStateOf(old?.ownerId)};var note by rememberSaveable{mutableStateOf(old?.note?:"")};var taskId by rememberSaveable{mutableStateOf(old?.taskId)};var picker by remember{mutableStateOf(false)}
 FormPage("زمان انجام‌شده",onClose){TextInput("عنوان",title,{title=it});OwnerChoice(people,owner,{owner=it;taskId=null});TextInput("تاریخ شمسی",date,{date=it});TextInput("ساعت شروع",start,{start=it});TextInput("دقیقه سپری‌شده",minutes,{minutes=it});TextInput("یادداشت",note,{note=it},4000);OutlinedButton(onClick={picker=true}){Text(tasks.firstOrNull{it.id==taskId}?.title?:"اتصال اختیاری به کار")};if(taskId!=null)TextButton(onClick={taskId=null}){Text("قطع ارتباط")};Text("بازه تکراری پذیرفته نمی‌شود. برای فعالیتی که با تایمر ثبت شده زمان دستی وارد نکن.",style=MaterialTheme.typography.bodySmall);if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error);val d=parsePersianDay(date);val m=parseMeetingTime(start);val n=normalizeText(minutes).toIntOrNull();Button(onClick={onSave(TimeLog(id,title,owner,taskId,d!!,m!!,n!!,note))},enabled=!busy && title.isNotBlank() && d!=null && m!=null && n!=null){Text("ذخیره")}}
 if(picker)TaskSelect(tasks.filter{!it.archived},{picker=false}){taskId=it.id;picker=false}
}
@Composable fun TaskPlanningPanel(db:AppDatabase,task:Task,today:Long){
 val plans by db.finalDao().repeats().collectAsState(emptyList());val reminders by db.finalDao().reminders().collectAsState(emptyList());val scope=rememberCoroutineScope();var error by remember{mutableStateOf("")};var dialog by remember{mutableStateOf(false)};var busy by remember{mutableStateOf(false)};val context=LocalContext.current;val permission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){scope.launch{runCatching{PlanningAlarm.refresh(context,db)}}}
 val plan=plans.firstOrNull{it.taskId==task.id};val reminder=reminders.firstOrNull{it.taskId==task.id}
 Column{Text("زمان‌بندی و تکرار",style=MaterialTheme.typography.titleMedium);Row{OutlinedButton(onClick={dialog=true},enabled=!task.archived){Text("تکرار کار")};Spacer(Modifier.width(8.dp));OutlinedButton(onClick={scope.launch{try{require(task.dueDay!=null && task.dueMinute!=null){"اول برای کار تاریخ و ساعت بگذار."};db.finalDao().put(TaskReminder(task.id,0,reminder?.enabled!=true));if(Build.VERSION.SDK_INT>=33)permission.launch(Manifest.permission.POST_NOTIFICATIONS)}catch(e:Exception){error=e.message?:"خطا"}}},enabled=!task.archived && !task.done){Text(if(reminder?.enabled==true)"خاموش‌کردن یادآوری"else"یادآوری در موعد")}};if(reminder?.enabled==true)Text("اعلان در موعد کار؛ ممکن است با محدودیت باتری گوشی تأخیر داشته باشد.",style=MaterialTheme.typography.bodySmall);if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}
 if(dialog){var interval by rememberSaveable{mutableStateOf(plan?.intervalDays?.toString()?:"7")};var start by rememberSaveable{mutableStateOf(persianDay(maxOf(today,plan?.nextDay?:((task.dueDay?:today)+7)),true))};var end by rememberSaveable{mutableStateOf(persianDay(plan?.endDay?:today+90,true))};FormPage("تکرار مستقل کار",{dialog=false}){Text("عنوان، مسئول، مدت و زیرکارها از کار منبع کپی می‌شوند. تغییر هر نمونه مستقل است؛ پیش‌نیازها و ارتباط هدف کپی نمی‌شوند.",style=MaterialTheme.typography.bodySmall);ChoiceRow(listOf("1" to "هر روز","7" to "هر هفته"),interval,{interval=it});TextInput("فاصله به روز: ۱ تا ۳۰",interval,{interval=it});TextInput("شروع شمسی",start,{start=it});TextInput("پایان شمسی",end,{end=it});if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error);val n=normalizeText(interval).toIntOrNull();val a=parsePersianDay(start);val b=parsePersianDay(end);Button(onClick={if(!busy){busy=true;scope.launch{try{FinalEngine(db).repeat(RepeatPlan(plan?.id?:java.util.UUID.randomUUID().toString(),task.id,n!!,a!!,b!!));FinalEngine(db).generate(today);dialog=false}catch(e:Exception){error=e.message?:"خطا"}finally{busy=false}}}},enabled=!busy && n!=null && a!=null && b!=null){Text("ذخیره تکرار")}}}
}
