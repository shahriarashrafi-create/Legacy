package com.shahriar.growth.data
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import java.util.zip.ZipEntry

/** No extraction to disk: strict one-entry, bounded backup container. */
object BackupArchive {
 const val MAX_BYTES=20*1024*1024
 fun write(json:ByteArray,output:OutputStream,maxBytes:Int=MAX_BYTES){
  require(json.isNotEmpty() && json.size<=maxBytes){"حجم پشتیبان معتبر نیست."}
  ZipOutputStream(output).use{it.putNextEntry(ZipEntry("growth.json"));it.write(json);it.closeEntry()}
 }
 fun read(input:InputStream,maxBytes:Int=MAX_BYTES):ByteArray=ZipInputStream(input).use{z->
  val entry=z.nextEntry;require(entry!=null && entry.name=="growth.json" && !entry.isDirectory){"این فایل پشتیبان مسیر من نیست."}
  val data=java.io.ByteArrayOutputStream();val buffer=ByteArray(8192)
  while(true){val n=z.read(buffer);if(n<0)break;require(data.size().toLong()+n<=maxBytes){"پشتیبان بزرگ‌تر از سقف مجاز است."};data.write(buffer,0,n)}
  require(data.size()>0 && z.nextEntry==null){"ساختار پشتیبان معتبر نیست."};data.toByteArray()
 }
}
