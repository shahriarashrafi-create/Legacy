package com.shahriar.growth

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.shahriar.growth.data.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId

@Composable fun FormPage(title:String,onClose:()->Unit,content:@Composable ColumnScope.()->Unit){
 Dialog(onDismissRequest=onClose,properties=DialogProperties(usePlatformDefaultWidth=false)){Surface(Modifier.fillMaxSize().imePadding(),color=MaterialTheme.colorScheme.background){Column(Modifier.safeDrawingPadding().verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
 Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(title,Modifier.weight(1f),style=MaterialTheme.typography.titleLarge);TextButton(onClick=onClose){Text("بستن")}}
 content()
 }}}
}
@Composable fun TextInput(label:String,value:String,onValue:(String)->Unit,max:Int=120){OutlinedTextField(value,{if(it.length<=max)onValue(it)},label={Text(label)},modifier=Modifier.fillMaxWidth())}
@Composable fun ChoiceRow(options:List<Pair<String,String>>,value:String,onValue:(String)->Unit){Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){options.forEach{(id,label)->FilterChip(value==id,{onValue(id)},label={Text(label)})}}}
@Composable fun OwnerChoice(people:List<Person>,owner:String?,onPick:(String?)->Unit){var picker by remember{mutableStateOf(false)};OutlinedButton(onClick={picker=true}){Text("مسئول: "+(people.firstOrNull{it.id==owner}?.name?:"خودم"))};if(picker)AlertDialog(onDismissRequest={picker=false},title={Text("انتخاب مسئول")},text={Column(Modifier.heightIn(max=350.dp).verticalScroll(rememberScrollState())){TextButton(onClick={onPick(null);picker=false}){Text("خودم")};people.filter{!it.archived}.forEach{p->TextButton(onClick={onPick(p.id);picker=false}){Text(p.name)}}}},confirmButton={TextButton(onClick={picker=false}){Text("بستن")}})}
@Composable fun TaskSelect(tasks:List<Task>,onClose:()->Unit,onSelect:(Task)->Unit){var q by rememberSaveable{mutableStateOf("")};FormPage("انتخاب کار",onClose){TextInput("جست‌وجو",q,{q=it});val shown=tasks.filter{normalizeText(it.title).contains(normalizeText(q))};Text("${faNumber(shown.size)} کار");shown.take(100).forEach{t->OutlinedButton(onClick={onSelect(t)},modifier=Modifier.fillMaxWidth()){Text(t.title)}};if(shown.size>100)Text("برای یافتن کار، جست‌وجو را دقیق‌تر کن.")}}
@Composable fun GoalsPage(modifier:Modifier,db:AppDatabase,today:Long,onOpenTask:(String)->Unit,onReport:()->Unit,initialFilter:String="all"){
 val goals by db.finalDao().goals().collectAsState(emptyList());val links by db.finalDao().links().collectAsState(emptyList());val tasks by db.taskDao().observe().collectAsState(emptyList());val people by db.networkDao().observe().collectAsState(emptyList())
 val contacts by db.crmDao().contacts().collectAsState(emptyList());val orders by db.crmDao().orders().collectAsState(emptyList());val meetings by db.meetingDao().observe().collectAsState(emptyList());val entries by db.reportingDao().entries().collectAsState(emptyList());val credits by db.reportingDao().credits().collectAsState(emptyList());val logs by db.finalDao().logs().collectAsState(emptyList());val sessions by db.executionDao().allSessionsFlow().collectAsState(emptyList())
 val scope=rememberCoroutineScope();val engine=remember(db){FinalEngine(db)};var error by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)}
 var edit by remember{mutableStateOf<Goal?>(null)};var parent by remember{mutableStateOf<Goal?>(null)};var editor by remember{mutableStateOf(false)};var detailId by rememberSaveable{mutableStateOf<String?>(null)};var archive by rememberSaveable{mutableStateOf(false)};var owner by rememberSaveable(initialFilter){mutableStateOf<String?>(initialFilter.takeUnless{it=="all" || it=="self"})};var all by rememberSaveable(initialFilter){mutableStateOf(initialFilter=="all")};var selectTask by remember{mutableStateOf(false)}
 fun act(action:suspend()->Unit){if(busy)return;busy=true;error="";scope.launch{try{action()}catch(e:Exception){error=e.message?:"عملیات انجام نشد"}finally{busy=false}}}
 fun actual(g:Goal)=goalActual(g,computePerformance(g.ownerId,g.team,DayRange(g.startDay,g.endDay),people,contacts,orders,tasks,meetings,entries,credits),measuredMinutes(g,logs,sessions,credits,people))
 val detail=goals.firstOrNull{it.id==detailId};BackHandler(detail!=null){detailId=null}
 LazyColumn(modifier.fillMaxSize().padding(horizontal=20.dp),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(vertical=16.dp)){
 item{Row(Modifier.fillMaxWidth()){Text(if(detail==null)"هدف‌های من" else "جزئیات هدف",Modifier.weight(1f),style=MaterialTheme.typography.headlineSmall);if(detail==null)Button(onClick={edit=null;parent=null;editor=true}){Text("+ هدف")}else TextButton(onClick={detailId=null}){Text("بازگشت")}}}
 item{if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}
 if(detail==null){
 item{OutlinedButton(onClick=onReport,modifier=Modifier.fillMaxWidth()){Text("ثبت عملکرد و گزارش PV / GV")};Text("پیشرفت هدف از خریدها، عملکرد و کارهای واقعی محاسبه می‌شود.",style=MaterialTheme.typography.bodySmall)}
 item{Row{FilterChip(all,{all=!all},label={Text("همه افراد")});Spacer(Modifier.width(8.dp));FilterChip(archive,{archive=!archive},label={Text("بایگانی")})};if(!all)OwnerChoice(people,owner,{owner=it})}
 val shown=goals.filter{it.archived==archive && (all || it.ownerId==owner)}
 if(shown.isEmpty())item{Text("هنوز هدفی در این فهرست نیست. یک هدف کوچک و مشخص بساز.")}
 items(shown,key={it.id}){g->GoalCard(g,actual(g),today,people,{detailId=g.id})}
 }else{
 item{GoalCard(detail,actual(detail),today,people,{})}
 item{Row(Modifier.horizontalScroll(rememberScrollState())){TextButton(onClick={edit=detail;parent=goals.firstOrNull{it.id==detail.parentId};editor=true},enabled=!busy && !detail.archived){Text("ویرایش")};TextButton(onClick={act{engine.archive(detail,!detail.archived)}},enabled=!busy){Text(if(detail.archived)"بازگردانی"else"بایگانی با زیرهدف‌ها")};TextButton(onClick={parent=detail;edit=null;editor=true},enabled=!detail.archived){Text("+ زیرهدف")}}}
 item{Text("قدم‌های مرتبط",style=MaterialTheme.typography.titleMedium);Text("این ارتباط برای برنامه‌ریزی است؛ پیشرفت از کل عملکرد همان مسئول و بازه محاسبه می‌شود.",style=MaterialTheme.typography.bodySmall);OutlinedButton(onClick={selectTask=true},enabled=!detail.archived){Text("اتصال کار موجود")}}
 items(links.filter{it.goalId==detail.id},key={it.taskId}){link->tasks.firstOrNull{it.id==link.taskId}?.let{t->Card{Column(Modifier.fillMaxWidth().padding(12.dp)){Text(t.title);Row{TextButton(onClick={onOpenTask(t.id)}){Text("باز کردن")};TextButton(onClick={act{db.finalDao().unlink(detail.id,t.id)}}){Text("قطع ارتباط")}}}}}}
 item{Text("زیرهدف‌ها",style=MaterialTheme.typography.titleMedium)}
 items(goals.filter{it.parentId==detail.id && !it.archived},key={it.id}){g->GoalCard(g,actual(g),today,people,{detailId=g.id})}
 }
 }
 if(editor)GoalForm(edit,parent,people,today,busy,error,{editor=false},{g->act{engine.save(g);editor=false}})
 if(selectTask && detail!=null)TaskSelect(tasks.filter{!it.archived},{selectTask=false}){t->act{val own=currentTaskOwner(db,t.id);require(own in metricScope(detail.ownerId,detail.team,people)){"مسئول کار با محدوده هدف یکسان نیست."};db.finalDao().link(GoalTask(detail.id,t.id));selectTask=false}}
}
@Composable fun GoalCard(g:Goal,actual:Double,today:Long,people:List<Person>,onOpen:()->Unit){Card(onClick=onOpen,modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
 Text(g.title,style=MaterialTheme.typography.titleMedium);Text((people.firstOrNull{it.id==g.ownerId}?.name?:"خودم")+(if(g.team)" و زیرمجموعه"else"")+" · "+goalMetrics.firstOrNull{it.first==g.metric}?.second,style=MaterialTheme.typography.bodySmall)
 Text("${metricNumber(actual)} از ${metricNumber(g.target)}");LinearProgressIndicator(progress={goalRatio(actual,g.target)},modifier=Modifier.fillMaxWidth())
 Text(persianDay(g.startDay)+" تا "+persianDay(g.endDay-1),style=MaterialTheme.typography.bodySmall)
 val left=(g.target-actual).coerceAtLeast(0.0);val days=(g.endDay-maxOf(today,g.startDay)).coerceAtLeast(1)
 Text(when{g.archived->"بایگانی";actual>=g.target->"هدف محقق شد ★";today>=g.endDay->"بازه تمام شد · باقی‌مانده ${metricNumber(left)}";today<g.startDay->"از ${persianDay(g.startDay)} شروع می‌شود";else->"باقی‌مانده ${metricNumber(left)} · پیشنهاد روزانه ${metricNumber(kotlin.math.ceil(left/days*10)/10)}"},style=MaterialTheme.typography.bodySmall)
}}}
@Composable fun GoalForm(old:Goal?,parent:Goal?,people:List<Person>,today:Long,busy:Boolean,error:String,onClose:()->Unit,onSave:(Goal)->Unit){
 val id=remember{old?.id?:java.util.UUID.randomUUID().toString()};var title by rememberSaveable{mutableStateOf(old?.title?:"")};var owner by rememberSaveable{mutableStateOf(if(old!=null)old.ownerId else parent?.ownerId)};var team by rememberSaveable{mutableStateOf(old?.team?:parent?.team?:false)};var metric by rememberSaveable{mutableStateOf(old?.metric?:parent?.metric?:"pv")};var target by rememberSaveable{mutableStateOf(old?.target?.toString()?:"")};var start by rememberSaveable{mutableStateOf(persianDay(old?.startDay?:parent?.startDay?:today,true))};var end by rememberSaveable{mutableStateOf(persianDay((old?.endDay?:parent?.endDay?:reportRange(today,"month").end)-1,true))}
 FormPage(if(old==null)"هدف جدید"else"ویرایش هدف",onClose){
 if(parent!=null)Text("زیرهدف: ${parent.title}");TextInput("عنوان هدف",title,{title=it});if(parent==null){OwnerChoice(people,owner,{owner=it});Row(verticalAlignment=Alignment.CenterVertically){Switch(team,{team=it});Text("همراه زیرمجموعه")};ChoiceRow(goalMetrics,metric,{metric=it})}
 TextInput("مقدار هدف",target,{target=it},16)
 if(old==null && parent==null)ChoiceRow(listOf("day" to "روزانه","week" to "هفتگی","month" to "ماهانه"),""){val r=reportRange(today,it);start=persianDay(r.start,true);end=persianDay(r.end-1,true)}
 TextInput("شروع شمسی: سال/ماه/روز",start,{start=it},12);TextInput("پایان شمسی: سال/ماه/روز",end,{end=it},12)
 Text("برای خردکردن هدف ماهانه، زیرهدف‌های هفتگی یا روزانه بساز؛ بازه‌ها نباید با هم تداخل داشته باشند.",style=MaterialTheme.typography.bodySmall)
 if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
 val a=parsePersianDay(start);val b=parsePersianDay(end);val n=normalizeText(target).replace('٫','.').toDoubleOrNull()
 Button(onClick={onSave(Goal(id,title,owner,team,metric,a!!,b!!+1,n!!,old?.parentId?:parent?.id,old?.archived?:false))},enabled=!busy && title.isNotBlank() && a!=null && b!=null && n!=null){Text("ذخیره هدف")}
 }
}
