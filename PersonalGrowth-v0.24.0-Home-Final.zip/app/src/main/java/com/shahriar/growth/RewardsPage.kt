package com.shahriar.growth

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.shahriar.growth.data.*
import kotlinx.coroutines.launch
import java.time.ZoneId

fun dreamIcon(symbol:String)=when(symbol){"home"->Icons.Outlined.Home;"travel"->Icons.Outlined.Flight;"health"->Icons.Outlined.FavoriteBorder;"learn"->Icons.Outlined.School;"team"->Icons.Outlined.Groups;else->Icons.Outlined.AutoAwesome}
val dreamSymbols=listOf("star" to "رشد","home" to "خانه","travel" to "سفر","health" to "سلامتی","learn" to "یادگیری","team" to "تیم")
@Composable fun DreamsPage(modifier:Modifier,db:AppDatabase,onBack:()->Unit,onGoals:()->Unit){
 val dreams by db.finalDao().dreams().collectAsState(emptyList());val goals by db.finalDao().goals().collectAsState(emptyList());val scope=rememberCoroutineScope();var edit by remember{mutableStateOf<Dream?>(null)};var editor by remember{mutableStateOf(false)};var archived by rememberSaveable{mutableStateOf(false)};var error by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)}
 fun act(action:suspend()->Unit){if(busy)return;busy=true;scope.launch{try{action();error=""}catch(e:Exception){error=e.message?:"ذخیره نشد"}finally{busy=false}}}
 LazyColumn(modifier.fillMaxSize().padding(horizontal=20.dp),verticalArrangement=Arrangement.spacedBy(14.dp),contentPadding=PaddingValues(vertical=16.dp)){
 item{Row{Text("تابلو آرزوها",Modifier.weight(1f),style=MaterialTheme.typography.headlineSmall);TextButton(onClick=onBack){Text("بازگشت")}}}
 item{Row{Button(onClick={edit=null;editor=true}){Text("+ آرزو")};Spacer(Modifier.width(8.dp));FilterChip(archived,{archived=!archived},label={Text("بایگانی")})};Text("یک تصویر ذهنی، یک هدف قابل سنجش، یک قدم امروز.",style=MaterialTheme.typography.bodySmall)}
 item{if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}
 if(dreams.none{it.archived==archived})item{Text("اولین آرزویت را بنویس؛ با یک نماد و یک هدف واقعی به آن شکل بده.")}
 items(dreams.filter{it.archived==archived},key={it.id}){d->Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer)){Column(Modifier.padding(22.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Icon(dreamIcon(d.symbol),d.title,Modifier.size(44.dp));Text(d.title,style=MaterialTheme.typography.headlineSmall);if(d.note.isNotBlank())Text(d.note);d.goalId?.let{id->val g=goals.firstOrNull{it.id==id};Text("هدف مرتبط: "+(g?.title?:"ناموجود")+if(g?.archived==true)" (بایگانی)"else"");TextButton(onClick=onGoals){Text("بررسی هدف‌ها")}};Row{TextButton(onClick={edit=d;editor=true},enabled=!busy){Text("ویرایش")};TextButton(onClick={act{FinalEngine(db).dream(d.copy(archived=!d.archived))}},enabled=!busy){Text(if(d.archived)"بازگردانی"else"بایگانی")}}}}}
 }
 if(editor){val old=edit;val id=remember{old?.id?:java.util.UUID.randomUUID().toString()};var title by rememberSaveable{mutableStateOf(old?.title?:"")};var note by rememberSaveable{mutableStateOf(old?.note?:"")};var symbol by rememberSaveable{mutableStateOf(old?.symbol?:"star")};var goal by rememberSaveable{mutableStateOf(old?.goalId)};var picker by remember{mutableStateOf(false)}
 FormPage("آرزوی من",{editor=false}){TextInput("عنوان آرزو",title,{title=it});ChoiceRow(dreamSymbols,symbol,{symbol=it});Icon(dreamIcon(symbol),null,Modifier.size(48.dp));TextInput("چرا برایم مهم است؟",note,{note=it},4000);OutlinedButton(onClick={picker=true}){Text(goals.firstOrNull{it.id==goal}?.title?:"اتصال اختیاری به هدف")};if(goal!=null)TextButton(onClick={goal=null}){Text("قطع ارتباط هدف")};if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error);Button(onClick={act{FinalEngine(db).dream(Dream(id,title,note,symbol,goal,old?.archived?:false));editor=false}},enabled=!busy && title.isNotBlank()){Text("ذخیره آرزو")}}
 if(picker)AlertDialog(onDismissRequest={picker=false},title={Text("انتخاب هدف")},text={Column(Modifier.heightIn(max=350.dp).verticalScroll(rememberScrollState())){if(goals.none{!it.archived})Text("اول یک هدف بساز.");goals.filter{!it.archived}.forEach{g->TextButton(onClick={goal=g.id;picker=false}){Text(g.title)}}}},confirmButton={TextButton(onClick={picker=false}){Text("بستن")}})
 }
}
@Composable fun RewardsPage(modifier:Modifier,db:AppDatabase,today:Long,onBack:()->Unit){
 val wallet by db.finalDao().wallet().collectAsState(emptyList());val prizes by db.finalDao().prizes().collectAsState(emptyList());val purchases by db.finalDao().redemptions().collectAsState(emptyList());val tasks by db.taskDao().observe().collectAsState(emptyList());val scope=rememberCoroutineScope();var error by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)};var tab by rememberSaveable{mutableStateOf("progress")};var editor by remember{mutableStateOf(false)};var edit by remember{mutableStateOf<Prize?>(null)};var buy by remember{mutableStateOf<Prize?>(null)};var refund by remember{mutableStateOf<Redemption?>(null)};var archives by rememberSaveable{mutableStateOf(false)}
 fun act(action:suspend()->Unit){if(busy)return;busy=true;error="";scope.launch{try{action()}catch(e:Exception){error=e.message?:"عملیات انجام نشد"}finally{busy=false}}}
 val coins=wallet.sumOf{it.coins};val xp=wallet.sumOf{it.xp};val level=levelFor(xp);val done=tasks.filter{it.done};val days=done.mapNotNull{it.completedAt?.let{at->localDay(at,ZoneId.systemDefault())}}.toSet();val streak=streakDays(days,today)
 LazyColumn(modifier.fillMaxSize().padding(horizontal=20.dp),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(vertical=16.dp)){
 item{Row{Text("جشن پیشرفت",Modifier.weight(1f),style=MaterialTheme.typography.headlineSmall);TextButton(onClick=onBack){Text("بازگشت")}}}
 item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer)){Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Icon(Icons.Outlined.EmojiEvents,null,Modifier.size(40.dp));Text("سطح ${faNumber(level)} · ${faNumber(coins)} سکه",style=MaterialTheme.typography.titleLarge);Text("${faNumber(xp)} تجربه · کمبوی ${faNumber(streak)} روز");LinearProgressIndicator(progress={(xp.coerceAtLeast(0)%100)/100f},modifier=Modifier.fillMaxWidth());Text("تا سطح بعد: ${faNumber(100-xp.coerceAtLeast(0)%100)} تجربه",style=MaterialTheme.typography.bodySmall)}}}
 item{ChoiceRow(listOf("progress" to "دستاوردها","shop" to "پاداش‌ها","purchases" to "دریافت‌ها","history" to "تاریخچه"),tab,{tab=it})}
 item{if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error);if(coins<0)Text("پاداش کار بازشده از موجودی کسر شده است؛ با فعالیت بعدی کسری جبران می‌شود.",color=MaterialTheme.colorScheme.error)}
 when(tab){
 "progress"->{
 item{Text("هر کار موفق: ۲۰ تجربه و ۱۰ تا ۲۰ سکه بر اساس اهمیت. بازکردن کار، پاداشش را برمی‌گرداند و انجام دوباره پاداش اضافه نمی‌دهد. کارهای قدیمی پیش از ارتقا، سکه اولیه ندارند.",style=MaterialTheme.typography.bodySmall);Text("کمبو: هر روز دست‌کم یک کار کامل؛ اگر امروز هنوز کاری انجام نداده‌ای، رشته دیروز حفظ می‌شود. کمبو ضریب سکه ندارد.",style=MaterialTheme.typography.bodySmall)}
 val badges=listOf(Triple("قدم اول",done.size>=1,"۱ کار کامل"),Triple("ده قدم",done.size>=10,"۱۰ کار کامل"),Triple("پنجاه قدم",done.size>=50,"۵۰ کار کامل"),Triple("ریتم سه‌روزه",streak>=3,"۳ روز پیاپی"),Triple("هفته پیوسته",streak>=7,"۷ روز پیاپی"),Triple("قهرمان تجربه",level>=5,"رسیدن به سطح ۵"))
 items(badges){(title,earned,rule)->Card(Modifier.fillMaxWidth()){Row(Modifier.padding(16.dp),horizontalArrangement=Arrangement.spacedBy(12.dp)){Icon(if(earned)Icons.Outlined.WorkspacePremium else Icons.Outlined.Lock,null);Column{Text(title+if(earned)" ✓"else"");Text(rule,style=MaterialTheme.typography.bodySmall)}}}}
 item{Text("نشان‌ها وضعیت فعلی تو را نشان می‌دهند و سکه جداگانه ندارند؛ بازکردن کار می‌تواند پیشرفت نشان را کم کند.",style=MaterialTheme.typography.bodySmall)}
 }
 "shop"->{
 item{Row{Button(onClick={edit=null;editor=true}){Text("+ پاداش شخصی")};Spacer(Modifier.width(8.dp));FilterChip(archives,{archives=!archives},label={Text("بایگانی")})};Text("مثلاً یک استراحت دلخواه یا خریدی که برای خودت در نظر گرفته‌ای. سکه‌ها ارزش پولی ندارند.",style=MaterialTheme.typography.bodySmall)}
 if(prizes.none{it.archived==archives})item{Text("اولین پاداش شخصی‌ات را تعریف کن.")}
 items(prizes.filter{it.archived==archives},key={it.id}){p->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(p.title,style=MaterialTheme.typography.titleMedium);Text("${faNumber(p.cost)} سکه");Row(Modifier.horizontalScroll(rememberScrollState())){if(!p.archived)Button(onClick={buy=p},enabled=!busy && coins>=p.cost){Text("دریافت")};TextButton(onClick={edit=p;editor=true}){Text("ویرایش")};TextButton(onClick={act{db.finalDao().put(p.copy(archived=!p.archived))}},enabled=!busy){Text(if(p.archived)"بازگردانی"else"بایگانی")}}}}}
 }
 "purchases"->{if(purchases.isEmpty())item{Text("هنوز پاداشی دریافت نکرده‌ای.")};items(purchases,key={it.id}){p->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(p.title);Text("${faNumber(p.cost)} سکه · "+persianDay(localDay(p.at,ZoneId.systemDefault())));if(p.refunded)Text("سکه برگشت داده شد")else TextButton(onClick={refund=p},enabled=!busy){Text("لغو دریافت و برگشت سکه")}}}}}
 "history"->{items(wallet.take(200),key={it.id}){w->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(w.label);Text("${faNumber(w.coins)} سکه · ${faNumber(w.xp)} تجربه");Text(persianDay(localDay(w.at,ZoneId.systemDefault())),style=MaterialTheme.typography.bodySmall)}}};if(wallet.isEmpty())item{Text("با انجام اولین کار، اینجا پر می‌شود.")};if(wallet.size>200)item{Text("۲۰۰ مورد آخر نمایش داده می‌شود؛ همه موارد در پشتیبان حفظ می‌شوند.")}}
 }
 }
 buy?.let{p->AlertDialog(onDismissRequest={buy=null},title={Text("دریافت ${p.title}")},text={Text("${faNumber(p.cost)} سکه از موجودی کسر شود؟")},confirmButton={TextButton(onClick={buy=null;act{FinalEngine(db).buy(p.id)}}){Text("دریافت")}},dismissButton={TextButton(onClick={buy=null}){Text("انصراف")}})}
 refund?.let{p->AlertDialog(onDismissRequest={refund=null},title={Text("لغو دریافت")},text={Text("دریافت این پاداش لغو و ${faNumber(p.cost)} سکه یک بار برگردانده می‌شود.")},confirmButton={TextButton(onClick={refund=null;act{FinalEngine(db).refund(p.id)}}){Text("برگشت سکه")}},dismissButton={TextButton(onClick={refund=null}){Text("انصراف")}})}
 if(editor){val old=edit;var title by rememberSaveable{mutableStateOf(old?.title?:"")};var cost by rememberSaveable{mutableStateOf(old?.cost?.toString()?:"100")};FormPage("پاداش شخصی",{editor=false}){TextInput("عنوان",title,{title=it});TextInput("قیمت به سکه",cost,{cost=it});if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error);val n=normalizeText(cost).toLongOrNull();Button(onClick={act{FinalEngine(db).prize(Prize(old?.id?:java.util.UUID.randomUUID().toString(),title,n!!,old?.archived?:false));editor=false}},enabled=!busy && title.isNotBlank() && n!=null && n>0){Text("ذخیره")}}}
}
