# Build fix v0.21.1

Added `@OptIn(ExperimentalMaterial3Api::class)` to `GrowthApp` in MainActivity.kt for `ModalBottomSheet`. Updated versionCode/versionName. This fix has not been verified by a Gradle build in this environment. If CI still fails, share the first `e:` Kotlin compiler diagnostic from the full log.
