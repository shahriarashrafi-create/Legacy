# v0.21.0 — Home UI iteration

- Replaced Home layout with approved level card, 4 indicators, three suggested tasks, and up to three future meeting cards.
- Home rewards read existing rewardFor/XP rules; level XP is derived from existing wallet.
- Header simplified to app monogram/name/search/settings.
- Bottom navigation fixed Home and Sections, with 0–3 user-selected shortcuts persisted via existing DataStore.
- Sections sheet supports search, add/remove, and ordering with arrow controls; long-press a bottom shortcut for removal.
- No Room schema migration and no change to task completion, reward calculation, or underlying database entities.

## Known limitations
- Drag-and-drop gestures are NOT yet implemented; the sheet provides tap-to-add and arrow-to-reorder instead.
- Profile photo is a placeholder because the current Profile entity has no photo field.
- Achievement badge/level names are presentational placeholders; per-level bespoke assets are not yet included.
- Task suggestions preserve the original first nextAction decision; additional candidates use existing due date, priority and prerequisite fields.
- Meeting cards rely on meeting-linked tasks with a future due day; meetings without such dates cannot appear.
- Compilation could not be verified: Gradle wrapper attempted to download Gradle 8.7, but the environment has no network access.
