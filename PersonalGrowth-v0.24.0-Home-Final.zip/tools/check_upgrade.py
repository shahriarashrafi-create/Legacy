"""Host SQLite test: v12/schema6 -> v20/schema7; no Android emulator needed."""
import json,re,sqlite3,pathlib
root=pathlib.Path(__file__).resolve().parents[1]
schemas=root/'app/schemas/com.shahriar.growth.data.AppDatabase'
old=json.loads((schemas/'6.json').read_text())['database']
new=json.loads((schemas/'7.json').read_text())['database']
def fresh(schema):
 c=sqlite3.connect(':memory:')
 for e in schema['entities']:
  c.execute(e['createSql'].replace('${TABLE_NAME}',e['tableName']))
  for i in e['indices']:c.execute(i['createSql'].replace('${TABLE_NAME}',e['tableName']))
 return c
c=fresh(old)
for e in old['entities']:
 name=e['tableName'];cols=list(c.execute(f'PRAGMA table_info(`{name}`)'));vals=[]
 for _,col,type_,notnull,default,pk in cols:
  vals.append(None if not notnull and not pk else 1 if type_=='INTEGER' else 1.5 if type_=='REAL' else f'seed:{name}:{col}')
 c.execute(f'INSERT INTO `{name}` VALUES ({",".join("?" for _ in vals)})',vals)
before={e['tableName']:list(c.execute(f'SELECT * FROM `{e["tableName"]}`')) for e in old['entities']}
source=(root/'app/src/main/java/com/shahriar/growth/data/FinalFeatures.kt').read_text()
migration=source.split('val MIGRATION_6_7=')[1].split('fun freeSlots')[0]
statements=re.findall(r'db.execSQL\("([^"\n]+)"\)',migration)
assert len(statements)==10,len(statements)
for sql in statements:c.execute(sql)
expected=fresh(new)
for e in new['entities']:
 name=e['tableName']
 assert list(c.execute(f'PRAGMA table_info(`{name}`)'))==list(expected.execute(f'PRAGMA table_info(`{name}`)')),name
 assert list(c.execute(f'PRAGMA index_list(`{name}`)'))==list(expected.execute(f'PRAGMA index_list(`{name}`)')),name
for name,rows in before.items():assert list(c.execute(f'SELECT * FROM `{name}`'))==rows,name
assert len(new['entities'])==32
print(f'PASS: schema 6 -> 7; all {len(before)} old tables preserve seed data; all 32 table definitions/indices match Room schema.')
