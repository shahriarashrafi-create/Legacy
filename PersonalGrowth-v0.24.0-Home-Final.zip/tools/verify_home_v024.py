#!/usr/bin/env python3
"""Static checks and proportional-height budget tests for v0.24 Home.
This deliberately does not claim to replace an Android device/build test.
"""
from pathlib import Path
import re
import xml.etree.ElementTree as ET
root = Path(__file__).resolve().parents[1]
home = (root/'app/src/main/java/com/shahriar/growth/RedesignedHome.kt').read_text()
main = (root/'app/src/main/java/com/shahriar/growth/MainActivity.kt').read_text()
meetings = (root/'app/src/main/java/com/shahriar/growth/MeetingScreens.kt').read_text()
gradle = (root/'app/build.gradle.kts').read_text()
assert '.verticalScroll(' not in home and 'LazyColumn(' not in home
assert 'val weightBlue = 80f' in home and 'val weightWhite = 73f' in home
assert 'HomeColoredMetric' in home and 'HomeDoneMetric' in home
assert 'val meetingHeight = if (upcoming.isEmpty())' in home
assert 'repeat(3) { index ->' in home and 'upcoming.getOrNull(index)' in home
assert 'onNewMeeting={openMeetings("all","",createNew=true)}' in main
assert 'var editor by rememberSaveable(initialNew)' in meetings
assert 'Spacer(Modifier.fillMaxWidth().navigationBarsPadding())' in main
assert 'HomeRouteLogo' in main
assert 'versionCode = 24' in gradle and 'versionName = "0.24.0"' in gradle
ET.parse(root/'app/src/main/res/drawable/ic_launcher.xml')
for height in range(360, 901, 10):
    short = height < 540
    very_short = height < 450
    outer = 3 if very_short else 5 if short else 8
    gap = 4 if very_short else 6 if short else 9
    budget = height - 2 * outer - 2 * gap
    level = min(budget * .21, 110 if short else 122)
    meetings_full = min(budget * .27, 138 if short else 162)
    meetings_empty = min(budget * .18, 98)
    tasks_full = budget - level - meetings_full
    tasks_empty = budget - level - meetings_empty
    # All sections occupy exactly the scaffold's safe content region.
    assert abs((level + tasks_full + meetings_full + 2*gap + 2*outer) - height) < 1e-6
    assert abs((level + tasks_empty + meetings_empty + 2*gap + 2*outer) - height) < 1e-6
    assert tasks_full > meetings_full > level, (height,level,meetings_full,tasks_full)
    assert tasks_empty > tasks_full
    assert tasks_full > 165, height
print('PASS: static Android source/resource checks')
print('PASS: proportional height budgets for 360–900dp (full/empty meetings)')
print('NOTE: Android compilation and on-device layout not verified here.')
