package com.shahriar.growth

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shahriar.growth.data.*
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private val HomeBlue = Color(0xFF355CDE)
private val HomeInk = Color(0xFF17223B)
private val HomeMuted = Color(0xFF78849A)
private val HomePale = Color(0xFFEEF2FF)
private val HomeShape = RoundedCornerShape(21.dp)
private val CoinGold = Color(0xFFF1BE47)
private val DoneGreen = Color(0xFF229E65)
private val ComboOrange = Color(0xFFF07732)

/** All graphics are drawn locally. No image assets or network image requests. */
@Composable
fun HomeRouteLogo(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val track = Path().apply {
            moveTo(.16f*w,.78f*h)
            cubicTo(.36f*w,.58f*h,.49f*w,.40f*h,.60f*w,.18f*h)
            lineTo(.59f*w,.59f*h)
            cubicTo(.65f*w,.66f*h,.75f*w,.72f*h,.85f*w,.80f*h)
            cubicTo(.68f*w,.78f*h,.56f*w,.75f*h,.45f*w,.76f*h)
            cubicTo(.34f*w,.78f*h,.25f*w,.81f*h,.16f*w,.78f*h)
            close()
        }
        drawPath(track, Color.White)
        val flag = Path().apply {
            moveTo(.62f*w,.19f*h)
            lineTo(.82f*w,.19f*h)
            lineTo(.75f*w,.28f*h)
            lineTo(.82f*w,.37f*h)
            lineTo(.62f*w,.37f*h)
            close()
        }
        drawPath(flag, Color.White)
    }
}

@Composable
fun RedesignedHome(
    modifier: Modifier,
    tasks: List<Task>, choice: ActionChoice?, today: Long, active: FocusSession?,
    edges: List<Prerequisite>, meetings: List<Meeting>,
    onFocus: (String) -> Unit, onSchedule: () -> Unit, onMeetings: (String) -> Unit,
    onNewMeeting: () -> Unit, onNew: () -> Unit, onOpen: (String) -> Unit, onList: (Int) -> Unit
) {
    // Meetings have a linked Task. Keep them out of regular task suggestions.
    val meetingTaskIds = meetings.map { it.taskId }.toSet()
    val regularTasks = tasks.filterNot { it.id in meetingTaskIds }
    val first = regularTasks.firstOrNull { it.id == active?.taskId } ?: nextAction(regularTasks, choice, today, edges)
    val candidates = regularTasks.filter { !it.archived && !it.done && it.id != first?.id && it.excludedDay != today }
        .filter { candidate -> edges.none { edge -> edge.taskId == candidate.id && tasks.any { it.id == edge.dependsOnId && !it.done } } }
        .sortedWith(compareBy<Task> { if (it.dueDay == null) 2 else if (it.dueDay < today) 0 else if (it.dueDay == today) 1 else 3 }
            .thenByDescending { it.priority }.thenBy { it.dueDay ?: Long.MAX_VALUE }.thenBy { it.dueMinute ?: 1440 }.thenBy { it.createdAt })
    val suggested = (listOfNotNull(first) + candidates).distinctBy { it.id }.take(3)

    val nowMinute = LocalTime.now().toSecondOfDay() / 60
    val upcoming = meetings.mapNotNull { meeting ->
        tasks.firstOrNull { it.id == meeting.taskId }?.let { task ->
            if (!task.archived && !task.done && task.dueDay != null &&
                (task.dueDay > today || (task.dueDay == today && (task.dueMinute ?: 1440) >= nowMinute))) {
                meeting to task
            } else null
        }
    }.sortedWith(compareBy<Pair<Meeting, Task>> { it.second.dueDay }.thenBy { it.second.dueMinute ?: 1440 }).take(3)

    // The complete identity+XP+metrics strip is in Scaffold.topBar.
    // This body contains tasks and meetings only, so neither can overlap
    // the fixed header or bottom navigation. No scrolling or clipping hacks.
    BoxWithConstraints(modifier.fillMaxSize()) {
        val short = maxHeight < 430.dp
        val veryShort = maxHeight < 350.dp
        val pad = if (veryShort) 4.dp else if (short) 6.dp else 10.dp
        val sectionGap = if (veryShort) 6.dp else 10.dp
        val usable = (maxHeight - pad*2 - sectionGap).coerceAtLeast(0.dp)
        val meetingHeight = if (upcoming.isEmpty())
            (usable * .23f).coerceAtMost(105.dp)
        else (usable * .36f).coerceAtMost(175.dp)
        val tasksHeight = (usable - meetingHeight).coerceAtLeast(0.dp)
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = pad),
            verticalArrangement = Arrangement.spacedBy(sectionGap)) {
            HomeTasksSection(Modifier.fillMaxWidth().height(tasksHeight), suggested, veryShort,
                onAll = { onList(6) }, onNew = onNew, onOpen = onOpen)
            HomeMeetingsSection(Modifier.fillMaxWidth().height(meetingHeight), upcoming, veryShort,
                onSchedule = onSchedule, onMeetings = onMeetings, onAdd = onNewMeeting)
        }
    }
}

/**
 * One fixed home header, occupying the Scaffold topBar slot.
 * RTL: [medal] [user name (right) / level (left) above XP bar] [local avatar].
 * Four bold gamification chips share one second row. No separate logo,
 * settings/search buttons, or standalone level card on Home.
 */
@Composable
fun HomeUnifiedHeader(name: String?, tasks: List<Task>, wallet: List<WalletEntry>, today: Long) {
    val earnedXp = wallet.sumOf { it.xp }.coerceAtLeast(0L)
    val currentLevel = levelFor(earnedXp)
    val progressXp = (earnedXp % 100L).toInt()
    val coins = wallet.sumOf { it.coins }
    val finished = tasks.filter {
        !it.archived && it.done && it.completedAt?.let { stamp ->
            localDay(stamp, ZoneId.systemDefault()) == today
        } == true
    }
    val doneToday = finished.size
    val combo = streakDays(tasks.filter { it.done }.mapNotNull { it.completedAt?.let { stamp ->
        localDay(stamp, ZoneId.systemDefault())
    } }.toSet(), today)
    val context = LocalContext.current
    // The optional avatar is only read from the application's private local storage.
    val localAvatar = remember(context) { LocalProfileAvatar.load(context) }

    Surface(color = Color.White, shadowElevation = 1.dp) {
        Column(Modifier.fillMaxWidth().statusBarsPadding()
            .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(Modifier.fillMaxWidth().height(55.dp), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                HomeMedal(currentLevel, 52.dp)
                Column(Modifier.weight(1f).fillMaxHeight(),
                    verticalArrangement = Arrangement.Center) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(name?.takeIf { it.isNotBlank() } ?: "نام کاربر",
                            modifier = Modifier.weight(1f), color = HomeInk,
                            fontWeight = FontWeight.Bold, fontSize = 12.sp,
                            textAlign = TextAlign.Right, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("Level $currentLevel: ${homeLevelName(currentLevel)}",
                            modifier = Modifier.weight(1.3f), color = HomeInk,
                            fontWeight = FontWeight.ExtraBold, fontSize = 11.sp,
                            textAlign = TextAlign.Left, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Spacer(Modifier.height(8.dp))
                    // XP goes physically left-to-right even when the whole screen is RTL.
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Box(Modifier.fillMaxWidth().height(8.dp)
                            .clip(RoundedCornerShape(8.dp)).background(Color(0xFFE6ECFA))) {
                            if (progressXp > 0) {
                                Box(Modifier.fillMaxWidth(progressXp / 100f).fillMaxHeight()
                                    .background(Brush.horizontalGradient(listOf(HomeBlue, Color(0xFF7197FF))), RoundedCornerShape(8.dp)))
                            }
                        }
                    }
                }
                Box(Modifier.size(48.dp).clip(CircleShape).background(Color(0xFFE9EDF5)),
                    contentAlignment = Alignment.Center) {
                    if (localAvatar != null) {
                        Image(bitmap = localAvatar, contentDescription = "عکس پروفایل کاربر",
                            contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    } else {
                        Icon(Icons.Outlined.PersonOutline, "آواتار پیش‌فرض", tint = Color(0xFF8290A6),
                            modifier = Modifier.size(29.dp))
                    }
                }
            }
            // Exactly four equally sized colored cards. Each graphic is constructed
            // locally; DONE is not a circular-progress widget.
            Row(Modifier.fillMaxWidth().height(43.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                HomeGameMetric(Modifier.weight(1f), HomeBlue, Color.White, "xp", "$progressXp/100")
                HomeGameMetric(Modifier.weight(1f), CoinGold, Color(0xFF483006), "coin", "$coins")
                HomeGameMetric(Modifier.weight(1f), DoneGreen, Color.White, "done", "$doneToday")
                HomeGameMetric(Modifier.weight(1f), ComboOrange, Color.White, "combo", "$combo")
            }
        }
    }
}

@Composable
private fun HomeGameMetric(modifier: Modifier, background: Color, foreground: Color,
                           kind: String, value: String) {
    Box(modifier.clip(RoundedCornerShape(12.dp))
        .background(Brush.verticalGradient(listOf(background.copy(alpha=.86f), background))),
        contentAlignment = Alignment.Center) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 3.dp),
            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            HomeGameGlyph(kind, Modifier.size(20.dp))
            Spacer(Modifier.width(2.dp))
            val title = when (kind) { "done" -> "DONE"; "combo" -> "COMBO"; else -> "" }
            if (title.isNotEmpty()) {
                Text(title, color = foreground, fontSize = 8.sp, maxLines = 1,
                    fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.width(3.dp))
            }
            Text(value, color = foreground, fontSize = if (value.length > 7) 9.sp else 10.sp,
                fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** Small premium-style, offline Canvas glyphs; no image files or external requests. */
@Composable
private fun HomeGameGlyph(kind: String, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        when (kind) {
            "xp" -> {
                val bolt = Path().apply {
                    moveTo(w*.56f, h*.03f); lineTo(w*.16f,h*.55f)
                    lineTo(w*.47f,h*.55f); lineTo(w*.35f,h*.97f)
                    lineTo(w*.88f,h*.39f); lineTo(w*.57f,h*.39f); close()
                }
                drawPath(bolt, Color(0xFFFFE784))
                drawPath(bolt, Color.White.copy(alpha=.65f), style=Stroke(width=1.dp.toPx()))
            }
            "coin" -> {
                val r = min(w,h)*.46f
                val c = Offset(w*.5f,h*.5f)
                drawCircle(Color(0xFF9C6310), r, c)
                drawCircle(Color(0xFFFFE78B), r*.90f, c)
                drawCircle(Color(0xFFC78C1F), r*.70f, c, style=Stroke(width=1.3.dp.toPx()))
                val star = Path().apply {
                    moveTo(c.x, c.y-r*.54f)
                    lineTo(c.x+r*.20f,c.y-r*.13f)
                    lineTo(c.x+r*.56f,c.y-r*.10f)
                    lineTo(c.x+r*.27f,c.y+r*.17f)
                    lineTo(c.x+r*.36f,c.y+r*.51f)
                    lineTo(c.x,c.y+r*.34f)
                    lineTo(c.x-r*.36f,c.y+r*.51f)
                    lineTo(c.x-r*.27f,c.y+r*.17f)
                    lineTo(c.x-r*.56f,c.y-r*.10f)
                    lineTo(c.x-r*.20f,c.y-r*.13f); close()
                }
                drawPath(star, Color(0xFFB37712))
            }
            "done" -> {
                val shield = Path().apply {
                    moveTo(w*.5f,h*.06f); lineTo(w*.88f,h*.23f)
                    lineTo(w*.82f,h*.67f); lineTo(w*.5f,h*.94f)
                    lineTo(w*.18f,h*.67f); lineTo(w*.12f,h*.23f); close()
                }
                drawPath(shield, Color(0xFFC0FFDC).copy(alpha=.80f))
                val check = Path().apply {
                    moveTo(w*.27f,h*.48f); lineTo(w*.44f,h*.65f); lineTo(w*.75f,h*.32f)
                }
                drawPath(check, Color(0xFF087C41), style=Stroke(width=2.6.dp.toPx()))
            }
            "combo" -> {
                val flame = Path().apply {
                    moveTo(w*.52f,h*.02f)
                    cubicTo(w*.60f,h*.34f,w*.95f,h*.39f,w*.85f,h*.72f)
                    cubicTo(w*.77f,h*1.03f,w*.25f,h*1.03f,w*.15f,h*.73f)
                    cubicTo(w*.05f,h*.43f,w*.37f,h*.30f,w*.52f,h*.02f)
                    close()
                }
                drawPath(flame, Color(0xFFFFE77C))
                val inner = Path().apply {
                    moveTo(w*.48f,h*.45f)
                    cubicTo(w*.62f,h*.63f,w*.69f,h*.72f,w*.59f,h*.84f)
                    cubicTo(w*.47f,h*.97f,w*.28f,h*.79f,w*.36f,h*.65f)
                    close()
                }
                drawPath(inner, Color(0xFFE95D21))
            }
        }
    }
}

/** Ribboned gold medal. Number and geometry make every level individually recognisable. */
@Composable
private fun HomeMedal(level: Int, boxSize: Dp) {
    Box(Modifier.size(boxSize).background(HomePale, RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(3.dp)) {
            val w = size.width
            val h = size.height
            val ribbonLeft = Path().apply {
                moveTo(.28f*w, .02f*h); lineTo(.45f*w, .02f*h)
                lineTo(.59f*w, .45f*h); lineTo(.44f*w, .54f*h); close()
            }
            val ribbonRight = Path().apply {
                moveTo(.57f*w, .02f*h); lineTo(.74f*w, .02f*h)
                lineTo(.59f*w, .54f*h); lineTo(.43f*w, .46f*h); close()
            }
            drawPath(ribbonLeft, Color(0xFF3465D9))
            drawPath(ribbonRight, Color(0xFFE45F4F))
            // Small scallops vary between adjacent levels; no grouped badge tiers.
            val petals = 9 + (level.coerceAtLeast(1) % 5)
            val centre = Offset(.51f*w, .65f*h)
            val radius = min(w, h) * .265f
            for (i in 0 until petals) {
                val angle = 2 * PI * i / petals
                val dot = Offset(centre.x + (radius * cos(angle)).toFloat(), centre.y + (radius * sin(angle)).toFloat())
                drawCircle(Color(0xFFE8A629), radius = w * .074f, center = dot)
            }
            drawCircle(Color(0xFFFFD870), radius = radius * .96f, center = centre)
            drawCircle(Color(0xFFE6A321), radius = radius * .83f, center = centre, style = Stroke(width = 1.6.dp.toPx()))
            drawCircle(Color(0xFFFFF0AF), radius = radius * .72f, center = centre)
        }
        Text("$level", modifier = Modifier.offset(y = boxSize * .12f),
            color = Color(0xFF966113), fontSize = if (boxSize < 32.dp) 10.sp else 12.sp,
            fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun HomeTasksSection(
    modifier: Modifier, suggested: List<Task>, veryShort: Boolean,
    onAll: () -> Unit, onNew: () -> Unit, onOpen: (String) -> Unit
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(if (veryShort) 4.dp else 6.dp)) {
        HomeSectionTitle("قدم بعدی", "مشاهده همه", onAll, veryShort)
        if (suggested.isEmpty()) {
            Card(Modifier.fillMaxWidth().weight(1f), shape = HomeShape,
                colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.fillMaxSize().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("فعلاً کاری برای شروع وجود ندارد.", modifier = Modifier.weight(1f), color = HomeMuted, fontSize = 12.sp)
                    TextButton(onClick = onNew) { Text("افزودن کار") }
                }
            }
        } else {
            // 80:73:73 ratio including the actual remaining task area, independent of phone size.
            val weightBlue = 80f
            val weightWhite = 73f * (suggested.size - 1)
            HomeTaskRow(suggested[0], true, Modifier.fillMaxWidth().weight(weightBlue), veryShort) { onOpen(suggested[0].id) }
            if (suggested.size > 1) {
                Card(Modifier.fillMaxWidth().weight(weightWhite), shape = HomeShape,
                    colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.fillMaxSize()) {
                        suggested.drop(1).forEachIndexed { index, task ->
                            if (index > 0) HorizontalDivider(Modifier.padding(horizontal = 12.dp), color = Color(0xFFE9EDF5))
                            HomeTaskRow(task, false, Modifier.fillMaxWidth().weight(1f), veryShort) { onOpen(task.id) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeTaskRow(task: Task, featured: Boolean, modifier: Modifier, veryShort: Boolean, onStart: () -> Unit) {
    val ink = if (featured) Color.White else HomeInk
    val payout = rewardFor(task.priority)
    val inner: @Composable () -> Unit = {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val constrained = maxHeight < 70.dp || veryShort
            val iconDim = if (constrained) 32.dp else 37.dp
            val buttonDim = if (constrained) 50.dp else 61.dp
            Row(
                Modifier.fillMaxSize().padding(horizontal = if (constrained) 8.dp else 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(if (constrained) 5.dp else 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(iconDim).background(if (featured) Color(0xFF5477ED) else HomePale,
                    RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.ListAlt, null, tint = if (featured) Color.White else HomeBlue,
                        modifier = Modifier.size(if (constrained) 20.dp else 22.dp))
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(if (constrained) 2.dp else 4.dp)) {
                    HomeAutoTaskTitle(task.title, ink, if (constrained) 12f else 14f)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        HomeTaskReward(Icons.Outlined.Bolt, "$TASK_COMPLETION_XP XP", featured, constrained)
                        HomeTaskReward(Icons.Outlined.Paid, "$payout", featured, constrained)
                    }
                }
                Button(onClick = onStart, modifier = Modifier.width(buttonDim).height(if (constrained) 37.dp else 43.dp),
                    shape = RoundedCornerShape(11.dp), contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (featured) Color.White else HomePale,
                        contentColor = HomeBlue), elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)) {
                    Text("شروع", fontSize = if (constrained) 11.sp else 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
    if (featured) Surface(shape = HomeShape, color = HomeBlue, modifier = modifier) { inner() }
    else Box(modifier) { inner() }
}

@Composable
private fun HomeAutoTaskTitle(value: String, color: Color, initialSize: Float) {
    var font by remember(value, initialSize) { mutableStateOf(initialSize) }
    Text(value, modifier = Modifier.fillMaxWidth(), color = color,
        fontWeight = FontWeight.SemiBold, fontSize = font.sp, maxLines = 1,
        softWrap = false, overflow = TextOverflow.Ellipsis,
        onTextLayout = { if (it.didOverflowWidth && font > 10f) font = (font - .5f).coerceAtLeast(10f) })
}

@Composable
private fun HomeTaskReward(icon: ImageVector, value: String, featured: Boolean, compact: Boolean) {
    // Force a stable local text direction so Persian+Latin XP labels never swap around.
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            Icon(icon, null, tint = if (featured) Color.White else HomeBlue,
                modifier = Modifier.size(if (compact) 12.dp else 14.dp))
            Text(value, fontSize = if (compact) 9.sp else 10.sp, maxLines = 1,
                color = if (featured) Color.White.copy(alpha = .95f) else HomeMuted)
        }
    }
}

@Composable
private fun HomeMeetingsSection(
    modifier: Modifier, upcoming: List<Pair<Meeting, Task>>, veryShort: Boolean,
    onSchedule: () -> Unit, onMeetings: (String) -> Unit, onAdd: () -> Unit
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(if (veryShort) 4.dp else 6.dp)) {
        HomeSectionTitle("جلسه بعدی", "تایم‌شیت", onSchedule, veryShort)
        if (upcoming.isEmpty()) {
            Surface(Modifier.fillMaxWidth().weight(1f), color = Color.White, shape = HomeShape) {
                Row(Modifier.fillMaxSize().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("جلسه آینده‌ای ندارید", modifier = Modifier.weight(1f), maxLines = 1,
                        color = HomeMuted, fontSize = if (veryShort) 10.sp else 12.sp)
                    TextButton(onClick = onAdd, contentPadding = PaddingValues(horizontal = 4.dp)) {
                        Icon(Icons.Outlined.Add, null, modifier = Modifier.size(16.dp))
                        Text("افزودن جلسه", fontSize = if (veryShort) 10.sp else 11.sp)
                    }
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                // RTL Row starts with the closest meeting on the right.
                repeat(3) { index ->
                    val event = upcoming.getOrNull(index)
                    if (event == null) {
                        Surface(onClick = onAdd, modifier = Modifier.weight(1f).fillMaxHeight(),
                            shape = RoundedCornerShape(16.dp), color = Color.White,
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE1E6F0))) {
                            Column(Modifier.fillMaxSize().padding(3.dp), horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center) {
                                Icon(Icons.Outlined.AddCircleOutline, "افزودن جلسه", tint = HomeBlue,
                                    modifier = Modifier.size(23.dp))
                                Spacer(Modifier.height(5.dp))
                                Text("افزودن جلسه", fontSize = if (veryShort) 9.sp else 10.sp, color = HomeBlue,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    } else {
                        val (meeting, task) = event
                        Card(onClick = { onMeetings(meeting.id) },
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = .7.dp)) {
                            Column(Modifier.fillMaxSize().padding(horizontal = 5.dp, vertical = 7.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.SpaceEvenly) {
                                Text(homeWeekday(requireNotNull(task.dueDay)), fontSize = if (veryShort) 10.sp else 11.sp,
                                    color = HomeInk, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Text(task.dueMinute?.let { String.format(Locale.ROOT, "%02d:%02d", it / 60, it % 60) } ?: "—",
                                    fontSize = if (veryShort) 12.sp else 14.sp, color = HomeBlue,
                                    fontWeight = FontWeight.Bold, maxLines = 1)
                                HomeMeetingTitle(task.title, veryShort)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeMeetingTitle(title: String, veryShort: Boolean) {
    var font by remember(title, veryShort) { mutableStateOf(if (veryShort) 10f else 11.5f) }
    Text(title, modifier = Modifier.fillMaxWidth(), fontSize = font.sp,
        maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis,
        color = HomeMuted, onTextLayout = {
            if (it.didOverflowWidth && font > 9f) font = (font - .5f).coerceAtLeast(9f)
        })
}

private fun homeWeekday(day: Long): String = when (LocalDate.ofEpochDay(day).dayOfWeek.value) {
    1 -> "دوشنبه"; 2 -> "سه‌شنبه"; 3 -> "چهارشنبه"; 4 -> "پنجشنبه"
    5 -> "جمعه"; 6 -> "شنبه"; else -> "یکشنبه"
}

private fun homeLevelName(level: Int): String = when (level) {
    1 -> "Beginner"; 2 -> "Explorer"; 3 -> "Learner"; 4 -> "Builder"; 5 -> "Achiever";
    6 -> "Rising Star"; 7 -> "Challenger"; 8 -> "Expert"; 9 -> "Champion";
    10 -> "Elite"; 11 -> "Legend"; 12 -> "Master"; else -> "Ascendant $level"
}

@Composable
private fun HomeSectionTitle(title: String, action: String, onClick: () -> Unit, veryShort: Boolean) {
    Row(Modifier.fillMaxWidth().height(if (veryShort) 21.dp else 24.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, fontWeight = FontWeight.ExtraBold, fontSize = if (veryShort) 13.sp else 15.sp,
            maxLines = 1, color = HomeInk)
        Row(Modifier.clickable(onClick = onClick).padding(horizontal = 2.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(action, fontSize = if (veryShort) 10.sp else 11.sp,
                fontWeight = FontWeight.SemiBold, color = HomeBlue)
            Spacer(Modifier.width(3.dp))
            Icon(Icons.Outlined.ArrowBack, null, tint = HomeBlue, modifier = Modifier.size(13.dp))
        }
    }
}
