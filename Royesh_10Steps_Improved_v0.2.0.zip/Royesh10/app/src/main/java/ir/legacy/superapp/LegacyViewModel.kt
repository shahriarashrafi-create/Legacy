package ir.legacy.superapp

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import ir.legacy.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import java.util.Calendar
import java.util.UUID
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

private object LocalCredentials {
    fun salt(): String = ByteArray(16).also { SecureRandom().nextBytes(it) }.let { Base64.getEncoder().encodeToString(it) }
    fun hash(password: String, salt: String): String {
        val spec = PBEKeySpec(password.toCharArray(), Base64.getDecoder().decode(salt), 120_000, 256)
        return try { Base64.getEncoder().encodeToString(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded) }
        finally { spec.clearPassword() }
    }
    fun matches(password: String, salt: String, expected: String): Boolean =
        MessageDigest.isEqual(Base64.getDecoder().decode(hash(password, salt)), Base64.getDecoder().decode(expected))
}

@OptIn(ExperimentalCoroutinesApi::class)
class LegacyViewModel(application: Application) : AndroidViewModel(application) {
    private val store = SessionStore(application)
    private val database = RoyeshDatabase.get(application)
    private val dao = database.dao()
    private val sharing = SharingStarted.Eagerly
    val accountId = store.accountId.stateIn(viewModelScope, sharing, "")
    val account = accountId.flatMapLatest { id -> if (id.isBlank()) flowOf(null) else dao.observeAccount(id) }
        .stateIn(viewModelScope, sharing, null)
    val signedIn = accountId.map { it.isNotBlank() }.stateIn(viewModelScope, sharing, false)
    val onboardingDone = account.map { it?.onboardingDone == true }.stateIn(viewModelScope, sharing, false)
    val displayName = account.map { it?.displayName ?: "عضو جدید" }.stateIn(viewModelScope, sharing, "عضو جدید")
    val tasks = accountId.flatMapLatest { if(it.isBlank()) flowOf(emptyList()) else dao.observeTasks(it) }
        .stateIn(viewModelScope, sharing, emptyList())
    val steps = accountId.flatMapLatest { if(it.isBlank()) flowOf(emptyList()) else dao.observeSteps(it) }
        .stateIn(viewModelScope, sharing, emptyList())
    val activities = accountId.flatMapLatest { if(it.isBlank()) flowOf(emptyList()) else dao.observeActivities(it) }
        .stateIn(viewModelScope, sharing, emptyList())
    val focusSessions = accountId.flatMapLatest { if(it.isBlank()) flowOf(emptyList()) else dao.observeFocusSessions(it) }
        .stateIn(viewModelScope, sharing, emptyList())
    val draft = accountId.flatMapLatest { if(it.isBlank()) flowOf(null) else dao.observeDraft(it) }
        .stateIn(viewModelScope, sharing, null)
    val members = account.flatMapLatest { if(it==null) flowOf(emptyList()) else dao.organizationMembers(it.organizationId) }
        .stateIn(viewModelScope, sharing, emptyList())
    private val _message = MutableStateFlow("")
    val message: StateFlow<String> = _message
    val legacyAvailable = store.legacyState.map { it.hadProfile }.stateIn(viewModelScope, sharing, false)
    init {
        viewModelScope.launch {
            // Upgrade to a personal local account without copying old tasks into a new user's data.
            if(store.accountId.first().isBlank() && store.shouldAutoRestore.first() && store.legacyState.first().wasSignedIn && dao.taskCount("legacy-local")>0) {
                restoreLegacyInternal()
            }
        }
    }
    fun clearMessage() { _message.value = "" }
    private suspend fun owner(): String? = store.accountId.first().ifBlank { null }

    fun register(name: String, phone: String, password: String, sponsorPhone: String, organizationName: String) = viewModelScope.launch {
        val cleanPhone = phone.filter { it.isDigit() || it == '+' }
        if (name.trim().length < 2 || cleanPhone.length !in 9..15 || password.length < 8) {
            _message.value = "نام، شماره معتبر و رمز حداقل ۸ کاراکتری لازم است."; return@launch
        }
        withContext(Dispatchers.IO) {
            try {
                if(dao.accountByPhone(cleanPhone)!=null) { _message.value = "این شماره قبلاً ثبت شده است."; return@withContext }
                val sponsor = sponsorPhone.trim().takeIf { it.isNotEmpty() }?.let { dao.accountByPhone(it.filter { c->c.isDigit() || c=='+' }) }
                if(sponsorPhone.isNotBlank() && sponsor==null) { _message.value = "حامی با این شماره در نسخه محلی وجود ندارد."; return@withContext }
                if(sponsor == null && organizationName.trim().length < 2) { _message.value = "نام سازمان خود را وارد کن."; return@withContext }
                val salt = LocalCredentials.salt()
                val id = UUID.randomUUID().toString()
                val a = AccountRecord(id = id, phone = cleanPhone, displayName = name.trim(),
                    passwordSalt = salt, passwordHash = LocalCredentials.hash(password, salt),
                    organizationId = sponsor?.organizationId ?: UUID.randomUUID().toString(),
                    organizationName = sponsor?.organizationName ?: organizationName.trim(),
                    sponsorId = sponsor?.id, sponsorName = sponsor?.displayName,
                    role = if (sponsor == null) MemberRole.HEAD.name else MemberRole.MEMBER.name)
                dao.addAccount(a)
                dao.createWithSteps(TaskRecord(title = "ثبت اولین اقدام واقعی", ownerId = id,
                    priority = TaskPriority.IMPORTANT.name), listOf("انتخاب اقدام", "ثبت نتیجه"))
                store.markAutoRestore()
                store.setAccount(id)
            } catch (e: Exception) { _message.value = "ثبت حساب محلی انجام نشد: ${e.message ?: "خطای نامشخص"}" }
        }
    }
    fun login(phone: String, password: String) = viewModelScope.launch {
        withContext(Dispatchers.IO) {
            val a = dao.accountByPhone(phone.filter { it.isDigit() || it == '+' })
            if (a == null || !LocalCredentials.matches(password, a.passwordSalt, a.passwordHash)) {
                _message.value = "شماره یا رمز عبور درست نیست."; return@withContext
            }
            store.markAutoRestore()
            store.setAccount(a.id)
        }
    }
    private suspend fun restoreLegacyInternal() {
        val old = store.legacyState.first()
        if(dao.accountById("legacy-local") == null) {
            val salt=LocalCredentials.salt()
            dao.addAccount(AccountRecord(id="legacy-local",phone="LEGACY_LOCAL",displayName=old.name,
                passwordSalt=salt,passwordHash=LocalCredentials.hash(UUID.randomUUID().toString(),salt),
                organizationId="legacy-org",organizationName="سازمان نسخه قبلی",
                role=MemberRole.MEMBER.name,onboardingDone=old.finished,firstMissionDone=old.finished))
        }
        store.setAccount("legacy-local")
        store.markAutoRestore()
    }
    fun restoreLegacy() = viewModelScope.launch {
        if(dao.taskCount("legacy-local")>0) restoreLegacyInternal()
        else _message.value="داده‌ای از نسخه قدیمی پیدا نشد."
    }
    fun setLegacyCredentials(phone: String, password: String) = viewModelScope.launch {
        val id=owner() ?: return@launch
        if(id!="legacy-local") return@launch
        val cleaned=phone.filter{it.isDigit()||it=='+'}
        if(cleaned.length !in 9..15 || password.length<8 || (dao.accountByPhone(cleaned)!=null)) {
            _message.value="شماره جدید و رمز حداقل ۸ کاراکتری لازم است.";return@launch
        }
        val existing=dao.accountById(id)?:return@launch
        val salt=LocalCredentials.salt()
        dao.updateAccount(existing.copy(phone=cleaned,passwordSalt=salt,passwordHash=LocalCredentials.hash(password,salt)))
        store.clearLegacyMarker()
        _message.value="رمز حساب بازیابی‌شده تنظیم شد."
    }
    fun signOut() = viewModelScope.launch { store.signOut() }
    fun nextOnboarding(step: Int) = viewModelScope.launch { owner()?.let { dao.saveOnboardingStep(it, step.coerceIn(0,5)) } }
    fun setDailyTarget(number: Int) = viewModelScope.launch { owner()?.let { dao.setDailyTarget(it, number.coerceIn(1,20)) } }
    fun firstMission(title: String, kind: ActivityKind, outcome: String) = viewModelScope.launch {
        val id = owner() ?: return@launch
        if(title.isBlank() || kind == ActivityKind.SALE || kind == ActivityKind.JOIN) return@launch
        database.withTransaction {
            if(dao.accountById(id)?.firstMissionDone==true) return@withTransaction
            val activityId=dao.insertActivity(ActivityRecord(kind = kind.name, title = title.trim(), outcome = outcome, ownerId = id))
            if(outcome == "نیاز به پیگیری" && activityId > 0) createFollowUpTask(id,title.trim(),activityId)
            val initial=dao.findInitialTask(id)
            if(initial!=null) {
                dao.findTaskSteps(initial.id,id).forEach { dao.markStep(it.id,id,true) }
                dao.completeTaskAtomic(id,initial.id,System.currentTimeMillis())
            }
            dao.setFirstMission(id)
            dao.insertAudit(AuditRecord(ownerId = id, action = "FIRST_ACTION", subjectId = kind.name))
        }
    }
    fun finishOnboarding() = viewModelScope.launch {
        val id = owner() ?: return@launch
        val a = dao.accountById(id) ?: return@launch
        if (a.firstMissionDone) dao.finishOnboarding(id)
        else _message.value = "ابتدا اولین اقدام واقعی را ثبت کن."
    }
    fun addTask(title: String, priority: TaskPriority, kind: TaskKind, repeat: RepeatRule, dueAt: Long, checklist: String) = viewModelScope.launch {
        val id = owner() ?: return@launch
        if(title.isBlank()) return@launch
        if(kind != TaskKind.PERSONAL) { _message.value="ساخت مأموریت سازمانی و حمایتی به مجوز معتبر نیاز دارد."; return@launch }
        dao.createWithSteps(TaskRecord(title = title.trim(), priority = priority.name,
            kind = kind.name, repeatRule = repeat.name, dueAt = dueAt, ownerId = id), checklist.lines())
    }
    fun markStep(id: Long, checked: Boolean) = viewModelScope.launch { owner()?.let { dao.markStep(id, it, checked) } }
    fun setTaskStatus(task: TaskRecord, status: TaskStatus) = viewModelScope.launch {
        val id = owner() ?: return@launch
        if(status == TaskStatus.COMPLETED) {
            if(!dao.completeTaskAtomic(id, task.id,System.currentTimeMillis())) _message.value = "برای تکمیل، ابتدا تمام مراحل را انجام بده."
        } else if(status == TaskStatus.ACTIVE || status == TaskStatus.READY || status == TaskStatus.CANCELLED || status == TaskStatus.REVIEW) {
            val current = dao.findTask(task.id,id)
            if(current != null && current.status != TaskStatus.COMPLETED.name && current.status != TaskStatus.CANCELLED.name) {
                dao.changeTaskStatus(task.id,id,status.name,System.currentTimeMillis())
            }
        }
    }
    fun editTask(task: TaskRecord, title: String, notes: String, priority: TaskPriority, dueAt: Long) = viewModelScope.launch {
        val id=owner()?:return@launch
        if(title.isNotBlank()) dao.editTask(task.id,id,title.trim(),notes,priority.name,dueAt,System.currentTimeMillis())
    }
    fun addActivity(kind: ActivityKind, title: String, outcome: String) = viewModelScope.launch {
        val id=owner()?:return@launch
        if(title.isBlank() || kind == ActivityKind.SALE || kind == ActivityKind.JOIN) return@launch
        database.withTransaction {
            val activityId = dao.insertActivity(ActivityRecord(kind=kind.name,title=title.trim(),outcome=outcome,ownerId=id))
            if(outcome == "نیاز به پیگیری" && activityId > 0) createFollowUpTask(id,title.trim(),activityId)
        }
    }
    fun voidActivity(record: ActivityRecord) = viewModelScope.launch {
        val id=owner()?:return@launch
        database.withTransaction {
            dao.voidActivity(record.id,id,System.currentTimeMillis())
            dao.cancelGeneratedFollowup(id,-record.id,System.currentTimeMillis())
            dao.insertAudit(AuditRecord(ownerId=id,action="VOID_ACTIVITY",subjectId=record.id.toString()))
        }
    }
    fun changeMemberRole(targetId: String, newRole: MemberRole) = viewModelScope.launch {
        val actorId=owner()?:return@launch
        val actor=dao.accountById(actorId)?:return@launch
        val target=dao.accountById(targetId)?:return@launch
        if(actor.role!="HEAD" || target.id==actor.id || actor.organizationId!=target.organizationId ||
            newRole !in listOf(MemberRole.MEMBER,MemberRole.LEADER,MemberRole.ADMIN)) {
            _message.value="اجازه تغییر این نقش را نداری.";return@launch
        }
        database.withTransaction {
            if(dao.updateRole(target.id,actor.organizationId,newRole.name)>0) {
                dao.insertAudit(AuditRecord(ownerId=actorId,action="ROLE_CHANGED",subjectId=targetId,details=newRole.name))
            }
        }
    }
    private fun isDownline(actorId:String,targetId:String,members:List<AccountRecord>):Boolean {
        val byId=members.associateBy{it.id}
        var current=byId[targetId]
        val visited=mutableSetOf<String>()
        while(current != null) {
            val memberId=current.id
            val sponsor=current.sponsorId ?: break
            if(!visited.add(memberId)) break
            if(sponsor==actorId) return true
            current=byId[sponsor]
        }
        return false
    }
    fun assignTask(targetId: String, title: String, kind: TaskKind, due: Long) = viewModelScope.launch {
        val current=owner()?:return@launch
        val actor=dao.accountById(current)?:return@launch
        val target=dao.accountById(targetId)?:return@launch
        if(title.isBlank() || kind !in listOf(TaskKind.SUPPORT, TaskKind.ORGANIZATION)) return@launch
        val actorRole=MemberRole.entries.find {it.name==actor.role}?:MemberRole.MEMBER
        val inOwnTree = isDownline(actor.id, target.id, dao.listOrganization(actor.organizationId))
        val membership=Membership(actor.id,actor.organizationId,actor.organizationName,actor.sponsorId,actor.sponsorName,
            actorRole,scope=if(actorRole==MemberRole.HEAD||actorRole==MemberRole.ADMIN)Scope.ORGANIZATION else Scope.DOWNLINE)
        val targetMember=Membership(target.id,target.organizationId,target.organizationName,target.sponsorId,target.sponsorName,
            MemberRole.entries.find{it.name==target.role}?:MemberRole.MEMBER)
        val permission=if(kind==TaskKind.SUPPORT) Permission.ASSIGN_SUPPORT else Permission.MANAGE_ORG_TASK
        if(!AccessRules.allowed(membership,targetMember,permission,inOwnTree)) {
            _message.value="دسترسی تعیین مأموریت برای این عضو را نداری.";return@launch
        }
        dao.createWithSteps(TaskRecord(title=title.trim(),ownerId=target.id,kind=kind.name,
            notes="صادرکننده: ${actor.displayName}",dueAt=due), emptyList())
        dao.insertAudit(AuditRecord(ownerId=current,action="ASSIGN_TASK",subjectId=target.id,details=title.trim()))
        _message.value="مأموریت برای عضو انتخابی ثبت شد."
    }
    private suspend fun createFollowUpTask(id:String,title:String,activityId:Long) {
        if(dao.childCount(id,-activityId)>0) return
        val c=Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR,1);set(Calendar.HOUR_OF_DAY,10);set(Calendar.MINUTE,0) }
        dao.createWithSteps(TaskRecord(title="پیگیری: $title",ownerId=id,dueAt=c.timeInMillis,
            originId=-activityId,priority=TaskPriority.IMPORTANT.name,kind=TaskKind.AUTOMATIC.name), emptyList())
    }
    fun editActivity(record: ActivityRecord, title: String, outcome: String) = viewModelScope.launch {
        val id=owner()?:return@launch
        if(title.isNotBlank()) database.withTransaction {
            val stored=dao.findActivity(record.id,id)?:return@withTransaction
            if(stored.validation=="VERIFIED" || stored.validation=="VOID") return@withTransaction
            dao.editActivity(record.id,id,title.trim(),outcome,System.currentTimeMillis())
            dao.insertAudit(AuditRecord(ownerId=id,action="EDIT_ACTIVITY",subjectId=record.id.toString()))
            if(outcome=="نیاز به پیگیری" && stored.outcome!="نیاز به پیگیری") createFollowUpTask(id,title.trim(),record.id)
        }
    }
    fun prepareFocus(taskId: Long, minutes: Int = 25) = viewModelScope.launch {
        val id=owner()?:return@launch
        val old=dao.findDraft(id)
        if(old!=null && old.taskId!=taskId) {
            _message.value="ابتدا جلسه تمرکز قبلی را پایان بده."; return@launch
        }
        if(dao.findTask(taskId,id)!=null && old==null) dao.saveDraft(FocusDraftRecord(ownerId=id,taskId=taskId,durationSeconds=minutes*60))
    }
    fun setFocusMinutes(minutes: Int) = viewModelScope.launch {
        val id=owner()?:return@launch
        val f=dao.findDraft(id)?:return@launch
        if(!f.isRunning && f.elapsedSeconds==0) dao.saveDraft(f.copy(durationSeconds=minutes.coerceIn(1,180)*60))
    }
    fun startFocus() = viewModelScope.launch {
        val id=owner()?:return@launch
        val f=dao.findDraft(id)?:return@launch
        if(!f.isRunning) dao.saveDraft(f.copy(isRunning=true,runningSince=System.currentTimeMillis()))
    }
    fun pauseFocus() = viewModelScope.launch {
        val id=owner()?:return@launch
        val f=dao.findDraft(id)?:return@launch
        val elapsed=effectiveElapsed(f)
        dao.saveDraft(f.copy(isRunning=false,runningSince=0,elapsedSeconds=elapsed))
    }
    fun finishFocus(result: String, note: String, activityType: ActivityKind?) = viewModelScope.launch {
        val id=owner()?:return@launch
        database.withTransaction {
            val f=dao.findDraft(id)?:return@withTransaction
            val seconds=effectiveElapsed(f)
            if(seconds <= 0) { _message.value="زمان جلسه ثبت نشده است.";return@withTransaction }
            val focusId=dao.insertFocus(FocusRecord(taskId=f.taskId,secondsSpent=seconds,result=result,note=note.trim(),ownerId=id))
            if(result == "تکمیل شد" && !dao.completeTaskAtomic(id,f.taskId,System.currentTimeMillis())) {
                _message.value="زمان تمرکز ثبت شد؛ برای تکمیل مأموریت، مراحل باقی‌مانده را انجام بده."
            }
            if(activityType!=null && activityType!=ActivityKind.SALE && activityType!=ActivityKind.JOIN && note.isNotBlank()) {
                dao.insertActivity(ActivityRecord(kind=activityType.name,title=note.trim(),outcome=result,
                    taskId=f.taskId,ownerId=id,sourceKey="focus:$focusId"))
            }
            dao.clearDraft(id)
        }
    }
    fun discardFocus() = viewModelScope.launch { owner()?.let { dao.clearDraft(it) } }
}

fun effectiveElapsed(f: FocusDraftRecord, now: Long = System.currentTimeMillis()): Int =
    (f.elapsedSeconds.toLong() + if(f.isRunning) ((now-f.runningSince).coerceAtLeast(0)/1000) else 0)
        .coerceIn(0,f.durationSeconds.toLong()).toInt()
