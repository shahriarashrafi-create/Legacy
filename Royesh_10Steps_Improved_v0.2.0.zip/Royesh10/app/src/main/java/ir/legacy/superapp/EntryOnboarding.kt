package ir.legacy.superapp

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.legacy.core.ActivityKind

@Composable
fun EntryScreen(vm: LegacyViewModel) {
    val legacyAvailable by vm.legacyAvailable.collectAsState()
    var register by rememberSaveable { mutableStateOf(false) }
    var name by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var sponsorPhone by rememberSaveable { mutableStateOf("") }
    var org by rememberSaveable { mutableStateOf("") }
    Spacer(Modifier.height(32.dp))
    Icon(Icons.Default.Spa,contentDescription=null,modifier=Modifier.size(54.dp),tint=LegacyTeal)
    Text("رویش",style=MaterialTheme.typography.displaySmall,fontWeight=FontWeight.Bold)
    Text("هر قدم، یک رشد واقعی",style=MaterialTheme.typography.titleMedium,color=LegacyTeal)
    SoftCard {
        Text(if(register) "ساخت حساب محلی" else "ورود به حساب محلی",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
        if(register) OutlinedTextField(value=name,onValueChange={name=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("نام و نام خانوادگی")})
        OutlinedTextField(value=phone,onValueChange={phone=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("شماره تلفن")})
        OutlinedTextField(value=password,onValueChange={password=it},modifier=Modifier.fillMaxWidth(),singleLine=true,
            visualTransformation=androidx.compose.ui.text.input.PasswordVisualTransformation(),label={Text("رمز عبور (حداقل ۸ کاراکتر)")})
        if(register) {
            OutlinedTextField(value=sponsorPhone,onValueChange={sponsorPhone=it},modifier=Modifier.fillMaxWidth(),singleLine=true,
                label={Text("شماره حامی (اگر دعوت شده‌ای)")})
            if(sponsorPhone.isBlank()) OutlinedTextField(value=org,onValueChange={org=it},modifier=Modifier.fillMaxWidth(),
                label={Text("نام سازمان نمونه خودت")})
            Text("اگر حامی داری، ابتدا او باید روی همین دستگاه حساب محلی ساخته باشد.",style=MaterialTheme.typography.bodySmall)
        }
        Button(onClick={if(register) vm.register(name,phone,password,sponsorPhone,org) else vm.login(phone,password)},modifier=Modifier.fillMaxWidth()) {
            Text(if(register) "ایجاد حساب و شروع مسیر" else "ورود")
        }
        TextButton(onClick={register=!register},modifier=Modifier.align(Alignment.CenterHorizontally)) {
            Text(if(register) "حساب دارم؛ وارد می‌شوم" else "ساخت حساب جدید")
        }
        if(legacyAvailable) OutlinedButton(onClick={vm.restoreLegacy()},modifier=Modifier.fillMaxWidth()) {
            Text("بازیابی اطلاعات نسخه قبلی از همین گوشی")
        }
        Text("نسخه محلی توسعه: رمز با مشتق‌سازی امن در گوشی نگهداری می‌شود. تأیید پیامکی، بازیابی رمز و ورود چنددستگاهی تا زمان اتصال به سرور فعال نیستند.",
            color=MaterialTheme.colorScheme.onSurfaceVariant,style=MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun OnboardingScreen(a: AccountRecord,vm:LegacyViewModel) {
    val step=a.onboardingStep.coerceIn(0,5)
    val titles=listOf("سازمان و حامی","اطلاعات اولیه","آشنایی با مسیر","هدف روز اول","اولین اقدام واقعی","پشتیبانی و شروع")
    var goal by rememberSaveable { mutableIntStateOf(a.dailyTarget) }
    var firstTitle by rememberSaveable { mutableStateOf("") }
    var kind by rememberSaveable { mutableStateOf(ActivityKind.CONNECTION) }
    var outcome by rememberSaveable { mutableStateOf("انجام شد") }
    Heading("خوش آمدی، ${a.displayName}","راه‌اندازی اولیه • مرحله ${step+1} از ۶")
    LinearProgressIndicator(progress={ (step+1)/6f },modifier=Modifier.fillMaxWidth())
    SoftCard {
        Text(titles[step],style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        when(step) {
            0 -> {
                Text("سازمان: ${a.organizationName}")
                Text("حامی: ${a.sponsorName ?: "ایجادکننده سازمان محلی"}")
                Text("این عضویت فقط روی گوشی ثبت شده است. تأیید سازمان واقعی نیازمند سرور است.",style=MaterialTheme.typography.bodySmall)
            }
            1 -> { Text("نام: ${a.displayName}"); Text("شماره ثبت‌شده: ${a.phone}");Text("اطلاعات حساس در این نما نمایش عمومی ندارند.") }
            2 -> {
                Text("خانه فقط اقدام بعدی را نشان می‌دهد.")
                Text("مرکز اقدامات محل مدیریت مأموریت‌هاست.")
                Text("گزارش روزانه، نتیجه واقعی کارها را ثبت می‌کند.")
            }
            3 -> {
                Text("چند فعالیت واقعی برای روز اول در نظر بگیریم؟")
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    listOf(1,3,5).forEach { n -> FilterChip(selected=goal==n,onClick={goal=n;vm.setDailyTarget(n)},label={Text("$n اقدام")}) }
                }
                Text("این هدف قابل تنظیم است و باعث تولید امتیاز مصنوعی نمی‌شود.",style=MaterialTheme.typography.bodySmall)
            }
            4 -> {
                if(a.firstMissionDone) {
                    Text("اولین اقدام ثبت شد!",color=LegacyTeal,fontWeight=FontWeight.Bold)
                } else {
                    Text("برای ورود به خانه، نتیجه یک اقدام واقعی را ثبت کن.")
                    PickOption(kind.label,ActivityKind.entries.filter { it != ActivityKind.SALE && it != ActivityKind.JOIN }.map{it.label},
                        onChange={kind=ActivityKind.entries.filter { it != ActivityKind.SALE && it != ActivityKind.JOIN }[it]})
                    OutlinedTextField(value=firstTitle,onValueChange={firstTitle=it},modifier=Modifier.fillMaxWidth(),label={Text("چه کاری انجام دادی؟")})
                    PickOption(outcome,listOf("انجام شد","نیاز به پیگیری","بدون نتیجه"),onChange={outcome=listOf("انجام شد","نیاز به پیگیری","بدون نتیجه")[it]})
                    Button(enabled=firstTitle.isNotBlank(),onClick={vm.firstMission(firstTitle,kind,outcome)},modifier=Modifier.fillMaxWidth()) {
                        Text("ثبت اولین اقدام")
                    }
                }
            }
            5 -> {
                Text("حامی: ${a.sponsorName ?: "برای این حساب، حامی بالادستی ثبت نشده است."}")
                Text("در نسخه محلی، پیام‌رسان و درخواست پشتیبانی سروری فعال نیست. اکنون می‌توانی مسیر رشد و فعالیت‌های خودت را شروع کنی.")
            }
        }
        Button(enabled=step!=4 || a.firstMissionDone,onClick={if(step==5) vm.finishOnboarding() else vm.nextOnboarding(step+1)},modifier=Modifier.fillMaxWidth()) {
            Text(if(step==5) "ورود به صفحه اصلی" else "مرحله بعد")
        }
        if(step>0) TextButton(onClick={vm.nextOnboarding(step-1)},modifier=Modifier.align(Alignment.CenterHorizontally)) {Text("مرحله قبل")}
    }
    OutlinedButton(onClick={vm.signOut()},modifier=Modifier.fillMaxWidth()) { Text("خروج از حساب") }
}
