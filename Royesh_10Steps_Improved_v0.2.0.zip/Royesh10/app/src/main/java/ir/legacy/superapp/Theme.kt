package ir.legacy.superapp

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val LegacyTeal = Color(0xFF168D79)
val BackgroundCream = Color(0xFFFAFAF7)

private val colors = lightColorScheme(
    primary = LegacyTeal,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD7F1E9),
    onPrimaryContainer = Color(0xFF084E40),
    background = BackgroundCream,
    onBackground = Color(0xFF22282B),
    surface = Color.White,
    onSurface = Color(0xFF22282B),
    surfaceVariant = Color(0xFFF0F2F0),
    onSurfaceVariant = Color(0xFF666D70),
    outline = Color(0xFFDDE3DF)
)

@Composable
fun LegacyTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = colors, typography = Typography(), content = content)
}
