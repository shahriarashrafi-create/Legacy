package ir.legacy.superapp

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable
fun LegacyApp(vm: LegacyViewModel) {
    val signedIn by vm.signedIn.collectAsState()
    val ownerId by vm.accountId.collectAsState()
    val account by vm.account.collectAsState()
    val tasks by vm.tasks.collectAsState()
    val steps by vm.steps.collectAsState()
    val activities by vm.activities.collectAsState()
    val focus by vm.focusSessions.collectAsState()
    val draft by vm.draft.collectAsState()
    val members by vm.members.collectAsState()
    val message by vm.message.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val myTasks = tasks.filter { it.ownerId == ownerId }
    val mySteps = steps.filter { it.ownerId == ownerId }
    val myActivities = activities.filter { it.ownerId == ownerId }
    val myFocus = focus.filter { it.ownerId == ownerId }
    val myMembers = members.filter { it.organizationId == account?.organizationId }
    val myDraft = draft?.takeIf { it.ownerId == ownerId }
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(message) {
        if(message.isNotBlank()) { snackbar.showSnackbar(message); vm.clearMessage() }
    }
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if(signedIn && account?.id == ownerId && account?.onboardingDone == true) {
                NavigationBar {
                    val titles=listOf("خانه","اقدامات","تمرکز","گزارش","پروفایل")
                    val icons=listOf(Icons.Default.Home,Icons.Default.Checklist,Icons.Default.Timer,Icons.Default.Assessment,Icons.Default.Person)
                    titles.forEachIndexed { index, title ->
                        NavigationBarItem(selected=tab==index,onClick={tab=index},
                            icon={Icon(icons[index],contentDescription=null)},
                            label={Text(title,maxLines=1,overflow=TextOverflow.Ellipsis)})
                    }
                }
            }
        }
    ) { insets ->
        Column(Modifier.fillMaxSize().padding(insets).verticalScroll(rememberScrollState()).padding(horizontal=16.dp),
            verticalArrangement=Arrangement.spacedBy(14.dp)) {
            Spacer(Modifier.height(6.dp))
            when {
                !signedIn -> EntryScreen(vm)
                account?.id != ownerId -> CircularProgressIndicator()
                !account!!.onboardingDone -> OnboardingScreen(account!!,vm)
                else -> when(tab) {
                    0 -> HomeScreen(account!!,myTasks,myActivities,
                        onTasks={tab=1}, onFocus={ taskId -> vm.prepareFocus(taskId);tab=2 },onReport={tab=3})
                    1 -> TasksScreen(account!!,myMembers,myTasks,mySteps,vm,onFocus={taskId->vm.prepareFocus(taskId);tab=2})
                    2 -> FocusScreen(myTasks,myDraft,myFocus,vm)
                    3 -> ActivitiesScreen(account!!,myActivities,vm)
                    else -> ProfileScreen(account!!,myMembers,myTasks,myActivities,myFocus,vm,onSignOut={vm.signOut();tab=0})
                }
            }
            Spacer(Modifier.height(18.dp))
        }
    }
}
