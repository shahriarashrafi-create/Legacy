package ir.legacy.superapp

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

fun dateLabel(at: Long): String = SimpleDateFormat("yyyy/MM/dd – HH:mm", Locale("fa","IR")).format(Date(at))
@Composable
fun Heading(title: String, subtitle: String) {
    Column(verticalArrangement=Arrangement.spacedBy(4.dp)) {
        Text(title, style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
        Text(subtitle, style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
@Composable
fun SoftCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier.fillMaxWidth(),shape=RoundedCornerShape(20.dp),
        colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.62f))) {
        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp),content=content)
    }
}
@Composable
fun CounterTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier,shape=RoundedCornerShape(15.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
        Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
            Text(value,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
            Text(label,style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
@Composable
fun PickOption(value: String, options: List<String>, onChange:(Int)->Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick={open=true}) { Text(value); Icon(Icons.Default.ArrowDropDown,null) }
        DropdownMenu(expanded=open,onDismissRequest={open=false}) {
            options.forEachIndexed { index, item ->
                DropdownMenuItem(text={Text(item)},onClick={onChange(index);open=false})
            }
        }
    }
}
@Composable
fun DateTimeChoice(time: Long, onChange:(Long)->Unit) {
    val context=LocalContext.current
    OutlinedButton(onClick={
        val base=Calendar.getInstance().apply { timeInMillis=time }
        DatePickerDialog(context,{_,year,month,day->
            val candidate=Calendar.getInstance().apply { timeInMillis=time;set(year,month,day) }
            TimePickerDialog(context,{_,hour,minute->
                candidate.set(Calendar.HOUR_OF_DAY,hour);candidate.set(Calendar.MINUTE,minute);candidate.set(Calendar.SECOND,0)
                onChange(candidate.timeInMillis)
            },base.get(Calendar.HOUR_OF_DAY),base.get(Calendar.MINUTE),true).show()
        },base.get(Calendar.YEAR),base.get(Calendar.MONTH),base.get(Calendar.DAY_OF_MONTH)).show()
    }) { Text("زمان: ${dateLabel(time)}") }
}
