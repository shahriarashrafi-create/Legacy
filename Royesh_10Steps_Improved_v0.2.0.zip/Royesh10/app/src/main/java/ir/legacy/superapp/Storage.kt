package ir.legacy.superapp

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.*
import ir.legacy.core.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

@Entity(tableName = "accounts", indices = [Index(value = ["phone"], unique = true)])
data class AccountRecord(
    @PrimaryKey val id: String, val phone: String, val displayName: String,
    val passwordSalt: String, val passwordHash: String,
    val organizationId: String, val organizationName: String,
    val sponsorId: String? = null, val sponsorName: String? = null,
    val role: String = "MEMBER", val joinedAt: Long = System.currentTimeMillis(),
    val onboardingStep: Int = 0, val onboardingDone: Boolean = false,
    val dailyTarget: Int = 3, val firstMissionDone: Boolean = false
)
@Entity(tableName = "tasks", indices = [Index("ownerId"), Index("originId")])
data class TaskRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val kind: String = "PERSONAL", val priority: String = "NORMAL", val status: String = "READY",
    val repeatRule: String = "NONE", val dueAt: Long = System.currentTimeMillis(),
    val notes: String = "", val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "'legacy-local'") val ownerId: String = "legacy-local", val originId: Long? = null,
    @ColumnInfo(defaultValue = "0") val updatedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "1") val version: Int = 1,
    @ColumnInfo(defaultValue = "'LOCAL_ONLY'") val syncState: String = "LOCAL_ONLY"
)
@Entity(tableName = "task_steps", indices = [Index("taskId"), Index("ownerId")])
data class TaskStepRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskId: Long, val title: String, val done: Boolean = false,
    @ColumnInfo(defaultValue = "'legacy-local'") val ownerId: String = "legacy-local"
)
@Entity(tableName = "activities", indices = [Index("ownerId"), Index(value = ["sourceKey"], unique = true)])
data class ActivityRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String, val title: String, val outcome: String,
    val validation: String = "SELF_REPORTED", val taskId: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "'legacy-local'") val ownerId: String = "legacy-local",
    val sourceKey: String? = null,
    @ColumnInfo(defaultValue = "0") val updatedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "'LOCAL_ONLY'") val syncState: String = "LOCAL_ONLY",
    @ColumnInfo(defaultValue = "''") val note: String = ""
)
@Entity(tableName = "focus_sessions", indices = [Index("ownerId")])
data class FocusRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskId: Long?, val secondsSpent: Int, val result: String, val note: String,
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "'legacy-local'") val ownerId: String = "legacy-local"
)
@Entity(tableName = "focus_drafts")
data class FocusDraftRecord(
    @PrimaryKey val ownerId: String, val taskId: Long,
    val durationSeconds: Int, val elapsedSeconds: Int = 0,
    val runningSince: Long = 0L, val isRunning: Boolean = false
)
@Entity(tableName = "audit_events", indices = [Index("ownerId")])
data class AuditRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ownerId: String, val action: String, val subjectId: String,
    val details: String = "", val createdAt: Long = System.currentTimeMillis()
)

@Dao
abstract class LocalDao {
    @Query("SELECT * FROM accounts WHERE phone = :phone LIMIT 1") abstract suspend fun accountByPhone(phone: String): AccountRecord?
    @Query("SELECT * FROM accounts WHERE id = :id LIMIT 1") abstract suspend fun accountById(id: String): AccountRecord?
    @Query("SELECT * FROM accounts WHERE id = :id LIMIT 1") abstract fun observeAccount(id: String): Flow<AccountRecord?>
    @Query("SELECT * FROM accounts WHERE organizationId = :organizationId") abstract fun organizationMembers(organizationId: String): Flow<List<AccountRecord>>
    @Insert(onConflict = OnConflictStrategy.ABORT) abstract suspend fun addAccount(a: AccountRecord)
    @Update abstract suspend fun updateAccount(a: AccountRecord)
    @Query("UPDATE accounts SET role = :role WHERE id = :id AND organizationId = :org AND role NOT IN ('HEAD', 'PLATFORM_ADMIN')")
    abstract suspend fun updateRole(id: String, org: String, role: String): Int
    @Query("SELECT * FROM accounts WHERE organizationId = :organizationId")
    abstract suspend fun listOrganization(organizationId: String): List<AccountRecord>
    @Query("UPDATE accounts SET onboardingStep = :step WHERE id = :owner") abstract suspend fun saveOnboardingStep(owner: String, step: Int)
    @Query("UPDATE accounts SET dailyTarget = :count WHERE id = :owner") abstract suspend fun setDailyTarget(owner: String, count: Int)
    @Query("UPDATE accounts SET firstMissionDone = 1 WHERE id = :owner") abstract suspend fun setFirstMission(owner: String)
    @Query("UPDATE accounts SET onboardingDone = 1, onboardingStep = 5 WHERE id = :owner") abstract suspend fun finishOnboarding(owner: String)
    @Query("SELECT * FROM tasks WHERE ownerId = :owner ORDER BY CASE priority WHEN 'URGENT' THEN 0 WHEN 'IMPORTANT' THEN 1 ELSE 2 END, dueAt ASC, createdAt DESC") abstract fun observeTasks(owner: String): Flow<List<TaskRecord>>
    @Query("SELECT * FROM task_steps WHERE ownerId = :owner ORDER BY id ASC") abstract fun observeSteps(owner: String): Flow<List<TaskStepRecord>>
    @Query("SELECT * FROM activities WHERE ownerId = :owner ORDER BY createdAt DESC, id DESC") abstract fun observeActivities(owner: String): Flow<List<ActivityRecord>>
    @Query("SELECT * FROM focus_sessions WHERE ownerId = :owner ORDER BY createdAt DESC") abstract fun observeFocusSessions(owner: String): Flow<List<FocusRecord>>
    @Query("SELECT * FROM focus_drafts WHERE ownerId = :owner LIMIT 1") abstract fun observeDraft(owner: String): Flow<FocusDraftRecord?>
    @Query("SELECT * FROM focus_drafts WHERE ownerId = :owner LIMIT 1") abstract suspend fun findDraft(owner: String): FocusDraftRecord?
    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun saveDraft(draft: FocusDraftRecord)
    @Query("DELETE FROM focus_drafts WHERE ownerId = :owner") abstract suspend fun clearDraft(owner: String)
    @Insert abstract suspend fun insertTask(task: TaskRecord): Long
    @Insert abstract suspend fun insertStep(step: TaskStepRecord)
    @Insert(onConflict = OnConflictStrategy.IGNORE) abstract suspend fun insertActivity(activity: ActivityRecord): Long
    @Insert abstract suspend fun insertFocus(focus: FocusRecord): Long
    @Insert abstract suspend fun insertAudit(a: AuditRecord)
    @Query("UPDATE task_steps SET done = :done WHERE id = :id AND ownerId = :owner") abstract suspend fun markStep(id: Long, owner: String, done: Boolean)
    @Query("UPDATE tasks SET status = :status, updatedAt = :now, version = version + 1 WHERE id = :id AND ownerId = :owner") abstract suspend fun changeTaskStatus(id: Long, owner: String, status: String, now: Long)
    @Query("UPDATE tasks SET title = :title, notes = :notes, priority = :priority, dueAt = :due, updatedAt = :now, version = version + 1 WHERE id = :id AND ownerId = :owner AND status != 'COMPLETED'") abstract suspend fun editTask(id: Long, owner: String, title: String, notes: String, priority: String, due: Long, now: Long)
    @Query("SELECT COUNT(*) FROM tasks WHERE ownerId = :owner") abstract suspend fun taskCount(owner: String): Int
    @Query("SELECT * FROM tasks WHERE ownerId = :owner AND title = 'ثبت اولین اقدام واقعی' LIMIT 1")
    abstract suspend fun findInitialTask(owner: String): TaskRecord?
    @Query("SELECT * FROM tasks WHERE id = :id AND ownerId = :owner LIMIT 1") abstract suspend fun findTask(id: Long, owner: String): TaskRecord?
    @Query("SELECT * FROM task_steps WHERE taskId = :taskId AND ownerId = :owner ORDER BY id ASC") abstract suspend fun findTaskSteps(taskId: Long, owner: String): List<TaskStepRecord>
    @Query("SELECT * FROM activities WHERE id = :id AND ownerId = :owner LIMIT 1") abstract suspend fun findActivity(id: Long, owner: String): ActivityRecord?
    @Query("UPDATE activities SET title = :title, outcome = :outcome, validation = 'SELF_REPORTED', updatedAt = :now WHERE id = :id AND ownerId = :owner AND validation != 'VERIFIED'") abstract suspend fun editActivity(id: Long, owner: String, title: String, outcome: String, now: Long)
    @Query("UPDATE tasks SET status = 'CANCELLED', updatedAt = :now WHERE ownerId = :owner AND originId = :origin AND status IN ('READY', 'ACTIVE')")
    abstract suspend fun cancelGeneratedFollowup(owner: String, origin: Long, now: Long)
    @Query("UPDATE activities SET validation = 'VOID', updatedAt = :now WHERE id = :id AND ownerId = :owner AND validation != 'VERIFIED'") abstract suspend fun voidActivity(id: Long, owner: String, now: Long)
    @Query("SELECT COUNT(*) FROM tasks WHERE ownerId = :owner AND originId = :origin") abstract suspend fun childCount(owner: String, origin: Long): Int
    @Transaction open suspend fun completeTaskAtomic(owner: String, id: Long, now: Long): Boolean {
        val task = findTask(id, owner) ?: return false
        if (task.status == TaskStatus.COMPLETED.name || task.status == TaskStatus.CANCELLED.name) return false
        val originalSteps = findTaskSteps(id, owner)
        if (originalSteps.any { !it.done }) return false
        changeTaskStatus(id, owner, TaskStatus.COMPLETED.name, now)
        insertAudit(AuditRecord(ownerId = owner, action = "TASK_COMPLETED", subjectId = id.toString()))
        val rule = RepeatRule.entries.find { it.name == task.repeatRule } ?: RepeatRule.NONE
        val next = nextOccurrence(task.dueAt, rule, now)
        if (next != null && childCount(owner, task.id) == 0) {
            createWithSteps(task.copy(id = 0, originId = task.id, status = TaskStatus.READY.name,
                dueAt = next, createdAt = now, updatedAt = now, version = 1), originalSteps.map { it.title })
        }
        return true
    }
    @Transaction open suspend fun createWithSteps(task: TaskRecord, steps: List<String>): Long {
        val id = insertTask(task)
        steps.filter { it.isNotBlank() }.take(12).forEach { insertStep(TaskStepRecord(taskId = id, title = it.trim(), ownerId = task.ownerId)) }
        return id
    }
}

@Database(entities = [AccountRecord::class, TaskRecord::class, TaskStepRecord::class, ActivityRecord::class, FocusRecord::class, FocusDraftRecord::class, AuditRecord::class], version = 2, exportSchema = false)
abstract class RoyeshDatabase : RoomDatabase() {
    abstract fun dao(): LocalDao
    companion object {
        @Volatile private var instance: RoyeshDatabase? = null
        private val migration = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `accounts` (`id` TEXT NOT NULL, `phone` TEXT NOT NULL, `displayName` TEXT NOT NULL, `passwordSalt` TEXT NOT NULL, `passwordHash` TEXT NOT NULL, `organizationId` TEXT NOT NULL, `organizationName` TEXT NOT NULL, `sponsorId` TEXT, `sponsorName` TEXT, `role` TEXT NOT NULL, `joinedAt` INTEGER NOT NULL, `onboardingStep` INTEGER NOT NULL, `onboardingDone` INTEGER NOT NULL, `dailyTarget` INTEGER NOT NULL, `firstMissionDone` INTEGER NOT NULL, PRIMARY KEY(`id`))")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_accounts_phone` ON `accounts` (`phone`)")
                db.execSQL("ALTER TABLE tasks ADD COLUMN ownerId TEXT NOT NULL DEFAULT 'legacy-local'")
                db.execSQL("ALTER TABLE tasks ADD COLUMN originId INTEGER")
                db.execSQL("ALTER TABLE tasks ADD COLUMN updatedAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE tasks ADD COLUMN version INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE tasks ADD COLUMN syncState TEXT NOT NULL DEFAULT 'LOCAL_ONLY'")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_tasks_ownerId` ON `tasks` (`ownerId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_tasks_originId` ON `tasks` (`originId`)")
                db.execSQL("ALTER TABLE task_steps ADD COLUMN ownerId TEXT NOT NULL DEFAULT 'legacy-local'")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_task_steps_taskId` ON `task_steps` (`taskId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_task_steps_ownerId` ON `task_steps` (`ownerId`)")
                db.execSQL("ALTER TABLE activities ADD COLUMN ownerId TEXT NOT NULL DEFAULT 'legacy-local'")
                db.execSQL("ALTER TABLE activities ADD COLUMN sourceKey TEXT")
                db.execSQL("ALTER TABLE activities ADD COLUMN updatedAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE activities ADD COLUMN syncState TEXT NOT NULL DEFAULT 'LOCAL_ONLY'")
                db.execSQL("ALTER TABLE activities ADD COLUMN note TEXT NOT NULL DEFAULT ''")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_activities_ownerId` ON `activities` (`ownerId`)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_activities_sourceKey` ON `activities` (`sourceKey`)")
                db.execSQL("ALTER TABLE focus_sessions ADD COLUMN ownerId TEXT NOT NULL DEFAULT 'legacy-local'")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_focus_sessions_ownerId` ON `focus_sessions` (`ownerId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `focus_drafts` (`ownerId` TEXT NOT NULL, `taskId` INTEGER NOT NULL, `durationSeconds` INTEGER NOT NULL, `elapsedSeconds` INTEGER NOT NULL, `runningSince` INTEGER NOT NULL, `isRunning` INTEGER NOT NULL, PRIMARY KEY(`ownerId`))")
                db.execSQL("CREATE TABLE IF NOT EXISTS `audit_events` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `ownerId` TEXT NOT NULL, `action` TEXT NOT NULL, `subjectId` TEXT NOT NULL, `details` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_audit_events_ownerId` ON `audit_events` (`ownerId`)")
            }
        }
        fun get(context: Context): RoyeshDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, RoyeshDatabase::class.java, "legacy_local.db")
                .addMigrations(migration).build().also { instance = it }
        }
    }
}
private val Context.sessionPreferences by preferencesDataStore("legacy_session")
class SessionStore(private val context: Context) {
    private val currentUser = stringPreferencesKey("current_royeh_account")
    private val legacySignedIn = booleanPreferencesKey("demo_signed_in")
    private val legacyName = stringPreferencesKey("demo_name")
    private val legacyOnboarding = booleanPreferencesKey("onboarding_done")
    private val legacyAutoRestored = booleanPreferencesKey("legacy_auto_restored")
    val shouldAutoRestore: Flow<Boolean> = context.sessionPreferences.data.map { it[legacyAutoRestored] != true }
    data class LegacyState(val hadProfile: Boolean, val name: String, val finished: Boolean, val wasSignedIn: Boolean)
    val legacyState: Flow<LegacyState> = context.sessionPreferences.data.map {
        LegacyState(it[legacySignedIn] == true || it[legacyName] != null,
            it[legacyName] ?: "عضو قدیمی", it[legacyOnboarding] ?: false, it[legacySignedIn] == true)
    }
    val accountId: Flow<String> = context.sessionPreferences.data.map { it[currentUser] ?: "" }
    suspend fun setAccount(id: String) { context.sessionPreferences.edit { it[currentUser] = id } }
    suspend fun signOut() = setAccount("")
    suspend fun markAutoRestore() { context.sessionPreferences.edit { it[legacyAutoRestored] = true } }
    suspend fun clearLegacyMarker() { context.sessionPreferences.edit { it.remove(legacySignedIn); it.remove(legacyName) } }
}
