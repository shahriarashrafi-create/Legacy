package ir.legacy.superapp

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.legacy.core.*
import java.util.Calendar

fun nextActions(tasks: List<TaskRecord>): List<TaskRecord> {
    val now=System.currentTimeMillis()
    return tasks.filter { it.status != TaskStatus.COMPLETED.name && it.status != TaskStatus.CANCELLED.name }
        .sortedWith(compareBy<TaskRecord> { task ->
            val age=now-task.dueAt
            when {
                task.priority==TaskPriority.URGENT.name && age>0 -> 0
                task.priority==TaskPriority.IMPORTANT.name && age in 0..7*86_400_000L -> 1
                task.priority==TaskPriority.URGENT.name -> 2
                task.priority==TaskPriority.IMPORTANT.name -> 3
                task.priority==TaskPriority.NORMAL.name && age>0 -> 4
                else -> 5
            }
        }.thenBy { it.dueAt })
}

@Composable
fun HomeScreen(a: AccountRecord, tasks: List<TaskRecord>, activities: List<ActivityRecord>,
    onTasks:()->Unit,onFocus:(Long)->Unit,onReport:()->Unit) {
    val pending=nextActions(tasks)
    val completed=tasks.count { it.status==TaskStatus.COMPLETED.name }
    val today=activities.count { it.validation!="VOID" && sameLocalDay(it.createdAt,System.currentTimeMillis()) }
    Heading("سلام، ${a.displayName}!","رویش • امروز یک قدم واقعی جلوتر")
    Card(colors=CardDefaults.cardColors(containerColor=Color.White),
        border=BorderStroke(1.dp,LegacyTeal.copy(alpha=.25f)),shape=androidx.compose.foundation.shape.RoundedCornerShape(22.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.TrackChanges,null,tint=LegacyTeal)
                Text("اقدام بعدی من",fontWeight=FontWeight.Bold)
            }
            if(pending.isNotEmpty()) {
                val task=pending.first()
                Text(task.title,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
                Text("${TaskPriority.entries.firstOrNull{it.name==task.priority}?.label ?: "عادی"} • ${dateLabel(task.dueAt)}",
                    style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                Button(onClick={onFocus(task.id)},modifier=Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.PlayArrow,null);Spacer(Modifier.width(6.dp));Text("شروع همین اقدام")
                }
            } else {
                Text("اقدام آماده‌ای باقی نمانده؛ برای فردا برنامه بساز.")
                Button(onClick=onTasks,modifier=Modifier.fillMaxWidth()) {Text("برنامه‌ریزی اقدام")}
            }
        }
    }
    SoftCard {
        Text("خلاصه امروز",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            CounterTile("کارهای باقی‌مانده",pending.size.toString(),Modifier.weight(1f))
            CounterTile("فعالیت‌های امروز",today.toString(),Modifier.weight(1f))
        }
        val progress=completionProgress(tasks.mapNotNull{t->TaskStatus.entries.find{it.name==t.status}})
        LinearProgressIndicator(progress={progress},modifier=Modifier.fillMaxWidth())
        Text("$completed اقدام تکمیل شده • ${tasks.count{it.status!=TaskStatus.CANCELLED.name}} اقدام معتبر در فهرست",
            style=MaterialTheme.typography.bodySmall)
        val dailyProgress=(today.toFloat()/a.dailyTarget).coerceIn(0f,1f)
        Text("هدف فعالیت روز: $today از ${a.dailyTarget}",style=MaterialTheme.typography.bodyMedium)
        LinearProgressIndicator(progress={dailyProgress},modifier=Modifier.fillMaxWidth())
    }
    SoftCard {
        Text("برنامه نزدیک",fontWeight=FontWeight.Bold)
        pending.take(3).forEach { t ->
            HorizontalDivider();Text("• ${t.title}",style=MaterialTheme.typography.bodyMedium)
        }
        OutlinedButton(onClick=onTasks,modifier=Modifier.fillMaxWidth()) {Text("مرکز اقدامات")}
    }
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick=onReport,modifier=Modifier.weight(1f)) {Text("گزارش روزانه")}
        OutlinedButton(onClick=onTasks,modifier=Modifier.weight(1f)) {Text("اقدام جدید")}
    }
    Text("رتبه و امتیاز رسمی تا زمان اعتبارسنجی سروری فعال نیستند.",style=MaterialTheme.typography.bodySmall,
        color=MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
fun TasksScreen(account: AccountRecord,members: List<AccountRecord>,tasks: List<TaskRecord>,steps: List<TaskStepRecord>,vm:LegacyViewModel,onFocus:(Long)->Unit) {
    var newTask by rememberSaveable { mutableStateOf(false) }
    var assignOpen by rememberSaveable { mutableStateOf(false) }
    var filter by rememberSaveable { mutableStateOf("همه") }
    var expanded by rememberSaveable { mutableLongStateOf(-1L) }
    var edit by remember { mutableStateOf<TaskRecord?>(null) }
    Heading("مرکز اقدامات","برنامه، زیروظیفه، تکرار و نتیجه واقعی")
    Button(onClick={newTask=true},modifier=Modifier.fillMaxWidth()) {
        Icon(Icons.Default.Add,null);Text("ایجاد اقدام شخصی")
    }
    if(account.role in listOf("HEAD","ADMIN","LEADER")) {
        OutlinedButton(onClick={assignOpen=true},modifier=Modifier.fillMaxWidth()) {Text("تعیین مأموریت برای عضو مجاز")}
    }
    Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
        listOf("همه","آماده","تکمیل‌شده","لغوشده").forEach { option ->
            FilterChip(selected=filter==option,onClick={filter=option},label={Text(option)})
        }
    }
    val filtered=tasks.filter { when(filter) {
        "آماده" -> it.status!=TaskStatus.COMPLETED.name && it.status!=TaskStatus.CANCELLED.name
        "تکمیل‌شده" -> it.status==TaskStatus.COMPLETED.name
        "لغوشده" -> it.status==TaskStatus.CANCELLED.name
        else->true
    } }
    if(filtered.isEmpty()) SoftCard {Text("در این دسته فعلاً اقدامی وجود ندارد.")}
    filtered.forEach { t ->
        val children=steps.filter{it.taskId==t.id}
        val finished=t.status==TaskStatus.COMPLETED.name
        val canceled=t.status==TaskStatus.CANCELLED.name
        SoftCard {
            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Icon(if(finished) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,null,
                    tint=if(finished) LegacyTeal else MaterialTheme.colorScheme.onSurfaceVariant)
                Column(Modifier.weight(1f)) {
                    Text(t.title,fontWeight=FontWeight.Bold)
                    Text("${TaskKind.entries.firstOrNull{it.name==t.kind}?.label ?: "شخصی"} • ${TaskPriority.entries.firstOrNull{it.name==t.priority}?.label ?: "عادی"} • ${dateLabel(t.dueAt)}",
                        color=MaterialTheme.colorScheme.onSurfaceVariant,style=MaterialTheme.typography.labelSmall)
                }
                IconButton(onClick={expanded=if(expanded==t.id)-1 else t.id}) {Icon(Icons.Default.ExpandMore,"جزئیات")}
            }
            if(expanded==t.id) {
                Text("وضعیت: ${TaskStatus.entries.firstOrNull{it.name==t.status}?.label ?: "آماده"}")
                if(children.isNotEmpty()) {
                    Text("مراحل انجام",fontWeight=FontWeight.Medium)
                    children.forEach { s ->
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Checkbox(checked=s.done,enabled=!finished&&!canceled,onCheckedChange={vm.markStep(s.id,it)})
                            Text(s.title)
                        }
                    }
                }
                Text("تکرار: ${RepeatRule.entries.find{it.name==t.repeatRule}?.label ?: "بدون تکرار"}",style=MaterialTheme.typography.bodySmall)
                if(!finished&&!canceled) {
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick={edit=t},modifier=Modifier.weight(1f)) { Text("ویرایش") }
                        OutlinedButton(onClick={onFocus(t.id)},modifier=Modifier.weight(1f)) {Text("تمرکز")}
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick={vm.setTaskStatus(t,if(t.status==TaskStatus.ACTIVE.name)TaskStatus.READY else TaskStatus.ACTIVE)},modifier=Modifier.weight(1f)) {
                            Text(if(t.status==TaskStatus.ACTIVE.name)"توقف" else "در حال انجام")
                        }
                        OutlinedButton(onClick={vm.setTaskStatus(t,TaskStatus.CANCELLED)},modifier=Modifier.weight(1f)) {Text("لغو اقدام")}
                    }
                    Button(onClick={vm.setTaskStatus(t,TaskStatus.COMPLETED)},
                        enabled=children.all{it.done},modifier=Modifier.fillMaxWidth()) {Text("ثبت تکمیل معتبر")}
                    if(children.any{!it.done}) Text("ابتدا تمام مراحل انجام را تکمیل کن.",style=MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
    if(newTask) NewTaskDialog(onDismiss={newTask=false},onCreate={name,priority,repeat,due,parts->
        vm.addTask(name,priority,TaskKind.PERSONAL,repeat,due,parts);newTask=false
    })
    if(assignOpen) AssignDialog(account,members,onDismiss={assignOpen=false},onAssign={target,title,kind,due->
        vm.assignTask(target,title,kind,due);assignOpen=false
    })
    edit?.let { t -> EditTaskDialog(t,onDismiss={edit=null},onSave={title,notes,priority,due->
        vm.editTask(t,title,notes,priority,due);edit=null
    }) }
}

@Composable
private fun NewTaskDialog(onDismiss:()->Unit,onCreate:(String,TaskPriority,RepeatRule,Long,String)->Unit) {
    var title by rememberSaveable {mutableStateOf("")}
    var children by rememberSaveable {mutableStateOf("")}
    var priority by remember {mutableStateOf(TaskPriority.NORMAL)}
    var repeat by remember {mutableStateOf(RepeatRule.NONE)}
    var due by remember {mutableLongStateOf(System.currentTimeMillis()+3600000)}
    AlertDialog(onDismissRequest=onDismiss,title={Text("اقدام جدید")},text={
        Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(value=title,onValueChange={title=it},label={Text("عنوان اقدام")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(value=children,onValueChange={children=it},label={Text("مراحل؛ هر خط یک مرحله")},modifier=Modifier.fillMaxWidth(),minLines=2)
            Text("اولویت")
            PickOption(priority.label,TaskPriority.entries.map{it.label},onChange={priority=TaskPriority.entries[it]})
            Text("تکرار")
            PickOption(repeat.label,RepeatRule.entries.map{it.label},onChange={repeat=RepeatRule.entries[it]})
            DateTimeChoice(due,onChange={due=it})
        }
    },confirmButton={TextButton(enabled=title.isNotBlank(),onClick={onCreate(title,priority,repeat,due,children)}){Text("ذخیره")}},
        dismissButton={TextButton(onClick=onDismiss){Text("بستن")}})
}

@Composable
private fun EditTaskDialog(t:TaskRecord,onDismiss:()->Unit,onSave:(String,String,TaskPriority,Long)->Unit) {
    var title by remember(t.id) {mutableStateOf(t.title)}
    var notes by remember(t.id) {mutableStateOf(t.notes)}
    var due by remember(t.id) {mutableLongStateOf(t.dueAt)}
    var priority by remember(t.id) {mutableStateOf(TaskPriority.entries.firstOrNull{it.name==t.priority}?:TaskPriority.NORMAL)}
    AlertDialog(onDismissRequest=onDismiss,title={Text("ویرایش اقدام")},text={
        Column(verticalArrangement=Arrangement.spacedBy(9.dp)) {
            OutlinedTextField(value=title,onValueChange={title=it},label={Text("عنوان")})
            OutlinedTextField(value=notes,onValueChange={notes=it},label={Text("یادداشت")})
            PickOption(priority.label,TaskPriority.entries.map{it.label},onChange={priority=TaskPriority.entries[it]})
            DateTimeChoice(due,onChange={due=it})
        }
    },confirmButton={TextButton(enabled=title.isNotBlank(),onClick={onSave(title,notes,priority,due)}){Text("ذخیره")}},
    dismissButton={TextButton(onClick=onDismiss){Text("انصراف")}})
}

@Composable
private fun AssignDialog(actor:AccountRecord,members:List<AccountRecord>,onDismiss:()->Unit,onAssign:(String,String,TaskKind,Long)->Unit) {
    val candidates=members.filter { it.id!=actor.id && (actor.role=="HEAD"||actor.role=="ADMIN"||it.sponsorId==actor.id) }
    var targetId by remember { mutableStateOf(candidates.firstOrNull()?.id.orEmpty()) }
    var title by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf(TaskKind.SUPPORT) }
    var due by remember { mutableLongStateOf(System.currentTimeMillis()+86400000L) }
    AlertDialog(onDismissRequest=onDismiss,title={Text("مأموریت سازمانی یا حمایتی")},text={
        Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
            if(candidates.isEmpty()) Text("فعلاً عضو مجازی برای تعیین مأموریت وجود ندارد.")
            else PickOption(candidates.find{it.id==targetId}?.displayName?:"انتخاب عضو",candidates.map{it.displayName},onChange={targetId=candidates[it].id})
            OutlinedTextField(value=title,onValueChange={title=it},label={Text("عنوان مأموریت")})
            PickOption(kind.label,listOf("حمایتی","سازمانی"),onChange={kind=if(it==0)TaskKind.SUPPORT else TaskKind.ORGANIZATION})
            DateTimeChoice(due,onChange={due=it})
            Text("فقط افراد مجاز سازمان و رابطه حمایتی قابل انتخاب هستند.",style=MaterialTheme.typography.bodySmall)
        }
    },confirmButton={TextButton(enabled=targetId.isNotBlank()&&title.isNotBlank(),onClick={onAssign(targetId,title,kind,due)}){Text("ثبت مأموریت")}},
        dismissButton={TextButton(onClick=onDismiss){Text("انصراف")}})
}
