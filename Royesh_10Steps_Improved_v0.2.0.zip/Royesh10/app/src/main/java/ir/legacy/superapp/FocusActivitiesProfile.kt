package ir.legacy.superapp

import android.media.MediaPlayer
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ir.legacy.core.*
import kotlinx.coroutines.delay

@Composable
fun FocusScreen(tasks:List<TaskRecord>,draft:FocusDraftRecord?,records:List<FocusRecord>,vm:LegacyViewModel) {
    var minutes by rememberSaveable { mutableIntStateOf(25) }
    var showResult by rememberSaveable { mutableStateOf(false) }
    var result by rememberSaveable { mutableStateOf("ادامه دارد") }
    var note by rememberSaveable { mutableStateOf("") }
    var activity by rememberSaveable { mutableStateOf<ActivityKind?>(null) }
    var rain by rememberSaveable { mutableStateOf(false) }
    var clock by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val context=LocalContext.current
    DisposableEffect(rain) {
        val player=if(rain) MediaPlayer.create(context,R.raw.focus_rain) else null
        player?.isLooping=true
        player?.setVolume(.18f,.18f)
        player?.start()
        onDispose {player?.stop();player?.release()}
    }
    LaunchedEffect(draft?.isRunning,draft?.runningSince,draft?.elapsedSeconds) {
        while(draft?.isRunning == true) { clock=System.currentTimeMillis();delay(500) }
    }
    val elapsed=draft?.let {effectiveElapsed(it,clock)}?:0
    LaunchedEffect(draft?.isRunning,elapsed,draft?.durationSeconds) {
        if(draft?.isRunning==true && elapsed>=draft.durationSeconds) vm.pauseFocus()
    }
    val activeTask=tasks.find{it.id==draft?.taskId}
    val pending=nextActions(tasks)
    Heading("حالت تمرکز","یک مأموریت • زمان واقعی • ثبت نتیجه")
    if(draft==null) {
        SoftCard {
            Text("یک مأموریت برای تمرکز انتخاب کن",fontWeight=FontWeight.Bold)
            if(pending.isEmpty()) Text("ابتدا در مرکز اقدامات یک کار جدید بساز.")
            else pending.take(12).forEach { t ->
                OutlinedButton(onClick={vm.prepareFocus(t.id,minutes)},modifier=Modifier.fillMaxWidth()) {
                    Text(t.title)
                }
            }
        }
    } else {
        SoftCard {
            Text(activeTask?.title ?: "مأموریت ثبت‌شده",fontWeight=FontWeight.Bold)
            Text("هدف زمانی جلسه: ${draft.durationSeconds/60} دقیقه")
            if(!draft.isRunning && elapsed==0) {
                Row(horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    listOf(15,25,45).forEach { n -> FilterChip(selected=draft.durationSeconds==n*60,
                        onClick={vm.setFocusMinutes(n)},label={Text("$n دقیقه")}) }
                }
                var custom by rememberSaveable { mutableStateOf("") }
                OutlinedTextField(value=custom,onValueChange={custom=it.filter{c->c.isDigit()}.take(3)},singleLine=true,
                    label={Text("زمان دلخواه (۱ تا ۱۸۰ دقیقه)")},modifier=Modifier.fillMaxWidth())
                OutlinedButton(onClick={custom.toIntOrNull()?.let(vm::setFocusMinutes)},enabled=(custom.toIntOrNull()?:0) in 1..180) {
                    Text("تنظیم زمان دلخواه")
                }
            }
        }
        val left=(draft.durationSeconds-elapsed).coerceAtLeast(0)
        SoftCard {
            Column(Modifier.fillMaxWidth(),horizontalAlignment=Alignment.CenterHorizontally,
                verticalArrangement=Arrangement.spacedBy(16.dp)) {
                Text(if(draft.isRunning) "در حال تمرکز" else if(elapsed>0) "توقف موقت" else "آماده شروع")
                CircularProgressIndicator(progress={elapsed.toFloat()/draft.durationSeconds.coerceAtLeast(1)},
                    modifier=Modifier.size(120.dp),strokeWidth=8.dp)
                Text("%02d:%02d".format(left/60,left%60),style=MaterialTheme.typography.displayMedium,fontWeight=FontWeight.Bold)
                Text("مدت سپری‌شده: ${elapsed/60} دقیقه و ${elapsed%60} ثانیه")
                if(draft.isRunning) {
                    Button(onClick={vm.pauseFocus()},modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Pause,null);Text("توقف موقت") }
                } else {
                    Button(enabled=left>0,onClick={vm.startFocus()},modifier=Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.PlayArrow,null);Text(if(elapsed>0)"ادامه تمرکز" else "شروع تمرکز")
                    }
                }
                OutlinedButton(enabled=elapsed>0,onClick={vm.pauseFocus();showResult=true},modifier=Modifier.fillMaxWidth()) {
                    Text("پایان و ثبت نتیجه")
                }
                if(!draft.isRunning && elapsed==0) TextButton(onClick={vm.discardFocus()}) {Text("انصراف از این جلسه")}
            }
        }
    }
    SoftCard {
        Row(verticalAlignment=Alignment.CenterVertically) {
            Icon(if(rain) Icons.Default.VolumeUp else Icons.Default.VolumeOff,null,tint=LegacyTeal)
            Spacer(Modifier.width(8.dp))
            Text("صدای آرام باران (تولیدشده در برنامه)",modifier=Modifier.weight(1f))
            Switch(checked=rain,onCheckedChange={rain=it})
        }
        Text("صدا کاملاً اختیاری است و با ترک صفحه قطع می‌شود.",style=MaterialTheme.typography.bodySmall)
    }
    SoftCard {
        Text("جلسه‌های قبلی",fontWeight=FontWeight.Bold)
        if(records.isEmpty()) Text("هنوز جلسه‌ای ثبت نشده است.")
        records.take(4).forEach { record ->Text("• ${record.secondsSpent/60} دقیقه • ${record.result}")}
    }
    if(showResult && draft!=null) AlertDialog(onDismissRequest={showResult=false},title={Text("نتیجه تمرکز")},text={
        Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)) {
            Text("زمان: ${elapsed/60} دقیقه و ${elapsed%60} ثانیه")
            PickOption(result,listOf("تکمیل شد","ادامه دارد","بدون نتیجه"),onChange={result=listOf("تکمیل شد","ادامه دارد","بدون نتیجه")[it]})
            OutlinedTextField(value=note,onValueChange={note=it},modifier=Modifier.fillMaxWidth(),
                label={Text("شرح نتیجه (اختیاری)")})
            Text("آیا این جلسه یک فعالیت قابل ثبت هم بود؟",style=MaterialTheme.typography.bodySmall)
            val options=listOf<ActivityKind?>(null)+ActivityKind.entries.filter {it!=ActivityKind.JOIN&&it!=ActivityKind.SALE}
            PickOption(activity?.label?:"فقط ثبت زمان تمرکز",options.map{it?.label?:"فقط زمان"},onChange={activity=options[it]})
            Text("برای ثبت فعالیت واقعی، شرح نتیجه ضروری است. تکمیل مأموریت نیز فقط پس از انجام زیروظیفه‌ها پذیرفته می‌شود.",style=MaterialTheme.typography.bodySmall)
        }
    },confirmButton={TextButton(enabled=activity==null||note.isNotBlank(),onClick={
        vm.finishFocus(result,note,activity);showResult=false;note="";result="ادامه دارد";activity=null
    }){Text("ثبت نتیجه")}},dismissButton={TextButton(onClick={showResult=false}){Text("بازگشت")}})
}

@Composable
fun ActivitiesScreen(a:AccountRecord,allActivities:List<ActivityRecord>,vm:LegacyViewModel) {
    var adding by rememberSaveable {mutableStateOf(false)}
    var filter by rememberSaveable {mutableStateOf("همه")}
    var edit by remember {mutableStateOf<ActivityRecord?>(null)}
    var confirmVoid by remember {mutableStateOf<ActivityRecord?>(null)}
    val activities=allActivities.filter {it.validation!="VOID"}
    val shown=activities.filter {filter=="همه"||ActivityKind.entries.find{k->k.name==it.kind}?.label==filter}
    val today=activities.filter{sameLocalDay(it.createdAt,System.currentTimeMillis())}
    val verified=today.count{it.validation=="VERIFIED"}
    val followup=today.count{it.outcome=="نیاز به پیگیری"}
    Heading("گزارش روزانه","فعالیت واقعی، نتیجه و اقدام بعدی")
    SoftCard {
        Text("وضعیت امروز",fontWeight=FontWeight.Bold)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            CounterTile("فعالیت امروز",today.size.toString(),Modifier.weight(1f))
            CounterTile("تأییدشده",verified.toString(),Modifier.weight(1f))
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            CounterTile("هدف روزانه",a.dailyTarget.toString(),Modifier.weight(1f))
            CounterTile("نیازمند پیگیری",followup.toString(),Modifier.weight(1f))
        }
        LinearProgressIndicator(progress={(today.size.toFloat()/a.dailyTarget).coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth())
        Text("فعالیت‌های محلی خوداظهاری‌اند؛ امتیاز و تأیید رسمی ندارند.",style=MaterialTheme.typography.bodySmall)
    }
    Button(onClick={adding=true},modifier=Modifier.fillMaxWidth()) {Icon(Icons.Default.Add,null);Text("ثبت فعالیت واقعی")}
    Text("دسته‌های فعالیت",fontWeight=FontWeight.Bold)
    ActivityKind.entries.chunked(4).forEach { group ->
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
            group.forEach { kind ->
                FilterChip(selected=filter==kind.label,onClick={filter=if(filter==kind.label)"همه" else kind.label},
                    label={Text("${kind.label} ${activities.count{it.kind==kind.name}}",style=MaterialTheme.typography.labelSmall)},
                    modifier=Modifier)
            }
        }
    }
    Text("تاریخچه فعالیت‌ها",fontWeight=FontWeight.Bold)
    if(shown.isEmpty()) SoftCard { Text("برای این دسته هنوز فعالیتی ثبت نشده است.") }
    shown.take(30).forEach { activity ->
        SoftCard {
            Text(activity.title,fontWeight=FontWeight.Medium)
            Text("${ActivityKind.entries.find{it.name==activity.kind}?.label?:"فعالیت"} • ${activity.outcome}",style=MaterialTheme.typography.bodySmall)
            Text("${dateLabel(activity.createdAt)} • ${if(activity.validation=="VERIFIED") "تأییدشده" else "خوداظهاری"}",style=MaterialTheme.typography.labelSmall)
            if(activity.validation!="VERIFIED") {
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick={edit=activity}) {Text("اصلاح")}
                    TextButton(onClick={confirmVoid=activity}) {Text("باطل کردن")}
                }
            }
        }
    }
    if(adding) ActivityDialog(null,onDismiss={adding=false},onSave={kind,title,outcome->
        vm.addActivity(kind,title,outcome);adding=false
    })
    edit?.let { record -> ActivityDialog(record,onDismiss={edit=null},onSave={_,title,outcome->
        vm.editActivity(record,title,outcome);edit=null
    }) }
    confirmVoid?.let { record -> AlertDialog(onDismissRequest={confirmVoid=null},title={Text("باطل کردن فعالیت؟")},
        text={Text("رکورد برای حسابرسی محفوظ می‌ماند، اما از آمار کنار می‌رود.")},
        confirmButton={TextButton(onClick={vm.voidActivity(record);confirmVoid=null}){Text("تأیید ابطال")}},
        dismissButton={TextButton(onClick={confirmVoid=null}){Text("بازگشت")}}) }
}

@Composable
private fun ActivityDialog(record:ActivityRecord?,onDismiss:()->Unit,onSave:(ActivityKind,String,String)->Unit) {
    var kind by remember(record?.id) {mutableStateOf(ActivityKind.entries.find{it.name==record?.kind}?:ActivityKind.CONNECTION)}
    var title by remember(record?.id) {mutableStateOf(record?.title?:"")}
    var outcome by remember(record?.id) {mutableStateOf(record?.outcome?:"انجام شد")}
    val restricted=kind==ActivityKind.SALE||kind==ActivityKind.JOIN
    AlertDialog(onDismissRequest=onDismiss,title={Text(if(record==null)"ثبت فعالیت" else "اصلاح فعالیت")},text={
        Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
            if(record==null) PickOption(kind.label,ActivityKind.entries.map{it.label},onChange={kind=ActivityKind.entries[it]})
            if(restricted) Text("فروش و ثبت‌نام قطعی فقط از منبع رسمی تأییدشده دریافت می‌شوند.",color=MaterialTheme.colorScheme.error)
            else {
                OutlinedTextField(value=title,onValueChange={title=it},label={Text("توضیح واقعی فعالیت")},modifier=Modifier.fillMaxWidth())
                PickOption(outcome,listOf("انجام شد","نیاز به پیگیری","بدون نتیجه"),onChange={outcome=listOf("انجام شد","نیاز به پیگیری","بدون نتیجه")[it]})
                Text("اگر پیگیری لازم باشد، برای فردا یک اقدام ایجاد می‌شود.",style=MaterialTheme.typography.bodySmall)
            }
        }
    },confirmButton={TextButton(enabled=!restricted&&title.isNotBlank(),onClick={onSave(kind,title,outcome)}){Text("ذخیره")}},
        dismissButton={TextButton(onClick=onDismiss){Text("انصراف")}})
}

@Composable
fun ProfileScreen(a:AccountRecord,members:List<AccountRecord>,tasks:List<TaskRecord>,activities:List<ActivityRecord>,
    focus:List<FocusRecord>,vm:LegacyViewModel,onSignOut:()->Unit) {
    val pending=nextActions(tasks)
    val activeActivities=activities.filter{it.validation!="VOID"}
    val byId=members.associateBy { it.id }
    fun isBelow(id:String):Boolean {
        var current=byId[id]
        val visited=mutableSetOf<String>()
        while(current!=null && visited.add(current.id)) {
            val sponsor=current.sponsorId?:return false
            if(sponsor==a.id) return true
            current=byId[sponsor]
        }
        return false
    }
    val totalDownline=members.count{it.id!=a.id && isBelow(it.id)}
    var editLegacy by remember { mutableStateOf(false) }
    var selectedMember by remember { mutableStateOf<AccountRecord?>(null) }
    Heading("پروفایل ۳۶۰ درجه","وضعیت، تیم، فعالیت و قدم بعدی")
    SoftCard {
        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            Icon(Icons.Default.AccountCircle,null,modifier=Modifier.size(60.dp),tint=LegacyTeal)
            Column {
                Text(a.displayName,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
                Text("${a.organizationName} • ${MemberRole.entries.find{it.name==a.role}?.label?:"عضو"}")
                Text("از ${dateLabel(a.joinedAt)}",style=MaterialTheme.typography.bodySmall)
            }
        }
        HorizontalDivider()
        Text("اقدام بعدی",color=LegacyTeal,fontWeight=FontWeight.Bold)
        Text(pending.firstOrNull()?.title?:"برنامه‌ریزی اقدام جدید")
    }
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
        CounterTile("کار تکمیل‌شده",tasks.count{it.status=="COMPLETED"}.toString(),Modifier.weight(1f))
        CounterTile("فعالیت ثبت‌شده",activeActivities.size.toString(),Modifier.weight(1f))
    }
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
        CounterTile("جلسه تمرکز",focus.size.toString(),Modifier.weight(1f))
        CounterTile("هدف روزانه",a.dailyTarget.toString(),Modifier.weight(1f))
    }
    SoftCard {
        Text("شبکه و سازمان",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
        Text("حامی: ${a.sponsorName?:"ثبت نشده"}")
        Text("اعضای ثبت‌شده در سازمان محلی: ${members.size}")
        Text("زیرمجموعه مستقیم: ${members.count{it.sponsorId==a.id}}")
        Text("کل زیرمجموعه در سازمان محلی: $totalDownline")
        Text("نقش جاری: ${MemberRole.entries.find{it.name==a.role}?.label?:"عضو"}")
        Text("شماره و اطلاعات خصوصی سایر اعضا نمایش داده نمی‌شوند.",style=MaterialTheme.typography.bodySmall)
        if(a.role=="HEAD") {
            members.filter{it.id!=a.id}.forEach { member ->
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Text("${member.displayName} • ${MemberRole.entries.find{it.name==member.role}?.label?:"عضو"}",modifier=Modifier.weight(1f))
                    TextButton(onClick={selectedMember=member}) {Text("نقش")}
                }
            }
        }
    }
    SoftCard {
        Text("فعالیت و برنامه",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
        ActivityKind.entries.filter{it!=ActivityKind.SALE && it!=ActivityKind.JOIN}.forEach { k ->
            Text("${k.label}: ${activeActivities.count{it.kind==k.name}}")
        }
        Text("مجموع زمان ثبت‌شده: ${focus.sumOf{it.secondsSpent}/60} دقیقه")
    }
    SoftCard {
        Text("فروش، آموزش و افتخارات",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
        Text("این بخش‌ها تا زمان اجرای مراحل مربوط و اتصال به منابع معتبر، آمار ساختگی نمایش نمی‌دهند.")
        Text("رتبه، امتیاز تجربه و درآمد صرفاً بعد از تأیید سامانه اصلی قابل نمایش خواهند بود.",style=MaterialTheme.typography.bodySmall)
    }
    selectedMember?.let { member ->
        AlertDialog(onDismissRequest={selectedMember=null},title={Text("تنظیم نقش ${member.displayName}")},text={
            Column(verticalArrangement=Arrangement.spacedBy(7.dp)) {
                listOf(MemberRole.MEMBER,MemberRole.LEADER,MemberRole.ADMIN).forEach { role ->
                    OutlinedButton(onClick={vm.changeMemberRole(member.id,role);selectedMember=null},modifier=Modifier.fillMaxWidth()) {
                        Text(role.label)
                    }
                }
                Text("فقط مدیر اصلی سازمان محلی می‌تواند این نقش‌ها را تغییر دهد؛ تغییر در تاریخچه ثبت می‌شود.",style=MaterialTheme.typography.bodySmall)
            }
        },confirmButton={TextButton(onClick={selectedMember=null}){Text("بستن")}})
    }
    if(a.id=="legacy-local") {
        Button(onClick={editLegacy=true},modifier=Modifier.fillMaxWidth()) {Text("تنظیم شماره و رمز حساب قدیمی")}
    }
    if(editLegacy) {
        var phone by remember {mutableStateOf("")}
        var secret by remember {mutableStateOf("")}
        AlertDialog(onDismissRequest={editLegacy=false},title={Text("ایمن‌سازی حساب قدیمی")},text={
            Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value=phone,onValueChange={phone=it},label={Text("شماره تلفن")})
                OutlinedTextField(value=secret,onValueChange={secret=it},label={Text("رمز جدید")},
                    visualTransformation=androidx.compose.ui.text.input.PasswordVisualTransformation())
            }
        },confirmButton={TextButton(onClick={vm.setLegacyCredentials(phone,secret);editLegacy=false}){Text("ذخیره")}},
            dismissButton={TextButton(onClick={editLegacy=false}){Text("انصراف")}})
    }
    OutlinedButton(onClick=onSignOut,modifier=Modifier.fillMaxWidth()) {
        Icon(Icons.Default.Logout,null);Text("خروج از حساب")
    }
    Text("نسخه توسعه محلی؛ داده‌ها روی دستگاه هستند و با چند دستگاه همگام نمی‌شوند.",
        style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
}
