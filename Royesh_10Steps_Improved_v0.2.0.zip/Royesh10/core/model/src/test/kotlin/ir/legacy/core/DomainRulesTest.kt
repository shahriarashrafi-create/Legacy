package ir.legacy.core

import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test
import java.util.Calendar
import java.util.TimeZone

class DomainRulesTest {
    @Test fun canceledIsNotCompleted() {
        assertEquals(.5f,completionProgress(listOf(TaskStatus.CANCELLED,TaskStatus.READY,TaskStatus.COMPLETED)))
        assertEquals(0f,completionProgress(listOf(TaskStatus.CANCELLED)))
    }
    @Test fun organizationScopeIsEnforced() {
        val admin=Membership("a","org1","رویــش",null,null,MemberRole.HEAD,scope=Scope.ORGANIZATION)
        val friend=Membership("b","org1","رویش","a","حامی",MemberRole.MEMBER)
        assertTrue(AccessRules.allowed(admin,friend,Permission.ASSIGN_SUPPORT))
        assertFalse(AccessRules.allowed(admin,friend.copy(organizationId="org2"),Permission.ASSIGN_SUPPORT))
        assertFalse(AccessRules.canViewPrivateCustomerData(admin,friend))
    }
    @Test fun memberCannotCreateOrganizationTask() {
        val member=Membership("a","org","رویش",null,null,MemberRole.MEMBER)
        val target=member.copy(accountId="b")
        assertFalse(AccessRules.allowed(member,target,Permission.MANAGE_ORG_TASK))
    }
    @Test fun recurrenceNeverCreatesOverdueChild() {
        val old=Calendar.getInstance().apply {set(2025,0,1,10,0)}.timeInMillis
        assertTrue(nextOccurrence(old,RepeatRule.DAILY,System.currentTimeMillis())!!>System.currentTimeMillis())
        assertNull(nextOccurrence(old,RepeatRule.NONE,System.currentTimeMillis()))
    }
    @Test fun todayUsesLocalMidnight() {
        val tehran=TimeZone.getTimeZone("Asia/Tehran")
        val after=Calendar.getInstance(tehran).apply {set(2026,9,18,0,12);set(Calendar.MILLISECOND,0)}.timeInMillis
        assertFalse(sameLocalDay(after-30*60*1000L,after,tehran))
    }
}
