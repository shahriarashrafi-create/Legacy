package ir.legacy.core

import java.util.Calendar
import java.util.TimeZone

/** Shared domain vocabulary. Server authorization remains authoritative in production. */
enum class MemberRole(val label: String) {
    MEMBER("عضو"), LEADER("رهبر"), ADMIN("مدیر"), HEAD("مدیر سازمان"), PLATFORM_ADMIN("مدیر سامانه")
}
enum class Permission { VIEW_MEMBER, ASSIGN_SUPPORT, MANAGE_ORG_TASK, VIEW_TEAM_METRICS, VIEW_PRIVATE_CUSTOMER, MANAGE_MEMBERSHIP, MANAGE_PLATFORM }
enum class Scope { SELF, DIRECT, DOWNLINE, ORGANIZATION, PLATFORM }
enum class TaskKind(val label: String) {
    PERSONAL("شخصی"), ORGANIZATION("سازمانی"), SUPPORT("حمایتی"), AUTOMATIC("خودکار")
}
enum class TaskPriority(val label: String) {
    NORMAL("عادی"), IMPORTANT("مهم"), URGENT("فوری")
}
enum class TaskStatus(val label: String) {
    READY("آماده"), ACTIVE("در حال انجام"), REVIEW("در انتظار تأیید"), COMPLETED("تکمیل‌شده"), CANCELLED("لغوشده")
}
enum class RepeatRule(val label: String) {
    NONE("بدون تکرار"), DAILY("روزانه"), WEEKLY("هفتگی"), MONTHLY("ماهانه")
}
enum class ActivityKind(val label: String) {
    CONNECTION("ارتباط‌سازی"), INVITATION("دعوت"), PRESENTATION("معرفی"), FOLLOWUP("پیگیری"),
    SALE("فروش"), CUSTOMER("مشتری"), JOIN("ثبت‌نام"), SUPPORT("حمایت")
}
data class Membership(
    val accountId: String, val organizationId: String, val organizationName: String,
    val sponsorId: String?, val sponsorName: String?, val role: MemberRole,
    val permissions: Set<Permission> = emptySet(), val scope: Scope = Scope.SELF
)

object AccessRules {
    fun defaultPermissions(role: MemberRole): Set<Permission> = when(role) {
        MemberRole.MEMBER -> setOf(Permission.VIEW_MEMBER)
        MemberRole.LEADER -> setOf(Permission.VIEW_MEMBER, Permission.ASSIGN_SUPPORT, Permission.VIEW_TEAM_METRICS)
        MemberRole.ADMIN, MemberRole.HEAD -> setOf(Permission.VIEW_MEMBER, Permission.ASSIGN_SUPPORT, Permission.MANAGE_ORG_TASK,
            Permission.VIEW_TEAM_METRICS, Permission.MANAGE_MEMBERSHIP)
        MemberRole.PLATFORM_ADMIN -> setOf(Permission.MANAGE_PLATFORM)
    }
    fun allowed(actor: Membership, target: Membership, permission: Permission, inDownline: Boolean = false): Boolean {
        if (actor.accountId == target.accountId && permission == Permission.VIEW_MEMBER) return true
        if (actor.organizationId != target.organizationId) return false
        val grants = defaultPermissions(actor.role) + actor.permissions
        if (permission !in grants) return false
        // A platform admin gets no customer or organization access merely because of title.
        if (permission == Permission.VIEW_PRIVATE_CUSTOMER && actor.accountId != target.accountId) return false
        return when(actor.scope) {
            Scope.SELF -> actor.accountId == target.accountId
            Scope.DIRECT -> target.sponsorId == actor.accountId || actor.accountId == target.accountId
            Scope.DOWNLINE -> inDownline || actor.accountId == target.accountId
            Scope.ORGANIZATION -> true
            Scope.PLATFORM -> permission == Permission.MANAGE_PLATFORM
        }
    }
    fun canAssignSupportTask(actor: Membership, target: Membership, isInOwnBranch: Boolean) =
        allowed(actor, target, Permission.ASSIGN_SUPPORT, isInOwnBranch)
    fun canViewPrivateCustomerData(actor: Membership, owner: Membership) = actor.accountId == owner.accountId
}

/** A canceled item isn't completed. Workload counts should not include canceled items. */
fun completionProgress(statuses: List<TaskStatus>): Float {
    val applicable = statuses.filter { it != TaskStatus.CANCELLED }
    return if (applicable.isEmpty()) 0f else applicable.count { it == TaskStatus.COMPLETED }.toFloat() / applicable.size
}

/** Strict local calendar-day boundaries, respecting the user's timezone and DST. */
fun sameLocalDay(a: Long, b: Long, zone: TimeZone = TimeZone.getDefault()): Boolean {
    val one = Calendar.getInstance(zone).apply { timeInMillis = a }
    val two = Calendar.getInstance(zone).apply { timeInMillis = b }
    return one.get(Calendar.ERA) == two.get(Calendar.ERA) &&
        one.get(Calendar.YEAR) == two.get(Calendar.YEAR) &&
        one.get(Calendar.DAY_OF_YEAR) == two.get(Calendar.DAY_OF_YEAR)
}

/** First recurrence strictly after now; late completions never create a backlog of overdue copies. */
fun nextOccurrence(dueAt: Long, rule: RepeatRule, now: Long): Long? {
    if (rule == RepeatRule.NONE) return null
    val c = Calendar.getInstance().apply { timeInMillis = dueAt }
    repeat(5000) {
        when(rule) {
            RepeatRule.DAILY -> c.add(Calendar.DAY_OF_YEAR, 1)
            RepeatRule.WEEKLY -> c.add(Calendar.WEEK_OF_YEAR, 1)
            RepeatRule.MONTHLY -> c.add(Calendar.MONTH, 1)
            RepeatRule.NONE -> Unit
        }
        if (c.timeInMillis > now) return c.timeInMillis
    }
    return null
}
