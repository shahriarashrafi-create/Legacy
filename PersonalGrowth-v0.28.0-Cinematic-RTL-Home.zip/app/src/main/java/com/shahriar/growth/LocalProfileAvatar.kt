package com.shahriar.growth

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.File
import kotlin.math.max
import kotlin.math.min

/**
 * A user-selected avatar copied into private device storage.
 * No cloud fetching, permissions for ongoing gallery access, or Room migration.
 * This does not alter any existing profile/XP/coins/task data.
 */
object LocalProfileAvatar {
    private const val FILE_NAME = "local_profile_avatar.jpg"

    fun load(context: Context): ImageBitmap? = runCatching {
        val file = File(context.filesDir, FILE_NAME)
        if (!file.isFile) null else BitmapFactory.decodeFile(file.absolutePath)?.asImageBitmap()
    }.getOrNull()

    fun save(context: Context, uri: Uri): Boolean = runCatching {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Invalid photo" }

        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 640) sample *= 2
        val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sample }
        val bitmap = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, decodeOptions)
        } ?: return@runCatching false

        val side = min(bitmap.width, bitmap.height)
        val crop = Bitmap.createBitmap(
            bitmap, (bitmap.width - side) / 2, (bitmap.height - side) / 2,
            side, side
        )
        val thumb = Bitmap.createScaledBitmap(crop, 320, 320, true)
        val temp = File(context.filesDir, "$FILE_NAME.tmp")
        temp.outputStream().use { require(thumb.compress(Bitmap.CompressFormat.JPEG, 86, it)) }
        val destination = File(context.filesDir, FILE_NAME)
        if (destination.exists()) destination.delete()
        check(temp.renameTo(destination)) { "Could not save the avatar" }
        if (thumb !== crop) thumb.recycle()
        if (crop !== bitmap) crop.recycle()
        bitmap.recycle()
        true
    }.getOrDefault(false)
}
