# گزارش بررسی سورس 0.26.0

| مرحله | نتیجه |
|---|---|
| `tools/verify_home_v026.py` — بررسی قرارداد UI، منابع و تطبیق منطق | PASS |
| `tools/check_upgrade.py` — مهاجرت SQLite از schema 6 به 7، 22 جدول قدیمی محفوظ | PASS |
| آزمون Kotlin/JVM خالص `starterMeetingSlots` — حالت 3 جلسه، موعد گذشته/آینده، روزهای هفته | PASS |
| بررسی فایل‌های Kotlin با کامپایلر مستقل فاقد classpath اندروید | هیچ خطای parsing مستقل دیده نشد؛ **کامپایل نیست** |
| XML آیکن لانچر | PASS |
| سلامت ZIP | پس از بسته‌بندی کنترل می‌شود |
| Gradle/Kotlin Android compile | **NOT VERIFIED:** Gradle wrapper نیازمند دانلود distribution 8.7 بود؛ DNS `services.gradle.org` در محیط در دسترس نبود |
| APK قابل نصب، UnitTestهای Gradle، تست UI دستگاه واقعی | **NOT RUN** |

- سورس مبنا: `PersonalGrowth-v0.25.0-Unified-Home.zip`، شناسه بسته و کلید امضا حفظ شده است.
- شماره نسخه: `versionCode 26`, `versionName 0.26.0`; Room schema برابر 7.
- تغییرات کد اصلی محدود به چهار فایل یادشده در `IMPLEMENTATION-NOTES-v0.26.0.md` هستند.
- برای بیلد: پروژه را استخراج کرده و با JDK 17 + Android SDK 35 + دسترسی Gradle دستور `./gradlew assembleDebug testDebugUnitTest` را اجرا کنید.
- برای تضمین تناسب صفحه، تست فیزیکی با عرض‌های 320، 360، 393 و 412dp و ترکیب‌های ناوبری/فونت ضروری است. تست ریاضی `Scaffold` جای رندر Compose را نمی‌گیرد.
