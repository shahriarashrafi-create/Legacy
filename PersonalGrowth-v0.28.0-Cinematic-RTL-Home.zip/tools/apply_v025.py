from pathlib import Path
root=Path('/mnt/data/growth_v025_work')
p=root/'app/src/main/java/com/shahriar/growth/RedesignedHome.kt'
s=p.read_text()
s=s.replace('import androidx.compose.foundation.Canvas\n', 'import androidx.compose.foundation.Canvas\nimport androidx.compose.foundation.Image\n')
s=s.replace('import androidx.compose.ui.Alignment\n', 'import androidx.compose.ui.Alignment\nimport androidx.compose.ui.layout.ContentScale\nimport androidx.compose.ui.platform.LocalContext\nimport androidx.compose.ui.text.style.TextAlign\n')
s=s.replace('import androidx.compose.ui.graphics.Color\n', 'import androidx.compose.ui.graphics.Color\nimport androidx.compose.ui.graphics.Brush\n')
s=s.replace('import androidx.compose.ui.graphics.drawscope.Stroke\n', 'import androidx.compose.ui.graphics.drawscope.Stroke\nimport androidx.compose.ui.graphics.drawscope.DrawScope\n')
# Replace old Home level composable section, preserve HomeMedal after HomeDoneMetric
start=s.index('@Composable\nprivate fun HomeLevelCard(')
end=s.index('/** Ribboned gold medal.',start)
new_header='''/**
 * One fixed home header, occupying the Scaffold topBar slot.
 * RTL: [medal] [user name (right) / level (left) above XP bar] [local avatar].
 * Four bold gamification chips share one second row. No separate logo,
 * settings/search buttons, or standalone level card on Home.
 */
@Composable
fun HomeUnifiedHeader(name: String?, tasks: List<Task>, wallet: List<WalletEntry>, today: Long) {
    val earnedXp = wallet.sumOf { it.xp }.coerceAtLeast(0L)
    val currentLevel = levelFor(earnedXp)
    val progressXp = (earnedXp % 100L).toInt()
    val coins = wallet.sumOf { it.coins }
    val finished = tasks.filter {
        !it.archived && it.done && it.completedAt?.let { stamp ->
            localDay(stamp, ZoneId.systemDefault()) == today
        } == true
    }
    val doneToday = finished.size
    val combo = streakDays(tasks.filter { it.done }.mapNotNull { it.completedAt?.let { stamp ->
        localDay(stamp, ZoneId.systemDefault())
    } }.toSet(), today)
    val context = LocalContext.current
    // The optional avatar is only read from the application's private local storage.
    val localAvatar = remember(context) { LocalProfileAvatar.load(context) }

    Surface(color = Color.White, shadowElevation = 1.dp) {
        Column(Modifier.fillMaxWidth().statusBarsPadding()
            .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(Modifier.fillMaxWidth().height(55.dp), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                HomeMedal(currentLevel, 52.dp)
                Column(Modifier.weight(1f).fillMaxHeight(),
                    verticalArrangement = Arrangement.Center) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(name?.takeIf { it.isNotBlank() } ?: "نام کاربر",
                            modifier = Modifier.weight(1f), color = HomeInk,
                            fontWeight = FontWeight.Bold, fontSize = 12.sp,
                            textAlign = TextAlign.Right, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("Level $currentLevel: ${homeLevelName(currentLevel)}",
                            modifier = Modifier.weight(1.3f), color = HomeInk,
                            fontWeight = FontWeight.ExtraBold, fontSize = 11.sp,
                            textAlign = TextAlign.Left, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Spacer(Modifier.height(8.dp))
                    // XP goes physically left-to-right even when the whole screen is RTL.
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Box(Modifier.fillMaxWidth().height(8.dp)
                            .clip(RoundedCornerShape(8.dp)).background(Color(0xFFE6ECFA))) {
                            if (progressXp > 0) {
                                Box(Modifier.fillMaxWidth(progressXp / 100f).fillMaxHeight()
                                    .background(Brush.horizontalGradient(listOf(HomeBlue, Color(0xFF7197FF))), RoundedCornerShape(8.dp)))
                            }
                        }
                    }
                }
                Box(Modifier.size(48.dp).clip(CircleShape).background(Color(0xFFE9EDF5)),
                    contentAlignment = Alignment.Center) {
                    if (localAvatar != null) {
                        Image(bitmap = localAvatar, contentDescription = "عکس پروفایل کاربر",
                            contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    } else {
                        Icon(Icons.Outlined.PersonOutline, "آواتار پیش‌فرض", tint = Color(0xFF8290A6),
                            modifier = Modifier.size(29.dp))
                    }
                }
            }
            // Exactly four equally sized colored cards. Each graphic is constructed
            // locally; DONE is not a circular-progress widget.
            Row(Modifier.fillMaxWidth().height(43.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                HomeGameMetric(Modifier.weight(1f), HomeBlue, Color.White, "xp", "$progressXp/100")
                HomeGameMetric(Modifier.weight(1f), CoinGold, Color(0xFF483006), "coin", "$coins")
                HomeGameMetric(Modifier.weight(1f), DoneGreen, Color.White, "done", "$doneToday")
                HomeGameMetric(Modifier.weight(1f), ComboOrange, Color.White, "combo", "$combo")
            }
        }
    }
}

@Composable
private fun HomeGameMetric(modifier: Modifier, background: Color, foreground: Color,
                           kind: String, value: String) {
    Box(modifier.clip(RoundedCornerShape(12.dp))
        .background(Brush.verticalGradient(listOf(background.copy(alpha=.86f), background))),
        contentAlignment = Alignment.Center) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 3.dp),
            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            HomeGameGlyph(kind, Modifier.size(20.dp))
            Spacer(Modifier.width(2.dp))
            val title = when (kind) { "done" -> "DONE"; "combo" -> "COMBO"; else -> "" }
            if (title.isNotEmpty()) {
                Text(title, color = foreground, fontSize = 8.sp, maxLines = 1,
                    fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.width(3.dp))
            }
            Text(value, color = foreground, fontSize = if (value.length > 7) 9.sp else 10.sp,
                fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** Small premium-style, offline Canvas glyphs; no image files or external requests. */
@Composable
private fun HomeGameGlyph(kind: String, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        when (kind) {
            "xp" -> {
                val bolt = Path().apply {
                    moveTo(w*.56f, h*.03f); lineTo(w*.16f,h*.55f)
                    lineTo(w*.47f,h*.55f); lineTo(w*.35f,h*.97f)
                    lineTo(w*.88f,h*.39f); lineTo(w*.57f,h*.39f); close()
                }
                drawPath(bolt, Color(0xFFFFE784))
                drawPath(bolt, Color.White.copy(alpha=.65f), style=Stroke(width=1.dp.toPx()))
            }
            "coin" -> {
                val r = min(w,h)*.46f
                val c = Offset(w*.5f,h*.5f)
                drawCircle(Color(0xFF9C6310), r, c)
                drawCircle(Color(0xFFFFE78B), r*.90f, c)
                drawCircle(Color(0xFFC78C1F), r*.70f, c, style=Stroke(width=1.3.dp.toPx()))
                val star = Path().apply {
                    moveTo(c.x, c.y-r*.54f)
                    lineTo(c.x+r*.20f,c.y-r*.13f)
                    lineTo(c.x+r*.56f,c.y-r*.10f)
                    lineTo(c.x+r*.27f,c.y+r*.17f)
                    lineTo(c.x+r*.36f,c.y+r*.51f)
                    lineTo(c.x,c.y+r*.34f)
                    lineTo(c.x-r*.36f,c.y+r*.51f)
                    lineTo(c.x-r*.27f,c.y+r*.17f)
                    lineTo(c.x-r*.56f,c.y-r*.10f)
                    lineTo(c.x-r*.20f,c.y-r*.13f); close()
                }
                drawPath(star, Color(0xFFB37712))
            }
            "done" -> {
                val shield = Path().apply {
                    moveTo(w*.5f,h*.06f); lineTo(w*.88f,h*.23f)
                    lineTo(w*.82f,h*.67f); lineTo(w*.5f,h*.94f)
                    lineTo(w*.18f,h*.67f); lineTo(w*.12f,h*.23f); close()
                }
                drawPath(shield, Color(0xFFC0FFDC).copy(alpha=.80f))
                val check = Path().apply {
                    moveTo(w*.27f,h*.48f); lineTo(w*.44f,h*.65f); lineTo(w*.75f,h*.32f)
                }
                drawPath(check, Color(0xFF087C41), style=Stroke(width=2.6.dp.toPx()))
            }
            "combo" -> {
                val flame = Path().apply {
                    moveTo(w*.52f,h*.02f)
                    cubicTo(w*.60f,h*.34f,w*.95f,h*.39f,w*.85f,h*.72f)
                    cubicTo(w*.77f,h*1.03f,w*.25f,h*1.03f,w*.15f,h*.73f)
                    cubicTo(w*.05f,h*.43f,w*.37f,h*.30f,w*.52f,h*.02f)
                    close()
                }
                drawPath(flame, Color(0xFFFFE77C))
                val inner = Path().apply {
                    moveTo(w*.48f,h*.45f)
                    cubicTo(w*.62f,h*.63f,w*.69f,h*.72f,w*.59f,h*.84f)
                    cubicTo(w*.47f,h*.97f,w*.28f,h*.79f,w*.36f,h*.65f)
                    close()
                }
                drawPath(inner, Color(0xFFE95D21))
            }
        }
    }
}

'''
s=s[:start]+new_header+s[end:]
# replace count computation and layout to pure body tasks+meetings
start=s.index('    val xp = wallet.sumOf', s.index('fun RedesignedHome('))
end=s.index('    // Meetings have a linked Task.', start)
s=s[:start]+s[end:]
start=s.index('    // Scaffold owns both bars.', s.index('fun RedesignedHome('))
end=s.index('\n}\n\n',start)
new_body='''    // The complete identity+XP+metrics strip is in Scaffold.topBar.
    // This body contains tasks and meetings only, so neither can overlap
    // the fixed header or bottom navigation. No scrolling or clipping hacks.
    BoxWithConstraints(modifier.fillMaxSize()) {
        val short = maxHeight < 430.dp
        val veryShort = maxHeight < 350.dp
        val pad = if (veryShort) 4.dp else if (short) 6.dp else 10.dp
        val sectionGap = if (veryShort) 6.dp else 10.dp
        val usable = (maxHeight - pad*2 - sectionGap).coerceAtLeast(0.dp)
        val meetingHeight = if (upcoming.isEmpty())
            (usable * .23f).coerceAtMost(105.dp)
        else (usable * .36f).coerceAtMost(175.dp)
        val tasksHeight = (usable - meetingHeight).coerceAtLeast(0.dp)
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = pad),
            verticalArrangement = Arrangement.spacedBy(sectionGap)) {
            HomeTasksSection(Modifier.fillMaxWidth().height(tasksHeight), suggested, veryShort,
                onAll = { onList(6) }, onNew = onNew, onOpen = onOpen)
            HomeMeetingsSection(Modifier.fillMaxWidth().height(meetingHeight), upcoming, veryShort,
                onSchedule = onSchedule, onMeetings = onMeetings, onAdd = onNewMeeting)
        }
    }'''
s=s[:start]+new_body+s[end:]
# Strip unused deps in RedesignedHome signature (tasks,wallet,name remain solely header)
s=s.replace('    edges: List<Prerequisite>, meetings: List<Meeting>, wallet: List<WalletEntry>, name: String?,\n',
            '    edges: List<Prerequisite>, meetings: List<Meeting>,\n')
# Accessibility: keep not-used legacy logo removed? HomeRouteLogo used AppHeader other routes.
p.write_text(s)

p=root/'app/src/main/java/com/shahriar/growth/MainActivity.kt'
s=p.read_text()
old='topBar = { if(!focusOpen) AppHeader(profile?.name?.takeIf{it.isNotBlank()} ?: "نام کاربر", onSettings = { extraPage="";settingsOpen = true; pathOpen = false; meetingsOpen=false }, onSearch = {extraPage="search";settingsOpen=false}) },'
new='''topBar = {
                    if (!focusOpen) {
                        if (selected == 0 && extraPage.isEmpty() && !settingsOpen && !pathOpen && !meetingsOpen) {
                            HomeUnifiedHeader(profile?.name, tasks, wallet, today)
                        } else {
                            AppHeader(profile?.name?.takeIf{it.isNotBlank()} ?: "نام کاربر",
                                onSettings = { extraPage=""; settingsOpen=true; pathOpen=false; meetingsOpen=false },
                                onSearch = { extraPage="search"; settingsOpen=false })
                        }
                    }
                },'''
assert old in s
s=s.replace(old,new)
s=s.replace('Modifier.padding(padding),tasks,choice,today,active,edges,meetings,wallet,profile?.name,',
            'Modifier.padding(padding),tasks,choice,today,active,edges,meetings,')
p.write_text(s)

p=root/'app/build.gradle.kts'
s=p.read_text().replace('versionCode = 24','versionCode = 25').replace('versionName = "0.24.0"','versionName = "0.25.0"')
p.write_text(s)
print('Updated', [str(p) for p in [root/'app/src/main/java/com/shahriar/growth/RedesignedHome.kt',root/'app/src/main/java/com/shahriar/growth/MainActivity.kt',root/'app/build.gradle.kts']])
