#!/usr/bin/env python3
"""Static and host-level 0.26 checks; NOT an Android build or screenshot test."""
from pathlib import Path
import json, re, zipfile, math, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
source=root/'app/src/main/java/com/shahriar/growth'
home=(source/'RedesignedHome.kt').read_text()
main=(source/'MainActivity.kt').read_text()
appdata=(source/'data/AppData.kt').read_text()
gradle=(root/'app/build.gradle.kts').read_text()
assert 'versionCode = 26' in gradle and 'versionName = "0.26.0"' in gradle
assert 'fun HomePremiumLevelCard(' in home
assert 'HomePremiumLevelCard(profile?.name, tasks, wallet, today)' in main
assert 'HomeUnifiedHeader(' not in main
assert 'HomeRouteLogo(' not in home.split('fun HomePremiumLevelCard')[1].split('private fun HomeGameMetric')[0]
assert 'statusBarsPadding()' in home and 'navigationBarsPadding()' in main
assert 'Level $level: ${homeLevelName(level)}' in home
assert 'textAlign = TextAlign.Right' in home and 'textAlign = TextAlign.Left' in home
assert 'LocalProfileAvatar.load(context)' in home
assert 'progress > 0' in home and 'animatedProgress' in home
assert home.count('HomeGameMetric(Modifier.weight(1f)') == 4
for word in ('"xp"','"coin"','"done"','"combo"'):
    assert word in home
assert '"DONE"' in home and '"COMBO"' in home
assert 'CircularProgressIndicator(' not in home
assert 'val weightBlue' not in home  # old combined white card implementation removed
assert 'suggested.forEachIndexed' in home and 'weight(if (index == 0) 80f else 73f)' in home
assert 'HomeTaskReward("xp"' in home and 'HomeTaskReward("coin"' in home
assert 'HomeTaskGlyph(' in home and 'HomeMeetingGlyph(' in home
assert 'verticalScroll(' not in home and 'LazyColumn(' not in home
assert 'repeat(3) { index ->' in home and 'upcoming.getOrNull(index)' in home
assert 'Modifier.fillMaxWidth().navigationBarsPadding()' in main
assert 'shadowElevation = 7.dp' in main and 'RoundedCornerShape(23.dp)' in main
assert 'shortcuts.filter{it in selectableTabs}' in main and 'take(3)' in main
assert 'Text("پروفایل و تنظیمات")' in main
assert 'freshDatabase && shouldInsertStarterMeetings' in appdata
assert 'freshDatabase && shouldInsertStarterTasks' in appdata
assert 'getDatabasePath("growth.db").exists()' in main
assert 'settings.ensureStarterTasks(' in main and 'settings.ensureStarterMeetings(' in main
assert 'Task(title = "مطالعه فصل سوم کتاب"' in (source/'data/StarterTasks.kt').read_text()
assert '"برنامه‌ریزی هفتگی"' in (source/'data/StarterMeetings.kt').read_text()
assert 'version = 7' in appdata
ET.parse(root/'app/src/main/res/drawable/ic_launcher.xml')
with zipfile.ZipFile('/mnt/data/PersonalGrowth-v0.25.0-Unified-Home.zip') as z:
    preserved=['signing/personal-growth.jks','app/src/main/AndroidManifest.xml',
               'app/src/main/java/com/shahriar/growth/data/FinalFeatures.kt',
               'app/src/main/java/com/shahriar/growth/data/Tasks.kt',
               'app/src/main/java/com/shahriar/growth/data/Meetings.kt',
               'app/src/main/java/com/shahriar/growth/data/StarterMeetings.kt',
               'app/src/main/java/com/shahriar/growth/data/StarterTasks.kt']
    preserved += [x for x in z.namelist() if x.startswith('app/schemas/')]
    preserved += [x for x in z.namelist() if x.startswith('app/src/main/res/')]
    for name in set(preserved):
        assert (root/name).read_bytes() == z.read(name),f'Unexpected logic/resource edit: {name}'
# Verify actual allocated body heights for standard and compact devices; use the
# height left by Scaffold as input, NOT the screen's full raw dp height.
for remaining in range(300,801,5):
    short=remaining<425
    tiny=remaining<335
    pad=4 if tiny else 6 if short else 9
    gap=5 if tiny else 7 if short else 10
    usable=max(0,remaining-2*pad-gap)
    for n in (0,1,2,3):
        meetings=min(usable*(.23 if n==0 else .34), 93 if n==0 else 157)
        tasks=usable-meetings
        assert 0<=meetings<=usable and 0<=tasks<=usable
        assert abs((tasks+meetings+2*pad+gap)-remaining)<.001
        assert tasks>meetings
# Safety: never add new raster/web image artifacts.
assert not list(root.rglob('*.png')) and not list(root.rglob('*.jpg'))
print('PASS: v0.26 top card structure, four metric colors, Level/title/XP layout and local avatar')
print('PASS: three independent task cards, 80:73:73, badges, meeting/add slots, floating navigation')
print('PASS: safe Scaffold body allocation and no Home scroll, 300-800dp body ranges')
print('PASS: onboarding-only seed gating; reward/meeting engines, Room schemas, signing unchanged')
print('PASS: no added bitmap or external image files')
print('LIMIT: No Android UI rendering/build verified by this host-only check.')
