#!/usr/bin/env python3
"""Rework Home presentation only; retain original task/reward/meeting engines."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
home_path=root/'app/src/main/java/com/shahriar/growth/RedesignedHome.kt'
s=home_path.read_text()

def replace_between(start,end,replacement):
    global s
    a=s.index(start)
    b=s.index(end,a)
    s=s[:a]+replacement.rstrip()+"\n\n"+s[b:]

s=s.replace('import androidx.compose.foundation.Canvas','import androidx.compose.animation.core.animateFloatAsState\nimport androidx.compose.animation.core.tween\nimport androidx.compose.foundation.BorderStroke\nimport androidx.compose.foundation.Canvas')
s=s.replace('import androidx.compose.ui.platform.LocalContext','import androidx.compose.ui.platform.LocalConfiguration\nimport androidx.compose.ui.platform.LocalContext')

replace_between('    // The complete identity+XP+metrics strip is in Scaffold.topBar.', '\n}\n\n/**', '''    // The white premium Level card occupies the real Scaffold topBar slot.
    // The body is independently measured only AFTER Scaffold reserves top/bottom bars.
    BoxWithConstraints(modifier.fillMaxSize().background(
        Brush.verticalGradient(listOf(Color(0xFFFCFDFF), Color(0xFFF7F9FD), Color(0xFFF0F4FD))))) {
        val short = maxHeight < 425.dp
        val veryShort = maxHeight < 335.dp
        val pad = if (veryShort) 4.dp else if (short) 6.dp else 9.dp
        val between = if (veryShort) 5.dp else if (short) 7.dp else 10.dp
        val usable = (maxHeight - pad * 2 - between).coerceAtLeast(0.dp)
        // Meetings size to content first; all remaining space is assigned to the
        // higher-priority three task cards. There are no invisible spacer slots.
        val sessionsHeight = if (upcoming.isEmpty())
            (usable * .23f).coerceAtMost(93.dp)
        else (usable * .34f).coerceAtMost(157.dp)
        val stepsHeight = (usable - sessionsHeight).coerceAtLeast(0.dp)
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = pad),
            verticalArrangement = Arrangement.spacedBy(between)) {
            HomeTasksSection(Modifier.fillMaxWidth().height(stepsHeight), suggested, veryShort,
                onAll = { onList(6) }, onNew = onNew, onOpen = onOpen)
            HomeMeetingsSection(Modifier.fillMaxWidth().height(sessionsHeight), upcoming, veryShort,
                onSchedule = onSchedule, onMeetings = onMeetings, onAdd = onNewMeeting)
        }
    }''')

replace_between('/**\n * One fixed home header', '\n@Composable\nprivate fun HomeGameMetric', '''/** A SINGLE distinct, premium Level card; Compose drawing only, no downloaded images.
 * RTL: medal right, local avatar left. User name right / Level label left
 * ABOVE the XP line between the two portraits, then four colored game chips.
 */
@Composable
fun HomePremiumLevelCard(name: String?, tasks: List<Task>, wallet: List<WalletEntry>, today: Long) {
    val earnedXp = wallet.sumOf { it.xp }.coerceAtLeast(0L)
    val level = levelFor(earnedXp)
    val progress = (earnedXp % 100L).toInt()
    val animatedProgress by animateFloatAsState(
        targetValue = progress / 100f, animationSpec = tween(durationMillis = 540), label = "XP progress")
    val coins = wallet.sumOf { it.coins }
    val doneToday = tasks.count { task -> !task.archived && task.done &&
        task.completedAt?.let { localDay(it, ZoneId.systemDefault()) == today } == true }
    val combo = streakDays(tasks.filter { it.done }.mapNotNull { task ->
        task.completedAt?.let { localDay(it, ZoneId.systemDefault()) }
    }.toSet(), today)
    val context = LocalContext.current
    val localAvatar = remember(context) { LocalProfileAvatar.load(context) }
    val compact = LocalConfiguration.current.screenHeightDp < 695
    val tiny = LocalConfiguration.current.screenHeightDp < 600
    val portraitSize = if (tiny) 38.dp else if (compact) 45.dp else 52.dp
    val medalSize = if (tiny) 41.dp else if (compact) 49.dp else 57.dp
    val infoHeight = if (tiny) 43.dp else if (compact) 51.dp else 57.dp
    val metricHeight = if (tiny) 38.dp else if (compact) 42.dp else 48.dp
    val pad = if (tiny) 8.dp else if (compact) 10.dp else 12.dp
    Column(Modifier.fillMaxWidth().statusBarsPadding().padding(
        horizontal = 13.dp, vertical = if (tiny) 4.dp else 7.dp)) {
        Surface(Modifier.fillMaxWidth().shadow(6.dp, RoundedCornerShape(23.dp)),
            shape = RoundedCornerShape(23.dp), color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE9D4A3))) {
            Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(
                listOf(Color.White, Color(0xFFFEFCF7), Color.White)))
                .padding(horizontal = pad, vertical = pad),
                verticalArrangement = Arrangement.spacedBy(if (tiny) 5.dp else 8.dp)) {
                Row(Modifier.fillMaxWidth().height(infoHeight),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(if (tiny) 5.dp else 9.dp)) {
                    HomeMedal(level, medalSize)
                    Column(Modifier.weight(1f).fillMaxHeight(),
                        verticalArrangement = Arrangement.Center) {
                        Row(Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Text(name?.takeIf { it.isNotBlank() } ?: "نام کاربر",
                                modifier = Modifier.weight(.9f), color = HomeInk,
                                fontWeight = FontWeight.ExtraBold, fontSize = if (tiny) 10.sp else 12.sp,
                                textAlign = TextAlign.Right, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                            Text("Level $level: ${homeLevelName(level)}",
                                modifier = Modifier.weight(1.45f), color = Color(0xFF273C78),
                                fontWeight = FontWeight.ExtraBold, fontSize = if (tiny) 9.sp else 11.sp,
                                textAlign = TextAlign.Left, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                        }
                        Spacer(Modifier.height(if (tiny) 6.dp else 9.dp))
                        // LTR fill direction even though everything around it is RTL.
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Box(Modifier.fillMaxWidth().height(if (tiny) 8.dp else 11.dp)
                                .clip(CircleShape).background(Color(0xFFDDE6FA))) {
                                // The empty state is a truly empty track: no rounded zero dot.
                                if (progress > 0) {
                                    Box(Modifier.fillMaxWidth(animatedProgress.coerceIn(0f, 1f))
                                        .fillMaxHeight().clip(CircleShape)
                                        .background(Brush.horizontalGradient(listOf(
                                            Color(0xFF2048C2), Color(0xFF4776F0), Color(0xFF91B8FF)))))
                                    Box(Modifier.fillMaxWidth(animatedProgress.coerceIn(0f, 1f))
                                        .height(2.dp).padding(horizontal = 2.dp)
                                        .background(Color.White.copy(alpha = .38f)))
                                }
                            }
                        }
                    }
                    Box(Modifier.size(portraitSize).clip(CircleShape)
                        .background(Color(0xFFE8EDF7)), contentAlignment = Alignment.Center) {
                        if (localAvatar != null) {
                            Image(bitmap = localAvatar, contentDescription = "عکس پروفایل کاربر",
                                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        } else {
                            Icon(Icons.Outlined.PersonOutline, "آواتار پیش‌فرض", tint = Color(0xFF8796AE),
                                modifier = Modifier.size(portraitSize * .66f))
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().height(metricHeight),
                    horizontalArrangement = Arrangement.spacedBy(if (tiny) 3.dp else 6.dp)) {
                    HomeGameMetric(Modifier.weight(1f), HomeBlue, Color.White, "xp", "$progress/100")
                    HomeGameMetric(Modifier.weight(1f), CoinGold, Color(0xFF483006), "coin", "$coins")
                    HomeGameMetric(Modifier.weight(1f), DoneGreen, Color.White, "done", "$doneToday")
                    HomeGameMetric(Modifier.weight(1f), ComboOrange, Color.White, "combo", "$combo")
                }
            }
        }
    }
}''')

replace_between('@Composable\nprivate fun HomeGameMetric', '/** Small premium-style', '''@Composable
private fun HomeGameMetric(modifier: Modifier, background: Color, foreground: Color,
                           kind: String, value: String) {
    val highlight = when (kind) {
        "xp" -> Color(0xFF6988FA)
        "coin" -> Color(0xFFFFDF76)
        "done" -> Color(0xFF43CE91)
        else -> Color(0xFFFFAA62)
    }
    Box(modifier.clip(RoundedCornerShape(12.dp))
        .background(Brush.verticalGradient(listOf(highlight, background, background))),
        contentAlignment = Alignment.Center) {
        // The tiny top highlight gives game-UI depth without external assets.
        Box(Modifier.fillMaxWidth().height(1.dp).align(Alignment.TopCenter)
            .background(Color.White.copy(alpha = .48f)))
        Row(Modifier.fillMaxWidth().padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            HomeGameGlyph(kind, Modifier.size(18.dp))
            Spacer(Modifier.width(2.dp))
            val title = when (kind) { "done" -> "DONE"; "combo" -> "COMBO"; else -> "" }
            if (title.isNotEmpty()) {
                Text(title, color = foreground, fontSize = 8.sp, maxLines = 1,
                    fontWeight = FontWeight.Black)
                Spacer(Modifier.width(2.dp))
            }
            Text(value, color = foreground, fontSize = if (value.length > 7) 8.sp else 10.sp,
                fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}''')

# Enhance existing medal visuals: replace pale badge backing with transparent
s=s.replace('Box(Modifier.size(boxSize).background(HomePale, RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center)',
            'Box(Modifier.size(boxSize), contentAlignment = Alignment.Center)')
s=s.replace('drawCircle(Color(0xFFFFD870), radius = radius * .96f, center = centre)',
            '''drawCircle(brush = Brush.radialGradient(listOf(Color(0xFFFFF6BC),
                Color(0xFFF6C34F), Color(0xFFAB691A)), center = centre,
                radius = radius * 1.15f), radius = radius * .96f, center = centre)''')
s=s.replace('drawCircle(Color(0xFFFFF0AF), radius = radius * .72f, center = centre)',
            '''drawCircle(brush = Brush.radialGradient(listOf(Color(0xFFFFFBE0),
                Color(0xFFF7D778)), center = centre, radius = radius),
                radius = radius * .72f, center = centre)
            drawCircle(Color.White.copy(alpha = .75f), radius = radius * .13f,
                center = Offset(centre.x - radius * .34f, centre.y - radius * .32f))''')

replace_between('@Composable\nprivate fun HomeTasksSection(', '\n@Composable\nprivate fun HomeAutoTaskTitle', '''@Composable
private fun HomeTasksSection(
    modifier: Modifier, suggested: List<Task>, veryShort: Boolean,
    onAll: () -> Unit, onNew: () -> Unit, onOpen: (String) -> Unit
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(if (veryShort) 4.dp else 6.dp)) {
        HomeSectionTitle("قدم بعدی", "مشاهده همه", onAll, veryShort)
        if (suggested.isEmpty()) {
            Card(Modifier.fillMaxWidth().weight(1f), shape = HomeShape,
                colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.fillMaxSize().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("فعلاً کاری برای شروع وجود ندارد.", modifier = Modifier.weight(1f),
                        color = HomeMuted, fontSize = 12.sp)
                    TextButton(onClick = onNew) { Text("افزودن کار") }
                }
            }
        } else {
            // Three fully independent cards. Keep 80:73:73 when all three exist.
            suggested.forEachIndexed { index, task ->
                HomeTaskRow(task, featured = index == 0,
                    modifier = Modifier.fillMaxWidth().weight(if (index == 0) 80f else 73f),
                    veryShort = veryShort, onStart = { onOpen(task.id) })
            }
        }
    }
}

@Composable
private fun HomeTaskRow(task: Task, featured: Boolean, modifier: Modifier,
                        veryShort: Boolean, onStart: () -> Unit) {
    val ink = if (featured) Color.White else HomeInk
    val payout = rewardFor(task.priority)
    Surface(modifier = modifier.shadow(if (featured) 5.dp else 3.dp, RoundedCornerShape(19.dp)),
        shape = RoundedCornerShape(19.dp), color = if (featured) HomeBlue else Color.White,
        border = if (featured) null else BorderStroke(.7.dp, Color(0xFFE4EAF5))) {
        BoxWithConstraints(Modifier.fillMaxSize().then(if (featured) Modifier.background(
            Brush.horizontalGradient(listOf(Color(0xFF254ACA), HomeBlue, Color(0xFF4D77E9)))) else Modifier)) {
            val compact = maxHeight < 74.dp || veryShort
            val iconSize = if (compact) 31.dp else 39.dp
            Row(Modifier.fillMaxSize().padding(horizontal = if (compact) 8.dp else 12.dp,
                vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(if (compact) 5.dp else 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(iconSize).clip(RoundedCornerShape(10.dp))
                    .background(if (featured) Color.White.copy(alpha = .16f) else HomePale),
                    contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.ListAlt, null, tint = if (featured) Color.White else HomeBlue,
                        modifier = Modifier.size(if (compact) 19.dp else 23.dp))
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(
                    if (compact) 3.dp else 5.dp)) {
                    HomeAutoTaskTitle(task.title, ink, if (compact) 12f else 14f)
                    Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(if (compact) 3.dp else 5.dp)) {
                        HomeTaskReward("xp", "$TASK_COMPLETION_XP XP", compact)
                        HomeTaskReward("coin", "$payout", compact)
                    }
                }
                Button(onClick = onStart, modifier = Modifier.width(if (compact) 51.dp else 62.dp)
                    .height(if (compact) 37.dp else 42.dp),
                    shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (featured) Color.White else HomeBlue,
                        contentColor = if (featured) HomeBlue else Color.White),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 3.dp,
                        pressedElevation = 0.dp)) {
                    Text("شروع", fontSize = if (compact) 10.sp else 12.sp,
                        fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}''')

replace_between('@Composable\nprivate fun HomeTaskReward(', '\n@Composable\nprivate fun HomeMeetingsSection', '''@Composable
private fun HomeTaskReward(kind: String, value: String, compact: Boolean) {
    val blue = kind == "xp"
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(Modifier.clip(RoundedCornerShape(8.dp))
            .background(if (blue) Brush.horizontalGradient(listOf(Color(0xFF365EDF), Color(0xFF688DF8)))
                else Brush.horizontalGradient(listOf(Color(0xFFFFE38C), Color(0xFFF1BB47))))
            .padding(horizontal = if (compact) 4.dp else 6.dp,
                vertical = if (compact) 2.dp else 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            HomeGameGlyph(if (blue) "xp" else "coin", Modifier.size(if (compact) 12.dp else 14.dp))
            Text(value, fontSize = if (compact) 8.sp else 9.sp,
                fontWeight = FontWeight.Bold, maxLines = 1,
                color = if (blue) Color.White else Color(0xFF553706))
        }
    }
}''')

replace_between('@Composable\nprivate fun HomeMeetingsSection(', '\n@Composable\nprivate fun HomeMeetingTitle', '''@Composable
private fun HomeMeetingsSection(
    modifier: Modifier, upcoming: List<Pair<Meeting, Task>>, veryShort: Boolean,
    onSchedule: () -> Unit, onMeetings: (String) -> Unit, onAdd: () -> Unit
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(if (veryShort) 4.dp else 6.dp)) {
        HomeSectionTitle("جلسه بعدی", "تایم‌شیت", onSchedule, veryShort)
        if (upcoming.isEmpty()) {
            Surface(onClick = onAdd, modifier = Modifier.fillMaxWidth().weight(1f),
                color = Color.White, shape = RoundedCornerShape(18.dp),
                border = BorderStroke(.8.dp, Color(0xFFE5EBF5)), shadowElevation = 2.dp) {
                Row(Modifier.fillMaxSize().padding(horizontal = 13.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("جلسه آینده‌ای ندارید", modifier = Modifier.weight(1f),
                        maxLines = 1, color = HomeMuted, fontSize = 12.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.AddCircleOutline, null, tint = HomeBlue,
                            modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("افزودن جلسه", color = HomeBlue, fontSize = 11.sp,
                            fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().weight(1f),
                horizontalArrangement = Arrangement.spacedBy(if (veryShort) 4.dp else 7.dp)) {
                // In RTL, index 0 is the rightmost/closest event.
                repeat(3) { index ->
                    val event = upcoming.getOrNull(index)
                    if (event == null) {
                        Surface(onClick = onAdd, modifier = Modifier.weight(1f).fillMaxHeight(),
                            shape = RoundedCornerShape(17.dp), color = Color.White,
                            border = BorderStroke(1.dp, Color(0xFFC9D7F7)), shadowElevation = 2.dp) {
                            Column(Modifier.fillMaxSize().padding(3.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center) {
                                Icon(Icons.Outlined.AddCircleOutline, "افزودن جلسه",
                                    tint = HomeBlue, modifier = Modifier.size(if (veryShort) 19.dp else 25.dp))
                                Spacer(Modifier.height(5.dp))
                                Text("افزودن جلسه", fontSize = if (veryShort) 9.sp else 10.sp,
                                    color = HomeBlue, fontWeight = FontWeight.SemiBold,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    } else {
                        val (meeting, task) = event
                        Card(onClick = { onMeetings(meeting.id) },
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                            shape = RoundedCornerShape(17.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                            border = BorderStroke(.7.dp, Color(0xFFE6EBF5))) {
                            Column(Modifier.fillMaxSize().padding(horizontal = 4.dp, vertical = 5.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.SpaceEvenly) {
                                Icon(Icons.Outlined.EventNote, null,
                                    tint = HomeBlue, modifier = Modifier.size(if (veryShort) 14.dp else 17.dp))
                                Text(homeWeekday(requireNotNull(task.dueDay)),
                                    fontSize = if (veryShort) 10.sp else 11.sp,
                                    color = HomeInk, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Text(task.dueMinute?.let { String.format(Locale.ROOT,
                                    "%02d:%02d", it / 60, it % 60) } ?: "—",
                                    fontSize = if (veryShort) 13.sp else 16.sp,
                                    color = HomeBlue, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                                HomeMeetingTitle(task.title, veryShort)
                            }
                        }
                    }
                }
            }
        }
    }
}''')

home_path.write_text(s)

# Main: route new premium card and add a floating, rounded bottom surface.
mainpath=root/'app/src/main/java/com/shahriar/growth/MainActivity.kt'
m=mainpath.read_text()
m=m.replace('import androidx.compose.foundation.background',
'''import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background''',1)
m=m.replace('HomeUnifiedHeader(profile?.name, tasks, wallet, today)',
            'HomePremiumLevelCard(profile?.name, tasks, wallet, today)')
start=m.index('                    // A dedicated bar measured by Scaffold.')
end=m.index('                } }, containerColor',start)
m=m[:start]+'''                    // Floating bar lives INSIDE Scaffold.bottomBar. Its own inset is
                    // reserved, so meeting cards never enter the system navigation area.
                    Box(Modifier.fillMaxWidth().navigationBarsPadding()
                        .padding(horizontal = 13.dp, vertical = 6.dp)) {
                        Surface(modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(23.dp), color = Color.White,
                            shadowElevation = 7.dp,
                            border = BorderStroke(.8.dp, Color(0xFFE5EAF5))) {
                            Row(Modifier.fillMaxWidth().height(61.dp).padding(horizontal = 7.dp,
                                vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                                val tabs = listOf(0) + shortcuts.filter{it in selectableTabs}
                                    .distinct().take(3) + listOf(4)
                                tabs.forEach { id ->
                                    val label = if(id==0) "خانه" else if(id==4) "بخش‌ها" else shortcutLabels[id] ?: "بخش"
                                    val icon = if(id==0) Icons.Outlined.Home else if(id==4)
                                        Icons.Outlined.GridView else shortcutIcons[id] ?: Icons.Outlined.GridView
                                    val isActive = if (id == 0)
                                        selected == 0 && extraPage.isEmpty() && !pathOpen && !meetingsOpen
                                    else id == selected && extraPage.isEmpty() && !pathOpen && !meetingsOpen
                                    val iconTint = if(isActive) Blue else Color(0xFF8290A5)
                                    val itemModifier=Modifier.weight(1f).fillMaxHeight()
                                        .padding(horizontal=2.dp)
                                    Surface(onClick={if(id==4) sectionsOpen=true else if(id==0){
                                            selected=0;extraPage="";pathOpen=false;meetingsOpen=false;reportView=false
                                        } else openShortcut(id)},
                                        modifier=itemModifier,shape=RoundedCornerShape(16.dp),
                                        color=if(isActive)Color(0xFFEEF2FF) else Color.White) {
                                        Column(Modifier.fillMaxSize(),
                                            horizontalAlignment=Alignment.CenterHorizontally,
                                            verticalArrangement=Arrangement.Center) {
                                            Box(Modifier.size(25.dp).then(if(id!=0 && id!=4) Modifier.pointerInput(id) {
                                                detectTapGestures(onLongPress={shortcutMenu=id})
                                            } else Modifier), contentAlignment=Alignment.Center) {
                                                Icon(icon,null,tint=iconTint,modifier=Modifier.size(22.dp))
                                            }
                                            Spacer(Modifier.height(2.dp))
                                            Text(label,color=iconTint,
                                                fontWeight=if(isActive)FontWeight.Bold else FontWeight.Normal,
                                                fontSize=10.sp,maxLines=1,
                                                overflow=TextOverflow.Ellipsis)
                                        }
                                    }
                                }
                            }
                        }
                    }
''' + m[end:]
m=m.replace('نسخه ۰٫۲۴٫۰', 'نسخه ۰٫۲۶٫۰')
mainpath.write_text(m)

p=root/'app/build.gradle.kts'
b=p.read_text().replace('versionCode = 25','versionCode = 26').replace('versionName = "0.25.0"','versionName = "0.26.0"')
p.write_text(b)
print('v026 UI changes written')
