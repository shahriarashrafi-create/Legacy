#!/usr/bin/env python3
"""v0.25.0 source/geometry/regression checks; not a substitute for an Android build."""
from pathlib import Path
import re, xml.etree.ElementTree as ET, zipfile
root=Path(__file__).resolve().parents[1]
home=(root/'app/src/main/java/com/shahriar/growth/RedesignedHome.kt').read_text()
main=(root/'app/src/main/java/com/shahriar/growth/MainActivity.kt').read_text()
gradle=(root/'app/build.gradle.kts').read_text()
meetingseed=(root/'app/src/main/java/com/shahriar/growth/data/StarterMeetings.kt').read_text()
assert 'fun HomeUnifiedHeader(' in home
assert 'HomeMedal(currentLevel, 52.dp)' in home
assert 'textAlign = TextAlign.Right' in home and 'textAlign = TextAlign.Left' in home
assert 'localAvatar = remember(context) { LocalProfileAvatar.load(context) }' in home
assert 'val title = when (kind) { "done" -> "DONE"; "combo" -> "COMBO"' in home
assert 'HomeGameMetric(Modifier.weight(1f)' in home and home.count('HomeGameMetric(Modifier.weight(1f)')==4
assert 'HomeDoneMetric(' not in home and 'CircularProgressIndicator(' not in home
assert 'val weightBlue = 80f' in home and 'val weightWhite = 73f' in home
assert 'verticalScroll(' not in home and 'LazyColumn(' not in home
assert 'repeat(3) { index ->' in home and 'upcoming.getOrNull(index)' in home
assert 'fun HomeLevelCard(' not in home
assert 'HomeUnifiedHeader(profile?.name, tasks, wallet, today)' in main
assert 'if (selected == 0 && extraPage.isEmpty() && !settingsOpen && !pathOpen && !meetingsOpen)' in main
assert 'onNewMeeting={openMeetings("all","",createNew=true)}' in main
assert 'Spacer(Modifier.fillMaxWidth().navigationBarsPadding())' in main
assert 'versionCode = 25' in gradle and 'versionName = "0.25.0"' in gradle
assert 'shouldInsertStarterMeetings' in meetingseed and 'starterMeetingSlots' in meetingseed
ET.parse(root/'app/src/main/res/drawable/ic_launcher.xml')
# Assert source identity (no migrations or reward logic changed) against the original v0.24 archive
with zipfile.ZipFile('/mnt/data/PersonalGrowth-v0.24.0-Home-Final.zip') as z:
    for item in z.namelist():
        if item.endswith('.kt') and '/data/' in item:
            assert (root/item).read_bytes() == z.read(item), item
    assert (root/'app/src/main/java/com/shahriar/growth/MeetingScreens.kt').read_bytes()==z.read('app/src/main/java/com/shahriar/growth/MeetingScreens.kt')
# Budgets use the available Scaffold body height; no room borrowed from bottom nav.
for height in range(320,901,8):
    short=height<430
    very_short=height<350
    pad=4 if very_short else 6 if short else 10
    gap=6 if very_short else 10
    usable=max(0,height-2*pad-gap)
    for has_meeting in [True, False]:
        meeting=min(usable*(.36 if has_meeting else .23),175 if has_meeting else 105)
        task=max(0,usable-meeting)
        assert abs(task+meeting+2*pad+gap-height)<1e-7, (height, task, meeting)
        assert task>meeting, (height,task,meeting)
print('PASS: fixed unified header, RTL position, local avatar, four game chips, no separate level card')
print('PASS: no Home scrolling, content geometry covers body without entering fixed bottom bar')
print('PASS: existing database, rewards and meetings logic unchanged')
print('NOTE: Android/Compose build not verified without Gradle distribution.')
