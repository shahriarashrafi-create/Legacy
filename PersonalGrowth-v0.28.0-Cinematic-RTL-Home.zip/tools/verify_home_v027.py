#!/usr/bin/env python3
"""Host-only UI source invariants for v0.27; not an Android render/build."""
from pathlib import Path
import re,zipfile,json,hashlib,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
source=root/'app/src/main/java/com/shahriar/growth'
home=(source/'RedesignedHome.kt').read_text(encoding='utf-8')
main=(source/'MainActivity.kt').read_text(encoding='utf-8')
appdata=(source/'data/AppData.kt').read_text(encoding='utf-8')
gradle=(root/'app/build.gradle.kts').read_text(encoding='utf-8')
assert 'versionCode = 27' in gradle and 'versionName = "0.27.0"' in gradle
assert home.count('HomeGameMetric(Modifier.weight(1f).fillMaxHeight(),') == 4, 'Metric row previously reserved height without filling it'
assert 'val metricHeight = if (tiny) 45.dp else if (compact) 53.dp else 61.dp' in home
assert 'bottom = if (tiny) 4.dp else 5.dp' in home
assert 'fun HomePremiumLevelCard(' in home and 'HomePremiumLevelCard(profile?.name, tasks, wallet, today)' in main
assert 'val progress = (earnedXp % 100L).toInt()' in home and 'if (progress > 0)' in home
assert 'LocalProfileAvatar.load(context)' in home
for label in ('"XP"','"COIN"','"DONE"','"COMBO"'):
    assert label in home
for kind in ('"xp"','"coin"','"done"','"combo"'):
    assert kind in home
assert 'HomeTaskGlyph(featured' in home and 'val leftPages=Path()' in home and 'val rightPages=Path()' in home
assert 'book(.66f' in home and 'book(.48f' in home
assert 'CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {' in home, 'Task icon left, button right'
assert 'HomeAutoTaskTitle(task.title' in home and 'HomeTaskReward("xp"' in home and 'HomeTaskReward("coin"' in home
assert 'suggested.forEachIndexed' in home and 'weight(if (index == 0) 80f else 73f)' in home
assert 'repeat(3) { index ->' in home and 'upcoming.getOrNull(index)' in home
assert re.search(r'Row\(Modifier.fillMaxWidth\(\),\s*verticalAlignment = Alignment.CenterVertically,\s*horizontalArrangement = Arrangement.Center\) \{\s*HomeMeetingGlyph\(', home)
assert 'homeWeekday(requireNotNull(task.dueDay))' in home and 'TextAlign.Center' in home
assert 'HomeMeetingCategoryMark(task.title)' in home
assert 'HomeMeetingTitle(task.title, veryShort)' in home
assert 'HomeMeetingTitle(title: String' in home
assert 'verticalScroll(' not in home and 'LazyColumn(' not in home
assert 'Brush.verticalGradient(listOf(Color(0xFFFCFDFF), Color(0xFFF7F9FD), Color(0xFFF0F4FD)))' in home
assert 'Modifier.fillMaxWidth().navigationBarsPadding()' in main
assert 'val tabs = listOf(0) + shortcuts.filter{it in selectableTabs}' in main
assert 'freshDatabase && shouldInsertStarterMeetings' in appdata
assert 'freshDatabase && shouldInsertStarterTasks' in appdata
assert 'version = 7' in appdata
ET.parse(root/'app/src/main/res/drawable/ic_launcher.xml')
# The scope of changes is narrow and tracked. Data, signing, resources, settings and logic must match previous ZIP.
with zipfile.ZipFile('/mnt/data/PersonalGrowth-v0.26.0-Premium-Home.zip') as z:
    prior={n for n in z.namelist() if not n.endswith('/')}
    altered=[]
    for name in prior:
        f=root/name
        assert f.exists(),f'File from v026 unexpectedly removed: {name}'
        if f.read_bytes()!=z.read(name): altered.append(name)
    expected={'app/src/main/java/com/shahriar/growth/RedesignedHome.kt','app/build.gradle.kts',
              'README.md','CHANGELOG.md'}
    assert set(altered).issubset(expected),f'Unexpected file changes: {set(altered)-expected}'
    assert {'app/src/main/java/com/shahriar/growth/RedesignedHome.kt','app/build.gradle.kts'}.issubset(altered)
    print('Preserved original files; modified from v0.26:',', '.join(sorted(altered)))
assert not list(root.rglob('*.png')) and not list(root.rglob('*.jpg'))
# Old and new comparable card-height budgets: taller actual chips without expanding Level slot.
for old,new in [(8+16+43+5+38,6+7+4+45+4+45),
                (14+20+51+8+42,8+9+5+52+5+53),
                (14+24+57+8+48,8+11+5+59+5+61)]:
    assert new<=old+3,(old,new)
for remaining in range(300,801,5):
    short=remaining<425;tiny=remaining<335
    pad=4 if tiny else 6 if short else 9
    gap=5 if tiny else 7 if short else 10
    usable=max(0,remaining-2*pad-gap)
    for count in (0,1,2,3):
        meeting=min(usable*(.23 if count==0 else .34), 93 if count==0 else 157)
        task=usable-meeting
        assert task>meeting and abs(task+meeting+2*pad+gap-remaining)<1e-3
print('PASS: four full-height premium metrics, smaller card whitespace and header budget')
print('PASS: Canvas book stack, rich rewards, same-line weekday/calendar icon, centered meeting data')
print('PASS: task row LTR presentation, 80:73:73, safe Scaffold layout, unchanged Room/engine/navigation/signing/resources')
print('LIMITATION: source and mathematical checks are not Android APK compilation or device screenshot validation')
