# گزارش واقعی وضعیت ساخت و اعتبارسنجی 0.27.0

## پایه
- سورس مبنا: `PersonalGrowth-v0.26.0-Premium-Home.zip`.
- خروجی: سورس اندروید، نه APK. `applicationId=com.shahriar.growth`، کلید امضا و Room schema=7 دست‌نخورده‌اند؛ `versionCode=27`، `versionName=0.27.0`.

## آزمون‌های انجام‌شده

| بررسی | نتیجه | توضیح |
| --- | --- | --- |
| `python3 tools/verify_home_v027.py` | PASS | ارتفاع واقعی چهار شاخص، حاشیه Level، چهار اَسِت Canvas، کتاب چندلایه، ترتیب ردیف تسک و جلسه، نسبت ارتفاع و نبود Scroll |
| مقایسه بایت به بایت با ZIP نسخه 0.26 | PASS | از کد برنامه فقط `RedesignedHome.kt` و `app/build.gradle.kts` تغییر کرده؛ داده‌ها، reward engine، نام اپ، workflow، تصویر پروفایل، منابع، بانک اطلاعات و کلید امضا حفظ شده‌اند |
| `python3 tools/check_upgrade.py` | PASS | آزمون داده‌محور schema 6→7؛ هیچ نسخه یا migration جدیدی به DB اضافه نشده |
| Kotlin parser probe بدون Compose/Android classpath | PASS FOR SYNTAX ONLY | خطاهای `expecting`/`unexpected tokens` مشاهده نشد؛ خطاهای `unresolved reference: androidx` طبیعی است و نباید به‌عنوان کامپایل موفق تعبیر شود |
| XML آیکن | PASS | توسط ابزار تست استاتیک |
| ZIP CRC و فهرست فایل‌های الزامی | PASS | پس از ساخت ZIP بررسی می‌شود |

## موارد تأییدنشده

- `./gradlew --offline --no-daemon :app:compileDebugKotlin` پیش از شروع کامپایل، هنگام دریافت توزیع Gradle 8.7 با `UnknownHostException: services.gradle.org` متوقف شد.
- در این محیط Android SDK/Gradle کامل و رندر Compose دستگاه واقعی در دسترس نیست؛ **APK، تست Gradle و اسکرین‌شات واقعی 0.27.0 تأیید نشده است**.
- برای تأیید نهایی در محیط دارای JDK 17 + Android SDK 35: `./gradlew assembleDebug testDebugUnitTest` و سپس نصب APK و گرفتن تصویر هوم در عرض‌های 320، 360، 393 و 412dp، فونت درشت، حالت‌های 0 تا 3 جلسه و ناوبری ژستی/سه‌دکمه‌ای اجرا شود.
- اَسِت‌ها فقط با Compose Canvas به نمونه نزدیک شده‌اند؛ پیکسل‌به‌پیکسل با تصویر مرجع یکسان نیستند.
