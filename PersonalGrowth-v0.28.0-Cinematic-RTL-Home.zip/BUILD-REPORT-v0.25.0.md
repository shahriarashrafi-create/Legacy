# گزارش ساخت نسخه 0.25.0

- سورس پایه: `PersonalGrowth-v0.24.0-Home-Final.zip`
- پروژه: `com.shahriar.growth`؛ `versionCode = 25`، `versionName = 0.25.0`؛ شناسه و امضای نسخه قبلی حفظ شده‌اند.
- فایل‌های Kotlin ویرایش شده: `MainActivity.kt`, `RedesignedHome.kt`. سایر فایل‌های مدل و داده و اسکیمای Room بدون تغییر باقی‌اند.
- ابزار بررسی: `python3 tools/verify_home_v025.py` → PASS؛ تطابق فایل‌های منطق داده نسخه قبلی PASS؛ XML برداری موجود PASS؛ بودجه ارتفاع هوم برای 320–900dp در سناریوهای با/بدون جلسه PASS (فقط بررسی ریاضی، نه رندر).
- بررسی نحوی `kotlinc` با classpath ناقص انجام شد؛ خطای parsing مستقلی دیده نشد، اما unresolved referenceهای Compose/Android انتظار می‌رفتند. این بررسی جای کامپایل نیست.
- اجرای `./gradlew --offline --no-daemon :app:compileDebugKotlin` با خطای `UnknownHostException: services.gradle.org` برای دریافت توزیع Gradle 8.7 متوقف شد. **بیلد اندروید و APK تأیید نشده‌اند.**
- آزمایش بعدی: انتشار پروژه در GitHub Actions و اجرای `Build and Publish APK`، سپس مشاهده هوم روی گوشی واقعی، مخصوصاً نوارهای سیستم، متن طولانی و حالت فونت درشت.
