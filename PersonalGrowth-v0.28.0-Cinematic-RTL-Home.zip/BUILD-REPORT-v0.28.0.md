# وضعیت واقعی ساخت و اعتبارسنجی v0.28.0

## نتایج

| بررسی | نتیجه | جزئیات |
| --- | --- | --- |
| سورس UI و RTL | PASS (static) | چیدمان: اَسِت راست، دکمه چپ؛ جلسه: آیکن+روز یک خط، ساعت، عنوان مرکز |
| اَسِت Canvas مستقل | PASS (source) | کتاب مأموریت و مدال طلایی بدون افزودن عکس خارجی |
| شاخص XP | PASS (source) | `0/100 XP` زیر نوار؛ اندازه متن شاخص در کمبود عرض کوچک می‌شود |
| حفظ منطق و Room | PASS (SHA-256 comparison) | فایل‌های داده، محاسبات پاداش، schema=7 و امضا نسبت به ZIP قبلی تغییر نکردند |
| schema upgrade 6→7 | PASS (host tests) | `python3 tools/check_upgrade.py` |
| بررسی قرارداد UI و YAML Workflow | PASS | `python3 tools/verify_home_v028.py` |
| آزمون parser مستقل Kotlin | PARSE ONLY | علامت نحوی مستقل یافت نشد، اما بدون Compose/Android classpath خطاهای unresolved فراوان است |
| کامپایل واقعی Android | NOT VERIFIED | توزیع Gradle 8.7 در محیط قابل دانلود نیست: `java.net.UnknownHostException: services.gradle.org` |
| تست اجرای APK و رندر گوشی | NOT RUN | گوشی/SDK کامل در محیط موجود نیست |
| سلامت فایل ZIP | PASS | CRC و فهرست فایل‌ها پس از ساخت بررسی می‌شود |

## توصیه برای GitHub

1. ZIP نسخه 0.28 را به مخزن آپلود کن.
2. برای اعمال بهینه‌سازی صف و انتخاب ZIP جدید، فایل `.github/workflows/build-apk.yml` داخل ZIP را **در ریشه همان مسیر مخزن** به‌روزرسانی کن؛ آپلود ZIP به‌تنهایی Workflow را عوض نمی‌کند.
3. اگر اکشن قبل از دریافت Runner نارنجی (`Starting job...`) ماند، یعنی کامپایل حتی شروع نشده؛ کد برنامه را علت قطعی فرض نکن.
4. وقتی job شروع شد، Build logs را کنترل کن. موفقیت منوط به انجام Build واقعی GitHub است؛ قابل تضمین از اینجا نیست.
